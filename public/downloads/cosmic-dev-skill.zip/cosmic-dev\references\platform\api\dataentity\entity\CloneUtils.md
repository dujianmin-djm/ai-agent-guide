---
framework_version: "8.0.1"
api_class: "CloneUtils"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用数据包复制工具类时"
---

# CloneUtils API 说明

## 概述
数据包复制工具类。
主要功能：克隆当前实体数据成为一个新的实体对象、根据实体类型和实体数据克隆成为一个新的实。

## Import 路径
```java
import kd.bos.dataentity.entity.CloneUtils;
```

---

## 方法列表

### clone

**重载 1**

克隆当前实体数据成为一个新的实体对象

**方法签名：**
```java
public Object clone(IDataEntityBase dataEntity)
```

**参数说明：**
- `dataEntity`: `IDataEntityBase` — 实体数据包

**返回值：**
- `Object`: 新的实体对象，将当前的数据复制到了新的实体对象

---

**重载 2**

根据实体类型和实体数据克隆成为一个新的实体对象

**方法签名：**
```java
public Object clone(IDataEntityType dt, Object dataEntity)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `dataEntity`: `Object` — 实体数据包

**返回值：**
- `Object`: 新的实体对象

---
