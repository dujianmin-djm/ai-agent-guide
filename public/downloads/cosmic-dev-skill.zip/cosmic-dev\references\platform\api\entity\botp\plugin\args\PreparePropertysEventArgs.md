---
framework_version: "8.0.1"
api_class: "PreparePropertysEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用在读取下游目标单数据之前时"
---

# PreparePropertysEventArgs API 说明

## 概述
在读取下游目标单数据之前，触发此事件：用于添加需要加载的目标单字段。继承自 WriteBackEventArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.PreparePropertysEventArgs;
```

---

## 方法列表

### getFieldKeys

需要加载的目标单字段

**方法签名：**
```java
public List<String> getFieldKeys()
```

**返回值：**
- `List<String>`

---

### getMainType

目标单实体类型

**方法签名：**
```java
public BillEntityType getMainType()
```

**返回值：**
- `BillEntityType`

---
