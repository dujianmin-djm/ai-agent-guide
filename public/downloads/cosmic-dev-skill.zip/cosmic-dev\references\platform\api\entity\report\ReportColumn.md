---
framework_version: "8.0.1"
api_class: "ReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列表列信息时"
---

# ReportColumn API 说明

## 概述
报表列表列信息。继承自 AbstractReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：设置属性、读取属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.report.ReportColumn;
```

---

## 方法列表

### createBaseDataColumn

生成基础资料列

**方法签名：**
```java
public static ReportColumn createBaseDataColumn(String fieldKey, String entityId)
```

**参数说明：**
- `fieldKey`: `String` — 字段标识
- `entityId`: `String` — 基础资料实体

**返回值：**
- `ReportColumn`

---

### createBaseDataPropColumn

生成基础资料属性列

**方法签名：**
```java
public static ReportColumn createBaseDataPropColumn(String fieldKey, String refBasedataProp, String displayProp)
```

**参数说明：**
- `fieldKey`: `String` — 字段标识
- `refBasedataProp`: `String` — 引用的基础资料字段
- `displayProp`: `String` — 基础资料显示属性

**返回值：**
- `ReportColumn`

---

### createColumn

打包客户端报表列信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`: 返回客户端报表列信息

---

### createCurrencyColumn

生成币别列

**方法签名：**
```java
public static ReportColumn createCurrencyColumn(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String` — 字段标识

**返回值：**
- `ReportColumn`

---

### formatCell

**重载 1**

报表引出和合计无法支持缺省值，先不调用此方法
 报表列表字段支持缺省值

**方法签名：**
```java
public Object formatCell(DynamicObject rowData, Object value, NumberFormatProvider numberFormatProvider, DynamicProperty dynamicProperty)
```

**参数说明：**
- `rowData`: `DynamicObject`
- `value`: `Object`
- `numberFormatProvider`: `NumberFormatProvider`
- `dynamicProperty`: `DynamicProperty`

**返回值：**
- `Object`

---

**重载 2**

根据字段实体属性类型获取格式化值

**方法签名：**
```java
public Object formatCell(DynamicObject rowData, Object value, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject` — 行数据
- `value`: `Object` — 当前字段值
- `numberFormatProvider`: `NumberFormatProvider` — 格式化信息

**返回值：**
- `Object`

---

### getCheckBoxReportShowStyle

获取复选框风格

**方法签名：**
```java
public int getCheckBoxReportShowStyle()
```

**返回值：**
- `int`

---

### getCurrencyField

获取金额对应的币别字段

**方法签名：**
```java
public String getCurrencyField()
```

**返回值：**
- `String`

---

### getDateIndex

获取数据源字段

**方法签名：**
```java
public String getDateIndex()
```

**返回值：**
- `String`

---

### getDefValue

获取字段默认值

**方法签名：**
```java
public Object getDefValue()
```

**返回值：**
- `Object`

---

### getDisplayProp

获取基础资料显示属性

**方法签名：**
```java
public String getDisplayProp()
```

**返回值：**
- `String`

---

### getEntityId

获取基础资料实体ID

**方法签名：**
```java
public String getEntityId()
```

**返回值：**
- `String`

---

### getFieldKey

获取列标识

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`: 列标识

---

### getFieldProperty

获取列实体属性

**方法签名：**
```java
public DynamicProperty getFieldProperty()
```

**返回值：**
- `DynamicProperty`

---

### getFieldType

获取字段类型
 报表列字段类型用途列举：确定比较符；动态添加列，根据列定义反向生成实体属性；
 可选值范围在本类常量中有定义，基本固定：TYPE_TEXT, TYPE_DATE...
 增加新类型需要同步调整上述使用的代码。

**方法签名：**
```java
public String getFieldType()
```

**返回值：**
- `String`: 返回字段类型，如 ReportColumn.TYPE_TEXT 等

---

### getFmtInfo

获取格式化信息

**方法签名：**
```java
public int getFmtInfo(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject` — 行数据
- `numberFormatProvider`: `NumberFormatProvider` — 格式化信息

**返回值：**
- `int`

---

### getFormula

获取计算列公式

**方法签名：**
```java
public String getFormula()
```

**返回值：**
- `String`

---

### getMeasureUnitField

获取数量对应的计量单位字段

**方法签名：**
```java
public String getMeasureUnitField()
```

**返回值：**
- `String`

---

### getOTitleReport

获取（复选框）显示勾选时显示内容

**方法签名：**
```java
public String getOTitleReport()
```

**返回值：**
- `String`

---

### getOrgFuncs

获取组织职能id

**方法签名：**
```java
public String getOrgFuncs()
```

**返回值：**
- `String`

---

### getRefBasedataProp

获取引用的基础资料字段

**方法签名：**
```java
public String getRefBasedataProp()
```

**返回值：**
- `String`

---

### getScale

获取小数精度

**方法签名：**
```java
public int getScale()
```

**返回值：**
- `int`

---

### getStyle

获取列样式

**方法签名：**
```java
public ColumnStyle getStyle()
```

**返回值：**
- `ColumnStyle`

---

### getValue

获取单元格的值（从行数据包中取值并格式化）

**方法签名：**
```java
public Object getValue(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject` — 行数据
- `numberFormatProvider`: `NumberFormatProvider` — 格式化信息

**返回值：**
- `Object`: 返回单元格的值

---

### getWidth

获取列宽度

**方法签名：**
```java
public LocaleString getWidth()
```

**返回值：**
- `LocaleString`

---

### getXTitleReport

获取（复选框）显示不勾选时显示内容

**方法签名：**
```java
public String getXTitleReport()
```

**返回值：**
- `String`

---

### initNumberFormatProvider

被金额和数量引用的币别和计量单位精度取值

**方法签名：**
```java
public static NumberFormatProvider initNumberFormatProvider(DynamicObjectCollection datas, List<kd.ReportColumn> columns)
```

**参数说明：**
- `datas`: `DynamicObjectCollection`
- `columns`: `List<kd.ReportColumn>`

**返回值：**
- `NumberFormatProvider`

---

### isDesensitized

是否脱敏

**方法签名：**
```java
public boolean isDesensitized()
```

**返回值：**
- `boolean`

---

### isFreeze

获取冻结列

**方法签名：**
```java
public boolean isFreeze()
```

**返回值：**
- `boolean`

---

### isHide

获取是否隐藏列

**方法签名：**
```java
public boolean isHide()
```

**返回值：**
- `boolean`

---

### isHyperlink

获取是否显示为超链接

**方法签名：**
```java
public boolean isHyperlink()
```

**返回值：**
- `boolean`

---

### isNeedFormat

获取是否格式化显示

**方法签名：**
```java
public boolean isNeedFormat()
```

**返回值：**
- `boolean`

---

### isNoDisplayScaleZero

获取是否显示尾零

**方法签名：**
```java
public boolean isNoDisplayScaleZero()
```

**返回值：**
- `boolean`

---

### isPicture

获取是否是图片字段

**方法签名：**
```java
public boolean isPicture()
```

**返回值：**
- `boolean`

---

### isRefOrg

获取是否是组织字段或者是基础资料绑定的组织

**方法签名：**
```java
public boolean isRefOrg()
```

**返回值：**
- `boolean`

---

### isZeroShow

获取是否为零显示

**方法签名：**
```java
public boolean isZeroShow()
```

**返回值：**
- `boolean`

---

### setCheckBoxReportShowStyle

设置复选框风格

**方法签名：**
```java
public void setCheckBoxReportShowStyle(int checkBoxReportShowStyle)
```

**参数说明：**
- `checkBoxReportShowStyle`: `int` — 复选框风格

---

### setCurrencyField

设置金额对应的币别字段

**方法签名：**
```java
public void setCurrencyField(String currencyField)
```

**参数说明：**
- `currencyField`: `String` — 币别字段标识

---

### setDateIndex

设置数据源字段

**方法签名：**
```java
public void setDateIndex(String dateIndex)
```

**参数说明：**
- `dateIndex`: `String` — 数据源字段

---

### setDesensitized

设置字段是否需要脱敏展示

**方法签名：**
```java
public void setDesensitized(boolean desensitized)
```

**参数说明：**
- `desensitized`: `boolean` — 脱敏展示

---

### setDisplayProp

设置基础资料显示属性

**方法签名：**
```java
public void setDisplayProp(String displayProp)
```

**参数说明：**
- `displayProp`: `String` — 显示属性

---

### setEntityId

设置基础资料实体ID

**方法签名：**
```java
public void setEntityId(String entityId)
```

**参数说明：**
- `entityId`: `String` — 基础资料实体ID

---

### setFieldKey

设置列标识

**方法签名：**
```java
public void setFieldKey(String key)
```

**参数说明：**
- `key`: `String` — 列标识

---

### setFieldProperty

设置列实体属性

**方法签名：**
```java
public void setFieldProperty(DynamicProperty fieldProperty)
```

**参数说明：**
- `fieldProperty`: `DynamicProperty`

---

### setFieldType

设置字段类型

**方法签名：**
```java
public void setFieldType(String fieldType)
```

**参数说明：**
- `fieldType`: `String` — 字段类型

---

### setFormula

设置计算列公式

**方法签名：**
```java
public void setFormula(String formula)
```

**参数说明：**
- `formula`: `String` — 计算列公式

---

### setFreeze

设置冻结列

**方法签名：**
```java
public void setFreeze(boolean isFreeze)
```

**参数说明：**
- `isFreeze`: `boolean` — 冻结列

---

### setHide

设置是否隐藏列

**方法签名：**
```java
public void setHide(boolean isHide)
```

**参数说明：**
- `isHide`: `boolean` — 隐藏列

---

### setHyperlink

设置是否显示为超链接

**方法签名：**
```java
public void setHyperlink(boolean isHyperlink)
```

**参数说明：**
- `isHyperlink`: `boolean` — 显示为超链接

---

### setMeasureUnitField

设置数量对应的计量单位字段

**方法签名：**
```java
public void setMeasureUnitField(String measureUnitField)
```

**参数说明：**
- `measureUnitField`: `String` — 计量单位字段

---

### setNeedFormat

设置是否格式化显示

**方法签名：**
```java
public void setNeedFormat(boolean isNeedFormat)
```

**参数说明：**
- `isNeedFormat`: `boolean` — 格式化显示

---

### setNoDisplayScaleZero

设置是否显示尾零

**方法签名：**
```java
public void setNoDisplayScaleZero(boolean noDisplayScaleZero)
```

**参数说明：**
- `noDisplayScaleZero`: `boolean` — 不显示尾零

---

### setOTitleReport

设置（复选框）显示勾选时显示内容

**方法签名：**
```java
public void setOTitleReport(String oTitleReport)
```

**参数说明：**
- `oTitleReport`: `String` — 显示勾选时显示内容

---

### setOrgFuncs

设置组织职能id

**方法签名：**
```java
public void setOrgFuncs(String orgFuncs)
```

**参数说明：**
- `orgFuncs`: `String` — 组织职能id

---

### setPicture

设置是否是图片字段

**方法签名：**
```java
public void setPicture(boolean isPicture)
```

**参数说明：**
- `isPicture`: `boolean` — 图片类型

---

### setRefBasedataProp

设置引用的基础资料字段

**方法签名：**
```java
public void setRefBasedataProp(String refBasedataProp)
```

**参数说明：**
- `refBasedataProp`: `String` — 引用的基础资料字段

---

### setRefOrg

设置是否是组织字段或者是基础资料绑定的组织

**方法签名：**
```java
public void setRefOrg(boolean isRefOrg)
```

**参数说明：**
- `isRefOrg`: `boolean` — 组织字段

---

### setScale

设置小数精度

**方法签名：**
```java
public void setScale(int scale)
```

**参数说明：**
- `scale`: `int` — 精度

---

### setStyle

设置列样式

**方法签名：**
```java
public void setStyle(ColumnStyle style)
```

**参数说明：**
- `style`: `ColumnStyle` — 列样式

---

### setWidth

设置列宽度

**方法签名：**
```java
public void setWidth(LocaleString width)
```

**参数说明：**
- `width`: `LocaleString` — 宽度

---

### setXTitleReport

设置复选框）显示不勾选时显示内容

**方法签名：**
```java
public void setXTitleReport(String xTitleReport)
```

**参数说明：**
- `xTitleReport`: `String` — 显示不勾选时显示内容

---

### setZeroShow

设置为零显示

**方法签名：**
```java
public void setZeroShow(boolean zeroShow)
```

**参数说明：**
- `zeroShow`: `boolean` — 为零显示

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
