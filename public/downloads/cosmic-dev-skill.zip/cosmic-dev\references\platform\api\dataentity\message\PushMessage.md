---
framework_version: "8.0.1"
api_class: "PushMessage"
api_package: "kd.bos.dataentity.message"
when_to_use: "当你需要使用前端推送的消息类时"
---

# PushMessage API 说明

## 概述
前端推送的消息类。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.dataentity.message.PushMessage;
```

---

## 方法列表

### getBody

获取推送消息体

**方法签名：**
```java
public Object getBody()
```

**返回值：**
- `Object`: 推送消息体

---

### getCreateTime

获取推送消息生成时间

**方法签名：**
```java
public ZonedDateTime getCreateTime()
```

**返回值：**
- `ZonedDateTime`: 推送消息生成时间

---

### getFrom

获取消息来源

**方法签名：**
```java
public String getFrom()
```

**返回值：**
- `String`: 消息来源

---

### getId

获取对应推送消息的id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 对应推送消息的id值

---

### getProperties

获取推送消息属性

**方法签名：**
```java
public Map<String,String> getProperties()
```

**返回值：**
- `Map<String,String>`: 推送消息属性

---

### getRange

获取推送消息的范围（页面，会话，租户，全局）

**方法签名：**
```java
public PushMessageRange getRange()
```

**返回值：**
- `PushMessageRange`: PushMessageRange推送消息的范围

---

### getTo

获取消息去向（页面ID，会话ID，租户ID）

**方法签名：**
```java
public String getTo()
```

**返回值：**
- `String`: 消息去向

---

### getType

获取推送消息类型（表单指令，更新指令*）

**方法签名：**
```java
public PushMessageType getType()
```

**返回值：**
- `PushMessageType`: PushMessageType推送消息类型

---

### setBody

设置推送消息体

**方法签名：**
```java
public void setBody(Object body)
```

**参数说明：**
- `body`: `Object` — 推送消息体

---

### setCreateTime

设置推送消息生成时间

**方法签名：**
```java
public void setCreateTime(ZonedDateTime createTime)
```

**参数说明：**
- `createTime`: `ZonedDateTime` — 推送消息生成时间

---

### setFrom

设置消息来源

**方法签名：**
```java
public void setFrom(String from)
```

**参数说明：**
- `from`: `String` — 消息来源

---

### setId

设置对应推送消息的id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 对应推送消息的id

---

### setProperties

设置推送消息属性

**方法签名：**
```java
public void setProperties(Map<String,String> properties)
```

**参数说明：**
- `properties`: `Map<String,String>` — 推送消息属性

---

### setRange

设置推送消息的范围（页面，会话，租户，全局）

**方法签名：**
```java
public void setRange(PushMessageRange range)
```

**参数说明：**
- `range`: `PushMessageRange` — PushMessageRange推送消息的范围

---

### setTo

设置消息去向（页面ID，会话ID，租户ID）

**方法签名：**
```java
public void setTo(String to)
```

**参数说明：**
- `to`: `String` — 消息去向

---

### setType

设置推送消息类型（表单指令，更新指令*）

**方法签名：**
```java
public void setType(PushMessageType type)
```

**参数说明：**
- `type`: `PushMessageType` — PushMessageType推送消息类型

---

### toString

获取 对应推送消息的id、推送消息的范围、消息去向、推送消息体、推送消息类型值

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
