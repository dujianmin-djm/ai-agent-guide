---
framework_version: "8.0.1"
api_class: "AbstractConvertPlugIn"
api_package: "kd.bos.entity.botp.plugin"
when_to_use: "当你需要使用单据转换插件基类时"
---

# AbstractConvertPlugIn API 说明

## 概述
单据转换插件基类。实现 IConvertPlugIn。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.AbstractConvertPlugIn;
```

---

## 方法列表

### getOpType

{待补充}

**方法签名：**
```java
public ConvertOpType getOpType()
```

**返回值：**
- `ConvertOpType`

---

### getOption

{待补充}

**方法签名：**
```java
public OperateOption getOption()
```

**返回值：**
- `OperateOption`

---

### getRule

{待补充}

**方法签名：**
```java
public ConvertRuleElement getRule()
```

**返回值：**
- `ConvertRuleElement`

---

### getSrcMainType

{待补充}

**方法签名：**
```java
public BillEntityType getSrcMainType()
```

**返回值：**
- `BillEntityType`

---

### getTgtMainType

{待补充}

**方法签名：**
```java
public BillEntityType getTgtMainType()
```

**返回值：**
- `BillEntityType`

---

### setContext

{待补充}

**方法签名：**
```java
public void setContext(ConvertOpType opType, BillEntityType srcMainType, BillEntityType tgtMainType, ConvertRuleElement rule)
```

**参数说明：**
- `opType`: `ConvertOpType`
- `srcMainType`: `BillEntityType`
- `tgtMainType`: `BillEntityType`
- `rule`: `ConvertRuleElement`

---

### setOption

{待补充}

**方法签名：**
```java
public void setOption(OperateOption option)
```

**参数说明：**
- `option`: `OperateOption`

---
