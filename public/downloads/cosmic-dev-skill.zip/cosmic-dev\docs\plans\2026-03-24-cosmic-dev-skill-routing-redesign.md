# cosmic-dev Skill 路由重设计 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将路由规则精简为"薄规则 + 厚 SKILL.md"架构，在 SKILL.md 中建立 7 阶段 Vibecoding 流水线，同时修正旧版错误、清理残留文件。

**Architecture:** `.cursor/rules/cosmic-skill-routing.md` 只做触发层（alwaysApply 关键词快速映射 + 硬性防错），`cosmic-dev/SKILL.md` 扩展为全流水线编排中心（阶段跳转表 + 精确路由 + 技能执行原则 + Stage 6 插件开发详情）。

**Tech Stack:** Markdown 文档（Cursor SKILL.md / Rules），无代码变更。

**Spec:** `c:\Users\HP\workspace\cosmic\cosmic-dev\docs\specs\2026-03-24-cosmic-dev-skill-routing-redesign.md`

---

## 文件变更总览

| 操作 | 文件 |
|------|------|
| **重写** | `.cursor/rules/cosmic-skill-routing.md` |
| **重构** | `.cursor/skills/cosmic-dev/SKILL.md` |
| **删除** | `.cursor/skills/cosmic-dev/rules/cosmic-skill-routing.md` |

---

## Task 1：重写薄规则文件

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\rules\cosmic-skill-routing.md`（全量重写）

- [ ] **Step 1：备份旧内容（确认读取）**

  读取 `c:\Users\HP\workspace\cosmic\.cursor\rules\cosmic-skill-routing.md`，确认当前内容（80行旧版）。

- [ ] **Step 2：全量重写为新薄规则**

  将文件内容替换为以下内容（≤ 30 行）：

  ```markdown
  ---
  description: 苍穹标品/各业务线开发技能路由（触发层）
  alwaysApply: true
  ---

  # 苍穹技能路由

  收到苍穹开发相关指令时，**第一动作必须是：读取 cosmic-dev/SKILL.md**，再按其流水线阶段表执行。

  ## 快速阶段映射（关键词参考）

  | 关键词 | 阶段 |
  |--------|------|
  | 建单据 / 需求建模 / 建基础资料 / 主数据 / 元数据建模 / 一键建模 | Stage 3 元数据建模 |
  | 改单据 / 加字段 / 删字段 / 改必填 / 改类型 / 改字段名 / 修改元数据 | Stage 4 元数据修改 |
  | 生成PDM / 同步数据模型 / 建表脚本 / PDM同步 | Stage 5 PDM 生成 |
  | 写插件 / 生成插件 / 生成代码 / 业务逻辑 / 联动 / 校验 / 开发代码 | Stage 6 插件开发 |
  | 跑测试 / 验证元数据 / 测试建模 / 设计测试用例 / 查看测试结果 | Stage 7 单元测试 |
  | 重置环境 / RST ENV / rst env（大小写不敏感） | → 直接读 `cosmic-meta-api/modules/reset/SKILL.md` |

  ## 硬性防错（强制，无需读 SKILL.md 即生效）

  - **已有表单字段变更**：必须用 `modifyMeta`，**禁止** `buildMeta` 代替（会产生新 formId）
  - **含 formId 或"已有表单"语义**：强制路由到 Stage 4 元数据修改
  - **SKILL.md 未加载时**：禁止自创流程，必须先读技能再执行
  ```

- [ ] **Step 3：验证行数与格式**

  读取修改后的文件，确认：
  - 文件行数 ≤ 32 行
  - `alwaysApply: true` 存在
  - 阶段映射表含 **6 行数据行**（Stage 3/4/5/6/7 各一行 + 重置环境一行）
  - 3 条硬性防错规则完整
  - 不再出现 `cosmic-custom-control` 字样

---

## Task 2：重构 SKILL.md — Part A：更新 YAML description

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\SKILL.md`（YAML front matter 块，第 1-11 行）

- [ ] **Step 1：确认当前 YAML 内容**

  读取 SKILL.md 前 15 行，确认当前 description 仅覆盖插件开发场景。

- [ ] **Step 2：替换 YAML front matter**

  将 `---` 至 `---` 之间的内容替换为：

  ```yaml
  ---
  name: cosmic-dev
  description: >
    金蝶云苍穹（Kingdee Cloud Cosmic）标品开发 / 各业务线开发全流程助手。
    ALWAYS TRIGGER when 用户提到以下任一场景：
    元数据建模（建单据、建基础资料、主数据建模、创建元数据、一键建模）；
    元数据修改（加字段、删字段、改必填、改类型、改字段名、修改元数据）；
    PDM生成（数据模型同步、建表脚本、PDM同步）；
    插件开发（表单插件、操作插件、列表插件、工作流、调度任务、Java代码生成、写插件）；
    KWC 前端开发（React组件、前后端分离）；
    单元测试（验证元数据、测试建模、设计测试用例、查看测试结果）；
    苍穹 OpenAPI / 框架问题 / API 用法。
  ---
  ```

- [ ] **Step 3：验证**

  读取修改后 SKILL.md 前 20 行，确认 description 覆盖 7 类场景关键词，`name: cosmic-dev` 保留。

---

## Task 3：重构 SKILL.md — Part B：新增 Vibecoding 流水线节

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\SKILL.md`（在"轻量启动门"节之后插入新节）

- [ ] **Step 1：确认插入位置**

  读取 SKILL.md，找到以下唯一锚点行（当前约第 19 行）：
  ```
  > 字段完整性校验由子技能按需触发（元数据操作触发 Pre-flight Gate，代码生成仅需 `javaHome`）。
  ```
  确认该行之后紧跟 `**Cosmic DEV — 金蝶苍穹插件开发平台**` 欢迎信息。

  > **注意**：SKILL.md 中"轻量启动门"以**粗体行**呈现（非 `## 标题`），紧接 YAML 之后位于第 13–19 行区域。本 Task 不需要将其改为标题格式，保持原格式不变。

- [ ] **Step 2：在轻量启动门之后、欢迎信息之前插入流水线节**

  使用 StrReplace，将锚点行替换为「锚点行 + 新内容」（在锚点行之后追加）：

  在 `> 字段完整性校验由子技能按需触发...` 这行之后，紧接着插入：

  ```markdown

  ---

  ## Vibecoding 流水线

  金蝶云苍穹标品开发标准流水线（各阶段可独立进入，无需按顺序）：

  | 阶段 | 名称 | 关键词 | 执行路径 | 状态 |
  |------|------|--------|----------|------|
  | Stage 1 | 需求分析 | 需求分析/PRD/功能描述/用户故事 | `skills/requirements/SKILL.md` | 预留 |
  | Stage 2 | 架构设计 | 架构设计/模块划分/服务设计 | `skills/architecture/SKILL.md` | 预留 |
  | Stage 3 | 元数据建模 | 建单据/建基础资料/主数据/一键建模 | 读取 `skills/cosmic-meta-modeling/SKILL.md` | ✅ |
  | Stage 4 | 元数据修改 | 加字段/删字段/改必填/改类型/改字段名 | 读取 `skills/cosmic-meta-modifier/SKILL.md` | ✅ |
  | Stage 5 | PDM 生成 | 生成PDM/同步数据模型/建表脚本 | 从 context.md 获取 entityKey（可选）或手动提供 → `skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py` | ✅ |
  | Stage 6 | 插件开发 | 写插件/生成插件/业务逻辑/联动/校验 | 见下方「Stage 6 详情」节 | ✅ |
  | Stage 7 | 单元测试 | 跑测试/验证元数据/测试建模 | 读取 `skills/cosmic-meta-test/SKILL.md` | ✅ |

  ### 入口判断规则

  1. **关键词命中** → 直接跳入对应阶段，读取执行路径中的 SKILL.md（或执行脚本）
  2. **无法判断** → 展示上方阶段表，询问用户处于哪个阶段
  3. **阶段上下文传递**：如果 `SKILL_DIR/skills/cosmic-meta-api/runtime/context.md` 存在，可从中读取 entityKey / formId 加速后续阶段；Stage 5/6/7 不强制依赖此文件，各子技能自身已覆盖无 context.md 的场景
  4. **预留阶段触发时**：告知用户该阶段尚未实现，并引导：建模类意图（建单据/基础资料）→ Stage 3；开发类意图（插件/代码）→ Stage 6；无法判断 → 展示阶段表询问

  ```

- [ ] **Step 3：验证**

  读取 SKILL.md 约第 15-60 行，确认：
  - 流水线节位于轻量启动门之后
  - 7 行阶段表完整（含 2 个预留、5 个 ✅）
  - 4 条入口判断规则完整

---

## Task 4：重构 SKILL.md — Part C：新增技能执行原则节 + 重命名入口判断节

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\SKILL.md`（"项目目录"节之后，原"入口判断"节之前）

- [ ] **Step 1：确认当前"项目目录"和"入口判断"节的位置**

  读取 SKILL.md，找到 `## 项目目录` 和 `## 入口判断` 两个标题的行号。

- [ ] **Step 2：在"项目目录"节与"入口判断"节之间插入技能执行原则节**

  在 `## 入口判断` 行之前插入：

  ```markdown

  ## 技能执行原则

  一旦根据流水线阶段表选定某个技能，**第一动作必须是：读取该技能的 SKILL.md**，再按技能内规定的步骤执行。

  | 原则 | 说明 |
  |------|------|
  | **先读再做** | 先 `Read(技能/SKILL.md)`，再按 Step 0~N 执行；不凭记忆或直觉跳过读取 |
  | **不替技能造轮子** | 技能里已定义流程的，按现有 API/工具完成，不另写一次性脚本替代 |
  | **例外允许** | 仅当技能未覆盖该场景、技能内明确允许、或用户明确要求时，才可偏离技能流程 |

  ```

- [ ] **Step 3：将"入口判断"节重命名为"Stage 6 详情：插件开发"**

  将标题行 `## 入口判断` 改为：

  ```markdown
  ## Stage 6 详情：插件开发
  ```

  同时将紧跟其后的说明文字 `**当本技能被调用时，按以下规则判断执行路径：**` 改为：

  ```markdown
  **Stage 6 入口判断（本节仅适用于插件开发需求，其他阶段见上方流水线阶段表）：**
  ```

- [ ] **Step 4：验证**

  读取 SKILL.md，确认：
  - `## 技能执行原则` 节存在，含 3 行表格
  - `## Stage 6 详情：插件开发` 标题存在
  - 不再有孤立的 `## 入口判断` 标题
  - 原插件开发详情内容（5个路由规则 + 需求分析与路由等）完整保留

---

## Task 5：重构 SKILL.md — Part D：将"需求分析与路由"节重命名为 Stage 6 子节

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\SKILL.md`

- [ ] **Step 1：确认"需求分析与路由"节标题行**

  读取 SKILL.md，找到 `## 需求分析与路由` 标题所在行号。

- [ ] **Step 2：在该标题前加入层级标注**

  将 `## 需求分析与路由` 改为：

  ```markdown
  ### 需求分析与路由（Stage 6 核心流程）
  ```

  这样该节从二级标题降为三级，成为"Stage 6 详情"的子节，层级结构清晰。

- [ ] **Step 3：验证最终结构**

  读取完整 SKILL.md，确认文件节结构（按顺序）为：
  ```
  [YAML front matter]
  [轻量启动门 — 粗体段落，非标题]
  ## Vibecoding 流水线
  [欢迎信息 + 模式表]
  ## 全局配置
  ## 项目目录
  ## 技能执行原则
  ## Stage 6 详情：插件开发
  ### 需求分析与路由（Stage 6 核心流程）
  ## 错误恢复
  ```

  > 注意：轻量启动门无 `##` 标题，是粗体行，这是正确的格式，无需修改。

---

## Task 6：删除误写的残留文件

**Files:**
- Delete: `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\rules\cosmic-skill-routing.md`

- [ ] **Step 1：确认文件存在**

  读取 `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\rules\cosmic-skill-routing.md` 前 5 行，确认是上次误写的文件（含 `alwaysApply: true`）。

- [ ] **Step 2：删除文件**

  使用 Delete 工具删除该文件。

- [ ] **Step 3：确认目录状态**

  列出 `c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev\rules\` 目录内容，确认该文件已删除（目录可能为空或不存在）。

---

## Task 7：整体验证

- [ ] **Step 1：验证薄规则**

  读取 `.cursor/rules/cosmic-skill-routing.md`，确认：
  - `alwaysApply: true` 存在
  - 不含 `cosmic-custom-control` 字样
  - 阶段映射表含 **6 行数据行**（Stage 3/4/5/6/7 + 重置环境）
  - 含 3 条硬性防错规则

- [ ] **Step 2：验证 SKILL.md 结构完整性**

  读取完整 SKILL.md，确认：
  - description 含 7 类场景关键词
  - `## Vibecoding 流水线` 节存在（含 7 行阶段表）
  - `## 技能执行原则` 节存在
  - `## Stage 6 详情：插件开发` 节存在
  - `### 需求分析与路由` 为三级标题
  - `## 错误恢复` 节存在
  - 原插件开发详情内容（cosmic-gen 执行、Team 模式、前后端分离）完整

- [ ] **Step 3：确认残留文件已删除**

  确认 `.cursor/skills/cosmic-dev/rules/cosmic-skill-routing.md` 不存在。

- [ ] **Step 4：搜索旧术语**

  在两个修改的文件中搜索 `二开`、`cosmic-custom-control`，确认均不存在。
