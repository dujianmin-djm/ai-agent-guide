---
framework_version: "8.0.1"
api_class: "OperationContext"
api_package: "kd.bos.context"
when_to_use: "当你需要使用操作上下文时"
---

# OperationContext API 说明

## 概述
操作上下文，使用场景：日志log，审计audit，追踪apm。
主要功能：读取属性、设置属性、移除元素。

## Import 路径
```java
import kd.bos.context.OperationContext;
```

---

## 方法列表

### copy

操作上下文深拷贝

**方法签名：**
```java
public OperationContext copy()
```

**返回值：**
- `OperationContext`: 新的操作上下文对象

---

### get

获取操作上下文

**方法签名：**
```java
public static OperationContext get()
```

**返回值：**
- `OperationContext`: 操作上下文

---

### getAppId

获取操作上下文的应用编码

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用编码

---

### getFormId

获取操作上下文的表单id

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`: 表单id

---

### getFormName

获取操作上下文的表单名称

**方法签名：**
```java
public String getFormName()
```

**返回值：**
- `String`: 表单名称

---

### getOpKey

获取操作上下文的操作标识

**方法签名：**
```java
public String getOpKey()
```

**返回值：**
- `String`: 操作标识

---

### getOpMethod

获取操作上下文的操作方法

**方法签名：**
```java
public String getOpMethod()
```

**返回值：**
- `String`: 操作方法

---

### getTenantId

获取操作上下文的租户id

**方法签名：**
```java
public String getTenantId()
```

**返回值：**
- `String`: 租户id

---

### remove

移除当前线程的操作上下文

**方法签名：**
```java
public static void remove()
```

---

### set

设置操作上下文到当前线程

**方法签名：**
```java
public static void set(OperationContext context)
```

**参数说明：**
- `context`: `OperationContext` — 操作上下文

---

### setAppId

设置操作上下文的应用编码

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 应用编码

---

### setFormId

设置操作上下文的表单id

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 表单id

---

### setFormName

设置操作上下文的表单名称

**方法签名：**
```java
public void setFormName(String formName)
```

**参数说明：**
- `formName`: `String` — 表单名称

---

### setOpKey

设置操作上下文的操作标识

**方法签名：**
```java
public void setOpKey(String opKey)
```

**参数说明：**
- `opKey`: `String` — 操作标识

---

### setOpMethod

设置操作上下文的操作方法

**方法签名：**
```java
public void setOpMethod(String opMethod)
```

**参数说明：**
- `opMethod`: `String` — 操作方法

---

### setTenantId

设置操作上下文的租户id

**方法签名：**
```java
public void setTenantId(String tenantId)
```

**参数说明：**
- `tenantId`: `String` — 租户id

---
