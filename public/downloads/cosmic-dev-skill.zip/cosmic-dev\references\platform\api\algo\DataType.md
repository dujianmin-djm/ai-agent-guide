---
framework_version: "8.0.1"
api_class: "DataType"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用Algo内存数据库支持的数据类型时"
---

# DataType API 说明

## 概述
Algo内存数据库支持的数据类型。实现 Serializable。
主要功能：读取属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.algo.DataType;
```

---

## 方法列表

### acceptsType

判断是否预期的类型

**方法签名：**
```java
public abstract boolean acceptsType(DataType other)
```

**参数说明：**
- `other`: `DataType` — 被判断的类型

**返回值：**
- `boolean`: 是否预期的类型

---

### convertValue

**重载 1**

将值转为当前类型的值

**方法签名：**
```java
public Object convertValue(Object value)
```

**参数说明：**
- `value`: `Object` — 值

**返回值：**
- `Object`: 转为当前类型后的值

---

**重载 2**

将值进行指定类型转换

**方法签名：**
```java
public static Object convertValue(DataType dataType, Object value)
```

**参数说明：**
- `dataType`: `DataType` — Algo中的数据类型
- `value`: `Object` — 值

**返回值：**
- `Object`: 类型转换后的值

---

### createBigDecimalType

**重载 1**

TODO: if supported standalone BigDecimalType,
 dataType==DataType.BigDecimalType is illegal

**方法签名：**
```java
public static BigDecimalType createBigDecimalType(int precision)
```

**参数说明：**
- `precision`: `int` — 数值长度

**返回值：**
- `BigDecimalType`: BigDecimalType

---

**重载 2**

创建BigDecimal类型

**方法签名：**
```java
public static BigDecimalType createBigDecimalType(int precision, int scale)
```

**参数说明：**
- `precision`: `int` — 数值长度
- `scale`: `int` — 小数长度

**返回值：**
- `BigDecimalType`: BigDecimalType

---

### equals

检查值是否是当前类型

**方法签名：**
```java
public boolean equals(Object x)
```

**参数说明：**
- `x`: `Object`

**返回值：**
- `boolean`

---

### fromSqlType

将sql类型转为DataType

**方法签名：**
```java
public static DataType fromSqlType(int sqlType)
```

**参数说明：**
- `sqlType`: `int` — sql中类型的索引值

**返回值：**
- `DataType`: Algo中的数据类型

---

### getJavaType

返回对应的Java对象类型

**方法签名：**
```java
public abstract Class<?> getJavaType()
```

**返回值：**
- `Class<?>`: Java对象类型

---

### getName

返回类型名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 类型名称

---

### getSql

返回类型名称

**方法签名：**
```java
public String getSql()
```

**返回值：**
- `String`: 类型名称

---

### getSqlType

返回对应的数据库类型

**方法签名：**
```java
public abstract int getSqlType()
```

**返回值：**
- `int`: 数据库类型

---

### isAbstract

对应的java类型Class是否是抽象的

**方法签名：**
```java
public boolean isAbstract()
```

**返回值：**
- `boolean`

---

### toSqlType

将DataType转为sql类型

**方法签名：**
```java
public static int toSqlType(DataType dataType)
```

**参数说明：**
- `dataType`: `DataType` — Algo中的数据类型

**返回值：**
- `int`: Algo中的数据类型对应的sql中的类型的索引值

---

### toString

toString 返回类型名称

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 类型名称

---
