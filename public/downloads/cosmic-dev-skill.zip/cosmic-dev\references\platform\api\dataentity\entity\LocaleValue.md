---
framework_version: "8.0.1"
api_class: "LocaleValue"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用多语言记录类时"
---

# LocaleValue API 说明

## 概述
多语言记录类，注意在BOS的商业处理中使用了其派生类，而不是当前类。。实现 ILocaleValue, Map, Serializable, ILocaleResValue。
主要功能：读取属性、设置属性、状态判断、移除元素。

## Import 路径
```java
import kd.bos.dataentity.entity.LocaleValue;
```

---

## 方法列表

### clear

{待补充}

**方法签名：**
```java
public void clear()
```

---

### containsKey

{待补充}

**方法签名：**
```java
public boolean containsKey(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `boolean`

---

### containsValue

{待补充}

**方法签名：**
```java
public boolean containsValue(Object value)
```

**参数说明：**
- `value`: `Object`

**返回值：**
- `boolean`

---

### entrySet

{待补充}

**方法签名：**
```java
public Set<Map.Entry<String,T>> entrySet()
```

**返回值：**
- `Set<Map.Entry<String,T>>`

---

### equals

判断两个对象是否相等

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object` — 另外一个比较的对象

**返回值：**
- `boolean`: 如果另外一个对象也是LocaleValue且内部存储的数据相等，将返回true

---

### get

{待补充}

**方法签名：**
```java
public T get(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `T`

---

### getDefaultItem

{待补充}

**方法签名：**
```java
public T getDefaultItem()
```

**返回值：**
- `T`

---

### getItem

{待补充}

**方法签名：**
```java
public T getItem(String lcid)
```

**参数说明：**
- `lcid`: `String`

**返回值：**
- `T`

---

### getRawValue

直接取值

**方法签名：**
```java
public T getRawValue(String lcid)
```

**参数说明：**
- `lcid`: `String`

**返回值：**
- `T`

---

### getResName

{待补充}

**方法签名：**
```java
public String getResName()
```

**返回值：**
- `String`

---

### getResourceId

{待补充}

**方法签名：**
```java
public String getResourceId()
```

**返回值：**
- `String`

---

### getResourceProvider

{待补充}

**方法签名：**
```java
public IMetadataResourceProvider getResourceProvider()
```

**返回值：**
- `IMetadataResourceProvider`

---

### getSerializeResId

获取序列化时的resId   (对比 getResourceId 会包含术语标记)

**方法签名：**
```java
public String getSerializeResId()
```

**返回值：**
- `String`

---

### hashCode

返回重新计算的Hashcode值，他将所有的语言数据进行比对。

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`: 新的Hash值

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty()
```

**返回值：**
- `boolean`

---

### keySet

{待补充}

**方法签名：**
```java
public Set<String> keySet()
```

**返回值：**
- `Set<String>`

---

### put

{待补充}

**方法签名：**
```java
public T put(String key, T value)
```

**参数说明：**
- `key`: `String`
- `value`: `T`

**返回值：**
- `T`

---

### putAll

{待补充}

**方法签名：**
```java
public void putAll(Map<? extends String,? extends T> m)
```

**参数说明：**
- `m`: `Map<? extends String,? extends T>`

---

### remove

{待补充}

**方法签名：**
```java
public T remove(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `T`

---

### setItem

设置指定语言的值

**方法签名：**
```java
public final void setItem(String localeId, T value)
```

**参数说明：**
- `localeId`: `String` — 语言代码
- `value`: `T` — 值

---

### setResName

{待补充}

**方法签名：**
```java
public void setResName(String resName)
```

**参数说明：**
- `resName`: `String`

---

### setResourceId

{待补充}

**方法签名：**
```java
public void setResourceId(String resourceId)
```

**参数说明：**
- `resourceId`: `String`

---

### setResourceProvider

{待补充}

**方法签名：**
```java
public void setResourceProvider(IMetadataResourceProvider resourceProvider)
```

**参数说明：**
- `resourceProvider`: `IMetadataResourceProvider`

---

### setRuntimeRes

{待补充}

**方法签名：**
```java
public void setRuntimeRes(boolean use)
```

**参数说明：**
- `use`: `boolean`

---

### size

{待补充}

**方法签名：**
```java
public int size()
```

**返回值：**
- `int`

---

### values

{待补充}

**方法签名：**
```java
public Collection<T> values()
```

**返回值：**
- `Collection<T>`

---
