---
framework_version: "8.0.1"
api_class: "AttachmentPanelMapPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用附件面板映射策略时"
---

# AttachmentPanelMapPolicy API 说明

## 概述
附件面板映射策略。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.AttachmentPanelMapPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getItems

获取所有附件面板映射条目

**方法签名：**
```java
public List<kd.AttachmentPanelMapItem> getItems()
```

**返回值：**
- `List<kd.AttachmentPanelMapItem>`

---

### setItems

设置所有附件面板映射条目

**方法签名：**
```java
public void setItems(List<kd.AttachmentPanelMapItem> items)
```

**参数说明：**
- `items`: `List<kd.AttachmentPanelMapItem>`

---
