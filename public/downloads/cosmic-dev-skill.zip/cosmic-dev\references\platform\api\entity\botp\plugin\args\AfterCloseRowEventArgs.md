---
framework_version: "8.0.1"
api_class: "AfterCloseRowEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用对上游行进行了关闭状态填写后调用时"
---

# AfterCloseRowEventArgs API 说明

## 概述
对上游行进行了关闭状态填写后调用。继承自 WriteBackEventArgs。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterCloseRowEventArgs;
```

---

## 方法列表

### getRule

反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getSrcActiveRow

上游源单，关联主实体数据行

**方法签名：**
```java
public DynamicObject getSrcActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getSrcEntity

上游源单，关联主实体

**方法签名：**
```java
public EntityType getSrcEntity()
```

**返回值：**
- `EntityType`

---

### getSrcSubMainType

上游源单主实体，仅包含需要用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---

### getTargetActiveRow

下游目标单关联主实体，当前数据行；删除行时，这个属性可能没值

**方法签名：**
```java
public DynamicObject getTargetActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getTargetEntity

下游目标单关联主实体

**方法签名：**
```java
public EntityType getTargetEntity()
```

**返回值：**
- `EntityType`

---

### isCloseRow

是否达成行关闭条件

**方法签名：**
```java
public boolean isCloseRow()
```

**返回值：**
- `boolean`

---

### setCloseRow

设置中是否达成行关闭条件

**方法签名：**
```java
public void setCloseRow(boolean closeRow)
```

**参数说明：**
- `closeRow`: `boolean` — 是否达成行关闭条件

---
