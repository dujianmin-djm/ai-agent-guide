---
framework_version: "8.0.1"
api_class: "DLockInfo"
api_package: "kd.bos.dlock"
when_to_use: "当你需要使用分布式锁信息时"
---

# DLockInfo API 说明

## 概述
分布式锁信息。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dlock.DLockInfo;
```

---

## 方法列表

### getCreateTime

锁创建(申请到)的时间

**方法签名：**
```java
public Date getCreateTime()
```

**返回值：**
- `Date`

---

### getDesc

锁描述信息，值在创建时传入。

**方法签名：**
```java
public String getDesc()
```

**返回值：**
- `String`

---

### getInstance

持有锁的微服务节点名称

**方法签名：**
```java
public String getInstance()
```

**返回值：**
- `String`

---

### getInstanceThread

持有锁的线程名称

**方法签名：**
```java
public String getInstanceThread()
```

**返回值：**
- `String`

---

### getKey

锁key，值在创建时传入。

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getOwner

持有锁的会话ID(zk client session)

**方法签名：**
```java
public String getOwner()
```

**返回值：**
- `String`

---

### getStorePath

锁存储的路径(运维需要的信息)

**方法签名：**
```java
public String getStorePath()
```

**返回值：**
- `String`

---

### getWaitingLocks

获取锁的申请(等待)者数量

**方法签名：**
```java
public int getWaitingLocks()
```

**返回值：**
- `int`

---

### toString

锁的JSON格式信息

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
