---
framework_version: "8.0.1"
api_class: "InteractionContext"
api_package: "kd.bos.entity.operate.interaction"
when_to_use: "当你需要使用交互请求上下文对象时"
---

# InteractionContext API 说明

## 概述
交互请求上下文对象，包含交互提示内容、交互界面及显示参数等。实现 Serializable。
主要功能：读取属性、设置属性、添加元素、状态判断。

## Import 路径
```java
import kd.bos.entity.operate.interaction.InteractionContext;
```

---

## 方法列表

### addOperateInfo

添加一条交互提示

**方法签名：**
```java
public void addOperateInfo(OperateErrorInfo operateInfo)
```

**参数说明：**
- `operateInfo`: `OperateErrorInfo` — 操作信息

---

### getCustOperateInfos

获取如果不需要指定定制界面，可以直接通过此属性，指定需要显示的消息

**方法签名：**
```java
public List<kd.OperateErrorInfo> getCustOperateInfos()
```

**返回值：**
- `List<kd.OperateErrorInfo>`: 操作错误信息

---

### getCustShowFormId

获取指定显示的定制界面标识

**方法签名：**
```java
public String getCustShowFormId()
```

**返回值：**
- `String`: String

---

### getCustShowParameter

获取指定显示定制界面时，需要传入的界面参数

**方法签名：**
```java
public Map<String,String> getCustShowParameter()
```

**返回值：**
- `Map<String,String>`: 定制界面参数

---

### getSimpleMessage

获取简单交互信息(批量自定义消息时，此属性建议赋值，以便平台在批量操作时作简单提示)

**方法签名：**
```java
public String getSimpleMessage()
```

**返回值：**
- `String`: String

---

### isShowCustForm

是否指定了定制界面

**方法签名：**
```java
public boolean isShowCustForm()
```

**返回值：**
- `boolean`: 是否制定了定制界面

---

### setCustOperateInfos

设置如果不需要指定定制界面，可以直接通过此属性，设置指定需要显示的消息

**方法签名：**
```java
public void setCustOperateInfos(List<kd.OperateErrorInfo> custOperateInfos)
```

**参数说明：**
- `custOperateInfos`: `List<kd.OperateErrorInfo>` — 操作错误信息

---

### setCustShowFormId

设置指定显示的定制界面标识

**方法签名：**
```java
public void setCustShowFormId(String custShowFormId)
```

**参数说明：**
- `custShowFormId`: `String` — 自定义表单标识

---

### setCustShowParameter

设置指定显示定制界面时，需要传入的界面参数

**方法签名：**
```java
public void setCustShowParameter(Map<String,String> custShowParameter)
```

**参数说明：**
- `custShowParameter`: `Map<String,String>` — 界面参数

---

### setSimpleMessage

设置简单交互信息(批量自定义消息时，此属性建议赋值，以便平台在批量操作时作简单提示)

**方法签名：**
```java
public void setSimpleMessage(String simpleMessage)
```

**参数说明：**
- `simpleMessage`: `String` — 简单信息

---
