---
framework_version: "8.0.1"
api_class: "CharSequenceUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Operations on CharSequence that are时"
---

# CharSequenceUtils API 说明

## 概述
Operations on CharSequence that are。
主要功能：。

## Import 路径
```java
import kd.bos.dataentity.utils.CharSequenceUtils;
```

---

## 方法列表

### subSequence

Returns a new ` CharSequence` that is a subsequence of this
 sequence starting with the ` char` value at the specified index.

**方法签名：**
```java
public static CharSequence subSequence(CharSequence cs, int start)
```

**参数说明：**
- `cs`: `CharSequence` — the specified subsequence, null returns null
- `start`: `int` — the start index, inclusive, valid

**返回值：**
- `CharSequence`: a new subsequence, may be null

---
