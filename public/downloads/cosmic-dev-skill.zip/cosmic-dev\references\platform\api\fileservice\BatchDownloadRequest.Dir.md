---
framework_version: "8.0.1"
api_class: "BatchDownloadRequest.Dir"
api_package: "kd.bos.fileservice.BatchDownloadRequest"
when_to_use: "当你需要使用表示压缩包内的虚拟目录结构（支持多级嵌套）时"
---

# BatchDownloadRequest.Dir API 说明

## 概述
表示压缩包内的虚拟目录结构（支持多级嵌套）。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.fileservice.BatchDownloadRequest.BatchDownloadRequest.Dir;
```

---

## 方法列表

### getDirs

getter方法，子目录列表

**方法签名：**
```java
public BatchDownloadRequest.Dir[] getDirs()
```

**返回值：**
- `BatchDownloadRequest.Dir[]`

---

### getFiles

getter方法，当前目录下的直接文件集合

**方法签名：**
```java
public BatchDownloadRequest.File[] getFiles()
```

**返回值：**
- `BatchDownloadRequest.File[]`

---

### getName

getter方法，当前目录名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### setDirs

setter方法，子目录列表

**方法签名：**
```java
public void setDirs(BatchDownloadRequest.Dir[] dirs)
```

**参数说明：**
- `dirs`: `BatchDownloadRequest.Dir[]`

---

### setFiles

setter方法，当前目录下的直接文件集合

**方法签名：**
```java
public void setFiles(BatchDownloadRequest.File[] files)
```

**参数说明：**
- `files`: `BatchDownloadRequest.File[]`

---
