---
framework_version: "8.0.1"
api_class: "FilterPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用分录数据筛选策略时"
---

# FilterPolicy API 说明

## 概述
分录数据筛选策略。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.FilterPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getAdvCondition

启用高级条件

**方法签名：**
```java
public Boolean getAdvCondition()
```

**返回值：**
- `Boolean`

---

### getCondition

条件对象

**方法签名：**
```java
public CRCondition getCondition()
```

**返回值：**
- `CRCondition`

---

### getConditionList

条件对象

**方法签名：**
```java
public List<kd.CRCondition> getConditionList()
```

**返回值：**
- `List<kd.CRCondition>`

---
