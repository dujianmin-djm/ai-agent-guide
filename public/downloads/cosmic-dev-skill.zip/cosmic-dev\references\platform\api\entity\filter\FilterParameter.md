---
framework_version: "8.0.1"
api_class: "FilterParameter"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤参数时"
---

# FilterParameter API 说明

## 概述
过滤参数。实现 Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.FilterParameter;
```

---

## 方法列表

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### endInit

反序列化结束，把专用于序列化的QFilterDto集合，转为QFilter集合

**方法签名：**
```java
public void endInit()
```

---

### getConvertFieldsMap

获取转换字段

**方法签名：**
```java
public Map<String,String> getConvertFieldsMap()
```

**返回值：**
- `Map<String,String>`

---

### getFilters

{待补充}

**方法签名：**
```java
public List<kd.QFilterDto> getFilters()
```

**返回值：**
- `List<kd.QFilterDto>`

---

### getOrderBy

{待补充}

**方法签名：**
```java
public String getOrderBy()
```

**返回值：**
- `String`: 排序

---

### getOrgQFilter

{待补充}

**方法签名：**
```java
public QFilter getOrgQFilter()
```

**返回值：**
- `QFilter`: 获取Filter

---

### getParam

获取sqlParameter

**方法签名：**
```java
public List<SqlParameter> getParam()
```

**返回值：**
- `List<SqlParameter>`

---

### getQFilter

{待补充}

**方法签名：**
```java
public String getQFilter()
```

**返回值：**
- `String`: 序列化之后的过滤条件

---

### getQFilters

获取过滤条件

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getSelectEntity

获取选择实体

**方法签名：**
```java
public String getSelectEntity()
```

**返回值：**
- `String`

---

### getSelectFields

获取选择字段

**方法签名：**
```java
public List<String> getSelectFields()
```

**返回值：**
- `List<String>`

---

### getSelectFieldsWithNotCompare

获取选择字段

**方法签名：**
```java
public List<String> getSelectFieldsWithNotCompare()
```

**返回值：**
- `List<String>`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### mergeFilter

合并过滤条件

**方法签名：**
```java
public void mergeFilter(FilterParameter filter)
```

**参数说明：**
- `filter`: `FilterParameter`

---

### setConvertFieldsMap

设置转换字段

**方法签名：**
```java
public void setConvertFieldsMap(Map<String,String> convertFieldsMap)
```

**参数说明：**
- `convertFieldsMap`: `Map<String,String>`

---

### setFilter

{待补充}

**方法签名：**
```java
public void setFilter(QFilter qFilter)
```

**参数说明：**
- `qFilter`: `QFilter`

---

### setFilters

{待补充}

**方法签名：**
```java
public void setFilters(List<kd.QFilterDto> filters)
```

**参数说明：**
- `filters`: `List<kd.QFilterDto>`

---

### setOrderBy

{待补充}

**方法签名：**
```java
public void setOrderBy(String orderBy)
```

**参数说明：**
- `orderBy`: `String` — 排序字段

---

### setParam

设置sqlParameter

**方法签名：**
```java
public void setParam(List<SqlParameter> param)
```

**参数说明：**
- `param`: `List<SqlParameter>`

---

### setQFilter

{待补充}

**方法签名：**
```java
public void setQFilter(String qFilter)
```

**参数说明：**
- `qFilter`: `String`

---

### setQFilters

设置过滤条件

**方法签名：**
```java
public void setQFilters(List<QFilter> qFilters)
```

**参数说明：**
- `qFilters`: `List<QFilter>`

---

### setSelectEntity

设置选择实体

**方法签名：**
```java
public void setSelectEntity(String selectEntity)
```

**参数说明：**
- `selectEntity`: `String`

---

### setSelectFields

设置选择字段

**方法签名：**
```java
public void setSelectFields(List<String> selectFields)
```

**参数说明：**
- `selectFields`: `List<String>`

---

### setSelectFieldsWithNotCompare

设置选择字段

**方法签名：**
```java
public void setSelectFieldsWithNotCompare(List<String> selectFieldsWithNotCompare)
```

**参数说明：**
- `selectFieldsWithNotCompare`: `List<String>`

---
