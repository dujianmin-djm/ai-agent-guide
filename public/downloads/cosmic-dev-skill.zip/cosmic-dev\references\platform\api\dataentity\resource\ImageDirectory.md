---
framework_version: "8.0.1"
api_class: "ImageDirectory"
api_package: "kd.bos.dataentity.resource"
when_to_use: "当你需要使用图形目录枚举类时"
---

# ImageDirectory API 说明

## 概述
图形目录枚举类。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.resource.ImageDirectory;
```

---

## 方法列表

### forValue

获取图形目录枚举值

**方法签名：**
```java
public static ImageDirectory forValue(int value)
```

**参数说明：**
- `value`: `int` — 来源值

**返回值：**
- `ImageDirectory`: ImageDirectory 图形目录枚举值

---

### getValue

获取图形目录来源值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
