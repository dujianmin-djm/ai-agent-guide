---
framework_version: "8.0.1"
api_class: "BillCloseType"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用源单关闭方式时"
---

# BillCloseType API 说明

## 概述
源单关闭方式。实现 Comparable, Serializable。
主要功能：根据value获取源单关闭方式。

## Import 路径
```java
import kd.bos.entity.botp.BillCloseType;
```

---

## 方法列表

### valueOf

根据value获取源单关闭方式

**方法签名：**
```java
public static BillCloseType valueOf(int value)
```

**参数说明：**
- `value`: `int`

**返回值：**
- `BillCloseType`

---
