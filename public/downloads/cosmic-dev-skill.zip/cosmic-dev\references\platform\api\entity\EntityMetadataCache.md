---
framework_version: "8.0.1"
api_class: "EntityMetadataCache"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用实体元数据缓存服务类,用于获取实体元数据的各种元素信息时"
---

# EntityMetadataCache API 说明

## 概述
实体元数据缓存服务类,用于获取实体元数据的各种元素信息。
主要功能：读取属性、查询数据、移除元素、设置属性。

## Import 路径
```java
import kd.bos.entity.EntityMetadataCache;
```

---

## 方法列表

### getAppInfo

根据应用id获取应用信息

**方法签名：**
```java
public static AppInfo getAppInfo(String appId)
```

**参数说明：**
- `appId`: `String` — 应用id

**返回值：**
- `AppInfo`: 应用信息

---

### getAppNumberById

根据应用id获取应用编码

**方法签名：**
```java
public static String getAppNumberById(String appId)
```

**参数说明：**
- `appId`: `String` — 应用id

**返回值：**
- `String`: 字符串

---

### getBaseDataFieldFilterMeta

返回过滤元数据

**方法签名：**
```java
public static FilterCondition getBaseDataFieldFilterMeta(String formId, String key)
```

**参数说明：**
- `formId`: `String` — 表单标识
- `key`: `String` — 基础资料字段

**返回值：**
- `FilterCondition`: 返回过滤元数据

---

### getBizAppNumber

根据实体编码获取应用编码

**方法签名：**
```java
public static String getBizAppNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体类型

**返回值：**
- `String`

---

### getBizAppNumbers

根据实体number取应用

**方法签名：**
```java
public static String[] getBizAppNumbers(String[] entityNumbers)
```

**参数说明：**
- `entityNumbers`: `String[]`

**返回值：**
- `String[]`

---

### getCtLinkSet

单据关联配置

**方法签名：**
```java
public static CtLinkSetElement getCtLinkSet(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `CtLinkSetElement`

---

### getDataEntityNetCtrlOperate

网络控制元数据

**方法签名：**
```java
public static Map<String,List<Map<String,Object>>> getDataEntityNetCtrlOperate(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `Map<String,List<Map<String,Object>>>`: 网络控制元数据

---

### getDataEntityOperate

**重载 1**

获取操作元数据

**方法签名：**
```java
public static Map<String,Object> getDataEntityOperate(String entityNumber, String operKey)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识
- `operKey`: `String` — 操作标识

**返回值：**
- `Map<String,Object>`: 操作元数据

---

**重载 2**

返回实体操作元数据

**方法签名：**
```java
public static List<Map<String,Object>> getDataEntityOperate(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识

**返回值：**
- `List<Map<String,Object>>`: 实体操作元数据

---

### getDataEntityOperations

**重载 1**

获取实体操作元数据

**方法签名：**
```java
public static Operations getDataEntityOperations(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `Operations`: 操作

---

**重载 2**

获取指定实体的所有操作信息

**方法签名：**
```java
public static Map<String,List<Map<String,Object>>> getDataEntityOperations(Collection<String> entityNumbers)
```

**参数说明：**
- `entityNumbers`: `Collection<String>` — 实体编码

**返回值：**
- `Map<String,List<Map<String,Object>>>`

---

### getDataEntityType

**重载 1**

返回实体元数据

**方法签名：**
```java
public static MainEntityType getDataEntityType(String number)
```

**参数说明：**
- `number`: `String` — 实体标识

**返回值：**
- `MainEntityType`: MainEntityType 实体元数据

---

**重载 2**

返回实体元数据

**方法签名：**
```java
public static MainEntityType getDataEntityType(URL url)
```

**参数说明：**
- `url`: `URL` — 实体标识

**返回值：**
- `MainEntityType`: 实体元数据

---

### getDataEntityTypeById

获取实体元数据

**方法签名：**
```java
public static MainEntityType getDataEntityTypeById(String entityId)
```

**参数说明：**
- `entityId`: `String` — 实体id

**返回值：**
- `MainEntityType`: 主实体

---

### getDataEntityTypeNoCache

获取实时实体元数据（不带缓存）

**方法签名：**
```java
public static MainEntityType getDataEntityTypeNoCache(String number)
```

**参数说明：**
- `number`: `String` — 编码

**返回值：**
- `MainEntityType`: 数据实体类型

---

### getEnabledControlsMap

获取锁定字段控件Map对象

**方法签名：**
```java
public static Map<String,List<String>> getEnabledControlsMap(String formId)
```

**参数说明：**
- `formId`: `String` — 表单编码

**返回值：**
- `Map<String,List<String>>`

---

### getFeatureEnabledEntity

支持某特性的所有字段key

**方法签名：**
```java
public static Set<String> getFeatureEnabledEntity(String entityNumber, String featureName)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识
- `featureName`: `String` — 功能控制项名称

**返回值：**
- `Set<String>`: 某特性的所有字段key

---

### getGenExtPlugins

获取表单绑定的通用扩展点插件

**方法签名：**
```java
public static List<Map<String,Object>> getGenExtPlugins(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 表单标识

**返回值：**
- `List<Map<String,Object>>`: 通用扩展点插件集合

---

### getLinkSet

单据关联配置

**方法签名：**
```java
public static LinkSetElement getLinkSet(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `LinkSetElement`

---

### getPermissionControlType

获取权限控制类型

**方法签名：**
```java
public static PermissionControlType getPermissionControlType(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `PermissionControlType`: 权限控制类型

---

### getPermissionItems

权限项

**方法签名：**
```java
public static Set<String> getPermissionItems(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `Set<String>`: 指定表单的全部权限项集合

---

### getPluginScripts

返回插件脚本

**方法签名：**
```java
public static String getPluginScripts(String key)
```

**参数说明：**
- `key`: `String` — 实体标识

**返回值：**
- `String`: 插件脚本

---

### getPrincipalRelation

组织委托关系列表

**方法签名：**
```java
public static Map<String,OrgRelationConfig> getPrincipalRelation(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `Map<String,OrgRelationConfig>`: 网络控制元数据

---

### getProvider

获取实体元数据provider

**方法签名：**
```java
public static IEntityMetaDataProvider getProvider()
```

**返回值：**
- `IEntityMetaDataProvider`

---

### getRuntimeMetadataVersion

获取运行时元数据版本号

**方法签名：**
```java
public static String getRuntimeMetadataVersion(String number)
```

**参数说明：**
- `number`: `String` — 编码

**返回值：**
- `String`: 版本

---

### getSubDataEntityType

根据属性列表构造实体

**方法签名：**
```java
public static DynamicObjectType getSubDataEntityType(String entityNumber, Collection<String> properties)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识
- `properties`: `Collection<String>` — 实体属性列表

**返回值：**
- `DynamicObjectType`: 构造好的实体

---

### loadMainTableDefine

根据实体编码加载单据实体表格定义

**方法签名：**
```java
public static TableDefine loadMainTableDefine(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `TableDefine`

---

### loadTableDefine

**重载 1**

根据实体编码、实体标识加载单据实体表格定义

**方法签名：**
```java
public static TableDefine loadTableDefine(String entityNumber, String entityKey)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `entityKey`: `String` — 实体标识

**返回值：**
- `TableDefine`

---

**重载 2**

根据实体表格id或者实体表格

**方法签名：**
```java
public static TableDefine loadTableDefine(Long tableId)
```

**参数说明：**
- `tableId`: `Long`

**返回值：**
- `TableDefine`

---

### putBizAppNumber

设置实体应用编码

**方法签名：**
```java
public static void putBizAppNumber(String entityNumber, String bizAppNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `bizAppNumber`: `String` — 应用编码

---

### removeDataEntityTypeLocalCache

**重载 1**

根据实体编码移除实体本地缓存

**方法签名：**
```java
public static void removeDataEntityTypeLocalCache(String number)
```

**参数说明：**
- `number`: `String` — 编码

---

**重载 2**

根据应用分组、实体编码移除实体本地缓存

**方法签名：**
```java
public static void removeDataEntityTypeLocalCache(String appGroup, String number)
```

**参数说明：**
- `appGroup`: `String` — 应用集群组
- `number`: `String` — 编码

---

### setProvider

设置实体元数据provider

**方法签名：**
```java
public static void setProvider(IEntityMetaDataProvider pro)
```

**参数说明：**
- `pro`: `IEntityMetaDataProvider`

---
