---
framework_version: "8.0.1"
api_class: "CodeRuleEntryInfo"
api_package: "kd.bos.coderule.api"
when_to_use: "当你需要使用编码规则编码段分录信息对象时"
---

# CodeRuleEntryInfo API 说明

## 概述
编码规则编码段分录信息对象。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.coderule.api.CodeRuleEntryInfo;
```

---

## 方法列表

### getAddchar

获取使用模式为属性截断长度不够的补位符号

**方法签名：**
```java
public String getAddchar()
```

**返回值：**
- `String`: 补位符号

---

### getAddstyle

获取使用模式为属性截断长度不够的补位方式

**方法签名：**
```java
public Boolean getAddstyle()
```

**返回值：**
- `Boolean`: true：右侧补位；false：左侧补位

---

### getAttributeType

获取编码段类型
 常量 ：1；业务对象日期：2；业务对象字段：8；系统日期：9；随机码：10；流水号：16；校验码：128
 具体参考枚举类：`CodeRuleEntryTypeEnum`

**方法签名：**
```java
public String getAttributeType()
```

**返回值：**
- `String`: 编码段类型

---

### getCodeRuleInfo

获取当前编码段所在的编码规则信息

**方法签名：**
```java
public CodeRuleInfo getCodeRuleInfo()
```

**返回值：**
- `CodeRuleInfo`: 编码规则信息

---

### getCutstyle

获取使用模式为属性截断的截取方式

**方法签名：**
```java
public Boolean getCutstyle()
```

**返回值：**
- `Boolean`: true：从右向左截；false：从左向右截

---

### getEntryid

获取编码段分录内码

**方法签名：**
```java
public String getEntryid()
```

**返回值：**
- `String`: 分录内码

---

### getFormat

获取显示格式，仅适用于业务对象日期编码段

**方法签名：**
```java
public String getFormat()
```

**返回值：**
- `String`: 显示格式，如：yyyyMM

---

### getInitial

获取流水号起始值

**方法签名：**
```java
public long getInitial()
```

**返回值：**
- `long`: 流水号起始值

---

### getIsSortItem

获取当前编码段是否设置为依据

**方法签名：**
```java
public Boolean getIsSortItem()
```

**返回值：**
- `Boolean`: true：当前编码段是依据；false：当前编码段不是依据

---

### getIsSplitSign

获取是否有段间分隔符

**方法签名：**
```java
public Boolean getIsSplitSign()
```

**返回值：**
- `Boolean`: true：有段间分隔符；false：没有段间分隔符

---

### getLength

获取流水号长度

**方法签名：**
```java
public int getLength()
```

**返回值：**
- `int`: 流水号长度

---

### getSeq

获取编码段序号

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`: 编码段序号

---

### getSplitSign

获取段间分隔符

**方法签名：**
```java
public String getSplitSign()
```

**返回值：**
- `String`: 段间分隔符

---

### getStep

获取流水号步长

**方法签名：**
```java
public long getStep()
```

**返回值：**
- `long`: 流水号步长

---

### getValueAtribute

获取编码来源字段标识

**方法签名：**
```java
public String getValueAtribute()
```

**返回值：**
- `String`: 字段标识

---

### getVisable

获取当前编码段是否显示

**方法签名：**
```java
public boolean getVisable()
```

**返回值：**
- `boolean`: true：显示；false：不显示

---

### setAddchar

设置使用模式为属性截断长度不够的补位符号

**方法签名：**
```java
public void setAddchar(String addchar)
```

**参数说明：**
- `addchar`: `String` — 补位符号

---

### setAddstyle

设置使用模式为属性截断长度不够的补位方式

**方法签名：**
```java
public void setAddstyle(Boolean addstyle)
```

**参数说明：**
- `addstyle`: `Boolean` — true：右侧补位；false：左侧补位

---

### setAttributeType

设置编码段类型
 常量 ：1；业务对象日期：2；业务对象字段：8；系统日期：9；随机码：10；流水号：16；校验码：128
 具体参考枚举类：`CodeRuleEntryTypeEnum`

**方法签名：**
```java
public void setAttributeType(String attributeType)
```

**参数说明：**
- `attributeType`: `String` — 编码段类型

---

### setCodeRuleInfo

设置当前编码段所在的编码规则信息

**方法签名：**
```java
public void setCodeRuleInfo(CodeRuleInfo codeRuleInfo)
```

**参数说明：**
- `codeRuleInfo`: `CodeRuleInfo` — 编码规则信息

---

### setCutstyle

设置使用模式为属性截断的截取方式

**方法签名：**
```java
public void setCutstyle(Boolean cutstyle)
```

**参数说明：**
- `cutstyle`: `Boolean` — true：从右向左截；false：从左向右截

---

### setEntryid

设置编码段分录内码

**方法签名：**
```java
public void setEntryid(String entryid)
```

**参数说明：**
- `entryid`: `String` — 分录内码

---

### setFormat

设置显示格式，仅适用于业务对象日期编码段

**方法签名：**
```java
public void setFormat(String format)
```

**参数说明：**
- `format`: `String` — 显示格式，如：yyyyMM

---

### setInitial

设置流水号起始值

**方法签名：**
```java
public void setInitial(long initial)
```

**参数说明：**
- `initial`: `long` — 流水号起始值

---

### setIsSortItem

设置当前编码段是否设置为依据

**方法签名：**
```java
public void setIsSortItem(Boolean isSortItem)
```

**参数说明：**
- `isSortItem`: `Boolean` — true：当前编码段是依据；false：当前编码段不是依据

---

### setIsSplitSign

设置是否有段间分隔符

**方法签名：**
```java
public void setIsSplitSign(Boolean isSplitSign)
```

**参数说明：**
- `isSplitSign`: `Boolean` — true：有段间分隔符；false：没有段间分隔符

---

### setLength

设置流水号长度

**方法签名：**
```java
public void setLength(int length)
```

**参数说明：**
- `length`: `int` — 流水号长度

---

### setSeq

设置编码段序号

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int` — 编码段序号

---

### setSplitSign

设置段间分隔符

**方法签名：**
```java
public void setSplitSign(String splitSign)
```

**参数说明：**
- `splitSign`: `String` — 段间分隔符

---

### setStep

设置流水号步长

**方法签名：**
```java
public void setStep(long step)
```

**参数说明：**
- `step`: `long` — 流水号步长

---

### setValueAtribute

设置获取编码来源字段标识

**方法签名：**
```java
public void setValueAtribute(String valueAtribute)
```

**参数说明：**
- `valueAtribute`: `String` — 字段标识

---

### setVisable

设置当前编码段是否显示

**方法签名：**
```java
public void setVisable(boolean isVisable)
```

**参数说明：**
- `isVisable`: `boolean` — true：显示；false：不显示

---
