---
framework_version: "8.0.1"
api_class: "LocaleString"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用多语言文本字段值对象时"
---

# LocaleString API 说明

## 概述
多语言文本字段值对象。继承自 LocaleValue，实现 ILocaleString, Serializable, ILocaleValue, Map, ILocaleResValue。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.entity.LocaleString;
```

---

## 方法列表

### entrySet

{待补充}

**方法签名：**
```java
public Set<Map.Entry<String,String>> entrySet()
```

**返回值：**
- `Set<Map.Entry<String,String>>`

---

### fromMap

根据map对象转换成多语言文本字段值对象

**方法签名：**
```java
public static LocaleString fromMap(Map<String,String> values)
```

**参数说明：**
- `values`: `Map<String,String>` — map对象

**返回值：**
- `LocaleString`

---

### getLocaleValue

获取多语言值

**方法签名：**
```java
public String getLocaleValue()
```

**返回值：**
- `String`

---

### keySet

{待补充}

**方法签名：**
```java
public Set<String> keySet()
```

**返回值：**
- `Set<String>`

---

### toString

重载toString方法

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---

### values

{待补充}

**方法签名：**
```java
public Collection<String> values()
```

**返回值：**
- `Collection<String>`

---
