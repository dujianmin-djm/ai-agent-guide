---
framework_version: "8.0.1"
api_class: "ICodeRuleService"
api_package: "kd.bos.coderule.api"
when_to_use: "当你需要使用编码规则服务接口时"
---

# ICodeRuleService API 说明

## 概述
编码规则服务接口。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.coderule.api.ICodeRuleService;
```

---

## 方法列表

### getAllCodeRuleByEntity

获取指定实体的全部启用状态的编码规则。

**方法签名：**
```java
public List<kd.CodeRuleInfo> getAllCodeRuleByEntity(String entityID)
```

**参数说明：**
- `entityID`: `String` — 实体标识

**返回值：**
- `List<kd.CodeRuleInfo>`: 指定实体的全部启用状态的编码规则。

---

### getBatchNumber

批量生成编号，会根据指定实体，动态对象信息和受控组织ID，生成编号。

**方法签名：**
```java
public String[] getBatchNumber(String entityId, DynamicObject dataInfo, String orgID, int count)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject` — 数据对象（单据或基础资料，对象上需要具有生成编码的所需信息）
- `orgID`: `String` — 受控组织ID，如果没有配置受控组织，传null即可
- `count`: `int` — 批量生成编号的个数

**返回值：**
- `String[]`: String[] 编码规则生成的批量编号

---

### getCodeRule

获取编码规则配置信息

**方法签名：**
```java
public CodeRuleInfo getCodeRule(String entityId, DynamicObject dataInfo, String orgID)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject` — 数据对象集合（单据或基础资料，对象上需要具有编码规则配置的所需信息）
- `orgID`: `String` — 受控组织ID，如果没有配置受控组织，传null即可

**返回值：**
- `CodeRuleInfo`

---

### getNumber

生成编号
 会根据指定实体，动态对象信息和受控组织ID，生成编号。
 调用后最大号会加1，或者消耗断号记录（当前编码规则流水号段开启“断号补偿”时，才会消耗断号表的记录）

**方法签名：**
```java
public String getNumber(String entityId, DynamicObject dataInfo, String orgId)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject` — 数据对象（单据或基础资料，对象上需要具有生成编码的所需信息）
- `orgId`: `String` — 受控组织id，为空时默认取动态对象的主业务组织，主业务组织为空时默认取当前用户的组织

**返回值：**
- `String`: 编号

---

### readNumber

预读编号
 根据指定实体，动态对象信息和受控组织ID，生成编号。调用后最大号不变，断号记录也不会被消耗。

**方法签名：**
```java
public String readNumber(String entityId, DynamicObject dataInfo, String orgId)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject` — 数据对象（单据或基础资料，对象上需要具有生成编码的所需信息）
- `orgId`: `String` — 受控组织ID，如果没有配置受控组织，传null即可

**返回值：**
- `String`: 编号

---

### recycleBatchNumber

批量回收断号，当删除编号时，可以调用此方法保存断号

**方法签名：**
```java
public boolean[] recycleBatchNumber(String entityId, DynamicObject[] dataInfo, String orgID, String[] numbers)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject[]` — 数据对象集合（单据或基础资料，对象上需要具有回收编码的所需信息）
                 数据对象集合的顺序要和待回收编号集合numbers顺序一致
- `orgID`: `String` — 受控组织ID，如果没有配置受控组织，传null即可
- `numbers`: `String[]` — 待回收的编号集合

**返回值：**
- `boolean[]`: 是否成功

---

### recycleNumber

回收断号，当删除编号时，可以调用此方法保存断号

**方法签名：**
```java
public boolean recycleNumber(String entityId, DynamicObject dataInfo, String orgID, String number)
```

**参数说明：**
- `entityId`: `String` — 实体编码
- `dataInfo`: `DynamicObject` — 数据对象（单据或基础资料，对象上需要具有回收编码的所需信息）
- `orgID`: `String` — 受控组织ID，如果没有配置受控组织，传null即可
- `number`: `String` — 待回收的编号

**返回值：**
- `boolean`: 是否成功

---
