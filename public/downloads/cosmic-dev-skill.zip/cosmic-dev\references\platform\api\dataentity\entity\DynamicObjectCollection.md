---
framework_version: "8.0.1"
api_class: "DynamicObjectCollection"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用动态实体对象集合时"
---

# DynamicObjectCollection API 说明

## 概述
动态实体对象集合，承载DynamicObject的默认集合。继承自 DataEntityCollection，实现 Serializable, ISupportInitialize, List, RandomAccess, Cloneable。
主要功能：读取属性、添加元素、移除元素、设置属性。

## Import 路径
```java
import kd.bos.dataentity.entity.DynamicObjectCollection;
```

---

## 方法列表

### add

把动态实体对象插入到集合index索引的位置上

**方法签名：**
```java
public void add(int index, DynamicObject item)
```

**参数说明：**
- `index`: `int` — 从零开始的索引，应在index位置插入动态实体对象
- `item`: `DynamicObject` — 动态实体对象

---

### addAll

{待补充}

**方法签名：**
```java
public boolean addAll(Collection<? extends DynamicObject> c)
```

**参数说明：**
- `c`: `Collection<? extends DynamicObject>`

**返回值：**
- `boolean`

---

### addNew

创建一个新的的动态实体对象

**方法签名：**
```java
public DynamicObject addNew()
```

**返回值：**
- `DynamicObject`

---

### clear

清除集合数据

**方法签名：**
```java
public void clear()
```

---

### fetchEntryRows

**重载 1**

取当前页的分录数据

**方法签名：**
```java
public void fetchEntryRows(int pageIndex)
```

**参数说明：**
- `pageIndex`: `int` — 当前页数

---

**重载 2**

以起始行号开始，获取每页大小数据量的分录数据

**方法签名：**
```java
public void fetchEntryRows(int stratRowIndex, int pageSize)
```

**参数说明：**
- `stratRowIndex`: `int` — 起始行号
- `pageSize`: `int` — 每页大小

---

### getDeleteRows

获取被删除的行

**方法签名：**
```java
public final List<kd.DynamicObject> getDeleteRows()
```

**返回值：**
- `List<kd.DynamicObject>`: 返回被删除的行

---

### getDynamicCollectionItemPropertyType

请改用#getDynamicObjectType。

**方法签名：**
```java
public final DynamicObjectType getDynamicCollectionItemPropertyType()
```

**返回值：**
- `DynamicObjectType`

---

### getDynamicObjectType

返回集合属性的元素数据类型

**方法签名：**
```java
public final DynamicObjectType getDynamicObjectType()
```

**返回值：**
- `DynamicObjectType`

---

### getInsertRows

获取插入的行

**方法签名：**
```java
public final List<kd.DynamicObject> getInsertRows()
```

**返回值：**
- `List<kd.DynamicObject>`: 返回插入的行

---

### getPageCount

获取总页数

**方法签名：**
```java
public int getPageCount()
```

**返回值：**
- `int`: 总页数

---

### getPageIndex

获取分页索引

**方法签名：**
```java
public int getPageIndex()
```

**返回值：**
- `int`

---

### getPageSize

获取每页大小

**方法签名：**
```java
public int getPageSize()
```

**返回值：**
- `int`

---

### getRootEntity

获取主实体对象

**方法签名：**
```java
public DynamicObject getRootEntity()
```

**返回值：**
- `DynamicObject`

---

### getRootEntityType

获取主实体对象类型

**方法签名：**
```java
public DynamicObjectType getRootEntityType()
```

**返回值：**
- `DynamicObjectType`

---

### getRowCount

获取设置分页情况下总行数

**方法签名：**
```java
public int getRowCount()
```

**返回值：**
- `int`

---

### getStartRowIndex

获取当前页起始索引号，下标从零开始

**方法签名：**
```java
public int getStartRowIndex()
```

**返回值：**
- `int`

---

### getUpdateRows

获取被修改的行

**方法签名：**
```java
public final List<kd.DynamicObject> getUpdateRows()
```

**返回值：**
- `List<kd.DynamicObject>`: 返回被修改的行

---

### remove

**重载 1**

从集合中移除序号为index的元素

**方法签名：**
```java
public DynamicObject remove(int index)
```

**参数说明：**
- `index`: `int` — 要移除的元素的从零开始的索引

**返回值：**
- `DynamicObject`

---

**重载 2**

从集合中移除数据

**方法签名：**
```java
public boolean remove(Object obj)
```

**参数说明：**
- `obj`: `Object` — 动态对象数据

**返回值：**
- `boolean`

---

### setRowCount

设置分页情况下总行数

**方法签名：**
```java
public void setRowCount(int rowCount)
```

**参数说明：**
- `rowCount`: `int`

---

### setStartRowIndex

设置当前页起始索引号，下标从零开始

**方法签名：**
```java
public void setStartRowIndex(int rowIndex)
```

**参数说明：**
- `rowIndex`: `int`

---
