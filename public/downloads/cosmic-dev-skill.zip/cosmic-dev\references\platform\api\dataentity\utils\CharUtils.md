---
framework_version: "8.0.1"
api_class: "CharUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Operations on char primitives and Character objects.时"
---

# CharUtils API 说明

## 概述
Operations on char primitives and Character objects.。
主要功能：状态判断。

## Import 路径
```java
import kd.bos.dataentity.utils.CharUtils;
```

---

## 方法列表

### compare

Compares two ` char` values numerically. This is the same functionality as provided in Java 7.

**方法签名：**
```java
public static int compare(char x, char y)
```

**参数说明：**
- `x`: `char` — the first ` char` to compare
- `y`: `char` — the second ` char` to compare

**返回值：**
- `int`: the value ` 0` if ` x == y`;
         a value less than ` 0` if ` x  y`

---

### isAscii

Checks whether the character is ASCII 7 bit.

**方法签名：**
```java
public static boolean isAscii(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if less than 128

---

### isAsciiAlpha

Checks whether the character is ASCII 7 bit alphabetic.

**方法签名：**
```java
public static boolean isAsciiAlpha(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 65 and 90 or 97 and 122 inclusive

---

### isAsciiAlphaLower

Checks whether the character is ASCII 7 bit alphabetic lower case.

**方法签名：**
```java
public static boolean isAsciiAlphaLower(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 97 and 122 inclusive

---

### isAsciiAlphaUpper

Checks whether the character is ASCII 7 bit alphabetic upper case.

**方法签名：**
```java
public static boolean isAsciiAlphaUpper(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 65 and 90 inclusive

---

### isAsciiAlphanumeric

Checks whether the character is ASCII 7 bit numeric.

**方法签名：**
```java
public static boolean isAsciiAlphanumeric(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 48 and 57 or 65 and 90 or 97 and 122 inclusive

---

### isAsciiControl

Checks whether the character is ASCII 7 bit control.

**方法签名：**
```java
public static boolean isAsciiControl(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if less than 32 or equals 127

---

### isAsciiNumeric

Checks whether the character is ASCII 7 bit numeric.

**方法签名：**
```java
public static boolean isAsciiNumeric(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 48 and 57 inclusive

---

### isAsciiPrintable

Checks whether the character is ASCII 7 bit printable.

**方法签名：**
```java
public static boolean isAsciiPrintable(char ch)
```

**参数说明：**
- `ch`: `char` — the character to check

**返回值：**
- `boolean`: true if between 32 and 126 inclusive

---

### toChar

**重载 1**

Converts the Character to a char throwing an exception for ` null`.
 
 
   CharUtils.toChar(' ')  = ' '
   CharUtils.toChar('A')  = 'A'
   CharUtils.toChar(null) throws IllegalArgumentException

**方法签名：**
```java
public static char toChar(Character ch)
```

**参数说明：**
- `ch`: `Character` — the character to convert

**返回值：**
- `char`: the char value of the Character

---

**重载 2**

Converts the Character to a char handling ` null`.
 
 
   CharUtils.toChar(null, 'X') = 'X'
   CharUtils.toChar(' ', 'X')  = ' '
   CharUtils.toChar('A', 'X')  = 'A'

**方法签名：**
```java
public static char toChar(Character ch, char defaultValue)
```

**参数说明：**
- `ch`: `Character` — the character to convert
- `defaultValue`: `char` — the value to use if the  Character is null

**返回值：**
- `char`: the char value of the Character or the default if null

---

**重载 3**

Converts the String to a char using the first character, throwing
 an exception on empty Strings.
 
 
   CharUtils.toChar("A")  = 'A'
   CharUtils.toChar("BA") = 'B'
   CharUtils.toChar(null) throws IllegalArgumentException
   CharUtils.toChar("")   throws IllegalArgumentException

**方法签名：**
```java
public static char toChar(String str)
```

**参数说明：**
- `str`: `String` — the character to convert

**返回值：**
- `char`: the char value of the first letter of the String

---

**重载 4**

Converts the String to a char using the first character, defaulting
 the value on empty Strings.
 
 
   CharUtils.toChar(null, 'X') = 'X'
   CharUtils.toChar("", 'X')   = 'X'
   CharUtils.toChar("A", 'X')  = 'A'
   CharUtils.toChar("BA", 'X') = 'B'

**方法签名：**
```java
public static char toChar(String str, char defaultValue)
```

**参数说明：**
- `str`: `String` — the character to convert
- `defaultValue`: `char` — the value to use if the  Character is null

**返回值：**
- `char`: the char value of the first letter of the String or the default if null

---

### toCharacterObject

**重载 1**

Converts the character to a Character.
 
 For ASCII 7 bit characters, this uses a cache that will return the
 same Character object each time.

**方法签名：**
```java
public static Character toCharacterObject(char ch)
```

**参数说明：**
- `ch`: `char` — the character to convert

**返回值：**
- `Character`: a Character of the specified character

---

**重载 2**

Converts the String to a Character using the first character, returning
 null for empty Strings.
 
 For ASCII 7 bit characters, this uses a cache that will return the
 same Character object each time.
 
 
   CharUtils.toCharacterObject(null) = null
   CharUtils.toCharacterObject("")   = null
   CharUtils.toCharacterObject("A")  = 'A'
   CharUtils.toCharacterObject("BA") = 'B'

**方法签名：**
```java
public static Character toCharacterObject(String str)
```

**参数说明：**
- `str`: `String` — the character to convert

**返回值：**
- `Character`: the Character value of the first letter of the String

---

### toIntValue

**重载 1**

Converts the character to the Integer it represents, throwing an
 exception if the character is not numeric.
 
 This method coverts the char '1' to the int 1 and so on.

**方法签名：**
```java
public static int toIntValue(char ch)
```

**参数说明：**
- `ch`: `char` — the character to convert

**返回值：**
- `int`: the int value of the character

---

**重载 2**

Converts the character to the Integer it represents, throwing an
 exception if the character is not numeric.
 
 This method coverts the char '1' to the int 1 and so on.

**方法签名：**
```java
public static int toIntValue(char ch, int defaultValue)
```

**参数说明：**
- `ch`: `char` — the character to convert
- `defaultValue`: `int` — the default value to use if the character is not numeric

**返回值：**
- `int`: the int value of the character

---

**重载 3**

Converts the character to the Integer it represents, throwing an
 exception if the character is not numeric.
 
 This method coverts the char '1' to the int 1 and so on.

**方法签名：**
```java
public static int toIntValue(Character ch)
```

**参数说明：**
- `ch`: `Character` — the character to convert, not null

**返回值：**
- `int`: the int value of the character

---

**重载 4**

Converts the character to the Integer it represents, throwing an
 exception if the character is not numeric.
 
 This method coverts the char '1' to the int 1 and so on.

**方法签名：**
```java
public static int toIntValue(Character ch, int defaultValue)
```

**参数说明：**
- `ch`: `Character` — the character to convert
- `defaultValue`: `int` — the default value to use if the character is not numeric

**返回值：**
- `int`: the int value of the character

---

### toString

**重载 1**

Converts the character to a String that contains the one character.
 
 For ASCII 7 bit characters, this uses a cache that will return the
 same String object each time.

**方法签名：**
```java
public static String toString(char ch)
```

**参数说明：**
- `ch`: `char` — the character to convert

**返回值：**
- `String`: a String containing the one specified character

---

**重载 2**

Converts the character to a String that contains the one character.
 
 For ASCII 7 bit characters, this uses a cache that will return the
 same String object each time.
 
 If ` null` is passed in, ` null` will be returned.

**方法签名：**
```java
public static String toString(Character ch)
```

**参数说明：**
- `ch`: `Character` — the character to convert

**返回值：**
- `String`: a String containing the one specified character

---

### unicodeEscaped

**重载 1**

Converts the string to the Unicode format ' '.
 
 This format is the Java source code format.

**方法签名：**
```java
public static String unicodeEscaped(char ch)
```

**参数说明：**
- `ch`: `char` — the character to convert

**返回值：**
- `String`: the escaped Unicode string

---

**重载 2**

Converts the string to the Unicode format ' '.
 
 This format is the Java source code format.
 
 If ` null` is passed in, ` null` will be returned.

**方法签名：**
```java
public static String unicodeEscaped(Character ch)
```

**参数说明：**
- `ch`: `Character` — the character to convert, may be null

**返回值：**
- `String`: the escaped Unicode string, null if null input

---
