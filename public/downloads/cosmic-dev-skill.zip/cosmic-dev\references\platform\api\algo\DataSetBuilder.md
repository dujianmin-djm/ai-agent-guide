---
framework_version: "8.0.1"
api_class: "DataSetBuilder"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用此接口用来构建DataSet时"
---

# DataSetBuilder API 说明

## 概述
此接口用来构建DataSet，建议使用此接口，大量数据情况下，性能更优。。
主要功能：将当前数组数据添加到dataset中、将某个DataSet的行数据添加到当前d、生成dataset。

## Import 路径
```java
import kd.bos.algo.DataSetBuilder;
```

---

## 方法列表

### append

**重载 1**

将当前数组数据添加到dataset中

**方法签名：**
```java
public void append(Object[] values)
```

**参数说明：**
- `values`: `Object[]` — 数组数据

---

**重载 2**

将某个DataSet的行数据添加到当前dataset中

**方法签名：**
```java
public void append(Row row)
```

**参数说明：**
- `row`: `Row` — 数据行

---

### build

生成dataset

**方法签名：**
```java
public DataSet build()
```

**返回值：**
- `DataSet`: DataSet

---
