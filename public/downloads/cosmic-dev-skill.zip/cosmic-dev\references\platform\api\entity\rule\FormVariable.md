---
framework_version: "8.0.1"
api_class: "FormVariable"
api_package: "kd.bos.entity.rule"
when_to_use: "当你需要使用前端变量时"
---

# FormVariable API 说明

## 概述
前端变量。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.rule.FormVariable;
```

---

## 方法列表

### getNumber

获取前端变量编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### getType

获取前端变量类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### getValue

获取前端变量值

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`

---

### setNumber

设置前端变量编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---

### setType

设置前端变量类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---

### setValue

设置前端变量值

**方法签名：**
```java
public void setValue(Object value)
```

**参数说明：**
- `value`: `Object`

---
