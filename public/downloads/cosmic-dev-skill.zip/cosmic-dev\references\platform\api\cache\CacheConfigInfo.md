---
framework_version: "8.0.1"
api_class: "CacheConfigInfo"
api_package: "kd.bos.cache"
when_to_use: "当你需要使用本地缓存的配置信息载体时"
---

# CacheConfigInfo API 说明

## 概述
本地缓存的配置信息载体，用于定义缓存实例的行为策略。。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.cache.CacheConfigInfo;
```

---

## 方法列表

### getMaxItemSize

获取缓存允许的最大条目数量。

**方法签名：**
```java
public int getMaxItemSize()
```

**返回值：**
- `int`: ≥1 的整数，实际值可能根据系统属性调整

---

### getMaxMemSize

[已弃用] 获取最大堆内存限制（MB）。

**方法签名：**
```java
public int getMaxMemSize()
```

**返回值：**
- `int`

---

### getTimeout

获取当前配置的超时时间（秒）。

**方法签名：**
```java
public int getTimeout()
```

**返回值：**
- `int`: 正整数，必须 >0

---

### isTimeToLive

判断当前是否使用存活时间（TTL）策略。

**方法签名：**
```java
public boolean isTimeToLive()
```

**返回值：**
- `boolean`: true 表示基于创建时间过期，false 表示基于最后访问时间过期

---

### setMaxItemSize

设置最大条目数量限制。

**方法签名：**
```java
public void setMaxItemSize(int maxItemSize)
```

**参数说明：**
- `maxItemSize`: `int` — 必须 ≥1，建议值 ≥100 以避免频繁淘汰

---

### setMaxMemSize

[已弃用] 设置最大堆内存限制。设置后没有效果。

**方法签名：**
```java
public void setMaxMemSize(int maxMemSize)
```

**参数说明：**
- `maxMemSize`: `int`

---

### setTimeToLive

设置过期策略模式。

**方法签名：**
```java
public void setTimeToLive(boolean timeToLive)
```

**参数说明：**
- `timeToLive`: `boolean` — true=TTL模式，false=TTI模式

---

### setTimeout

设置缓存条目存活时间。

**方法签名：**
```java
public void setTimeout(int timeout)
```

**参数说明：**
- `timeout`: `int` — 超时时间（秒），必须 >0

---
