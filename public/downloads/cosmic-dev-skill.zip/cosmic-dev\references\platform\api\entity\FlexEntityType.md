---
framework_version: "8.0.1"
api_class: "FlexEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用弹性域主实体时"
---

# FlexEntityType API 说明

## 概述
弹性域主实体，内含弹性域各个维度。继承自 MainEntityType。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.FlexEntityType;
```

---

## 方法列表

### getFlexDataFormNumber

获取弹性域数据的表单编码

**方法签名：**
```java
public String getFlexDataFormNumber()
```

**返回值：**
- `String`: flexDataFormNumber 表单编码

---

### getFlexProperties

获取弹性域维度

**方法签名：**
```java
public List<kd.FlexProperty> getFlexProperties()
```

**返回值：**
- `List<kd.FlexProperty>`: flexProperties 弹性域维度

---

### getOrderProperties

获取排序后的弹性域维度

**方法签名：**
```java
public List<IDataEntityProperty> getOrderProperties()
```

**返回值：**
- `List<IDataEntityProperty>`: 排序后的弹性域维度

---

### getPermissionControlType

获取权限控制类型

**方法签名：**
```java
public synchronized PermissionControlType getPermissionControlType()
```

**返回值：**
- `PermissionControlType`: 获取权限控制类型

---

### hashCode

根据编码输出hashCode，以便在集合中，快速根据编码找到对应的数据项

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### putIndex

设置弹性域维度的索引顺序

**方法签名：**
```java
public void putIndex(String propName, int idx)
```

**参数说明：**
- `propName`: `String` — 维度属性
- `idx`: `int` — 索引号

---

### setFlexDataFormNumber

设置弹性域数据表单编码

**方法签名：**
```java
public void setFlexDataFormNumber(String flexDataFormNumber)
```

**参数说明：**
- `flexDataFormNumber`: `String` — 表单编码

---

### setFlexProperties

设置弹性域维度

**方法签名：**
```java
public void setFlexProperties(List<kd.FlexProperty> flexProperties)
```

**参数说明：**
- `flexProperties`: `List<kd.FlexProperty>` — 弹性域维度

---

### toString

根据维度名称格式化输出实例的信息

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
