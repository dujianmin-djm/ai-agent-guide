---
framework_version: "8.0.1"
api_class: "OrgRelationConfig"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用单据上组织字段之间的协作关系时"
---

# OrgRelationConfig API 说明

## 概述
单据上组织字段之间的协作关系。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgRelationConfig;
```

---

## 方法列表

### getDirect

获取协作方向

**方法签名：**
```java
public OrgRelationItemDirect getDirect()
```

**返回值：**
- `OrgRelationItemDirect`: 协作方向

---

### getId

获取内码，随机生成的唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 内码

---

### getPrincipal

获取委托组织（字段）

**方法签名：**
```java
public OrgRelationItemOrg getPrincipal()
```

**返回值：**
- `OrgRelationItemOrg`: 委托组织

---

### getTrustee

获取受托组织（字段）

**方法签名：**
```java
public OrgRelationItemOrg getTrustee()
```

**返回值：**
- `OrgRelationItemOrg`: 受托组织

---

### getType

获取业务协作类型

**方法签名：**
```java
public OrgRelationItemType getType()
```

**返回值：**
- `OrgRelationItemType`: 业务协作类型

---

### setDirect

设置协作方向

**方法签名：**
```java
public void setDirect(OrgRelationItemDirect direct)
```

**参数说明：**
- `direct`: `OrgRelationItemDirect` — 协作方向

---

### setId

设置内码

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 内码

---

### setPrincipal

设置委托组织（字段）

**方法签名：**
```java
public void setPrincipal(OrgRelationItemOrg principal)
```

**参数说明：**
- `principal`: `OrgRelationItemOrg` — 委托组织

---

### setTrustee

设置受托组织（字段）

**方法签名：**
```java
public void setTrustee(OrgRelationItemOrg trustee)
```

**参数说明：**
- `trustee`: `OrgRelationItemOrg` — 受托组织

---

### setType

设置业务协作类型

**方法签名：**
```java
public void setType(OrgRelationItemType type)
```

**参数说明：**
- `type`: `OrgRelationItemType` — 业务协作类型

---
