---
framework_version: "8.0.1"
api_class: "AlgoException"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用Algo异常信息时"
---

# AlgoException API 说明

## 概述
Algo异常信息。继承自 RuntimeException，实现 Serializable。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.algo.AlgoException;
```

---

## 方法列表

### create

**重载 1**

创建一个AlgoException

**方法签名：**
```java
public static AlgoException create(String message, Object[] args)
```

**参数说明：**
- `message`: `String` — 异常信息
- `args`: `Object[]` — 异常信息中的参数

**返回值：**
- `AlgoException`: AlgoException

---

**重载 2**

创建一个AlgoException

**方法签名：**
```java
public static AlgoException create(String message, Throwable cause, Object[] args)
```

**参数说明：**
- `message`: `String` — 异常信息
- `cause`: `Throwable` — 被包装的异常
- `args`: `Object[]` — 异常信息中的参数

**返回值：**
- `AlgoException`: AlgoException

---

### wrap

**重载 1**

将异常包装成AlgoException

**方法签名：**
```java
public static AlgoException wrap(Throwable cause)
```

**参数说明：**
- `cause`: `Throwable` — 被包装的异常

**返回值：**
- `AlgoException`: AlgoException

---

**重载 2**

将异常包装成AlgoException

**方法签名：**
```java
public static AlgoException wrap(Throwable cause, String message, Object[] args)
```

**参数说明：**
- `cause`: `Throwable` — 被包装的异常
- `message`: `String` — 异常信息
- `args`: `Object[]` — 异常信息中的占位参数

**返回值：**
- `AlgoException`: AlgoException

---
