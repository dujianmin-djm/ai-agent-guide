---
framework_version: "8.0.1"
api_class: "IntegerColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用整数格式化处理类时"
---

# IntegerColumnDesc API 说明

## 概述
整数格式化处理类。继承自 NumberColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.IntegerColumnDesc;
```

---

## 方法列表

### formatCell

{待补充}

**方法签名：**
```java
public Object formatCell(DynamicObject dr, Object value, boolean forExport)
```

**参数说明：**
- `dr`: `DynamicObject`
- `value`: `Object`
- `forExport`: `boolean`

**返回值：**
- `Object`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---
