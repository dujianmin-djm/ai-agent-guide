---
framework_version: "8.0.1"
api_class: "FlexProperty"
api_package: "kd.bos.entity.flex"
when_to_use: "当你需要使用弹性域维度定义时"
---

# FlexProperty API 说明

## 概述
弹性域维度定义。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.flex.FlexProperty;
```

---

## 方法列表

### getAssistantType

获取辅助资料类型

**方法签名：**
```java
public String getAssistantType()
```

**返回值：**
- `String`

---

### getBasedataValueCondition

获取基础资料值条件

**方法签名：**
```java
public String getBasedataValueCondition()
```

**返回值：**
- `String`

---

### getDataType

获取字段的数据类型

**方法签名：**
```java
public String getDataType()
```

**返回值：**
- `String`

---

### getDataTypeObject

获取字段的数据类型和值最大长度

**方法签名：**
```java
public Object getDataTypeObject()
```

**返回值：**
- `Object`

---

### getDatamaxlen

获取值最大长度

**方法签名：**
```java
public int getDatamaxlen()
```

**返回值：**
- `int`

---

### getDisplayProp

获取显示属性

**方法签名：**
```java
public String getDisplayProp()
```

**返回值：**
- `String`

---

### getDisplayStyle

获取显示样式类型，弹出或固定

**方法签名：**
```java
public FlexProperty.DisplayStyle getDisplayStyle()
```

**返回值：**
- `FlexProperty.DisplayStyle`

---

### getEnable

获取启用

**方法签名：**
```java
public String getEnable()
```

**返回值：**
- `String`

---

### getFlexBDValueCondition

获取基础资料过滤条件

**方法签名：**
```java
public FlexBDValueCondition getFlexBDValueCondition()
```

**返回值：**
- `FlexBDValueCondition`

---

### getFlexField

获取字段名

**方法签名：**
```java
public String getFlexField()
```

**返回值：**
- `String`

---

### getFlexId

获取弹性域类型，已废弃

**方法签名：**
```java
public int getFlexId()
```

**返回值：**
- `int`

---

### getFlexType

获取弹性域实体

**方法签名：**
```java
public FlexType getFlexType()
```

**返回值：**
- `FlexType`

---

### getFlexTypeId

获取弹性域类型

**方法签名：**
```java
public long getFlexTypeId()
```

**返回值：**
- `long`

---

### getGLName

获取弹性域属性名称（通用语言）

**方法签名：**
```java
public String getGLName()
```

**返回值：**
- `String`

---

### getId

{待补充}

**方法签名：**
```java
public long getId()
```

**返回值：**
- `long`: the id

---

### getIndex

获取属性的顺序

**方法签名：**
```java
public int getIndex()
```

**返回值：**
- `int`

---

### getName

获取弹性域属性名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getNumber

获取弹性域属性编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### getOrgFunc

获取组织职能id

**方法签名：**
```java
public long getOrgFunc()
```

**返回值：**
- `long`

---

### getOrgFuncNumber

获取组织职能编码

**方法签名：**
```java
public String getOrgFuncNumber()
```

**返回值：**
- `String`

---

### getPropId

获取维度ID

**方法签名：**
```java
public int getPropId()
```

**返回值：**
- `int`

---

### getStatus

获取状态

**方法签名：**
```java
public String getStatus()
```

**返回值：**
- `String`

---

### getValueSource

获取值来源 仅对基础资料和辅助资料类型有意义.基础资料的form

**方法签名：**
```java
public String getValueSource()
```

**返回值：**
- `String`

---

### getValueType

获取值类型

**方法签名：**
```java
public String getValueType()
```

**返回值：**
- `String`: 1：基础资料 2：辅助资料 3：文本

---

### setAssistantType

设置辅助资料类型

**方法签名：**
```java
public void setAssistantType(String assistantType)
```

**参数说明：**
- `assistantType`: `String`

---

### setBasedataValueCondition

设置基础资料值条件

**方法签名：**
```java
public void setBasedataValueCondition(String basedataValueCondition)
```

**参数说明：**
- `basedataValueCondition`: `String`

---

### setDataType

设置字段的数据类型

**方法签名：**
```java
public void setDataType(String dataType)
```

**参数说明：**
- `dataType`: `String`

---

### setDatamaxlen

设置值最大长度

**方法签名：**
```java
public void setDatamaxlen(int datamaxlen)
```

**参数说明：**
- `datamaxlen`: `int`

---

### setDisplayProp

设置显示属性

**方法签名：**
```java
public void setDisplayProp(String displayProp)
```

**参数说明：**
- `displayProp`: `String`

---

### setDisplayStyle

设置显示样式类型

**方法签名：**
```java
public void setDisplayStyle(FlexProperty.DisplayStyle displayStyle)
```

**参数说明：**
- `displayStyle`: `FlexProperty.DisplayStyle`

---

### setEnable

设置启用

**方法签名：**
```java
public void setEnable(String enable)
```

**参数说明：**
- `enable`: `String`

---

### setFlexField

设置字段名

**方法签名：**
```java
public void setFlexField(String flexField)
```

**参数说明：**
- `flexField`: `String`

---

### setFlexId

设置弹性域类型

**方法签名：**
```java
public void setFlexId(int flexId)
```

**参数说明：**
- `flexId`: `int`

---

### setFlexType

设置弹性域实体

**方法签名：**
```java
public void setFlexType(FlexType flexType)
```

**参数说明：**
- `flexType`: `FlexType`

---

### setFlexTypeId

设置弹性域类型

**方法签名：**
```java
public void setFlexTypeId(long flexTypeId)
```

**参数说明：**
- `flexTypeId`: `long`

---

### setGLName

设置弹性域属性名称（通用语言）

**方法签名：**
```java
public void setGLName(String glName)
```

**参数说明：**
- `glName`: `String`

---

### setId

{待补充}

**方法签名：**
```java
public void setId(long id)
```

**参数说明：**
- `id`: `long` — the id to set

---

### setIndex

设置属性的顺序

**方法签名：**
```java
public void setIndex(int index)
```

**参数说明：**
- `index`: `int`

---

### setName

设置弹性域属性名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setNumber

设置弹性域属性编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---

### setOrgFunc

设置组织职能id

**方法签名：**
```java
public void setOrgFunc(long orgFunc)
```

**参数说明：**
- `orgFunc`: `long`

---

### setOrgFuncNumber

设置组织职能编码

**方法签名：**
```java
public void setOrgFuncNumber(String orgFuncNumber)
```

**参数说明：**
- `orgFuncNumber`: `String`

---

### setPropId

设置维度ID

**方法签名：**
```java
public void setPropId(int propId)
```

**参数说明：**
- `propId`: `int`

---

### setStatus

设置状态

**方法签名：**
```java
public void setStatus(String status)
```

**参数说明：**
- `status`: `String`

---

### setValueSource

设置值来源 仅对基础资料和辅助资料类型有意义.基础资料的form

**方法签名：**
```java
public void setValueSource(String valueSource)
```

**参数说明：**
- `valueSource`: `String`

---

### setValueType

设置值类型

**方法签名：**
```java
public void setValueType(String valueType)
```

**参数说明：**
- `valueType`: `String` — 1：基础资料 2：辅助资料 3：文本

---
