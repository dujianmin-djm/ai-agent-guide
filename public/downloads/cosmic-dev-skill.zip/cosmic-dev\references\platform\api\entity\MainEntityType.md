---
framework_version: "8.0.1"
api_class: "MainEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用ORM实体描述时"
---

# MainEntityType API 说明

## 概述
ORM实体描述。继承自 EntityType。
主要功能：读取属性、设置属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.MainEntityType;
```

---

## 方法列表

### checkRefEntityVer

检查引用实体版本

**方法签名：**
```java
public boolean checkRefEntityVer()
```

**返回值：**
- `boolean`

---

### clearRefEntityTypeVer

开放对属性refEntityTypeVer 的清除

**方法签名：**
```java
public void clearRefEntityTypeVer()
```

---

### clearSubEntityTypecache

开放对属性subEntityTypecache的清除

**方法签名：**
```java
public void clearSubEntityTypecache()
```

---

### clone

clone

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createEntityTreeNodes

构造实体树

**方法签名：**
```java
public List<Map<String,Object>> createEntityTreeNodes(EntityTreeNode parentEntityTreeNode, boolean isIncludeEntry, boolean isAllNode)
```

**参数说明：**
- `parentEntityTreeNode`: `EntityTreeNode`
- `isIncludeEntry`: `boolean`
- `isAllNode`: `boolean`

**返回值：**
- `List<Map<String,Object>>`

---

### createPropIndexsNoCache

创建属性集合

**方法签名：**
```java
public synchronized void createPropIndexsNoCache()
```

---

### endInit

结束初始化

**方法签名：**
```java
public synchronized void endInit()
```

---

### getAllEntities

获取本对象的全部实体

**方法签名：**
```java
public Map<String,EntityType> getAllEntities()
```

**返回值：**
- `Map<String,EntityType>`: 本对象的全部实体

---

### getAllFields

获取全部字段清单，排除系统字段

**方法签名：**
```java
public Map<String,IDataEntityProperty> getAllFields()
```

**返回值：**
- `Map<String,IDataEntityProperty>`: 全部字段清单，排除系统字段

---

### getAppId

获取应用标识

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用标识

---

### getBOSVer

获取bos版本

**方法签名：**
```java
public String getBOSVer()
```

**返回值：**
- `String`

---

### getBizAppNumber

获取表单实体所属应用的原始编码

**方法签名：**
```java
public String getBizAppNumber()
```

**返回值：**
- `String`

---

### getCheckVersionTimeMillis

获取检查版本时间周期

**方法签名：**
```java
public long getCheckVersionTimeMillis()
```

**返回值：**
- `long`

---

### getInheritPath

获取继承路径

**方法签名：**
```java
public String getInheritPath()
```

**返回值：**
- `String`: 继承路径

---

### getMainOrg

获取主业务组织

**方法签名：**
```java
public String getMainOrg()
```

**返回值：**
- `String`: 主业务组织

---

### getPermissionControlType

获取权限控制
 无需序列化，在需要使用时单独读取

**方法签名：**
```java
public synchronized PermissionControlType getPermissionControlType()
```

**返回值：**
- `PermissionControlType`

---

### getPkList

主键集合

**方法签名：**
```java
public List<ISimpleProperty> getPkList()
```

**返回值：**
- `List<ISimpleProperty>`

---

### getRefPropTypes

引用属性类型

**方法签名：**
```java
public List<kd.RefPropType> getRefPropTypes()
```

**返回值：**
- `List<kd.RefPropType>`

---

### getUserOption

获取用户选项

**方法签名：**
```java
public String getUserOption()
```

**返回值：**
- `String`: 用户选项

---

### getVersion

获取元数据版本

**方法签名：**
```java
public String getVersion()
```

**返回值：**
- `String`: version 元数据版本

---

### getVersionControl

获取版本控制字段

**方法签名：**
```java
public String getVersionControl()
```

**返回值：**
- `String`

---

### isInheritFrom

是否从实体继承

**方法签名：**
```java
public boolean isInheritFrom(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String`

**返回值：**
- `boolean`

---

### setAppId

设置应用标识

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 用户标识

---

### setBOSVer

设置bos版本

**方法签名：**
```java
public void setBOSVer(String bosver)
```

**参数说明：**
- `bosver`: `String`

---

### setBizAppNumber

设置表单实体所属应用的原始编码

**方法签名：**
```java
public void setBizAppNumber(String bizAppNumber)
```

**参数说明：**
- `bizAppNumber`: `String`

---

### setCheckVersionTimeMillis

设置检查版本时间周期

**方法签名：**
```java
public void setCheckVersionTimeMillis(long checkVersionTimeMillis)
```

**参数说明：**
- `checkVersionTimeMillis`: `long`

---

### setInheritPath

设置继承路径

**方法签名：**
```java
public void setInheritPath(String inheritPath)
```

**参数说明：**
- `inheritPath`: `String` — 继承路径

---

### setMainOrg

设置主业务组织

**方法签名：**
```java
public void setMainOrg(String mainOrg)
```

**参数说明：**
- `mainOrg`: `String` — 主业务组织

---

### setPermissionControlType

设置权限控制

**方法签名：**
```java
public synchronized void setPermissionControlType(PermissionControlType permissionControlType)
```

**参数说明：**
- `permissionControlType`: `PermissionControlType`

---

### setUserOption

设置用户选项

**方法签名：**
```java
public void setUserOption(String userOption)
```

**参数说明：**
- `userOption`: `String` — 用户选项

---

### setVersion

设置元数据版本

**方法签名：**
```java
public void setVersion(String version)
```

**参数说明：**
- `version`: `String` — 元数据版本

---

### setVersionControl

设置版本控制字段

**方法签名：**
```java
public void setVersionControl(String versionControl)
```

**参数说明：**
- `versionControl`: `String`

---
