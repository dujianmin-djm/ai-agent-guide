---
framework_version: "8.0.1"
api_class: "DynamicObjectType"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用DynamicObjectType允许在运行时动态构建一个实体类型时"
---

# DynamicObjectType API 说明

## 概述
DynamicObjectType允许在运行时动态构建一个实体类型，而不需要在设计时预先定义好实体类型。。继承自 DynamicMetadata，实现 IDataEntityType, Serializable, Cloneable, IMetadata。
主要功能：读取属性、设置属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicObjectType;
```

---

## 方法列表

### Extract

从当前实体定义中提取一个精简版本

**方法签名：**
```java
public final DynamicObjectType Extract(ExtractOption option)
```

**参数说明：**
- `option`: `ExtractOption`

**返回值：**
- `DynamicObjectType`: 新提取出来的实体定义

---

### addProperty

向集合添加属性

**方法签名：**
```java
public void addProperty(DynamicProperty property)
```

**参数说明：**
- `property`: `DynamicProperty`

---

### checkUnmodifiable

{待补充}

**方法签名：**
```java
public void checkUnmodifiable()
```

---

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createHashCode

基于名称、扩展名称，生成本对象的hashCode

**方法签名：**
```java
public int createHashCode()
```

**返回值：**
- `int`

---

### createInstance

**重载 1**

使用当前类型创建一个动态实体的实例

**方法签名：**
```java
public final Object createInstance()
```

**返回值：**
- `Object`: 新的动态实体实例

---

**重载 2**

{待补充}

**方法签名：**
```java
public Object createInstance(boolean isQueryObj)
```

**参数说明：**
- `isQueryObj`: `boolean`

**返回值：**
- `Object`

---

### getAlias

{待补充}

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getCacheFlag

缓存隔离标志

**方法签名：**
```java
public String getCacheFlag()
```

**返回值：**
- `String`

---

### getCacheTypeId

获取实体缓存的类型

**方法签名：**
```java
public final int getCacheTypeId()
```

**返回值：**
- `int`

---

### getClrType

返回此动态实体最终创建后实体对应的CLR类型，默认情况下是DynamicObject

**方法签名：**
```java
public final Class<?> getClrType()
```

**返回值：**
- `Class<?>`

---

### getCreateTimeProperty

{待补充}

**方法签名：**
```java
public ICreateTimeProperty getCreateTimeProperty()
```

**返回值：**
- `ICreateTimeProperty`

---

### getCreatedByProperty

{待补充}

**方法签名：**
```java
public ICreatedByProperty getCreatedByProperty()
```

**返回值：**
- `ICreatedByProperty`

---

### getDBRouteKey

{待补充}

**方法签名：**
```java
public final String getDBRouteKey()
```

**返回值：**
- `String`

---

### getDataEntityReferenceSchema

{待补充}

**方法签名：**
```java
public Object getDataEntityReferenceSchema()
```

**返回值：**
- `Object`

---

### getDirtyProperties

**重载 1**

获取实体脏属性

**方法签名：**
```java
public List<kd.IDataEntityProperty> getDirtyProperties(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `List<kd.IDataEntityProperty>`

---

**重载 2**

获取实体脏属性

**方法签名：**
```java
public List<kd.IDataEntityProperty> getDirtyProperties(Object dataEntity, boolean includehasDefualt)
```

**参数说明：**
- `dataEntity`: `Object`
- `includehasDefualt`: `boolean`

**返回值：**
- `List<kd.IDataEntityProperty>`

---

### getDisplayName

{待补充}

**方法签名：**
```java
public LocaleString getDisplayName()
```

**返回值：**
- `LocaleString`

---

### getExtendName

扩展名称；类型名称与各属性名合并组成的字符串； 以此快速比对两个类型是否一致，作为缓存Region标识

**方法签名：**
```java
public final String getExtendName()
```

**返回值：**
- `String`

---

### getFlag

返回此实体类型特征，可选值包括：Class(缺省)、Abstract、Sealed、Interface

**方法签名：**
```java
public final DataEntityTypeFlag getFlag()
```

**返回值：**
- `DataEntityTypeFlag`

---

### getFullIndexFields

{待补充}

**方法签名：**
```java
public Set<String> getFullIndexFields()
```

**返回值：**
- `Set<String>`

---

### getJsonSerializerProperties

{待补充}

**方法签名：**
```java
public synchronized List<kd.IDataEntityProperty> getJsonSerializerProperties()
```

**返回值：**
- `List<kd.IDataEntityProperty>`

---

### getLocaleProperty

获取多语言字段属性集合

**方法签名：**
```java
public DynamicCollectionProperty getLocaleProperty()
```

**返回值：**
- `DynamicCollectionProperty`

---

### getModifierProperty

{待补充}

**方法签名：**
```java
public IModifierProperty getModifierProperty()
```

**返回值：**
- `IModifierProperty`

---

### getModifyTimeProperty

{待补充}

**方法签名：**
```java
public IModifyTimeProperty getModifyTimeProperty()
```

**返回值：**
- `IModifyTimeProperty`

---

### getName

返回实体类型的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getParent

**重载 1**

{待补充}

**方法签名：**
```java
public IDataEntityType getParent()
```

**返回值：**
- `IDataEntityType`

---

**重载 2**

{待补充}

**方法签名：**
```java
public Object getParent(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Object`

---

### getPkSnapshot

获取实体快照

**方法签名：**
```java
public PkSnapshotSet getPkSnapshot(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `PkSnapshotSet`: 返回实体的快照对象。

---

### getPrimaryKey

主键

**方法签名：**
```java
public final ISimpleProperty getPrimaryKey()
```

**返回值：**
- `ISimpleProperty`

---

### getProperties

{待补充}

**方法签名：**
```java
public DataEntityPropertyCollection getProperties()
```

**返回值：**
- `DataEntityPropertyCollection`

---

### getProperty

根据字段名获取字段名属性

**方法签名：**
```java
public DynamicProperty getProperty(String propertyName)
```

**参数说明：**
- `propertyName`: `String`

**返回值：**
- `DynamicProperty`

---

### getSortProperties

{待补充}

**方法签名：**
```java
public List<kd.ISimpleProperty> getSortProperties()
```

**返回值：**
- `List<kd.ISimpleProperty>`

---

### isDirty

判断实体是否为脏

**方法签名：**
```java
public boolean isDirty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isFullIndexDataSynced

{待补充}

**方法签名：**
```java
public boolean isFullIndexDataSynced()
```

**返回值：**
- `boolean`

---

### isInheritFrom

判断是否继承某个实体

**方法签名：**
```java
public boolean isInheritFrom(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String`

**返回值：**
- `boolean`

---

### isQueryObj

是否查询对象

**方法签名：**
```java
public boolean isQueryObj(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### registerCollectionProperty

注册一个集合属性 集合属性和复杂属性一样也是指向另外一个实体类型的引用，所不同的是集合属性表达主表与明细表的关系时候使用。
 在数据库中，集合属性会保存在明细表中，为一对多的关系。主实体与集合属性的关联主键使用主实体的主键，即要求明细表的外键名字和主表主键名字相同。
 如系统中的订单主表及明细表分录即使用集合属性来表示
 
 
 
      //构建一个订单
      DynamicObjectType saleOrderType = new DynamicObjectType("SaleOrder");
      //定义SaleOrderID属性，并设置为主键
      saleOrderType.RegisterSimpleProperty("SaleOrderID", typeof(int), 0, false, new SimplePropertyAttribute(true));
      //定义单据明细
      DynamicObjectType saleOrderItemType = new DynamicObjectType("SaleOrderItem");
      saleOrderItemType.RegisterSimpleProperty("SaleOrderItemID", typeof(int), 0, false, new SimplePropertyAttribute(true));
      //产品
      saleOrderItemType.RegisterSimpleProperty("ProductID", typeof(int));
      //注册集合属性
      DynamicProperty ItemsProperty = saleOrderType.RegisterCollectionProperty("Items", saleOrderItemType);
      //集合属性的读取和设置  
      DynamicObject obj = new DynamicObject(saleOrderType);
      //添加数据 
      IList list = (IList)ItemsProperty.GetValue(people);  //取得分录集合 
      list.Add(ItemsProperty.CollectionItemPropertyType.CreateInstance()); //集合操作，添加数据
      object aItem = list[0];
      IDataEntityType aItemType = aItem.CollectionItemPropertyType;  //取到第一个分录
      ((ISimpleProperty)aItemType.Properties["ProductID"]).SetValue(items[0], 2);  //赋值

**方法签名：**
```java
public final DynamicCollectionProperty registerCollectionProperty(DynamicCollectionProperty property)
```

**参数说明：**
- `property`: `DynamicCollectionProperty`

**返回值：**
- `DynamicCollectionProperty`: 新定义的属性

---

### registerComplexProperty

注册一个复杂属性 复杂属性指向另外一个实体类型的引用，以一个属性保存一个整体段信息。
 如系统中常用的中繁英文三个字段则可整体定义为复杂属性，整个系统可共用这个类型。
 注意的是数据库中复杂属性字段与主字段在同一个表中，对于保存到另一表中的情况，使用引用属性ReferenceAttribute.
 
 
 
     //构建一个订单
     DynamicObjectType saleOrderType = new DynamicObjectType("SaleOrder");
     // 定义SaleOrderID属性，并设置为主键
     saleOrderType.registerSimpleProperty("SaleOrderID", typeof(int), 0, false, new SimplePropertyAttribute(true));
     //注册复杂属性
     DynamicObjectType cpxType = new DynamicObjectType("CPX");
     DynamicProperty TelProperty = cpxType.registerSimpleProperty("Tel", typeof(string));
     DynamicProperty cpxProperty = saleOrderType.registerComplexProperty("ComplexProperty", cpxType); 
     //复杂属性的读取和设置
     DynamicObject obj = new DynamicObject(saleOrderType);
     DynamicObject cpxValue = (DynamicObject)cpxProperty.getValue(obj);
     TelProperty.setValue(cpxValue, "2008");

**方法签名：**
```java
public final DynamicComplexProperty registerComplexProperty(DynamicComplexProperty property)
```

**参数说明：**
- `property`: `DynamicComplexProperty`

**返回值：**
- `DynamicComplexProperty`: 新定义的属性定义

---

### registerProperty

注册一个普通属性，此属性不参与ORM的分析过程 仅供内部使用，外部请使用RegisterSimpleProperty

**方法签名：**
```java
public final DynamicProperty registerProperty(String name, Class<?> propertyType, Object defaultValue, boolean isReadonly)
```

**参数说明：**
- `name`: `String`
- `propertyType`: `Class<?>`
- `defaultValue`: `Object`
- `isReadonly`: `boolean`

**返回值：**
- `DynamicProperty`: 新定义的属性对象

---

### registerSimpleProperty

注册一个简单属性，此属性参与ORM的处理 简单属性对应数据库中最基本的类型,包括(整型、字符、浮点型、日期等)
 
 
 
 
     //构建一个订单
     DynamicObjectType saleOrderType = new DynamicObjectType("SaleOrder");
     //定义SaleOrderID属性，并设置为主键
     SaleOrderIDProperty = saleOrderType.registerSimpleProperty("SaleOrderID", typeof(int), 0, false, new SimplePropertyAttribute(true));
     //单据日期
     DynamicProperty SheetDateProperty = saleOrderType.registerProperty("SheetDate", typeof(DateTime),new DateTime(2009,9,1));
     //简单属性的读取和设置
     DynamicObject obj = new DynamicObject(saleOrderType);
     SaleOrderIDProperty.getValue(obj); //缺省值0
     SheetDateProperty.getValue(obj); //缺省值
     SaleOrderIDProperty.setValue(obj, 99);
     )

**方法签名：**
```java
public final DynamicProperty registerSimpleProperty(DynamicSimpleProperty property)
```

**参数说明：**
- `property`: `DynamicSimpleProperty`

**返回值：**
- `DynamicProperty`: 新定义的属性对象

---

### setAlias

{待补充}

**方法签名：**
```java
public void setAlias(String value)
```

**参数说明：**
- `value`: `String`

---

### setCacheFlag

设置缓存自定义标志
 用于本地缓存隔离

**方法签名：**
```java
public void setCacheFlag(String cacheFlag)
```

**参数说明：**
- `cacheFlag`: `String`

---

### setDBRouteKey

设置实体对应路由

**方法签名：**
```java
public void setDBRouteKey(String dbRouteKey)
```

**参数说明：**
- `dbRouteKey`: `String`

---

### setDataEntityReferenceSchema

{待补充}

**方法签名：**
```java
public void setDataEntityReferenceSchema(Object dataEntityReferenceSchema)
```

**参数说明：**
- `dataEntityReferenceSchema`: `Object`

---

### setDirty

修改实体的脏标志

**方法签名：**
```java
public void setDirty(Object dataEntity, boolean newValue)
```

**参数说明：**
- `dataEntity`: `Object`
- `newValue`: `boolean`

---

### setDisplayName

设置实体显示名称

**方法签名：**
```java
public void setDisplayName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setFromDatabase

**重载 1**

设置一个实体是从数据库加载而来，当读取或保存完毕后，调用此方法

**方法签名：**
```java
public void setFromDatabase(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

---

**重载 2**

{待补充}

**方法签名：**
```java
public void setFromDatabase(Object dataEntity, boolean clearDirty)
```

**参数说明：**
- `dataEntity`: `Object`
- `clearDirty`: `boolean`

---

### setName

设置实体名

**方法签名：**
```java
public void setName(String value)
```

**参数说明：**
- `value`: `String`

---

### setPkSnapshot

设置实体快照

**方法签名：**
```java
public void setPkSnapshot(Object dataEntity, PkSnapshotSet pkSnapshotSet)
```

**参数说明：**
- `dataEntity`: `Object`
- `pkSnapshotSet`: `PkSnapshotSet`

---

### toPlainString

{待补充}

**方法签名：**
```java
public String toPlainString()
```

**返回值：**
- `String`

---

### toString

返回类型的名称。

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 在动态实体实现中，返回的是Name值。

---
