---
framework_version: "8.0.1"
api_class: "DynamicLocaleProperty"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用实体的多语言子分录属性时"
---

# DynamicLocaleProperty API 说明

## 概述
实体的多语言子分录属性。继承自 DynamicCollectionProperty，实现 ICollectionProperty, Serializable, IDataEntityProperty, IMetadata, Cloneable。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicLocaleProperty;
```

---

## 方法列表

### getDTValueFast

{待补充}

**方法签名：**
```java
public Object getDTValueFast(DynamicObject obj)
```

**参数说明：**
- `obj`: `DynamicObject`

**返回值：**
- `Object`

---

### getPropertyType

{待补充}

**方法签名：**
```java
public Class<?> getPropertyType()
```

**返回值：**
- `Class<?>`

---

### isJsonSerialize

{待补充}

**方法签名：**
```java
public boolean isJsonSerialize()
```

**返回值：**
- `boolean`

---
