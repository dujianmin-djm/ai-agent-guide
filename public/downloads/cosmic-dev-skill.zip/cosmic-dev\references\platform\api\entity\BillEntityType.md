---
framework_version: "8.0.1"
api_class: "BillEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用单据实体类型时"
---

# BillEntityType API 说明

## 概述
单据实体类型。继承自 MainEntityType。
主要功能：读取属性、设置属性、状态判断、查询数据。

## Import 路径
```java
import kd.bos.entity.BillEntityType;
```

---

## 方法列表

### findProperty

根据字段标识获取对应属性对象

**方法签名：**
```java
public IDataEntityProperty findProperty(String name)
```

**参数说明：**
- `name`: `String`

**返回值：**
- `IDataEntityProperty`

---

### getBillKeyField

获取单据关键字段

**方法签名：**
```java
public String getBillKeyField()
```

**返回值：**
- `String`

---

### getBillNo

获取单据编号

**方法签名：**
```java
public String getBillNo()
```

**返回值：**
- `String`: 单据编号

---

### getBillParameter

获取单据参数

**方法签名：**
```java
public String getBillParameter()
```

**返回值：**
- `String`: billParameter 单据参数

---

### getBillStatus

获取单据状态

**方法签名：**
```java
public String getBillStatus()
```

**返回值：**
- `String`: 单据状态

---

### getBillType

获取单据类型

**方法签名：**
```java
public String getBillType()
```

**返回值：**
- `String`: 单据类型

---

### getBillTypePara

获取字段billTypePara的值

**方法签名：**
```java
public String getBillTypePara()
```

**返回值：**
- `String`: billTypePara的值

---

### getDefaultPageSetting

获取单据默认布局

**方法签名：**
```java
public String getDefaultPageSetting()
```

**返回值：**
- `String`

---

### getEntityTypeId

获取单据实体编码

**方法签名：**
```java
public String getEntityTypeId()
```

**返回值：**
- `String`: 单据实体编码

---

### getForbidStatus

获取禁用状态

**方法签名：**
```java
public String getForbidStatus()
```

**返回值：**
- `String`: 禁用状态

---

### getFullIndexFields

全文索引字段集合

**方法签名：**
```java
public Set<String> getFullIndexFields()
```

**返回值：**
- `Set<String>`

---

### getMainOrgProperty

获取主业务组织

**方法签名：**
```java
public MainOrgProp getMainOrgProperty()
```

**返回值：**
- `MainOrgProp`: 主业务组织

---

### getMobFormId

获取单据移动端标识

**方法签名：**
```java
public String getMobFormId()
```

**返回值：**
- `String`

---

### getOrgRelationConfigList

获取组织委托关系配置列表

**方法签名：**
```java
public Map<String,OrgRelationConfig> getOrgRelationConfigList()
```

**返回值：**
- `Map<String,OrgRelationConfig>`

---

### getSignField

获取签名字段

**方法签名：**
```java
public List<kd.SignField> getSignField()
```

**返回值：**
- `List<kd.SignField>`: List 签名字段集合

---

### isForceUpdateModifier

当前单据体没有修改人时，强制更新单据头的修改人

**方法签名：**
```java
public Boolean isForceUpdateModifier()
```

**返回值：**
- `Boolean`

---

### isFullIndexDataSynced

全文索引数据同步

**方法签名：**
```java
public boolean isFullIndexDataSynced()
```

**返回值：**
- `boolean`

---

### isTriggerDBRecord

{待补充}

**方法签名：**
```java
public boolean isTriggerDBRecord()
```

**返回值：**
- `boolean`

---

### setBillKeyField

设置单据关键字段

**方法签名：**
```java
public void setBillKeyField(String billKeyField)
```

**参数说明：**
- `billKeyField`: `String`

---

### setBillNo

设置单据编号

**方法签名：**
```java
public void setBillNo(String billNo)
```

**参数说明：**
- `billNo`: `String` — 单据编号

---

### setBillParameter

设置单据参数

**方法签名：**
```java
public void setBillParameter(String billParameter)
```

**参数说明：**
- `billParameter`: `String` — 单据参数

---

### setBillStatus

设置单据状态

**方法签名：**
```java
public void setBillStatus(String billStatus)
```

**参数说明：**
- `billStatus`: `String` — 单据状态

---

### setBillType

设置单据类型

**方法签名：**
```java
public void setBillType(String billType)
```

**参数说明：**
- `billType`: `String` — 单据类型

---

### setBillTypePara

将参数billTypePara的值赋给字段billTypePara

**方法签名：**
```java
public void setBillTypePara(String billTypePara)
```

**参数说明：**
- `billTypePara`: `String` — 单据参数

---

### setDefaultPageSetting

设置单据默认布局

**方法签名：**
```java
public void setDefaultPageSetting(String defaultPageSetting)
```

**参数说明：**
- `defaultPageSetting`: `String`

---

### setEntityTypeId

设置单据实体编码

**方法签名：**
```java
public void setEntityTypeId(String entityTypeId)
```

**参数说明：**
- `entityTypeId`: `String` — 单据实体编码

---

### setForbidStatus

设置禁用状态

**方法签名：**
```java
public void setForbidStatus(String forbidStatus)
```

**参数说明：**
- `forbidStatus`: `String` — 禁用状态

---

### setMobFormId

设置单据移动端标识

**方法签名：**
```java
public void setMobFormId(String mobFormId)
```

**参数说明：**
- `mobFormId`: `String`

---

### setOrgRelationConfigList

设置组织委托关系配置列表

**方法签名：**
```java
public void setOrgRelationConfigList(Map<String,OrgRelationConfig> orgRelationConfigList)
```

**参数说明：**
- `orgRelationConfigList`: `Map<String,OrgRelationConfig>`

---

### setSignField

设置签名字段

**方法签名：**
```java
public void setSignField(List<kd.SignField> signField)
```

**参数说明：**
- `signField`: `List<kd.SignField>`

---
