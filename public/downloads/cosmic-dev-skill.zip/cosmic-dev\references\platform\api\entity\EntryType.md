---
framework_version: "8.0.1"
api_class: "EntryType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用分录实体类型时"
---

# EntryType API 说明

## 概述
分录实体类型。继承自 EntityType。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.EntryType;
```

---

## 方法列表

### endInit

结束初始化

**方法签名：**
```java
public synchronized void endInit()
```

---

### getEntryNotMustInputRules

获取单据体非必录规则

**方法签名：**
```java
public List<kd.AbstractRule> getEntryNotMustInputRules(String source)
```

**参数说明：**
- `source`: `String`

**返回值：**
- `List<kd.AbstractRule>`

---

### getKeyField

获取关键字段

**方法签名：**
```java
public String getKeyField()
```

**返回值：**
- `String`: 关键字段

---

### getMustInputCondition

获取必录条件

**方法签名：**
```java
public String getMustInputCondition()
```

**返回值：**
- `String`

---

### getSeqProperty

获取seq属性

**方法签名：**
```java
public IDataEntityProperty getSeqProperty()
```

**返回值：**
- `IDataEntityProperty`

---

### isKeyEntry

是否关键实体

**方法签名：**
```java
public boolean isKeyEntry()
```

**返回值：**
- `boolean`: false:不是关键实体，true:是关键实体

---

### isMustIuput

是否必录

**方法签名：**
```java
public boolean isMustIuput()
```

**返回值：**
- `boolean`: false:不必录，true:必录

---

### isQuickAdd

是否快捷新增

**方法签名：**
```java
public boolean isQuickAdd()
```

**返回值：**
- `boolean`: false:不快捷新增，true:快捷新增

---

### isRefParentProperty

是否在运行期以来父表单的属性

**方法签名：**
```java
public boolean isRefParentProperty()
```

**返回值：**
- `boolean`: 是否在运行期以来父表单的属性

---

### setKeyEntry

设置是否关键实体

**方法签名：**
```java
public void setKeyEntry(boolean keyEntry)
```

**参数说明：**
- `keyEntry`: `boolean` — false:不是关键实体，true:是关键实体

---

### setKeyField

设置关键字段

**方法签名：**
```java
public void setKeyField(String keyField)
```

**参数说明：**
- `keyField`: `String` — 关键字段

---

### setMustInputCondition

设置必录条件

**方法签名：**
```java
public void setMustInputCondition(String mustInputCondition)
```

**参数说明：**
- `mustInputCondition`: `String`

---

### setMustIuput

设置是否必录

**方法签名：**
```java
public void setMustIuput(boolean mustIuput)
```

**参数说明：**
- `mustIuput`: `boolean` — false:不必录，true:必录

---

### setQuickAdd

设置是否快捷新增

**方法签名：**
```java
public void setQuickAdd(boolean quickAdd)
```

**参数说明：**
- `quickAdd`: `boolean` — false:不快捷新增，true:快捷新增

---

### setRefParentProperty

设置是否在运行期以来父表单的属性

**方法签名：**
```java
public void setRefParentProperty(boolean refParentProperty)
```

**参数说明：**
- `refParentProperty`: `boolean`

---
