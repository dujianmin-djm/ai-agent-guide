---
framework_version: "8.0.1"
api_class: "DataEntityBase"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用数据包基类时"
---

# DataEntityBase API 说明

## 概述
数据包基类，DynamicObject的父类。实现 INotifyPropertyChanged, ISupportInitialize, IDataEntityBase, IObjectWithParent, Serializable。
主要功能：读取属性、状态判断、添加元素、移除元素。

## Import 路径
```java
import kd.bos.dataentity.entity.DataEntityBase;
```

---

## 方法列表

### OnPropertyChanged

触发属性改变事件

**方法签名：**
```java
public void OnPropertyChanged(PropertyChangeEvent e)
```

**参数说明：**
- `e`: `PropertyChangeEvent` — 属性改变的事件参数

---

### addPropertyChangeListener

{待补充}

**方法签名：**
```java
public void addPropertyChangeListener(PropertyChangeListener listener)
```

**参数说明：**
- `listener`: `PropertyChangeListener`

---

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### beginResetDirtyFlag

开始重置脏标记

**方法签名：**
```java
public void beginResetDirtyFlag()
```

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### endResetDirtyFlag

结束重置脏标记

**方法签名：**
```java
public void endResetDirtyFlag()
```

---

### getDataEntityState

返回当前数据行的状态管理

**方法签名：**
```java
public final synchronized DataEntityState getDataEntityState()
```

**返回值：**
- `DataEntityState`

---

### getDataEntityType

返回实体的数据类型

**方法签名：**
```java
public abstract IDataEntityType getDataEntityType()
```

**返回值：**
- `IDataEntityType`: ORM定义的数据结构

---

### getParent

返回此实体对应的父对象

**方法签名：**
```java
public final Object getParent()
```

**返回值：**
- `Object`

---

### getPkValue

{待补充}

**方法签名：**
```java
public Object getPkValue()
```

**返回值：**
- `Object`

---

### getPropertyChangeListeners

{待补充}

**方法签名：**
```java
public PropertyChangeListener[] getPropertyChangeListeners()
```

**返回值：**
- `PropertyChangeListener[]`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### isInitializing

返回是否正在初始化过程中。

**方法签名：**
```java
public final boolean isInitializing()
```

**返回值：**
- `boolean`

---

### isResetDirtyFlag

是否重置脏标记

**方法签名：**
```java
public final boolean isResetDirtyFlag()
```

**返回值：**
- `boolean`

---

### refreshDataEntityState

允许在初始化后再增加属性： 增加属性后调用此方法刷新实体状态。

**方法签名：**
```java
public void refreshDataEntityState()
```

---

### removePropertyChangeListener

{待补充}

**方法签名：**
```java
public void removePropertyChangeListener(PropertyChangeListener listener)
```

**参数说明：**
- `listener`: `PropertyChangeListener`

---

### setParent

设置此实体对应的父对象

**方法签名：**
```java
public void setParent(Object value)
```

**参数说明：**
- `value`: `Object`

---
