---
framework_version: "8.0.1"
api_class: "IntegralType"
api_package: "kd.bos.algo.datatype"
when_to_use: "当你需要使用Integer,Long等整数类型的抽象父类时"
---

# IntegralType API 说明

## 概述
Integer,Long等整数类型的抽象父类。继承自 NumericType，实现 Serializable。
主要功能：型比较，返回类型索引较大的类型。但是较大、类型比较，返回类型索引较小的类型。但是较。

## Import 路径
```java
import kd.bos.algo.datatype.IntegralType;
```

---

## 方法列表

### computeCompatibleDown

型比较，返回类型索引较大的类型。但是较大类型大于Long时，则返回Long

**方法签名：**
```java
public static IntegralType computeCompatibleDown(NumericType left, NumericType right)
```

**参数说明：**
- `left`: `NumericType` — 类型1
- `right`: `NumericType` — 类型1

**返回值：**
- `IntegralType`: 返回类型索引较大的类型

---

### computeCompatibleUp

类型比较，返回类型索引较小的类型。但是较小类型大于Long时，则返回Long

**方法签名：**
```java
public static IntegralType computeCompatibleUp(NumericType left, NumericType right)
```

**参数说明：**
- `left`: `NumericType` — 类型1
- `right`: `NumericType` — 类型1

**返回值：**
- `IntegralType`: 返回索引较小的类型

---
