---
framework_version: "8.0.1"
api_class: "AfterBizRuleEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用业务规则后事件时"
---

# AfterBizRuleEventArgs API 说明

## 概述
业务规则后事件，插件可以在这个事件中，对生成的目标单数据，进行修改。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterBizRuleEventArgs;
```

---

## 方法列表

### getFldProperties

源单字段，与数据包属性对应字典，可以据此到源单数据包中读取字段值

**方法签名：**
```java
public Map<String,DynamicProperty> getFldProperties()
```

**返回值：**
- `Map<String,DynamicProperty>`

---

### getTargetExtDataEntitySet

生成的目标单空数据包

**方法签名：**
```java
public ExtendedDataEntitySet getTargetExtDataEntitySet()
```

**返回值：**
- `ExtendedDataEntitySet`

---

### setTargetExtDataEntitySet

设置生成的目标单空数据包

**方法签名：**
```java
public void setTargetExtDataEntitySet(ExtendedDataEntitySet targetExtDataEntitySet)
```

**参数说明：**
- `targetExtDataEntitySet`: `ExtendedDataEntitySet` — 生成的目标单空数据包

---
