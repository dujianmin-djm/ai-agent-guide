---
framework_version: "8.0.1"
api_class: "ResultAwarable"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用元数据获取接口时"
---

# ResultAwarable API 说明

## 概述
元数据获取接口。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algox.ResultAwarable;
```

---

## 方法列表

### getResultRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getResultRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
