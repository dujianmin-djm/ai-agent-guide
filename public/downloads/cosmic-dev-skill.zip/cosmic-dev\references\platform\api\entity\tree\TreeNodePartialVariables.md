---
framework_version: "8.0.1"
api_class: "TreeNodePartialVariables"
api_package: "kd.bos.entity.tree"
when_to_use: "当你需要使用用于客户端局部更新节点属性（节点名称、是否锁定、是否展开、标签信息、图标信息）时"
---

# TreeNodePartialVariables API 说明

## 概述
用于客户端局部更新节点属性（节点名称、是否锁定、是否展开、标签信息、图标信息）。实现 Serializable。
主要功能：设置属性、读取属性、添加元素、状态判断。

## Import 路径
```java
import kd.bos.entity.tree.TreeNodePartialVariables;
```

---

## 方法列表

### addLabelPara

设置节点的标签，自动转为客户端控件使用的参数包

**方法签名：**
```java
public void addLabelPara(List<kd.TreeNodeLabel> labelPara)
```

**参数说明：**
- `labelPara`: `List<kd.TreeNodeLabel>` — 标签

---

### getIcon

获取节点图片

**方法签名：**
```java
public String getIcon()
```

**返回值：**
- `String`: 节点图片

---

### getId

返回节点标识

**方法签名：**
```java
public final String getId()
```

**返回值：**
- `String`: 节点标识

---

### getIsOpened

返回节点是否默认展开

**方法签名：**
```java
public Boolean getIsOpened()
```

**返回值：**
- `Boolean`: 返回true-默认展开

---

### getLabelPara

获取节点的标签参数包

**方法签名：**
```java
public List<Map<String,String>> getLabelPara()
```

**返回值：**
- `List<Map<String,String>>`: 返回客户端树形控件使用的参数包

---

### getParentid

返回父节点标识

**方法签名：**
```java
public final String getParentid()
```

**返回值：**
- `String`: 父节点标识

---

### getSuffixIconProps

获取树节点后缀小图标属性

**方法签名：**
```java
public SuffixIconProps getSuffixIconProps()
```

**返回值：**
- `SuffixIconProps`

---

### getText

返回节点显示内容

**方法签名：**
```java
public final String getText()
```

**返回值：**
- `String`: 显示内容

---

### isDisabled

本节点是否禁用

**方法签名：**
```java
public Boolean isDisabled()
```

**返回值：**
- `Boolean`: 返回true-禁用

---

### setDisabled

设置节点是否禁用

**方法签名：**
```java
public void setDisabled(Boolean disabled)
```

**参数说明：**
- `disabled`: `Boolean` — 设置为true-禁用

---

### setIcon

设置节点图片

**方法签名：**
```java
public void setIcon(String icon)
```

**参数说明：**
- `icon`: `String` — 节点图片

---

### setId

设置节点标识，用于指定更新哪个节点信息，不支持更新节点的id值

**方法签名：**
```java
public final void setId(String value)
```

**参数说明：**
- `value`: `String` — 节点标识

---

### setIsOpened

设置节点是否默认展开

**方法签名：**
```java
public void setIsOpened(Boolean isOpened)
```

**参数说明：**
- `isOpened`: `Boolean` — 设为true-默认展开

---

### setLabelPara

设置节点的标签，自动转为客户端控件使用的参数包

**方法签名：**
```java
public void setLabelPara(List<Map<String,String>> labelPara)
```

**参数说明：**
- `labelPara`: `List<Map<String,String>>` — 标签

---

### setParentid

设置父节点标识，仅用于当存在相同ID时，可根据parentid找到对应节点进行更新其他属性，不支持更新当前的父节点ID

**方法签名：**
```java
public final void setParentid(String value)
```

**参数说明：**
- `value`: `String` — 父节点标识

---

### setSuffixIconProps

设置树节点后缀小图标属性

**方法签名：**
```java
public void setSuffixIconProps(SuffixIconProps suffixIconProps)
```

**参数说明：**
- `suffixIconProps`: `SuffixIconProps`

---

### setText

设置节点显示内容

**方法签名：**
```java
public final void setText(String value)
```

**参数说明：**
- `value`: `String` — 显示内容

---

### toString

转换为字符串输出，含节点标识、显示内容

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
