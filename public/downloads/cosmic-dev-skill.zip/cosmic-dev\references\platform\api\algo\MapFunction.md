---
framework_version: "8.0.1"
api_class: "MapFunction"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用对数据进行分组处理时"
---

# MapFunction API 说明

## 概述
对数据进行分组处理。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：对DataSet进行自定义map函数处理。

## Import 路径
```java
import kd.bos.algo.MapFunction;
```

---

## 方法列表

### map

对DataSet进行自定义map函数处理

**方法签名：**
```java
public abstract Object[] map(Row row)
```

**参数说明：**
- `row`: `Row` — DataSet中的行

**返回值：**
- `Object[]`: 处理后的结果

---
