---
framework_version: "8.0.1"
api_class: "BizRulePolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用业务规则策略时"
---

# BizRulePolicy API 说明

## 概述
业务规则策略。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.BizRulePolicy;
```

---

## 方法列表

### getActions

获取业务规则列表。
 该列表包含了一系列的业务规则元素，每个元素代表一条具体的业务规则。

**方法签名：**
```java
public List<kd.CRBizRuleElement> getActions()
```

**返回值：**
- `List<kd.CRBizRuleElement>`: 返回业务规则元素列表

---

### setActions

设置业务规则列表

**方法签名：**
```java
public void setActions(List<kd.CRBizRuleElement> actions)
```

**参数说明：**
- `actions`: `List<kd.CRBizRuleElement>` — 要设置的业务规则元素列表

---
