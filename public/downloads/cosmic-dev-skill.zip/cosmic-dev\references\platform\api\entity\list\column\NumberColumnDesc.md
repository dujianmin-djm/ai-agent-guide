---
framework_version: "8.0.1"
api_class: "NumberColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用数字类型的格式化处理基类时"
---

# NumberColumnDesc API 说明

## 概述
数字类型的格式化处理基类。继承自 ColumnDesc，实现 Serializable。
主要功能：设置属性、状态判断、读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.NumberColumnDesc;
```

---

## 方法列表

### getListShowZeroConfig

获取列表显示尾零配置

**方法签名：**
```java
public ListShowZeroConfig getListShowZeroConfig()
```

**返回值：**
- `ListShowZeroConfig`

---

### isMobNoDisplayScaleZero

获取移动列表字段不显示尾零属性

**方法签名：**
```java
public boolean isMobNoDisplayScaleZero()
```

**返回值：**
- `boolean`

---

### isZeroShow

PC端不显示尾零属性

**方法签名：**
```java
public boolean isZeroShow()
```

**返回值：**
- `boolean`

---

### setListShowZeroConfig

设置列表显示尾零配置

**方法签名：**
```java
public void setListShowZeroConfig(ListShowZeroConfig listShowZeroConfig)
```

**参数说明：**
- `listShowZeroConfig`: `ListShowZeroConfig`

---

### setMobNoDisplayScaleZero

设置移动列表字段不显示尾零属性

**方法签名：**
```java
public void setMobNoDisplayScaleZero(boolean mobNoDisplayScaleZero)
```

**参数说明：**
- `mobNoDisplayScaleZero`: `boolean` — 移动列表字段不显示尾零属性

---

### setZeroShow

设置PC端不显示尾零属性

**方法签名：**
```java
public void setZeroShow(boolean zeroShow)
```

**参数说明：**
- `zeroShow`: `boolean` — PC端不显示尾零属性

---
