---
framework_version: "8.0.1"
api_class: "CRCondition"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用转换规则时"
---

# CRCondition API 说明

## 概述
转换规则，条件。继承自 CRFormula。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.CRCondition;
```

---

## 方法列表

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### buildFullFormula

**重载 1**

合并条件表格、手书条件，生成一条完整的表达式

**方法签名：**
```java
public String buildFullFormula(MainEntityType mainType)
```

**参数说明：**
- `mainType`: `MainEntityType`

**返回值：**
- `String`

---

**重载 2**

合并条件表格、手书条件，生成一条完整的表达式

**方法签名：**
```java
public String buildFullFormula(MainEntityType mainType, IUserService userService, ITimeService timeService)
```

**参数说明：**
- `mainType`: `MainEntityType`
- `userService`: `IUserService` — 解析条件需要用到的用户服务（解析"我的部门"等比较符）
- `timeService`: `ITimeService` — 解析条件需要用到的时间服务（解析"今天"等比较符）

**返回值：**
- `String`

---

### check

{待补充}

**方法签名：**
```java
public void check(MainEntityType mainType, CheckPoint checkPoint, CheckResult checkResult)
```

**参数说明：**
- `mainType`: `MainEntityType`
- `checkPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### getFilterCondition

在条件表格中配置的内容

**方法签名：**
```java
public FilterCondition getFilterCondition()
```

**返回值：**
- `FilterCondition`

---

### getFilterString

输出FilterCondition对象的序列化字符串

**方法签名：**
```java
public String getFilterString()
```

**返回值：**
- `String`

---

### getId

自动产生的唯一标识，据此与扩展对象，进行差量化对比定位

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getSeq

获取插件执行顺序，数值小的先执行

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`: 执行顺序

---

### isEnabled

禁用启用

**方法签名：**
```java
public boolean isEnabled()
```

**返回值：**
- `boolean`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### setEnabled

设置禁用启用

**方法签名：**
```java
public void setEnabled(boolean enabled)
```

**参数说明：**
- `enabled`: `boolean`

---

### setFilterCondition

设置/更新表格条件

**方法签名：**
```java
public void setFilterCondition(FilterCondition newFilterCondition)
```

**参数说明：**
- `newFilterCondition`: `FilterCondition`

---

### setFilterString

FilterCondition对象的序列化字符串

**方法签名：**
```java
public void setFilterString(String filterString)
```

**参数说明：**
- `filterString`: `String`

---

### setId

自动产生的唯一标识

**方法签名：**
```java
public void setId(String value)
```

**参数说明：**
- `value`: `String`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setSeq

执行顺序

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---
