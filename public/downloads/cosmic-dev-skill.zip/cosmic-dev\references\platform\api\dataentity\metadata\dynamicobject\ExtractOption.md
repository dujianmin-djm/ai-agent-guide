---
framework_version: "8.0.1"
api_class: "ExtractOption"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用从一个动态实体定义中提取字段的选项 需要注意的是时"
---

# ExtractOption API 说明

## 概述
从一个动态实体定义中提取字段的选项 需要注意的是，未注册提取的实体类型将按源类型原封不动。 DynamicObjectType#Extract方法参数。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.ExtractOption;
```

---

## 方法列表

### GetExtractedProperties

返回指定类型应提取的属性列表

**方法签名：**
```java
public Set<String> GetExtractedProperties(String dtName)
```

**参数说明：**
- `dtName`: `String`

**返回值：**
- `Set<String>`: 最终决定提取的属性列表。如果是null，表示全部提取，不变更。

---

### isIncludeRefId

是否提取引用属性Id

**方法签名：**
```java
public boolean isIncludeRefId()
```

**返回值：**
- `boolean`

---

### register

注册提取的属性信息。包括实体类型名称及你需要提取的属性列表

**方法签名：**
```java
public void register(String dtName, String[] properties)
```

**参数说明：**
- `dtName`: `String`
- `properties`: `String[]`

---

### setIncludeRefId

设置是否提取引用属性Id

**方法签名：**
```java
public void setIncludeRefId(boolean includeRefId)
```

**参数说明：**
- `includeRefId`: `boolean`

---
