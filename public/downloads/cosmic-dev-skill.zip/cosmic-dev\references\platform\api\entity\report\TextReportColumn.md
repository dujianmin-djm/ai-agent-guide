---
framework_version: "8.0.1"
api_class: "TextReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-文本类型列时"
---

# TextReportColumn API 说明

## 概述
报表列-文本类型列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：设置属性、创建对象、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.report.TextReportColumn;
```

---

## 方法列表

### createColumn

{待补充}

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`

---

### getOriginType

获取字段的原始类型，如手机号

**方法签名：**
```java
public String getOriginType()
```

**返回值：**
- `String`

---

### isPassword

内容显示为密码

**方法签名：**
```java
public boolean isPassword()
```

**返回值：**
- `boolean`: 是否内容显示为密码

---

### setOriginType

设置字段的原始类型，如手机号

**方法签名：**
```java
public void setOriginType(String originType)
```

**参数说明：**
- `originType`: `String`

---

### setPassword

设置内容显示为密码

**方法签名：**
```java
public void setPassword(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否内容显示为密码

---
