---
framework_version: "8.0.1"
api_class: "AppCustomParam"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用应用参数时"
---

# AppCustomParam API 说明

## 概述
应用参数，自定义参数接口入参。。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.param.AppCustomParam;
```

---

## 方法列表

### getAppId

获取appId

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: appId

---

### getSearchKeySet

获取查询key集合

**方法签名：**
```java
public Set<String> getSearchKeySet()
```

**返回值：**
- `Set<String>`: 查询key集合

---

### setAppId

设置appId

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 应用参数中的appId

---

### setSearchKeySet

设置查询key集合

**方法签名：**
```java
public void setSearchKeySet(Set<String> searchKeySet)
```

**参数说明：**
- `searchKeySet`: `Set<String>` — 查询key集合

---

### toString

重写toString方法，便于对象的字符串表示

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 对象的字符串表示

---
