---
framework_version: "8.0.1"
api_class: "RouteInfo"
api_package: "kd.bos.db.archive"
when_to_use: "当你需要使用路由信息时"
---

# RouteInfo API 说明

## 概述
路由信息。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.db.archive.RouteInfo;
```

---

## 方法列表

### getArchiveInfo

当前路由的归档路由列表

**方法签名：**
```java
public List<kd.ArchiveInfo> getArchiveInfo()
```

**返回值：**
- `List<kd.ArchiveInfo>`

---

### getRouteKey

当前路由

**方法签名：**
```java
public String getRouteKey()
```

**返回值：**
- `String`

---

### setArchiveInfo

设置当前路由的归档路由列表

**方法签名：**
```java
public void setArchiveInfo(List<kd.ArchiveInfo> archiveInfo)
```

**参数说明：**
- `archiveInfo`: `List<kd.ArchiveInfo>`

---

### setRouteKey

当前路由

**方法签名：**
```java
public void setRouteKey(String routeKey)
```

**参数说明：**
- `routeKey`: `String`

---
