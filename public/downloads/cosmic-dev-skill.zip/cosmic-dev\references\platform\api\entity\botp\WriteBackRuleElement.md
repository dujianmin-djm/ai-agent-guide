---
framework_version: "8.0.1"
api_class: "WriteBackRuleElement"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用运行时反写规则时"
---

# WriteBackRuleElement API 说明

## 概述
运行时反写规则。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.WriteBackRuleElement;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public boolean check(CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

**返回值：**
- `boolean`

---

### getBillCloseFieldFailStatus

回滚反写后，恢复的源单关闭状态值

**方法签名：**
```java
public String getBillCloseFieldFailStatus()
```

**返回值：**
- `String`

---

### getBillCloseFieldKey

源单整单关闭状态字段

**方法签名：**
```java
public String getBillCloseFieldKey()
```

**返回值：**
- `String`

---

### getBillCloseFieldSuccesStatus

达成整单关闭条件后，源单关闭状态值

**方法签名：**
```java
public String getBillCloseFieldSuccesStatus()
```

**返回值：**
- `String`

---

### getBillCloseType

源单整体关闭方式：AllRowsClosed(0),OneRowClosed(1);

**方法签名：**
```java
public BillCloseType getBillCloseType()
```

**返回值：**
- `BillCloseType`

---

### getBizRules

业务规则：在反写完毕后，对源单其他字段进行同步刷新

**方法签名：**
```java
public List<kd.WriteBackBizRule> getBizRules()
```

**返回值：**
- `List<kd.WriteBackBizRule>`

---

### getCacheVersion

运行时版本，格式：yyyy-MM-dd hh:mm:ss

**方法签名：**
```java
public String getCacheVersion()
```

**返回值：**
- `String`

---

### getCheckVersionTimeMillis

最近一次检查版本时间

**方法签名：**
```java
public long getCheckVersionTimeMillis()
```

**返回值：**
- `long`

---

### getCloseCheckCondition

源单行关闭条件

**方法签名：**
```java
public CRCondition getCloseCheckCondition()
```

**返回值：**
- `CRCondition`

---

### getCustStatus

用户调整的状态：0 = 草稿；1 = 启用；2 = 禁用

**方法签名：**
```java
public String getCustStatus()
```

**返回值：**
- `String`

---

### getDistributeType

合并后反写超量分配方式：TopDown = 0, Weight = 1

**方法签名：**
```java
public DistributeType getDistributeType()
```

**返回值：**
- `DistributeType`

---

### getEntryCloseFieldFailStatus

回滚反写后，恢复的源单行关闭状态值

**方法签名：**
```java
public String getEntryCloseFieldFailStatus()
```

**返回值：**
- `String`

---

### getEntryCloseFieldKey

源单行关闭状态字段

**方法签名：**
```java
public String getEntryCloseFieldKey()
```

**返回值：**
- `String`

---

### getEntryCloseFieldSuccesStatus

达成关闭条件后，源单行关闭状态值

**方法签名：**
```java
public String getEntryCloseFieldSuccesStatus()
```

**返回值：**
- `String`

---

### getExcessCheckConditon

超额检查公式

**方法签名：**
```java
public CRCondition getExcessCheckConditon()
```

**返回值：**
- `CRCondition`

---

### getExcessCheckMessage

超额提示信息

**方法签名：**
```java
public LocaleString getExcessCheckMessage()
```

**返回值：**
- `LocaleString`

---

### getExcessCheckType

超额检查模式：StrictControl(0),CanExcessOneTime(1),CanExcellAlways(2),SelectByFormula(3)

**方法签名：**
```java
public ExcessCheckType getExcessCheckType()
```

**返回值：**
- `ExcessCheckType`

---

### getExcessSelectFalse

条件为假选择的超额控制模式

**方法签名：**
```java
public ExcessCheckType getExcessSelectFalse()
```

**返回值：**
- `ExcessCheckType`

---

### getExcessSelectTrue

条件为真时选择的超额控制模式

**方法签名：**
```java
public ExcessCheckType getExcessSelectTrue()
```

**返回值：**
- `ExcessCheckType`

---

### getExcessTypeSelectCondition

超额模式选择条件

**方法签名：**
```java
public CRCondition getExcessTypeSelectCondition()
```

**返回值：**
- `CRCondition`

---

### getExtVersion

扩展反写规则的版本：系统在保存扩展规则时，自动更新

**方法签名：**
```java
public long getExtVersion()
```

**返回值：**
- `long`

---

### getFormulas

反写公式集合

**方法签名：**
```java
public List<kd.WriteBackFormula> getFormulas()
```

**返回值：**
- `List<kd.WriteBackFormula>`

---

### getId

唯一标识：自动产生；对外号称ruleId

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getName

规则的名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getOp

执行反写的操作；本属性专用于序列化

**方法签名：**
```java
public String getOp()
```

**返回值：**
- `String`

---

### getOpType

执行反写的操作：Save = 0, Audit = 1

**方法签名：**
```java
public WriteBackOpType getOpType()
```

**返回值：**
- `WriteBackOpType`

---

### getOriVersion

原生反写规则的版本：系统自动产生，每次保存时，都自动更新；

**方法签名：**
```java
public long getOriVersion()
```

**返回值：**
- `long`

---

### getSourceEntityNumber

源头单据

**方法签名：**
```java
public String getSourceEntityNumber()
```

**返回值：**
- `String`

---

### getSysStatus

出厂时的状态：0 = 正常；1 = 禁用；出厂时的禁用状态最优先

**方法签名：**
```java
public String getSysStatus()
```

**返回值：**
- `String`

---

### getTargetEntityNumber

下游单据

**方法签名：**
```java
public String getTargetEntityNumber()
```

**返回值：**
- `String`

---

### isNormual

判断反写规则是否正常启用

**方法签名：**
```java
public boolean isNormual()
```

**返回值：**
- `boolean`

---

### setBillCloseFieldFailStatus

回滚反写后，恢复的源单关闭状态值

**方法签名：**
```java
public void setBillCloseFieldFailStatus(String billCloseFieldFailStatus)
```

**参数说明：**
- `billCloseFieldFailStatus`: `String`

---

### setBillCloseFieldKey

源单整单关闭状态字段

**方法签名：**
```java
public void setBillCloseFieldKey(String billCloseFieldKey)
```

**参数说明：**
- `billCloseFieldKey`: `String`

---

### setBillCloseFieldSuccesStatus

达成整单关闭条件后，源单关闭状态值

**方法签名：**
```java
public void setBillCloseFieldSuccesStatus(String billCloseFieldSuccesStatus)
```

**参数说明：**
- `billCloseFieldSuccesStatus`: `String`

---

### setBillCloseType

源单整体关闭方式：AllRowsClosed(0),OneRowClosed(1);

**方法签名：**
```java
public void setBillCloseType(BillCloseType billCloseType)
```

**参数说明：**
- `billCloseType`: `BillCloseType`

---

### setCacheVersion

运行时版本，格式：yyyy-MM-dd hh:mm:ss

**方法签名：**
```java
public void setCacheVersion(String cacheVersion)
```

**参数说明：**
- `cacheVersion`: `String`

---

### setCheckVersionTimeMillis

最近一次检查版本时间

**方法签名：**
```java
public void setCheckVersionTimeMillis(long checkVersionTimeMillis)
```

**参数说明：**
- `checkVersionTimeMillis`: `long`

---

### setCloseCheckCondition

源单行关闭条件

**方法签名：**
```java
public void setCloseCheckCondition(CRCondition closeCheckCondition)
```

**参数说明：**
- `closeCheckCondition`: `CRCondition`

---

### setDistributeType

合并后反写超量分配方式：TopDown = 0, Weight = 1

**方法签名：**
```java
public void setDistributeType(DistributeType distributeType)
```

**参数说明：**
- `distributeType`: `DistributeType`

---

### setEntryCloseFieldFailStatus

回滚反写后，恢复的源单行关闭状态值

**方法签名：**
```java
public void setEntryCloseFieldFailStatus(String entryCloseFieldFailStatus)
```

**参数说明：**
- `entryCloseFieldFailStatus`: `String`

---

### setEntryCloseFieldKey

源单行关闭状态字段

**方法签名：**
```java
public void setEntryCloseFieldKey(String entryCloseFieldKey)
```

**参数说明：**
- `entryCloseFieldKey`: `String`

---

### setEntryCloseFieldSuccesStatus

达成关闭条件后，源单行关闭状态值

**方法签名：**
```java
public void setEntryCloseFieldSuccesStatus(String entryCloseFieldSuccesStatus)
```

**参数说明：**
- `entryCloseFieldSuccesStatus`: `String`

---

### setExcessCheckConditon

超额检查公式

**方法签名：**
```java
public void setExcessCheckConditon(CRCondition excessCheckConditon)
```

**参数说明：**
- `excessCheckConditon`: `CRCondition`

---

### setExcessCheckMessage

超额提示信息

**方法签名：**
```java
public void setExcessCheckMessage(LocaleString excessCheckMessage)
```

**参数说明：**
- `excessCheckMessage`: `LocaleString`

---

### setExcessCheckType

超额检查模式：StrictControl(0),CanExcessOneTime(1),CanExcellAlways(2),SelectByFormula(3)

**方法签名：**
```java
public void setExcessCheckType(ExcessCheckType excessCheckType)
```

**参数说明：**
- `excessCheckType`: `ExcessCheckType`

---

### setExcessSelectFalse

条件为假选择的超额控制模式

**方法签名：**
```java
public void setExcessSelectFalse(ExcessCheckType excessSelectFalse)
```

**参数说明：**
- `excessSelectFalse`: `ExcessCheckType`

---

### setExcessSelectTrue

条件为真时选择的超额控制模式

**方法签名：**
```java
public void setExcessSelectTrue(ExcessCheckType excessSelectTrue)
```

**参数说明：**
- `excessSelectTrue`: `ExcessCheckType`

---

### setExcessTypeSelectCondition

超额模式选择条件

**方法签名：**
```java
public void setExcessTypeSelectCondition(CRCondition excessTypeSelectCondition)
```

**参数说明：**
- `excessTypeSelectCondition`: `CRCondition`

---

### setExtVersion

扩展反写规则的版本

**方法签名：**
```java
public void setExtVersion(long extVersion)
```

**参数说明：**
- `extVersion`: `long`

---

### setName

规则的名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setOpType

执行反写的操作：Save = 0, Audit = 1

**方法签名：**
```java
public void setOpType(WriteBackOpType opType)
```

**参数说明：**
- `opType`: `WriteBackOpType`

---

### setSourceEntityNumber

源头单据

**方法签名：**
```java
public void setSourceEntityNumber(String sourceEntityNumber)
```

**参数说明：**
- `sourceEntityNumber`: `String`

---

### setTargetEntityNumber

下游单据

**方法签名：**
```java
public void setTargetEntityNumber(String targetEntityNumber)
```

**参数说明：**
- `targetEntityNumber`: `String`

---
