---
framework_version: "8.0.1"
api_class: "CellStyle"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表单元格样式时"
---

# CellStyle API 说明

## 概述
报表单元格样式，在列样式ColumnStyle基础上添加了行标识。继承自 ColumnStyle，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.CellStyle;
```

---

## 方法列表

### getColumnKey

{待补充}

**方法签名：**
```java
public String getColumnKey()
```

**返回值：**
- `String`

---

### getFieldKey

获取字段标识

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`: 字段标识

---

### getRow

获取行号

**方法签名：**
```java
public int getRow()
```

**返回值：**
- `int`: 行号

---

### setFieldKey

设置字段标识

**方法签名：**
```java
public void setFieldKey(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String` — 字段标识

---

### setRow

设置行号

**方法签名：**
```java
public void setRow(int row)
```

**参数说明：**
- `row`: `int` — 行号

---

### setStyles

把样式（背景色、前景色、字体大小）打包输出

**方法签名：**
```java
public Map<String,Object> setStyles()
```

**返回值：**
- `Map<String,Object>`: 样式参数包

---
