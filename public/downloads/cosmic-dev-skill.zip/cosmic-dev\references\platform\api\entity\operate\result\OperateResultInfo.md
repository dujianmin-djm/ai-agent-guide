---
framework_version: "8.0.1"
api_class: "OperateResultInfo"
api_package: "kd.bos.entity.operate.result"
when_to_use: "当你需要使用操作结果信息时"
---

# OperateResultInfo API 说明

## 概述
操作结果信息。继承自 OperateInfo，实现 Serializable, IOperateInfo。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.operate.result.OperateResultInfo;
```

---

## 方法列表

### getDataEntityIndex

获取批量操作数据对象实体索引

**方法签名：**
```java
public int getDataEntityIndex()
```

**返回值：**
- `int`

---

### getName

操作业务对象的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getNumber

获取单据编号

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### isPkValueIsNullOrEmpty

pk是否为空

**方法签名：**
```java
public boolean isPkValueIsNullOrEmpty()
```

**返回值：**
- `boolean`

---

### setDataEntityIndex

设置批量操作数据对象实体索引

**方法签名：**
```java
public void setDataEntityIndex(int dataEntityIndex)
```

**参数说明：**
- `dataEntityIndex`: `int`

---

### setName

设置操作业务对象的名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String` — 名称

---

### setNumber

设置单据编号

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---
