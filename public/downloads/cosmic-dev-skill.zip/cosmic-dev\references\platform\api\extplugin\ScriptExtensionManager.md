---
framework_version: "8.0.1"
api_class: "ScriptExtensionManager"
api_package: "kd.bos.extplugin"
when_to_use: "当你需要使用脚本扩展点创建器时"
---

# ScriptExtensionManager API 说明

## 概述
脚本扩展点创建器。
主要功能：查询数据。

## Import 路径
```java
import kd.bos.extplugin.ScriptExtensionManager;
```

---

## 方法列表

### load

通过编码加载脚本扩展点

**方法签名：**
```java
public Object load(String useCaseNumber)
```

**参数说明：**
- `useCaseNumber`: `String`

**返回值：**
- `Object`

---
