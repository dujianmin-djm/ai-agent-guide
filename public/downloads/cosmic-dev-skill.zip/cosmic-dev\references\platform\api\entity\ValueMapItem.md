---
framework_version: "8.0.1"
api_class: "ValueMapItem"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用列表显示下拉列表字段格式化时用时"
---

# ValueMapItem API 说明

## 概述
列表显示下拉列表字段格式化时用。实现 Serializable。
主要功能：设置属性、读取属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.ValueMapItem;
```

---

## 方法列表

### createComboItem

创建下拉项

**方法签名：**
```java
public Map<String,Object> createComboItem()
```

**返回值：**
- `Map<String,Object>`

---

### getImageKey

获取下拉项标识

**方法签名：**
```java
public String getImageKey()
```

**返回值：**
- `String`: 下拉项标识

---

### getName

获取下拉项名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`: 下拉项名称

---

### getValue

获取下拉项值

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`: 下拉项值

---

### isItemVisible

选项是否可见

**方法签名：**
```java
public boolean isItemVisible()
```

**返回值：**
- `boolean`

---

### setImageKey

设置下拉项标识

**方法签名：**
```java
public void setImageKey(String imageKey)
```

**参数说明：**
- `imageKey`: `String` — 下拉项标识

---

### setItemVisible

设置选项是否可见

**方法签名：**
```java
public void setItemVisible(boolean itemVisible)
```

**参数说明：**
- `itemVisible`: `boolean`

---

### setName

设置下拉项名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setValue

设置下拉项值

**方法签名：**
```java
public void setValue(String value)
```

**参数说明：**
- `value`: `String`

---
