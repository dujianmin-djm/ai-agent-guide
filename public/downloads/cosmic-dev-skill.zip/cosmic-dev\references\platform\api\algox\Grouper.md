---
framework_version: "8.0.1"
api_class: "Grouper"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分组后的聚合操作时"
---

# Grouper API 说明

## 概述
分组后的聚合操作。
主要功能：对分组后的数据集进行combine操作、对分组后的数据集进行combine及re、分组计数、取分组后的最大值、取分组后的最小值。

## Import 路径
```java
import kd.bos.algox.Grouper;
```

---

## 方法列表

### combineGroup

对分组后的数据集进行combine操作

**方法签名：**
```java
public DataSetX combineGroup(GroupCombineFunction function)
```

**参数说明：**
- `function`: `GroupCombineFunction` — GroupCombineFunction

**返回值：**
- `DataSetX`: DataSetX

---

### combineReduceGroup

对分组后的数据集进行combine及reduce操作

**方法签名：**
```java
public DataSetX combineReduceGroup(GroupCombineReduceFunction func)
```

**参数说明：**
- `func`: `GroupCombineReduceFunction` — GroupCombineReduceFunction

**返回值：**
- `DataSetX`: DataSetX

---

### count

**重载 1**

分组计数

**方法签名：**
```java
public DataSetX count(String field)
```

**参数说明：**
- `field`: `String` — 计数的字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

分组计数

**方法签名：**
```java
public DataSetX count(String field, String alias)
```

**参数说明：**
- `field`: `String` — 计数的字段
- `alias`: `String` — 计数后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### max

**重载 1**

取分组后的最大值

**方法签名：**
```java
public DataSetX max(String field)
```

**参数说明：**
- `field`: `String` — 取最大值的字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

取分组后的最大值

**方法签名：**
```java
public DataSetX max(String field, String alias)
```

**参数说明：**
- `field`: `String` — 取最大值的字段
- `alias`: `String` — 取最大值后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### min

**重载 1**

取分组后的最小值

**方法签名：**
```java
public DataSetX min(String field)
```

**参数说明：**
- `field`: `String` — 取最小值的字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

取分组后的最小值

**方法签名：**
```java
public DataSetX min(String field, String alias)
```

**参数说明：**
- `field`: `String` — 取最小值的字段
- `alias`: `String` — 取最小值后的字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### reduceGroup

对分组后的数据集进行reduce操作

**方法签名：**
```java
public DataSetX reduceGroup(GroupReduceFunction function)
```

**参数说明：**
- `function`: `GroupReduceFunction` — GroupReduceFunction

**返回值：**
- `DataSetX`: DataSetX

---

### sum

**重载 1**

对分组后的数据进行求和

**方法签名：**
```java
public DataSetX sum(String field)
```

**参数说明：**
- `field`: `String` — 求和的字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

对分组后的数据求和

**方法签名：**
```java
public DataSetX sum(String field, String alias)
```

**参数说明：**
- `field`: `String` — 求和字段
- `alias`: `String` — 求和后字段的别名

**返回值：**
- `DataSetX`: DataSetX

---
