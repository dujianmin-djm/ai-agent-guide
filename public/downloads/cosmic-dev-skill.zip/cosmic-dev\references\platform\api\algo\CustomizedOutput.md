---
framework_version: "8.0.1"
api_class: "CustomizedOutput"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用algox使用:在algox处理完输入的Input之后时"
---

# CustomizedOutput API 说明

## 概述
algox使用:在algox处理完输入的Input之后，会形成一个输出Output,使用方可以通过实现此接口自定义输出。。实现 Output, Closeable, Serializable, AutoCloseable。
主要功能：关闭输出、打开输出、将处理后的row数据写入到输出。

## Import 路径
```java
import kd.bos.algo.CustomizedOutput;
```

---

## 方法列表

### close

关闭输出

**方法签名：**
```java
public void close()
```

---

### open

打开输出

**方法签名：**
```java
public void open()
```

---

### write

将处理后的row数据写入到输出

**方法签名：**
```java
public void write(Object[] row)
```

**参数说明：**
- `row`: `Object[]` — 行数据

---
