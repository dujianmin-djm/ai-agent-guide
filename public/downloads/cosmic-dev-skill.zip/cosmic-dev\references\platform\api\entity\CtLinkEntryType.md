---
framework_version: "8.0.1"
api_class: "CtLinkEntryType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用关联子实体时"
---

# CtLinkEntryType API 说明

## 概述
关联子实体。继承自 EntryType。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.CtLinkEntryType;
```

---

## 方法列表

### getCtrlFieldProps

ctrlFieldProps 原始携带属性

**方法签名：**
```java
public Map<String,DynamicProperty> getCtrlFieldProps()
```

**返回值：**
- `Map<String,DynamicProperty>`

---

### getOldCtrlFieldProps

oldCtrlFieldProps 原始携带属性

**方法签名：**
```java
public Map<String,DynamicProperty> getOldCtrlFieldProps()
```

**返回值：**
- `Map<String,DynamicProperty>`

---

### getSBillIdProp

获取记录源单内码的属性

**方法签名：**
```java
public DynamicProperty getSBillIdProp()
```

**返回值：**
- `DynamicProperty`

---

### getSIdProp

源单内码属性

**方法签名：**
```java
public DynamicProperty getSIdProp()
```

**返回值：**
- `DynamicProperty`

---

### getSTableIdProp

设置记录源单内码的属性

**方法签名：**
```java
public DynamicProperty getSTableIdProp()
```

**返回值：**
- `DynamicProperty`

---

### getSaccountIdProp

源单数据中心ID

**方法签名：**
```java
public DynamicProperty getSaccountIdProp()
```

**返回值：**
- `DynamicProperty`

---

### getStenantCoceProp

源租户编码

**方法签名：**
```java
public DynamicProperty getStenantCoceProp()
```

**返回值：**
- `DynamicProperty`

---
