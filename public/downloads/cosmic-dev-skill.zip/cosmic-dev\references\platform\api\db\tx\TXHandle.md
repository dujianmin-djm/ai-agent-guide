---
framework_version: "8.0.1"
api_class: "TXHandle"
api_package: "kd.bos.db.tx"
when_to_use: "当你需要使用事务句柄时"
---

# TXHandle API 说明

## 概述
事务句柄。实现 AutoCloseable。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.db.tx.TXHandle;
```

---

## 方法列表

### close

事务关闭。

**方法签名：**
```java
public void close()
```

---

### commit

事务提交。

**方法签名：**
```java
public void commit()
```

---

### get

当前事务句柄。

**方法签名：**
```java
public static TXHandle get()
```

**返回值：**
- `TXHandle`: TXHandle

---

### getPropagation

获取事务隔离级别。

**方法签名：**
```java
public Propagation getPropagation()
```

**返回值：**
- `Propagation`

---

### isRollback

是否回滚。

**方法签名：**
```java
public boolean isRollback()
```

**返回值：**
- `boolean`: true|false

---

### markRollback

标志回滚。

**方法签名：**
```java
public void markRollback()
```

---

### setRollback

设置事务回滚。

**方法签名：**
```java
public TXHandle setRollback(boolean rollback)
```

**参数说明：**
- `rollback`: `boolean`

**返回值：**
- `TXHandle`: TXHandle

---
