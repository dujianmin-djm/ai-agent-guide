---
framework_version: "8.0.1"
api_class: "SimpleFilterRow"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤行数据时"
---

# SimpleFilterRow API 说明

## 概述
过滤行数据。实现 Cloneable, IIsvFlag。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.SimpleFilterRow;
```

---

## 方法列表

### clone

{待补充}

**方法签名：**
```java
public SimpleFilterRow clone()
```

**返回值：**
- `SimpleFilterRow`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object o)
```

**参数说明：**
- `o`: `Object`

**返回值：**
- `boolean`

---

### getBaseDataIds

获取基础资料字段的id集合

**方法签名：**
```java
public List<kd.FilterValue> getBaseDataIds()
```

**返回值：**
- `List<kd.FilterValue>`: 基础资料字段的id集合

---

### getCompareType

获取比较符

**方法签名：**
```java
public String getCompareType()
```

**返回值：**
- `String`: 比较符

---

### getCompareTypeDesc

获取比较符描述

**方法签名：**
```java
public String getCompareTypeDesc()
```

**返回值：**
- `String`: 比较符描述

---

### getEntityNumber

获取实体编码

**方法签名：**
```java
public String getEntityNumber()
```

**返回值：**
- `String`: 实体编码

---

### getFieldName

获取字段名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: 字段名

---

### getId

获取PK

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: pk

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getLeftBracket

获取左括号

**方法签名：**
```java
public String getLeftBracket()
```

**返回值：**
- `String`: 左括号

---

### getLogic

获取逻辑比较符

**方法签名：**
```java
public String getLogic()
```

**返回值：**
- `String`: 逻辑比较符

---

### getRightBracket

获取右括号

**方法签名：**
```java
public String getRightBracket()
```

**返回值：**
- `String`: 右括号

---

### getValue

获取过滤值集合

**方法签名：**
```java
public List<kd.FilterValue> getValue()
```

**返回值：**
- `List<kd.FilterValue>`: 过滤值集合

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isLock

{待补充}

**方法签名：**
```java
public boolean isLock()
```

**返回值：**
- `boolean`

---

### setBaseDataIds

设置基础资料的id集合

**方法签名：**
```java
public void setBaseDataIds(List<kd.FilterValue> baseDataIds)
```

**参数说明：**
- `baseDataIds`: `List<kd.FilterValue>` — 基础资料字段的id集合

---

### setCompareType

设置比较符

**方法签名：**
```java
public void setCompareType(String compareType)
```

**参数说明：**
- `compareType`: `String` — 比较符

---

### setCompareTypeDesc

设置比较符描述

**方法签名：**
```java
public void setCompareTypeDesc(String compareTypeDesc)
```

**参数说明：**
- `compareTypeDesc`: `String` — 比较符描述

---

### setEntityNumber

设置实体编码

**方法签名：**
```java
public void setEntityNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

---

### setFieldName

设置字段名

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String` — 字段名

---

### setId

设置PK

**方法签名：**
```java
public void setId(String value)
```

**参数说明：**
- `value`: `String` — pk

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setLeftBracket

设置左括号

**方法签名：**
```java
public void setLeftBracket(String leftBracket)
```

**参数说明：**
- `leftBracket`: `String` — 左括号

---

### setLock

{待补充}

**方法签名：**
```java
public void setLock(boolean lock)
```

**参数说明：**
- `lock`: `boolean`

---

### setLogic

设置逻辑比较符

**方法签名：**
```java
public void setLogic(String logic)
```

**参数说明：**
- `logic`: `String` — 逻辑比较符

---

### setRightBracket

设置右括号

**方法签名：**
```java
public void setRightBracket(String rightBracket)
```

**参数说明：**
- `rightBracket`: `String` — 右括号

---

### setValue

设置过滤值集合

**方法签名：**
```java
public void setValue(List<kd.FilterValue> value)
```

**参数说明：**
- `value`: `List<kd.FilterValue>` — 过滤值集合

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
