---
framework_version: "8.0.1"
api_class: "IconProp"
api_package: "kd.bos.entity.property"
when_to_use: "当你需要使用图标属性时"
---

# IconProp API 说明

## 概述
图标属性。继承自 FieldProp。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.property.IconProp;
```

---

## 方法列表

### getListColumnDesc

{待补充}

**方法签名：**
```java
public AbstractColumnDesc getListColumnDesc(ListField col)
```

**参数说明：**
- `col`: `ListField`

**返回值：**
- `AbstractColumnDesc`

---
