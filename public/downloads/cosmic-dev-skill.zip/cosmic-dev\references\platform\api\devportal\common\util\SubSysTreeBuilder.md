---
framework_version: "8.0.1"
api_class: "SubSysTreeBuilder"
api_package: "kd.bos.devportal.common.util"
when_to_use: "当你需要使用构建子系统树工具类时"
---

# SubSysTreeBuilder API 说明

## 概述
构建子系统树工具类。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.devportal.common.util.SubSysTreeBuilder;
```

---

## 方法列表

### build

子系统树执行构建方法

**方法签名：**
```java
public TreeNode build()
```

**返回值：**
- `TreeNode`: 按传入参数返回一颗树

---

### getBizAppIds

获取指定业务应用范围id集合

**方法签名：**
```java
public List<String> getBizAppIds()
```

**返回值：**
- `List<String>`

---

### getBizCloudIds

获取指定业务云范围id集合

**方法签名：**
```java
public List<String> getBizCloudIds()
```

**返回值：**
- `List<String>`

---

### getIndustryId

获取行业属性

**方法签名：**
```java
public String getIndustryId()
```

**返回值：**
- `String`

---

### getLeafType

获取叶子节点类型

**方法签名：**
```java
public TreeLeafType getLeafType()
```

**返回值：**
- `TreeLeafType`

---

### getRootNodeId

获取根节点

**方法签名：**
```java
public String getRootNodeId()
```

**返回值：**
- `String`

---

### isAdminCtrl

是否开启管理员应用范围过滤

**方法签名：**
```java
public boolean isAdminCtrl()
```

**返回值：**
- `boolean`

---

### isOnlyDeployed

是否只构建启用的应用

**方法签名：**
```java
public boolean isOnlyDeployed()
```

**返回值：**
- `boolean`

---

### isOnlyVisible

是否只构建可见的应用

**方法签名：**
```java
public boolean isOnlyVisible()
```

**返回值：**
- `boolean`

---

### isRuntime

是否获取运行时的云、应用、菜单信息

**方法签名：**
```java
public boolean isRuntime()
```

**返回值：**
- `boolean`

---

### setAdminCtrl

设置是否开启管理员应用范围过滤

**方法签名：**
```java
public void setAdminCtrl(boolean adminCtrl)
```

**参数说明：**
- `adminCtrl`: `boolean`

---

### setBizAppIds

设置指定业务应用范围id集合

**方法签名：**
```java
public void setBizAppIds(List<String> bizAppIds)
```

**参数说明：**
- `bizAppIds`: `List<String>`

---

### setBizCloudIds

设置指定业务云范围id集合

**方法签名：**
```java
public void setBizCloudIds(List<String> bizCloudIds)
```

**参数说明：**
- `bizCloudIds`: `List<String>`

---

### setIndustryId

设置行业属性

**方法签名：**
```java
public void setIndustryId(String industryId)
```

**参数说明：**
- `industryId`: `String`

---

### setLeafType

设置叶子节点类型

**方法签名：**
```java
public void setLeafType(TreeLeafType leafType)
```

**参数说明：**
- `leafType`: `TreeLeafType`

---

### setOnlyDeployed

设置是否只构建启用的应用

**方法签名：**
```java
public void setOnlyDeployed(boolean onlyDeployed)
```

**参数说明：**
- `onlyDeployed`: `boolean`

---

### setOnlyVisible

设置是否只构建可见的应用

**方法签名：**
```java
public void setOnlyVisible(boolean onlyVisible)
```

**参数说明：**
- `onlyVisible`: `boolean`

---

### setRootNodeId

设置根节点

**方法签名：**
```java
public void setRootNodeId(String rootNodeId)
```

**参数说明：**
- `rootNodeId`: `String`

---

### setRuntime

设置是否获取运行时的云、应用、菜单信息

**方法签名：**
```java
public void setRuntime(boolean runtime)
```

**参数说明：**
- `runtime`: `boolean`

---
