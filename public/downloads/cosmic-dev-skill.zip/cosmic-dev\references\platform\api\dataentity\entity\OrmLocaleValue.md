---
framework_version: "8.0.1"
api_class: "OrmLocaleValue"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用Orm专用多语言文本字段值对象时"
---

# OrmLocaleValue API 说明

## 概述
Orm专用多语言文本字段值对象。实现 ILocaleString, Serializable, ILocaleValue, Map。
主要功能：读取属性、状态判断、移除元素、设置属性。

## Import 路径
```java
import kd.bos.dataentity.entity.OrmLocaleValue;
```

---

## 方法列表

### clear

{待补充}

**方法签名：**
```java
public void clear()
```

---

### containsKey

{待补充}

**方法签名：**
```java
public boolean containsKey(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `boolean`

---

### containsValue

{待补充}

**方法签名：**
```java
public boolean containsValue(Object value)
```

**参数说明：**
- `value`: `Object`

**返回值：**
- `boolean`

---

### entrySet

{待补充}

**方法签名：**
```java
public Set<Map.Entry<String,String>> entrySet()
```

**返回值：**
- `Set<Map.Entry<String,String>>`

---

### get

{待补充}

**方法签名：**
```java
public String get(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `String`

---

### getDefaultItem

{待补充}

**方法签名：**
```java
public String getDefaultItem()
```

**返回值：**
- `String`

---

### getItem

{待补充}

**方法签名：**
```java
public String getItem(String lcid)
```

**参数说明：**
- `lcid`: `String`

**返回值：**
- `String`

---

### getLocaleValue

{待补充}

**方法签名：**
```java
public String getLocaleValue()
```

**返回值：**
- `String`

---

### getRawValue

{待补充}

**方法签名：**
```java
public String getRawValue(String lcid)
```

**参数说明：**
- `lcid`: `String`

**返回值：**
- `String`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty()
```

**返回值：**
- `boolean`

---

### keySet

{待补充}

**方法签名：**
```java
public Set<String> keySet()
```

**返回值：**
- `Set<String>`

---

### put

{待补充}

**方法签名：**
```java
public String put(String key, String value)
```

**参数说明：**
- `key`: `String`
- `value`: `String`

**返回值：**
- `String`

---

### putAll

{待补充}

**方法签名：**
```java
public void putAll(Map<? extends String,? extends String> m)
```

**参数说明：**
- `m`: `Map<? extends String,? extends String>`

---

### remove

{待补充}

**方法签名：**
```java
public String remove(Object key)
```

**参数说明：**
- `key`: `Object`

**返回值：**
- `String`

---

### setItem

{待补充}

**方法签名：**
```java
public void setItem(String lcid, String value)
```

**参数说明：**
- `lcid`: `String`
- `value`: `String`

---

### size

{待补充}

**方法签名：**
```java
public int size()
```

**返回值：**
- `int`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---

### values

{待补充}

**方法签名：**
```java
public Collection<String> values()
```

**返回值：**
- `Collection<String>`

---
