---
framework_version: "8.0.1"
api_class: "DataEntityPropertyCollection"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用实体属性集合时"
---

# DataEntityPropertyCollection API 说明

## 概述
实体属性集合。继承自 KeyedCollectionBase，实现 Serializable, IKeyedCollectionBase, List, RandomAccess, Cloneable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.DataEntityPropertyCollection;
```

---

## 方法列表

### getBitSize

获取整型压缩存放位置

**方法签名：**
```java
public int getBitSize()
```

**返回值：**
- `int`

---

### getCollectionProperties

返回属性集合中所有的集合属性

**方法签名：**
```java
public List<kd.ICollectionProperty> getCollectionProperties(boolean onlyDbProperty)
```

**参数说明：**
- `onlyDbProperty`: `boolean`

**返回值：**
- `List<kd.ICollectionProperty>`: 被检测的属性列表

---

### getComplexProperties

返回属性集合中所有的复杂属性

**方法签名：**
```java
public List<kd.IComplexProperty> getComplexProperties(boolean onlyDbProperty)
```

**参数说明：**
- `onlyDbProperty`: `boolean`

**返回值：**
- `List<kd.IComplexProperty>`: 被检测的属性列表

---

### getOtherSize

获取对象型存放位置

**方法签名：**
```java
public int getOtherSize()
```

**返回值：**
- `int`

---

### getParent

获取实体集合对象的父对象，比如单据体的父对象就是基础资料或者单据等

**方法签名：**
```java
public IDataEntityType getParent()
```

**返回值：**
- `IDataEntityType`

---

### getSimpleProperties

返回属性集合中所有的简单属性

**方法签名：**
```java
public List<kd.ISimpleProperty> getSimpleProperties(boolean onlyDbProperty)
```

**参数说明：**
- `onlyDbProperty`: `boolean`

**返回值：**
- `List<kd.ISimpleProperty>`: 被检测的属性列表

---

### setBitSize

设置整型压缩存放位置

**方法签名：**
```java
public void setBitSize(int bitSize)
```

**参数说明：**
- `bitSize`: `int` — 存放位置下标

---

### setOtherSize

设置对象型存放位置

**方法签名：**
```java
public void setOtherSize(int otherSize)
```

**参数说明：**
- `otherSize`: `int` — 存放位置下标

---
