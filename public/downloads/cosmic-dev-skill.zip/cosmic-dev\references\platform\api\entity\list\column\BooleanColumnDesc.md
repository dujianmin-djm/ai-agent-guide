---
framework_version: "8.0.1"
api_class: "BooleanColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用布尔类型列格式化时"
---

# BooleanColumnDesc API 说明

## 概述
布尔类型列格式化。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.BooleanColumnDesc;
```

---

## 方法列表

### getCheckBoxItemShowStyle

获取显示样式类型

**方法签名：**
```java
public int getCheckBoxItemShowStyle()
```

**返回值：**
- `int`

---

### getOTitle

{待补充}

**方法签名：**
```java
public LocaleString getOTitle()
```

**返回值：**
- `LocaleString`: 值为真时显示内容

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---

### getXTitle

{待补充}

**方法签名：**
```java
public LocaleString getXTitle()
```

**返回值：**
- `LocaleString`: 值为假时显示内容

---

### setCheckBoxItemShowStyle

设置显示样式类型

**方法签名：**
```java
public void setCheckBoxItemShowStyle(int checkBoxItemShowStyle)
```

**参数说明：**
- `checkBoxItemShowStyle`: `int` — 显示样式类型

---

### setOTitle

{待补充}

**方法签名：**
```java
public void setOTitle(LocaleString oTitle)
```

**参数说明：**
- `oTitle`: `LocaleString` — 值为真时显示内容

---

### setXTitle

{待补充}

**方法签名：**
```java
public void setXTitle(LocaleString xTitle)
```

**参数说明：**
- `xTitle`: `LocaleString` — 值为假时显示内容

---
