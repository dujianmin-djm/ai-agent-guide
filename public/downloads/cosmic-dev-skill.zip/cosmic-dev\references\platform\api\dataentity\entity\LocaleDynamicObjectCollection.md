---
framework_version: "8.0.1"
api_class: "LocaleDynamicObjectCollection"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用多语言分录特定的数据行集合时"
---

# LocaleDynamicObjectCollection API 说明

## 概述
多语言分录特定的数据行集合。继承自 DynamicObjectCollection，实现 Serializable, ISupportInitialize, List, RandomAccess, Cloneable。
主要功能：读取属性、设置属性、移除元素、添加元素。

## Import 路径
```java
import kd.bos.dataentity.entity.LocaleDynamicObjectCollection;
```

---

## 方法列表

### add

把对象插入到集合index的位置上

**方法签名：**
```java
public void add(int index, DynamicObject item)
```

**参数说明：**
- `index`: `int` — 从零开始的索引，应在index位置插入item
- `item`: `DynamicObject`

---

### clearValue

清除某个字段的所有语言的值

**方法签名：**
```java
public void clearValue(IDataEntityProperty inLocalProperty)
```

**参数说明：**
- `inLocalProperty`: `IDataEntityProperty` — 要处理的属性对象

---

### createLocaleValue

创建Orm专用多语言文本字段值对象

**方法签名：**
```java
public static Object createLocaleValue(LocaleDynamicObjectCollection col, DynamicSimpleProperty inLocaleProperty)
```

**参数说明：**
- `col`: `LocaleDynamicObjectCollection` — 多语言分录特定的数据行集合
- `inLocaleProperty`: `DynamicSimpleProperty` — 属性对象

**返回值：**
- `Object`

---

### findByLocaleId

返回等于当前国家语言编号的明细

**方法签名：**
```java
public boolean findByLocaleId(String localeId, RefObject<kd.DynamicObject> obj)
```

**参数说明：**
- `localeId`: `String` — 语言代码
- `obj`: `RefObject<kd.DynamicObject>` — 动态实体对象

**返回值：**
- `boolean`

---

### getCurrentLocaleValue

返回当前语言的文本

**方法签名：**
```java
public Object getCurrentLocaleValue(IDataEntityProperty inLocalProperty)
```

**参数说明：**
- `inLocalProperty`: `IDataEntityProperty` — 属性对象

**返回值：**
- `Object`

---

### getLocaleIdProperty

获取多语言的属性对象

**方法签名：**
```java
public IDataEntityProperty getLocaleIdProperty()
```

**返回值：**
- `IDataEntityProperty`

---

### getOrCreateItemByLocaleId

获取或创建指定国家语言的行

**方法签名：**
```java
public DynamicObject getOrCreateItemByLocaleId(String localeId)
```

**参数说明：**
- `localeId`: `String` — 语言代码

**返回值：**
- `DynamicObject`

---

### getValue

返回指定国家语言的值

**方法签名：**
```java
public Object getValue(IDataEntityProperty inLocalProperty, String localeId)
```

**参数说明：**
- `inLocalProperty`: `IDataEntityProperty` — 属性对象
- `localeId`: `String` — 语言代码

**返回值：**
- `Object`

---

### removeEmpty

删除所有空的行

**方法签名：**
```java
public void removeEmpty()
```

---

### removeIfEmpty

检测某个区域的所有字段是否都是空，如果是，删除此行

**方法签名：**
```java
public boolean removeIfEmpty(DynamicObject obj)
```

**参数说明：**
- `obj`: `DynamicObject` — 动态实体对象

**返回值：**
- `boolean`

---

### setCurrentLocaleValue

将新值填充到当前语言下

**方法签名：**
```java
public void setCurrentLocaleValue(IDataEntityProperty inLocalProperty, Object newValue)
```

**参数说明：**
- `inLocalProperty`: `IDataEntityProperty` — 属性对象
- `newValue`: `Object` — 新值

---

### setValue

**重载 1**

设置某个国家语言的值，当这个国家语言的行不存在时，会自动创建行

**方法签名：**
```java
public void setValue(IDataEntityProperty inLocalProperty, String localeId, Object newValue)
```

**参数说明：**
- `inLocalProperty`: `IDataEntityProperty`
- `localeId`: `String` — 语言代码
- `newValue`: `Object` — 新值

---

**重载 2**

一次性对某个属性设置所有语言的值

**方法签名：**
```java
public void setValue(DynamicProperty inLocalProperty, ILocaleString values)
```

**参数说明：**
- `inLocalProperty`: `DynamicProperty` — 要处理的属性对象
- `values`: `ILocaleString` — 枚举列表，罗列了所有的时区及对应的数据

---
