---
framework_version: "8.0.1"
api_class: "ConvertDataService"
api_package: "kd.bos.botp"
when_to_use: "当你需要使用转换数据服务时"
---

# ConvertDataService API 说明

## 概述
转换数据服务。
主要功能：查询数据。

## Import 路径
```java
import kd.bos.botp.ConvertDataService;
```

---

## 方法列表

### loadAllConvertPaths

加载全部转换路线

**方法签名：**
```java
public List<ConvertPath> loadAllConvertPaths()
```

**返回值：**
- `List<ConvertPath>`

---

### loadConvertBills

加载全部目标单据信息，用于下推操作，列出可选目标单

**方法签名：**
```java
public List<ConvertBill> loadConvertBills(String entityNumber, ConvertOpType opType)
```

**参数说明：**
- `entityNumber`: `String`
- `opType`: `ConvertOpType`

**返回值：**
- `List<ConvertBill>`: 可转换的目标单列表

---

### loadConvertRuleIdsByAppId

根据应用内码获取应用下所有的转换规则内码  （convertrulemetadata中bizappid为源单所在的应用，该接口也是按规则中源单所在应用进行分类）

**方法签名：**
```java
public List<String> loadConvertRuleIdsByAppId(String appId)
```

**参数说明：**
- `appId`: `String`

**返回值：**
- `List<String>`

---

### loadTableDefine

**重载 1**

根据单据和实体，加载其表格定义对象，从而获知其对应的表格编码

**方法签名：**
```java
public TableDefine loadTableDefine(String entityNumber, String entityKey)
```

**参数说明：**
- `entityNumber`: `String` — 单据
- `entityKey`: `String` — 实体

**返回值：**
- `TableDefine`

---

**重载 2**

根据表格编码，加载其表格定义对象，从而获知其对应的单据与实体

**方法签名：**
```java
public TableDefine loadTableDefine(Long tableId)
```

**参数说明：**
- `tableId`: `Long` — 表格编码

**返回值：**
- `TableDefine`

---

### loadThirdConvertBills

加载第三方目标单据信息，用于下推操作

**方法签名：**
```java
public List<ConvertBill> loadThirdConvertBills(String sourceEntityNumber, String targetEntityNumber)
```

**参数说明：**
- `sourceEntityNumber`: `String`
- `targetEntityNumber`: `String`

**返回值：**
- `List<ConvertBill>`: 可转换的目标单列表

---
