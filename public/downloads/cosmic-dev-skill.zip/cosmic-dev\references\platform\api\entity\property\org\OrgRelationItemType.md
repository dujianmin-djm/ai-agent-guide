---
framework_version: "8.0.1"
api_class: "OrgRelationItemType"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用业务单元间业务协作类型时"
---

# OrgRelationItemType API 说明

## 概述
业务单元间业务协作类型。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgRelationItemType;
```

---

## 方法列表

### getFromtype

获取委托方组织职能编码

**方法签名：**
```java
public String getFromtype()
```

**返回值：**
- `String`: 组织职能编码

---

### getFromtypename

获取委托方组织职能名称

**方法签名：**
```java
public String getFromtypename()
```

**返回值：**
- `String`: 组织职能名称

---

### getName

获取业务协作类型的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 名称

---

### getNumber

获取业务协作类型的编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`: 编码

---

### getTotype

获取受托方组织职能编码

**方法签名：**
```java
public String getTotype()
```

**返回值：**
- `String`: 组织职能编码

---

### getTotypename

获取受托方组织职能名称

**方法签名：**
```java
public String getTotypename()
```

**返回值：**
- `String`: 组织职能名称

---

### setFromtype

设置委托方组织职能编码

**方法签名：**
```java
public void setFromtype(String fromtype)
```

**参数说明：**
- `fromtype`: `String` — 组织职能编码

---

### setFromtypename

设置委托方组织职能名称

**方法签名：**
```java
public void setFromtypename(String fromtypename)
```

**参数说明：**
- `fromtypename`: `String` — 组织职能名称

---

### setName

设置业务协作类型的名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String` — 名称

---

### setNumber

设置业务协作类型的编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String` — 编码

---

### setTotype

设置受托方组织职能编码

**方法签名：**
```java
public void setTotype(String totype)
```

**参数说明：**
- `totype`: `String` — 组织职能编码

---

### setTotypename

设置受托方组织职能名称

**方法签名：**
```java
public void setTotypename(String totypename)
```

**参数说明：**
- `totypename`: `String` — 组织职能名称

---
