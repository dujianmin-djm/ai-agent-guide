---
framework_version: "8.0.1"
api_class: "ReportColumnGroup"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列分组信息时"
---

# ReportColumnGroup API 说明

## 概述
报表列分组信息。继承自 AbstractReportColumn，实现 IColumnGroup, Serializable, IBaseColumn。
主要功能：设置属性、状态判断、读取属性、创建对象。

## Import 路径
```java
import kd.bos.entity.report.ReportColumnGroup;
```

---

## 方法列表

### createColumn

打包客户端报表列元数据信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`: 返回客户端报表列元数据信息

---

### getChildren

获取分组下面的所有报表列

**方法签名：**
```java
public List<kd.AbstractReportColumn> getChildren()
```

**返回值：**
- `List<kd.AbstractReportColumn>`: 报表列

---

### getFieldKey

获取字段标识

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`: 字段标识

---

### getTextAlign

获取控件中字体的布局方式

**方法签名：**
```java
public String getTextAlign()
```

**返回值：**
- `String`: 控件中字体的布局方式

---

### isGroupCollapsible

获取字段分组是否可以折叠

**方法签名：**
```java
public boolean isGroupCollapsible()
```

**返回值：**
- `boolean`

---

### isGroupDefaultCollapse

获取字段分组是否默认折叠

**方法签名：**
```java
public boolean isGroupDefaultCollapse()
```

**返回值：**
- `boolean`

---

### isHeaderMerge

是否合并列头
 当该属性为true时，分组下的子列列头将合并为分组名称展示

**方法签名：**
```java
public boolean isHeaderMerge()
```

**返回值：**
- `boolean`

---

### isMerge

获取合并显示

**方法签名：**
```java
public boolean isMerge()
```

**返回值：**
- `boolean`: 返回true合并显示

---

### setFieldKey

设置字段标识

**方法签名：**
```java
public void setFieldKey(String key)
```

**参数说明：**
- `key`: `String` — 字段标识

---

### setGroupCollapsible

设置字段分组是否可以折叠

**方法签名：**
```java
public void setGroupCollapsible(boolean groupCollapsible)
```

**参数说明：**
- `groupCollapsible`: `boolean` — 是否可以折叠

---

### setGroupDefaultCollapse

设置字段分组是否默认折叠

**方法签名：**
```java
public void setGroupDefaultCollapse(boolean groupDefaultCollapse)
```

**参数说明：**
- `groupDefaultCollapse`: `boolean` — 默认折叠

---

### setHeaderMerge

设置是否合并列头

**方法签名：**
```java
public void setHeaderMerge(boolean headerMerge)
```

**参数说明：**
- `headerMerge`: `boolean` — true表示合并列头，false表示不合并

---

### setMerge

设置合并显示,合并后数据会展示成一列,优先级高于setHeaderMerge

**方法签名：**
```java
public void setMerge(boolean isMerge)
```

**参数说明：**
- `isMerge`: `boolean` — 设置为true合并显示

---

### setTextAlign

设置控件中字体的布局方式

**方法签名：**
```java
public void setTextAlign(String textAlign)
```

**参数说明：**
- `textAlign`: `String` — 字体的布局方式

---
