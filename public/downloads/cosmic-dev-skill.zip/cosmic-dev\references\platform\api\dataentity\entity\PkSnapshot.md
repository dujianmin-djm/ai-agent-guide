---
framework_version: "8.0.1"
api_class: "PkSnapshot"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用单个表对象的快照对象时"
---

# PkSnapshot API 说明

## 概述
单个表对象的快照对象。实现 Serializable。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.entity.PkSnapshot;
```

---

## 方法列表

### isLoaded

数据是否完整加载

**方法签名：**
```java
public boolean isLoaded()
```

**返回值：**
- `boolean`

---

### setLoaded

设置数据完整加载标记 （内部使用）

**方法签名：**
```java
public void setLoaded(boolean loaded)
```

**参数说明：**
- `loaded`: `boolean` — 是否完整加载

---
