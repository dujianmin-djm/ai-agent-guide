---
framework_version: "8.0.1"
api_class: "DataSetX"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分布式计算数据集操作接口时"
---

# DataSetX API 说明

## 概述
分布式计算数据集操作接口。
主要功能：添加元素、状态判断、移除元素、设置属性。

## Import 路径
```java
import kd.bos.algox.DataSetX;
```

---

## 方法列表

### addFields

增加字段

**方法签名：**
```java
public DataSetX addFields(Field[] fields, Object[] values)
```

**参数说明：**
- `fields`: `Field[]` — 字段名数组
- `values`: `Object[]` — 字段值数组

**返回值：**
- `DataSetX`: DataSetX

---

### coGroup

分组协作
 
 是一种特殊的join，coGroup后必须调用CoGroupDataSetX#on方法，用于确定分组join的key。

**方法签名：**
```java
public CoGroupDataSetX coGroup(DataSetX dataSet, CoGroupFunction func)
```

**参数说明：**
- `dataSet`: `DataSetX` — 需要join的数据集
- `func`: `CoGroupFunction` — 分组协作函数

**返回值：**
- `CoGroupDataSetX`: CoGroupDataSetX

---

### combineGroup

对整个数据集进行combine操作

**方法签名：**
```java
public DataSetX combineGroup(GroupCombineFunction func)
```

**参数说明：**
- `func`: `GroupCombineFunction` — GroupCombineFunction

**返回值：**
- `DataSetX`: DataSetX

---

### combineReduceGroup

对整个数据集进行combine和reduce操作

**方法签名：**
```java
public DataSetX combineReduceGroup(GroupCombineReduceFunction func)
```

**参数说明：**
- `func`: `GroupCombineReduceFunction` — GroupCombineReduceFunction

**返回值：**
- `DataSetX`: DataSetX

---

### count

**重载 1**

对整个数据集计数

**方法签名：**
```java
public DataSetX count(String field)
```

**参数说明：**
- `field`: `String` — 计数字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

对整个数据集计数

**方法签名：**
```java
public DataSetX count(String field, String alias)
```

**参数说明：**
- `field`: `String` — 计数字段
- `alias`: `String` — 计数后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### distinct

去重

**方法签名：**
```java
public DataSetX distinct(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 按字段列表去重复

**返回值：**
- `DataSetX`: DataSetX

---

### filter

**重载 1**

过滤数据集： 类似于SQL中的WHERE操作，返回满足条件的列

**方法签名：**
```java
public DataSetX filter(String expr)
```

**参数说明：**
- `expr`: `String` — 表达式，例如： id > 50

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

过滤数据集： 类似于SQL中的WHERE操作，返回满足条件的列

**方法签名：**
```java
public DataSetX filter(String expr, Map<String,Object> params)
```

**参数说明：**
- `expr`: `String` — 带参数的表达式，例如： id > var
- `params`: `Map<String,Object>` — 参数，例如： var -> 50

**返回值：**
- `DataSetX`: DataSetX

---

**重载 3**

过滤数据集： 类似于SQL中的WHERE操作，返回满足条件的列

**方法签名：**
```java
public DataSetX filter(FilterFunction func)
```

**参数说明：**
- `func`: `FilterFunction` — 自定义过滤函数

**返回值：**
- `DataSetX`: DataSetX

---

### flatMap

一对多映射，一行RowX生成多行RowX

**方法签名：**
```java
public DataSetX flatMap(FlatMapFunction func)
```

**参数说明：**
- `func`: `FlatMapFunction` — 映射函数

**返回值：**
- `DataSetX`: DataSetX

---

### fullJoin

全外连接

**方法签名：**
```java
public JoinDataSetX fullJoin(DataSetX right)
```

**参数说明：**
- `right`: `DataSetX` — DataSetX

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### groupBy

分组

**方法签名：**
```java
public Grouper groupBy(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 按字段分组

**返回值：**
- `Grouper`: Grouper

---

### isSingleParallel

返回节点并行度是否为1

**方法签名：**
```java
public boolean isSingleParallel()
```

**返回值：**
- `boolean`: boolean

---

### join

内连接

**方法签名：**
```java
public JoinDataSetX join(DataSetX right)
```

**参数说明：**
- `right`: `DataSetX` — DataSetX

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### leftJoin

左连接

**方法签名：**
```java
public JoinDataSetX leftJoin(DataSetX right)
```

**参数说明：**
- `right`: `DataSetX` — DataSetX

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### map

一对一映射，一行RowX生成一行新的RowX

**方法签名：**
```java
public DataSetX map(MapFunction func)
```

**参数说明：**
- `func`: `MapFunction` — 映射函数

**返回值：**
- `DataSetX`: DataSetX

---

### max

**重载 1**

对整个数据集取最大值

**方法签名：**
```java
public DataSetX max(String field)
```

**参数说明：**
- `field`: `String` — 取最大值字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

对整个数据集取最大值

**方法签名：**
```java
public DataSetX max(String field, String alias)
```

**参数说明：**
- `field`: `String` — 取最大值字段
- `alias`: `String` — 取最大值后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### min

**重载 1**

对整个数据集取最小值

**方法签名：**
```java
public DataSetX min(String field)
```

**参数说明：**
- `field`: `String` — 取最小值字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

对整个数据集取最小值

**方法签名：**
```java
public DataSetX min(String field, String alias)
```

**参数说明：**
- `field`: `String` — 取最小值字段
- `alias`: `String` — 取最小值后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### orderBy

排序

**方法签名：**
```java
public DataSetX orderBy(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 排序的字段列表，例如： id, name desc, age asc

**返回值：**
- `DataSetX`: DataSetX

---

### output

任务结果输出
 
 Job必须有Output，运行时Output全部正常结束，Job才结束。

**方法签名：**
```java
public void output(Output output)
```

**参数说明：**
- `output`: `Output` — 输出

---

### partitionByHash

主动根据字段进行hash将数据集重新分区

**方法签名：**
```java
public DataSetX partitionByHash(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 分区的字段

**返回值：**
- `DataSetX`: DataSetX

---

### reduceGroup

对整个数据集进行reduce操作

**方法签名：**
```java
public DataSetX reduceGroup(GroupReduceFunction func)
```

**参数说明：**
- `func`: `GroupReduceFunction` — GroupReduceFunction

**返回值：**
- `DataSetX`: DataSetX

---

### removeFields

删除字段

**方法签名：**
```java
public DataSetX removeFields(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 字段名数组

**返回值：**
- `DataSetX`: DataSetX

---

### rightJoin

右连接

**方法签名：**
```java
public JoinDataSetX rightJoin(DataSetX right)
```

**参数说明：**
- `right`: `DataSetX` — DataSetX

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### select

返回指定列

**方法签名：**
```java
public DataSetX select(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 要返回的列

**返回值：**
- `DataSetX`: DataSetX

---

### setSingleParallel

设置节点并行度

**方法签名：**
```java
public void setSingleParallel(boolean value)
```

**参数说明：**
- `value`: `boolean` — true： 并行度为1 false： 配置值

---

### sum

**重载 1**

对整个数据集求和

**方法签名：**
```java
public DataSetX sum(String field)
```

**参数说明：**
- `field`: `String` — 求和字段

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

对整个数据集求和

**方法签名：**
```java
public DataSetX sum(String field, String alias)
```

**参数说明：**
- `field`: `String` — 求和字段
- `alias`: `String` — 求和后字段别名

**返回值：**
- `DataSetX`: DataSetX

---

### top

取top行

**方法签名：**
```java
public DataSetX top(int n)
```

**参数说明：**
- `n`: `int` — top的行数

**返回值：**
- `DataSetX`: DataSetX

---

### union

合并数据集，类似SQL中的union

**方法签名：**
```java
public DataSetX union(DataSetX dataSet)
```

**参数说明：**
- `dataSet`: `DataSetX` — 需要合并的数据集

**返回值：**
- `DataSetX`: DataSetX

---
