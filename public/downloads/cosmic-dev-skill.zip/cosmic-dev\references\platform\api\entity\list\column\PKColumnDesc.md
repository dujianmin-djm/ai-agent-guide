---
framework_version: "8.0.1"
api_class: "PKColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用主键类型格式化处理时"
---

# PKColumnDesc API 说明

## 概述
主键类型格式化处理。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.PKColumnDesc;
```

---

## 方法列表

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject o)
```

**参数说明：**
- `o`: `DynamicObject`

**返回值：**
- `Object`

---
