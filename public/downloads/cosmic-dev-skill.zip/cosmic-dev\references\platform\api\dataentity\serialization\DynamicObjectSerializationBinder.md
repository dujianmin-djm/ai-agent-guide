---
framework_version: "8.0.1"
api_class: "DynamicObjectSerializationBinder"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用为动态实体在序列化和反序列化时时"
---

# DynamicObjectSerializationBinder API 说明

## 概述
为动态实体在序列化和反序列化时，使用的绑定器。继承自 DcBinder。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.dataentity.serialization.DynamicObjectSerializationBinder;
```

---

## 方法列表

### bindJSONReadAction

{待补充}

**方法签名：**
```java
public ISetJsonValueAction bindJSONReadAction(Class<?> dataType, ISetJsonValueAction defaultAction)
```

**参数说明：**
- `dataType`: `Class<?>`
- `defaultAction`: `ISetJsonValueAction`

**返回值：**
- `ISetJsonValueAction`

---

### createInstance

{待补充}

**方法签名：**
```java
public Object createInstance(IDataEntityType dt)
```

**参数说明：**
- `dt`: `IDataEntityType`

**返回值：**
- `Object`

---

### tryBindToType

根据节点的名称确定数据类型

**方法签名：**
```java
public IDataEntityType tryBindToType(String elementName, Map<String,String> attributes)
```

**参数说明：**
- `elementName`: `String` — 节点的名称
- `attributes`: `Map<String,String>` — 额外的附属Attribute信息

**返回值：**
- `IDataEntityType`: 如果找到返回true，否则返回false

---
