---
framework_version: "8.0.1"
api_class: "DynamicObject"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用动态实体对象,对应ORM的持久化对象时"
---

# DynamicObject API 说明

## 概述
动态实体对象,对应ORM的持久化对象。继承自 DataEntityBase，实现 Serializable, INotifyPropertyChanged, ISupportInitialize, IDataEntityBase, IObjectWithParent。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.entity.DynamicObject;
```

---

## 方法列表

### OnPropertyChanged

触发属性改变事件

**方法签名：**
```java
public void OnPropertyChanged(PropertyChangeEvent e)
```

**参数说明：**
- `e`: `PropertyChangeEvent` — 属性改变的事件参数

---

### containsProperty

返回属性是否存在

**方法签名：**
```java
public final boolean containsProperty(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `boolean`: 属性是否存在

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### get

**重载 1**

返回此实体中指定属性名称的值

**方法签名：**
```java
public final Object get(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `Object`: 返回此属性名称的值

---

**重载 2**

返回此实体中指定位置的数据

**方法签名：**
```java
public final Object get(int index)
```

**参数说明：**
- `index`: `int` — 属性所在的位置

**返回值：**
- `Object`: 返回此位置的值

---

**重载 3**

返回此实体中指定属性对象的数据

**方法签名：**
```java
public final Object get(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `Object`: 返回此字段的值

---

### getBigDecimal

**重载 1**

获取下级属性值，把值转为BigDecimal类型返回

**方法签名：**
```java
public BigDecimal getBigDecimal(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `BigDecimal`: BigDecimal对象

---

**重载 2**

获取下级属性值，把值转为BigDecimal类型返回

**方法签名：**
```java
public BigDecimal getBigDecimal(String propertyName, boolean enableNull)
```

**参数说明：**
- `propertyName`: `String` — 属性名称
- `enableNull`: `boolean` — 是否允许为空

**返回值：**
- `BigDecimal`: BigDecimal对象

---

**重载 3**

获取下级属性值，把值转为BigDecimal类型返回

**方法签名：**
```java
public BigDecimal getBigDecimal(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `BigDecimal`: BigDecimal对象

---

**重载 4**

获取下级属性值，把值转为BigDecimal类型返回

**方法签名：**
```java
public BigDecimal getBigDecimal(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `BigDecimal`: BigDecimal对象

---

### getBoolean

**重载 1**

获取下级属性值，把值转为Boolean类型返回

**方法签名：**
```java
public boolean getBoolean(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `boolean`: Boolean对象

---

**重载 2**

获取下级属性值，把值转为Boolean类型返回

**方法签名：**
```java
public boolean getBoolean(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `boolean`: Boolean对象

---

**重载 3**

获取下级属性值，把值转为Boolean类型返回

**方法签名：**
```java
public boolean getBoolean(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `boolean`: Boolean对象

---

### getDataEntityType

返回当前实体的数据类型

**方法签名：**
```java
public IDataEntityType getDataEntityType()
```

**返回值：**
- `IDataEntityType`: 当前实体的数据类型

---

### getDate

**重载 1**

获取下级属性值，把值转为Date类型返回

**方法签名：**
```java
public Date getDate(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `Date`: Date对象

---

**重载 2**

获取下级属性值，把值转为Date类型返回

**方法签名：**
```java
public Date getDate(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `Date`: Date对象

---

**重载 3**

获取下级属性值，把值转为Date类型返回

**方法签名：**
```java
public Date getDate(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `Date`: Date对象

---

### getDynamicObject

**重载 1**

获取下级属性值，把值转为动态实体对象类型返回

**方法签名：**
```java
public DynamicObject getDynamicObject(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `DynamicObject`: 动态实体对象

---

**重载 2**

获取下级属性值，把值转为动态实体对象类型返回

**方法签名：**
```java
public DynamicObject getDynamicObject(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `DynamicObject`: 动态实体对象

---

**重载 3**

获取下级属性值，把值转为动态实体对象类型返回

**方法签名：**
```java
public DynamicObject getDynamicObject(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `DynamicObject`: 动态实体对象

---

### getDynamicObjectCollection

**重载 1**

根据属性名称获取动态实体集合对象

**方法签名：**
```java
public DynamicObjectCollection getDynamicObjectCollection(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `DynamicObjectCollection`: 动态实体集合对象

---

**重载 2**

根据序号获取动态实体集合对象

**方法签名：**
```java
public DynamicObjectCollection getDynamicObjectCollection(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `DynamicObjectCollection`: 动态实体集合对象

---

**重载 3**

根据实体属性对象获取动态实体集合对象

**方法签名：**
```java
public DynamicObjectCollection getDynamicObjectCollection(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `DynamicObjectCollection`: 动态实体集合对象

---

### getDynamicObjectType

返回当前实体的动态实体类型

**方法签名：**
```java
public final DynamicObjectType getDynamicObjectType()
```

**返回值：**
- `DynamicObjectType`: 当前实体的动态实体类型

---

### getInt

**重载 1**

获取下级属性值，把值转为Integer类型返回

**方法签名：**
```java
public int getInt(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `int`: Integer对象

---

**重载 2**

获取下级属性值，把值转为Integer类型返回

**方法签名：**
```java
public int getInt(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `int`: Integer对象

---

**重载 3**

获取下级属性值，把值转为Integer类型返回

**方法签名：**
```java
public int getInt(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `int`: Integer对象

---

### getLastDirty

获取最后一次修改脏标志，缓存反序列化回来为空，属性修改后变化，用于缓存同步比较

**方法签名：**
```java
public BitSet getLastDirty()
```

**返回值：**
- `BitSet`

---

### getLocaleString

**重载 1**

获取下级属性值，把值转为多语言字符串类型返回

**方法签名：**
```java
public ILocaleString getLocaleString(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `ILocaleString`: 多语言字符串

---

**重载 2**

获取下级属性值，把值转为多语言字符串类型返回

**方法签名：**
```java
public ILocaleString getLocaleString(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `ILocaleString`: 多语言字符串

---

**重载 3**

获取下级属性值，把值转为多语言字符串类型返回

**方法签名：**
```java
public ILocaleString getLocaleString(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `ILocaleString`: 多语言字符串

---

### getLong

**重载 1**

获取下级属性值，把值转为Long类型返回

**方法签名：**
```java
public long getLong(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `long`: Long对象

---

**重载 2**

获取下级属性值，把值转为Long类型返回

**方法签名：**
```java
public long getLong(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `long`: Long对象

---

**重载 3**

获取下级属性值，把值转为Long类型返回

**方法签名：**
```java
public long getLong(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `long`: Long对象

---

### getString

**重载 1**

获取下级属性值，把值转为字符串类型返回

**方法签名：**
```java
public String getString(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `String`: 字符串

---

**重载 2**

获取下级属性值，把值转为字符串类型返回

**方法签名：**
```java
public String getString(int index)
```

**参数说明：**
- `index`: `int` — 序号

**返回值：**
- `String`: 字符串

---

**重载 3**

获取下级属性值，把值转为字符串类型返回

**方法签名：**
```java
public String getString(IDataEntityProperty dp)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象

**返回值：**
- `String`: 字符串

---

### isQueryObj

是否查询对象

**方法签名：**
```java
public boolean isQueryObj()
```

**返回值：**
- `boolean`

---

### isShared

是否缓存共享的对象

**方法签名：**
```java
public boolean isShared()
```

**返回值：**
- `boolean`

---

### set

**重载 1**

设置实体中指定属性名称的值

**方法签名：**
```java
public final void set(String propertyName, Object value)
```

**参数说明：**
- `propertyName`: `String` — 属性名称
- `value`: `Object` — 值对象

---

**重载 2**

设置实体中指定位置的值

**方法签名：**
```java
public final void set(int index, Object value)
```

**参数说明：**
- `index`: `int` — 序号
- `value`: `Object` — 值对象

---

**重载 3**

设置实体中指定实体属性对象的值

**方法签名：**
```java
public final void set(IDataEntityProperty dp, Object value)
```

**参数说明：**
- `dp`: `IDataEntityProperty` — 实体属性对象
- `value`: `Object` — 值对象

---

### setShared

设置为共享型实体缓存

**方法签名：**
```java
public void setShared(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否共享

---

### toString

重写toString方法，返回动态对象类型的名称+存储器的toString

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
