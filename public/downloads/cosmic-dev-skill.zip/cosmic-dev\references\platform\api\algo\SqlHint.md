---
framework_version: "8.0.1"
api_class: "SqlHint"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用用来注册自定义函数,在DataSet执行sql语句时时"
---

# SqlHint API 说明

## 概述
用来注册自定义函数,在DataSet执行sql语句时，可以从sqlHint中获取自定义聚合函数进行处理。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.SqlHint;
```

---

## 方法列表

### containsAggFunction

是否包含某个聚合函数

**方法签名：**
```java
public boolean containsAggFunction(String name)
```

**参数说明：**
- `name`: `String` — 函数名称

**返回值：**
- `boolean`: 是否包含某个聚合函数

---

### getAggFunction

通过名称获取聚合函数

**方法签名：**
```java
public CustomAggFunction<?> getAggFunction(String name)
```

**参数说明：**
- `name`: `String` — 函数名称

**返回值：**
- `CustomAggFunction<?>`: 聚合函数

---

### registerAggFunction

注册一个聚合函数

**方法签名：**
```java
public void registerAggFunction(CustomAggFunction<?> func)
```

**参数说明：**
- `func`: `CustomAggFunction<?>` — 自定义聚合函数

---
