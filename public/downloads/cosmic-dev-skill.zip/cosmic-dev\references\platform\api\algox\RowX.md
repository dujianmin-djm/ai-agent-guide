---
framework_version: "8.0.1"
api_class: "RowX"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用DataSetX中的一行数据时"
---

# RowX API 说明

## 概述
DataSetX中的一行数据。实现 RowFeature, Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.algox.RowX;
```

---

## 方法列表

### copy

拷贝一份新的RowX

**方法签名：**
```java
public RowX copy()
```

**返回值：**
- `RowX`: new RowX

---

### get

获取行中的单个值

**方法签名：**
```java
public final Object get(int index)
```

**参数说明：**
- `index`: `int` — 数组下标，从0开始

**返回值：**
- `Object`: 值

---

### getBigDecimal

获取BigDecimal类型的值

**方法签名：**
```java
public BigDecimal getBigDecimal(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `BigDecimal`: value

---

### getBoolean

获取boolean类型的值

**方法签名：**
```java
public Boolean getBoolean(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Boolean`: value

---

### getDate

获取date类型的值

**方法签名：**
```java
public Date getDate(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Date`: value

---

### getDouble

获取double类型的值

**方法签名：**
```java
public Double getDouble(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Double`: value

---

### getInteger

获取int类型的值

**方法签名：**
```java
public Integer getInteger(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Integer`: value

---

### getLong

获取long类型的值

**方法签名：**
```java
public Long getLong(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Long`: value

---

### getString

获取string类型的值

**方法签名：**
```java
public String getString(int index)
```

**参数说明：**
- `index`: `int` — 下标

**返回值：**
- `String`: value

---

### getTimestamp

获取timestamp类型的值

**方法签名：**
```java
public Timestamp getTimestamp(int index)
```

**参数说明：**
- `index`: `int` — 数组下标

**返回值：**
- `Timestamp`: value

---

### set

设置行中的单个值

**方法签名：**
```java
public final void set(int index, Object value)
```

**参数说明：**
- `index`: `int` — 数组下标，从0开始
- `value`: `Object` — 值

---

### setValues

设置行的值

**方法签名：**
```java
public final void setValues(Object[] values)
```

**参数说明：**
- `values`: `Object[]`

---

### size

获取一行数据的个数

**方法签名：**
```java
public final int size()
```

**返回值：**
- `int`: size

---

### toMap

将行数据转为map返回

**方法签名：**
```java
public Map<String,Object> toMap(RowMeta rowMeta, Map<String,Object> reuse)
```

**参数说明：**
- `rowMeta`: `RowMeta` — map的key
- `reuse`: `Map<String,Object>` — map

**返回值：**
- `Map<String,Object>`: map

---

### toString

toString

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: string

---

### values

获取数据数组

**方法签名：**
```java
public final Object[] values()
```

**返回值：**
- `Object[]`: row

---
