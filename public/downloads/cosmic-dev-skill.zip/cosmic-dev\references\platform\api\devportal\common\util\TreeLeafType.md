---
framework_version: "8.0.1"
api_class: "TreeLeafType"
api_package: "kd.bos.devportal.common.util"
when_to_use: "当你需要使用子系统数据节点类型枚举时"
---

# TreeLeafType API 说明

## 概述
子系统数据节点类型枚举。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.devportal.common.util.TreeLeafType;
```

---

## 方法列表

### getValue

{待补充}

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`: 类型值

---
