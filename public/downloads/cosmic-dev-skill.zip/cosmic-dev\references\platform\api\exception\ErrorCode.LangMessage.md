---
framework_version: "8.0.1"
api_class: "ErrorCode.LangMessage"
api_package: "kd.bos.exception.ErrorCode"
when_to_use: "当你需要使用多语言异常信息类时"
---

# ErrorCode.LangMessage API 说明

## 概述
多语言异常信息类。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.exception.ErrorCode.ErrorCode.LangMessage;
```

---

## 方法列表

### getDesc

获取多语言异常描述

**方法签名：**
```java
public String getDesc()
```

**返回值：**
- `String`

---

### getKey

获取key键

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getProject

获取项目名

**方法签名：**
```java
public String getProject()
```

**返回值：**
- `String`

---
