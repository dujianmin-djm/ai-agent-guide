---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "approved"
---

# 表单插件开发参考

> 覆盖：AbstractFormPlugin / AbstractBillPlugIn / AbstractBasePlugIn
> 来源：`kg/output/platform/form/framework/FORM_FRAMEWORK.md`

## 生命周期事件（执行顺序）

```
preOpenForm → initialize → registerListener →
afterCreateNewData（仅新增）/ afterLoadData（仅编辑）→
afterCopyData（仅复制）→ beforeBindData → afterBindData
→（运行中）propertyChanged / itemClick / beforeItemClick / afterAddRow / afterDeleteRow / beforeDoOperation / afterDoOperation
→ beforeClosed → destroy
```

| 事件 | 触发时机 | 典型用途 |
|------|---------|---------|
| `preOpenForm` | 界面打开之前，FormView 未创建 | 拦截打开、设置打开参数 |
| `initialize` | FormView 创建后初始化 | 初始化插件成员变量 |
| `registerListener` | 注册监听阶段 | 注册按钮/F7/Tab 监听 |
| `afterCreateNewData` | 仅新增时，数据包创建后 | 设置默认字段值、组织、用户 |
| `afterLoadData` | 仅编辑时，数据库数据加载后 | 读取数据做额外初始化 |
| `afterCopyData` | 仅复制时，数据包复制后 | 清空不应复制的字段 |
| `beforeBindData` | 控件绑定数据之前 | 注册分录行监听（EntryGrid） |
| `afterBindData` | 控件绑定数据之后 | 控制控件显隐/启用/初始值 |
| `propertyChanged` | 字段值改变时（前端 postBack） | 字段联动、动态过滤 |
| `itemClick` | 工具栏按钮点击 | 打开页面、执行操作 |
| `beforeItemClick` | 操作按钮执行前 | 前置校验、取消操作 |
| `beforeDoOperation` | 保存/提交/审核等操作前 | 准备操作参数，前置检查与控制 |
| `afterDoOperation` | 操作完成后 | 刷新、联动业务 |
| `closedCallBack` | 弹窗子页面关闭后 | 接收子页面回传数据 |
| `beforeClosed` | 页面关闭之前 | 关闭前确认 |
| `destroy` | 页面销毁后 | 清理资源 |

## 类结构模板

```java
package {isv}.{module}.formplugin;

import java.util.EventObject;
import kd.bos.dataentity.entity.DynamicObject;
import kd.bos.entity.datamodel.IDataModel;
import kd.bos.form.events.ItemClickEvent;
import kd.bos.form.plugin.AbstractFormPlugin;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

/**
 * {功能描述}
 * Author: {author}
 * Date: {yyyy-MM-dd}
 */
public class XxxFormPlugin extends AbstractFormPlugin {
    private static final Log logger = LogFactory.getLog(XxxFormPlugin.class);
    private static final String FIELD_XXX = "fieldKey";    // 字段标识常量

    @Override
    public void registerListener(EventObject e) {
        super.registerListener(e);
        addItemClickListeners("tbmain");    // 注册工具栏监听
        // addClickListeners("btnKey");    // 注册普通按钮监听
    }

    @Override
    public void afterCreateNewData(EventObject e) {
        super.afterCreateNewData(e);
        // 设置默认值
    }

    @Override
    public void afterBindData(EventObject e) {
        super.afterBindData(e);
        // 控件状态初始化
    }

    @Override
    public void propertyChanged(kd.bos.entity.datamodel.events.PropertyChangedArgs e) {
        super.propertyChanged(e);
        String key = e.getProperty().getName();
        if (FIELD_XXX.equals(key)) {
            // 字段联动逻辑
        }
    }

    @Override
    public void itemClick(ItemClickEvent evt) {
        super.itemClick(evt);
        String itemKey = evt.getItemKey();
        if ("btnCustom".equals(itemKey)) {
            // 按钮点击逻辑
        }
    }
}
```

## 单据插件（AbstractBillPlugIn）差异

- 继承 `kd.bos.form.plugin.AbstractBillPlugIn` 而非 `AbstractFormPlugin`
- 拥有 `billstatus`（单据状态）字段：`A`=创建、`B`=审批中、`C`=已审核、`D`=已关闭
- `beforeItemClick` 常用于校验操作前置条件
- 分录体操作：`afterAddRow`、`afterDeleteRow`、`afterMoveRow`

## 基础资料插件（AbstractBasePlugIn）差异

- 继承 `kd.bos.form.plugin.AbstractBasePlugIn`
- 常实现 `BeforeF7SelectListener` 接口来过滤 F7

## 分录操作模式

```java
// 获取当前行
int rowIndex = getModel().getEntryCurrentRowIndex("entryEntity");

// 获取行数据对象
DynamicObject row = getModel().getEntryRowEntity("entryEntity", rowIndex);

// 读写分录字段
Object val = getModel().getValue("entryField", rowIndex);
getModel().setValue("entryField", value, rowIndex);

// 遍历所有分录行
int rowCount = getModel().getEntryRowCount("entryEntity");
for (int i = 0; i < rowCount; i++) {
    DynamicObject r = getModel().getEntryRowEntity("entryEntity", i);
    // ...
}
```

### 分录字段 vs 单头字段的控件操作（重要）

**分录字段与单头字段的 setEnable / setVisible API 签名不同，禁止混用：**

| 操作目标 | setEnable | setVisible |
|---------|-----------|-----------|
| 单头字段 | `getView().setEnable(Boolean, String[])` | `getView().setVisible(Boolean, String[])` |
| 分录字段（指定行） | `getView().setEnable(Boolean, int rowIndex, String[])` | `getView().setVisible(Boolean, int rowIndex, String[])` |

锁定分录某列所有行需遍历设置：

```java
int rowCount = getModel().getEntryRowCount("entryEntity");
for (int i = 0; i < rowCount; i++) {
    getView().setEnable(Boolean.FALSE, i, new String[]{"entryFieldKey"});
}
```

> **注意**：用单头 API 操作分录字段不会报错但**不生效**，属于静默失败，难以排查。

