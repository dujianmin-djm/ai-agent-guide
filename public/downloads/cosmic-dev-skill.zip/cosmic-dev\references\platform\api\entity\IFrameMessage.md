---
framework_version: "8.0.1"
api_class: "IFrameMessage"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用IFrame信息对象时"
---

# IFrameMessage API 说明

## 概述
IFrame信息对象。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.IFrameMessage;
```

---

## 方法列表

### getContent

获取内容

**方法签名：**
```java
public Object getContent()
```

**返回值：**
- `Object`

---

### getOrigin

获取origin

**方法签名：**
```java
public String getOrigin()
```

**返回值：**
- `String`

---

### getType

获取类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### setContent

设置内容

**方法签名：**
```java
public void setContent(Object content)
```

**参数说明：**
- `content`: `Object`

---

### setOrigin

设置origin

**方法签名：**
```java
public void setOrigin(String origin)
```

**参数说明：**
- `origin`: `String`

---

### setType

设置类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---
