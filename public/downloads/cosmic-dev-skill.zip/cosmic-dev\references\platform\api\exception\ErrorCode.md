---
framework_version: "8.0.1"
api_class: "ErrorCode"
api_package: "kd.bos.exception"
when_to_use: "当你需要使用错误码时"
---

# ErrorCode API 说明

## 概述
错误码。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.exception.ErrorCode;
```

---

## 方法列表

### getCode

获取错误码

**方法签名：**
```java
public String getCode()
```

**返回值：**
- `String`

---

### getLangMessage

获取多语言异常信息

**方法签名：**
```java
public ErrorCode.LangMessage getLangMessage()
```

**返回值：**
- `ErrorCode.LangMessage`

---

### getMessage

获取错误信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### of

仅支持bos资源进行多语言处理，适用于已有的静态ErrorCode多语言改造，其他场景请传入当前语言的desc构建ErrorCode  ErrorCode(String errorCode, String message)

**方法签名：**
```java
public static ErrorCode of(String errorCode, String project, String key, String desc, boolean staticResource)
```

**参数说明：**
- `errorCode`: `String`
- `project`: `String`
- `key`: `String`
- `desc`: `String`
- `staticResource`: `boolean`

**返回值：**
- `ErrorCode`

---
