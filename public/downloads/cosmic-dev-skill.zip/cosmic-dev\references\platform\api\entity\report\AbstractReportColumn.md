---
framework_version: "8.0.1"
api_class: "AbstractReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列表列信息抽象基类时"
---

# AbstractReportColumn API 说明

## 概述
报表列表列信息抽象基类。实现 IBaseColumn, Serializable。
主要功能：设置属性、读取属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.report.AbstractReportColumn;
```

---

## 方法列表

### createColumn

设置报表列运行时元数据信息

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`

---

### getCaption

获取报表列名称

**方法签名：**
```java
public LocaleString getCaption()
```

**返回值：**
- `LocaleString`

---

### getCtlTips

字段显示tips

**方法签名：**
```java
public Tips getCtlTips()
```

**返回值：**
- `Tips`

---

### getTableHeaderCellBackColor

获取表头单元格背景色

**方法签名：**
```java
public String getTableHeaderCellBackColor()
```

**返回值：**
- `String`

---

### getUserFormat

获取用户格式化数据

**方法签名：**
```java
public FormatObject getUserFormat()
```

**返回值：**
- `FormatObject`

---

### isHideSingleColumnRow

获取是否允许隐藏只有列的表头行

**方法签名：**
```java
public boolean isHideSingleColumnRow()
```

**返回值：**
- `boolean`

---

### setCaption

设置报表列名称

**方法签名：**
```java
public void setCaption(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString` — 列名称

---

### setCtlTips

设置字段显示tips，可配置
 内容可以为纯文本或者单据Id

**方法签名：**
```java
public void setCtlTips(Tips ctlTips)
```

**参数说明：**
- `ctlTips`: `Tips` — 字段显示tips

---

### setHideSingleColumnRow

设置是否允许隐藏只有列的表头行: True: 隐藏(默认), False: 不隐藏

**方法签名：**
```java
public void setHideSingleColumnRow(boolean hideSingleColumnRow)
```

**参数说明：**
- `hideSingleColumnRow`: `boolean` — 是否隐私

---

### setTableHeaderCellBackColor

设置表头单元格背景色

**方法签名：**
```java
public void setTableHeaderCellBackColor(String tableHeaderCellBackColor)
```

**参数说明：**
- `tableHeaderCellBackColor`: `String` — 表头单元格背景色

---

### setUserFormat

设置用户格式化数据

**方法签名：**
```java
public void setUserFormat(FormatObject userFormat)
```

**参数说明：**
- `userFormat`: `FormatObject` — 格式化信息

---

### toString

获取报表列当前语言名称

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
