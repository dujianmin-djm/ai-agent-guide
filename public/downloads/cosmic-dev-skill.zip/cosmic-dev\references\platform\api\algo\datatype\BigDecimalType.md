---
framework_version: "8.0.1"
api_class: "BigDecimalType"
api_package: "kd.bos.algo.datatype"
when_to_use: "当你需要使用Algo中的数据类型,对应Java类型为BigDecimal时"
---

# BigDecimalType API 说明

## 概述
Algo中的数据类型,对应Java类型为BigDecimal。继承自 FractionalType，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.datatype.BigDecimalType;
```

---

## 方法列表

### getJavaType

获取对应的Java类型

**方法签名：**
```java
public Class<?> getJavaType()
```

**返回值：**
- `Class<?>`: 对应的Java类型

---

### getPrecision

获取精度

**方法签名：**
```java
public int getPrecision()
```

**返回值：**
- `int`: 精度

---

### getScale

获取范围（小数位数）

**方法签名：**
```java
public int getScale()
```

**返回值：**
- `int`: 范围

---
