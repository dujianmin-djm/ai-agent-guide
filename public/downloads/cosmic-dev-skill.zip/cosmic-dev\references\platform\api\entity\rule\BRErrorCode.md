---
framework_version: "8.0.1"
api_class: "BRErrorCode"
api_package: "kd.bos.entity.rule"
when_to_use: "当你需要使用表单业务规则（或界面规则）执行异常编码时"
---

# BRErrorCode API 说明

## 概述
表单业务规则（或界面规则）执行异常编码。
主要功能：状态判断。

## Import 路径
```java
import kd.bos.entity.rule.BRErrorCode;
```

---

## 方法列表

### isBRErrorCode

判断异常是否为表单业务规则执行异常

**方法签名：**
```java
public static boolean isBRErrorCode(ErrorCode errorCode)
```

**参数说明：**
- `errorCode`: `ErrorCode` — 异常编码对象

**返回值：**
- `boolean`: 如果是表单规则执行异常，返回true

---
