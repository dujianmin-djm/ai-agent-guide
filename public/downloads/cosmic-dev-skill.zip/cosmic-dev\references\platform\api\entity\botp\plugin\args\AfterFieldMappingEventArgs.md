---
framework_version: "8.0.1"
api_class: "AfterFieldMappingEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用目标字段赋值完毕后事件：插件可以在此基础上时"
---

# AfterFieldMappingEventArgs API 说明

## 概述
目标字段赋值完毕后事件：插件可以在此基础上，继续填写目标字段值。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterFieldMappingEventArgs;
```

---

## 方法列表

### getFldProperties

源单字段，与数据包属性对应字典，可以据此到源单数据包中读取字段值

**方法签名：**
```java
public Map<String,DynamicProperty> getFldProperties()
```

**返回值：**
- `Map<String,DynamicProperty>`

---

### getTargetExtDataEntitySet

生成的目标单数据包

**方法签名：**
```java
public ExtendedDataEntitySet getTargetExtDataEntitySet()
```

**返回值：**
- `ExtendedDataEntitySet`

---

### setTargetExtDataEntitySet

设置生成的目标单空数据包

**方法签名：**
```java
public void setTargetExtDataEntitySet(ExtendedDataEntitySet targetExtDataEntitySet)
```

**参数说明：**
- `targetExtDataEntitySet`: `ExtendedDataEntitySet` — 生成的目标单空数据包

---
