---
framework_version: "8.0.1"
api_class: "DynamicPropertyCollection"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用实体的属性集合时"
---

# DynamicPropertyCollection API 说明

## 概述
实体的属性集合。继承自 DataEntityPropertyCollection，实现 Serializable, IKeyedCollectionBase, List, RandomAccess, Cloneable。
主要功能：添加元素、移除元素。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicPropertyCollection;
```

---

## 方法列表

### add

**重载 1**

{待补充}

**方法签名：**
```java
public boolean add(IDataEntityProperty property)
```

**参数说明：**
- `property`: `IDataEntityProperty`

**返回值：**
- `boolean`

---

**重载 2**

{待补充}

**方法签名：**
```java
public void add(int index, IDataEntityProperty element)
```

**参数说明：**
- `index`: `int`
- `element`: `IDataEntityProperty`

---

### addAll

**重载 1**

{待补充}

**方法签名：**
```java
public boolean addAll(Collection<? extends IDataEntityProperty> c)
```

**参数说明：**
- `c`: `Collection<? extends IDataEntityProperty>`

**返回值：**
- `boolean`

---

**重载 2**

{待补充}

**方法签名：**
```java
public boolean addAll(int index, Collection<? extends IDataEntityProperty> c)
```

**参数说明：**
- `index`: `int`
- `c`: `Collection<? extends IDataEntityProperty>`

**返回值：**
- `boolean`

---

### remove

**重载 1**

{待补充}

**方法签名：**
```java
public boolean remove(Object element)
```

**参数说明：**
- `element`: `Object`

**返回值：**
- `boolean`

---

**重载 2**

{待补充}

**方法签名：**
```java
public IDataEntityProperty remove(int index)
```

**参数说明：**
- `index`: `int`

**返回值：**
- `IDataEntityProperty`

---

### removeAll

{待补充}

**方法签名：**
```java
public boolean removeAll(Collection<?> c)
```

**参数说明：**
- `c`: `Collection<?>`

**返回值：**
- `boolean`

---

### removeIf

{待补充}

**方法签名：**
```java
public boolean removeIf(Predicate<? super IDataEntityProperty> filter)
```

**参数说明：**
- `filter`: `Predicate<? super IDataEntityProperty>`

**返回值：**
- `boolean`

---
