---
framework_version: "8.0.1"
api_class: "Algo"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用此类可以用来创建algo上下文信息、DataSetBuilder、DataSet、CacheDataSet等时"
---

# Algo API 说明

## 概述
此类可以用来创建algo上下文信息、DataSetBuilder、DataSet、CacheDataSet等。。
主要功能：创建对象、读取属性、移除元素。

## Import 路径
```java
import kd.bos.algo.Algo;
```

---

## 方法列表

### closeAllDataSet

关闭当前线程的所有DataSet
 
 注意：
 谨慎使用，这会关闭当前线程的所有DataSet，这有可能会关闭其他地方不属于自己逻辑的DataSet，影响别的逻辑!

**方法签名：**
```java
public static void closeAllDataSet()
```

---

### create

创建Algo对象，此对象用来创建DataSet等操作

**方法签名：**
```java
public static Algo create(String algoKey)
```

**参数说明：**
- `algoKey`: `String` — 用来标记不同Algo对象的标识，用来进行内部进行监控DataSet的不同来源

**返回值：**
- `Algo`: Algo

---

### createCachedDataSetBuilder

创建缓存结果集的Builder

**方法签名：**
```java
public CachedDataSet.Builder createCachedDataSetBuilder(RowMeta rowMeta, CacheHint hint)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据
- `hint`: `CacheHint` — 创建缓存结果集时的提示，可以设置缓存过期时间等信息

**返回值：**
- `CachedDataSet.Builder`: CachedDataSet.Builder

---

### createDataSet

**重载 1**

使用一个集合,元数据创建DataSet，建议使用DataSetBuilder构造更好

**方法签名：**
```java
public abstract DataSet createDataSet(Collection<Object[]> rowList, RowMeta rowMeta)
```

**参数说明：**
- `rowList`: `Collection<Object[]>` — 集合数据
- `rowMeta`: `RowMeta` — 元数据

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

使用一个迭代器Iterator，元数据创建DataSet。

**方法签名：**
```java
public abstract DataSet createDataSet(Iterator<Object[]> iterator, RowMeta rowMeta)
```

**参数说明：**
- `iterator`: `Iterator<Object[]>` — 迭代器
- `rowMeta`: `RowMeta` — 元数据

**返回值：**
- `DataSet`: DataSet

---

**重载 3**

使用一个迭代器Iterable，元数据创建DataSet。

**方法签名：**
```java
public abstract DataSet createDataSet(Iterable<Object[]> iterator, RowMeta rowMeta)
```

**参数说明：**
- `iterator`: `Iterable<Object[]>` — 迭代器
- `rowMeta`: `RowMeta` — 元数据

**返回值：**
- `DataSet`: DataSet

---

**重载 4**

使用ResultSet 创建DataSet

**方法签名：**
```java
public abstract DataSet createDataSet(ResultSet rs)
```

**参数说明：**
- `rs`: `ResultSet` — 数据库结果集

**返回值：**
- `DataSet`: DataSet

---

**重载 5**

使用ResultSet和元数据创建DataSet

**方法签名：**
```java
public abstract DataSet createDataSet(ResultSet rs, RowMeta rowMeta)
```

**参数说明：**
- `rs`: `ResultSet` — 数据库结果集
- `rowMeta`: `RowMeta` — 元数据

**返回值：**
- `DataSet`: DataSet

---

**重载 6**

使用Input源创建DataSet，这个输入源可以是kd.bos.algo.input.OrmInput，kd.bos.algo.input.DbInput等，或者自己实现一个Input。

**方法签名：**
```java
public abstract DataSet createDataSet(Input[] inputs)
```

**参数说明：**
- `inputs`: `Input[]` — 输入源

**返回值：**
- `DataSet`: DataSet

---

### createDataSetBuilder

创建DataSetBuilder，可再使用它创建DataSet。

**方法签名：**
```java
public abstract DataSetBuilder createDataSetBuilder(RowMeta rowMeta)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据

**返回值：**
- `DataSetBuilder`: DataSetBuilder

---

### getCacheDataSet

获取缓存过的CachedDataSet

**方法签名：**
```java
public static CachedDataSet getCacheDataSet(String cacheId)
```

**参数说明：**
- `cacheId`: `String` — 缓存id

**返回值：**
- `CachedDataSet`: CachedDataSet

---

### newContext

创建一个Algo上下文kd.bos.algo.AlgoContext

**方法签名：**
```java
public static AlgoContext newContext()
```

**返回值：**
- `AlgoContext`: AlgoContext

---

### removeCacheDataSet

根据缓存id删除缓存DataSet

**方法签名：**
```java
public static void removeCacheDataSet(String cacheId)
```

**参数说明：**
- `cacheId`: `String` — 缓存id

---
