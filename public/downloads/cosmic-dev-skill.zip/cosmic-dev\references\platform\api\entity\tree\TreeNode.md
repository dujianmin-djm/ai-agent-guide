---
framework_version: "8.0.1"
api_class: "TreeNode"
api_package: "kd.bos.entity.tree"
when_to_use: "当你需要使用树形控件节点时"
---

# TreeNode API 说明

## 概述
树形控件节点。实现 Serializable。
主要功能：读取属性、设置属性、状态判断、添加元素。

## Import 路径
```java
import kd.bos.entity.tree.TreeNode;
```

---

## 方法列表

### Parse

Map 转 TreeNode

**方法签名：**
```java
public static TreeNode Parse(String rootParentId, Map<String,Object> map, String idKey, String textKey, String itemsKey)
```

**参数说明：**
- `rootParentId`: `String` — 父节点标识
- `map`: `Map<String,Object>` — 传入节点数据包，用Key-Value存储节点的属性值
- `idKey`: `String` — 传入的节点数据包中，存储节点标识属性的Key值
- `textKey`: `String` — 节点数据包中，存储节点显示内容属性的Key值
- `itemsKey`: `String` — 节点数据包中，存储节点子节点的Key值

**返回值：**
- `TreeNode`: 返回转换成功的节点

---

### addChild

**重载 1**

添加单个子节点

**方法签名：**
```java
public TreeNode addChild(TreeNode node)
```

**参数说明：**
- `node`: `TreeNode` — 子节点

**返回值：**
- `TreeNode`: 返回当前节点，方便链式操作

---

**重载 2**

特定位置添加单个子节点

**方法签名：**
```java
public TreeNode addChild(int i, TreeNode node)
```

**参数说明：**
- `i`: `int`
- `node`: `TreeNode` — 子节点

**返回值：**
- `TreeNode`: 返回当前节点，方便链式操作

---

### addChildren

添加多个子节点

**方法签名：**
```java
public TreeNode addChildren(List<kd.TreeNode> nodes)
```

**参数说明：**
- `nodes`: `List<kd.TreeNode>` — 子节点集合

**返回值：**
- `TreeNode`: 返回当前节点，方便链式操作

---

### deleteChildNode

递归删除子节点

**方法签名：**
```java
public TreeNode deleteChildNode(String id)
```

**参数说明：**
- `id`: `String` — 子节点标识

**返回值：**
- `TreeNode`: 删除节点的上一级节点

---

### getChildPath

获取子节点路径

**方法签名：**
```java
public List<String> getChildPath(String id)
```

**参数说明：**
- `id`: `String` — 子节点标识

**返回值：**
- `List<String>`: 返回子节点所有的上级节点标识集合，逐层往下排列

---

### getChildPathNodes

获取子节点路径

**方法签名：**
```java
public List<kd.TreeNode> getChildPathNodes(String id)
```

**参数说明：**
- `id`: `String` — 子节点标识

**返回值：**
- `List<kd.TreeNode>`: 返回子节点所有的上级节点集合，逐层往下排列

---

### getChildren

返回子节点集合

**方法签名：**
```java
public List<kd.TreeNode> getChildren()
```

**返回值：**
- `List<kd.TreeNode>`: 返回null表示无子节点；返回空集合表示子节点还未加载

---

### getChildrenAttr

获取子节点的一些属性。在这里设置，所有子节点都会生效

**方法签名：**
```java
public Map<String,Object> getChildrenAttr()
```

**返回值：**
- `Map<String,Object>`

---

### getColor

获取颜色

**方法签名：**
```java
public String getColor()
```

**返回值：**
- `String`: 颜色

---

### getData

返回附加数据

**方法签名：**
```java
public Object getData()
```

**返回值：**
- `Object`: 附加数据

---

### getIcon

获取节点图片

**方法签名：**
```java
public String getIcon()
```

**返回值：**
- `String`: 节点图片

---

### getId

返回节点标识

**方法签名：**
```java
public final String getId()
```

**返回值：**
- `String`: 节点标识

---

### getImg

获取图片路径

**方法签名：**
```java
public String getImg()
```

**返回值：**
- `String`: img

---

### getIsOpened

返回节点是否默认展开

**方法签名：**
```java
public boolean getIsOpened()
```

**返回值：**
- `boolean`: 返回true-默认展开

---

### getLabelPara

获取节点的标签参数包

**方法签名：**
```java
public List<Map<String,String>> getLabelPara()
```

**返回值：**
- `List<Map<String,String>>`: 返回客户端树形控件使用的参数包

---

### getLabelShowType

获取标签的显示风格

**方法签名：**
```java
public int getLabelShowType()
```

**返回值：**
- `int`: 0：鼠标移动到节点时显示  1：显示在节点右侧(名称后)

---

### getLongNumber

获取或返回长编码

**方法签名：**
```java
public String getLongNumber()
```

**返回值：**
- `String`: 返回长编码

---

### getLongText

返回节点长名称

**方法签名：**
```java
public final String getLongText()
```

**返回值：**
- `String`: 长名称

---

### getNodeLevel

获取节点的层级，没有找到返回-1

**方法签名：**
```java
public int getNodeLevel(String id, int startLevel)
```

**参数说明：**
- `id`: `String` — 节点标识
- `startLevel`: `int` — 开始层级

**返回值：**
- `int`: 返回节点的层级

---

### getParentid

返回父节点标识

**方法签名：**
```java
public final String getParentid()
```

**返回值：**
- `String`: 父节点标识

---

### getSuffixIconProps

树节点后缀小图标属性

**方法签名：**
```java
public SuffixIconProps getSuffixIconProps()
```

**返回值：**
- `SuffixIconProps`

---

### getText

返回节点显示内容

**方法签名：**
```java
public final String getText()
```

**返回值：**
- `String`: 显示内容

---

### getTreeNode

**重载 1**

递归查找id所在节点（准确匹配）

**方法签名：**
```java
public TreeNode getTreeNode(String id)
```

**参数说明：**
- `id`: `String` — 节点标识

**返回值：**
- `TreeNode`: 返回查到的节点

---

**重载 2**

递归查找id所在节点（准确匹配）

**方法签名：**
```java
public TreeNode getTreeNode(String id, int maxLevel)
```

**参数说明：**
- `id`: `String` — 节点标识
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `TreeNode`: 返回查到的节点

---

### getTreeNodeByText

递归查找text所在节点（模糊匹配）

**方法签名：**
```java
public TreeNode getTreeNodeByText(String text, int maxLevel)
```

**参数说明：**
- `text`: `String` — 节点显示内容
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `TreeNode`: 返回第一个查到的节点

---

### getTreeNodeListById

递归查找模糊匹配id所有节点

**方法签名：**
```java
public List<kd.TreeNode> getTreeNodeListById(List<kd.TreeNode> treeNodes, String id, int maxLevel)
```

**参数说明：**
- `treeNodes`: `List<kd.TreeNode>` — 输出找到的节点集合
- `id`: `String` — 节点标识
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `List<kd.TreeNode>`: 返回所有找到的节点

---

### getTreeNodeListByText

**重载 1**

递归查找text所在节点（模糊匹配）

**方法签名：**
```java
public List<kd.TreeNode> getTreeNodeListByText(List<kd.TreeNode> treeNodes, String text, int maxLevel)
```

**参数说明：**
- `treeNodes`: `List<kd.TreeNode>` — 输出所有匹配的节点
- `text`: `String` — 节点显示内容
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `List<kd.TreeNode>`: 返回所有模糊匹配的树节点集合

---

**重载 2**

递归查找text所在节点（模糊匹配）

**方法签名：**
```java
public List<kd.TreeNode> getTreeNodeListByText(List<kd.TreeNode> treeNodes, String text, Consumer<kd.TreeNode> childrenLoader, int maxLevel)
```

**参数说明：**
- `treeNodes`: `List<kd.TreeNode>` — 输出所有匹配的节点
- `text`: `String` — 节点显示内容
- `childrenLoader`: `Consumer<kd.TreeNode>` — 子节点加载实现：在递归时，如果发现子节点未加载，会通知本对象加载子节点
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `List<kd.TreeNode>`: 返回所有模糊匹配的树节点集合

---

### getType

返回节点类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`: 节点类型

---

### isCheckable

节点是否可选

**方法签名：**
```java
public boolean isCheckable()
```

**返回值：**
- `boolean`

---

### isDisabled

本节点是否禁用

**方法签名：**
```java
public boolean isDisabled()
```

**返回值：**
- `boolean`: 返回true-禁用

---

### isExpend

节点是否展开

**方法签名：**
```java
public boolean isExpend()
```

**返回值：**
- `boolean`: 返回true-展开

---

### isLeaf

本节点是否叶子节点（即无下级节点）

**方法签名：**
```java
public boolean isLeaf()
```

**返回值：**
- `boolean`: 返回true-是叶子节点

---

### iterate

遍历所有节点

**方法签名：**
```java
public void iterate(int maxLevel, Consumer<kd.TreeNode> callback)
```

**参数说明：**
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）
- `callback`: `Consumer<kd.TreeNode>` — 回调函数，可以传个lambda表达式

---

### setCheckable

设置节点是否可选

**方法签名：**
```java
public void setCheckable(boolean checkable)
```

**参数说明：**
- `checkable`: `boolean` — 设置为true可选

---

### setChildren

设置子节点集合

**方法签名：**
```java
public void setChildren(List<kd.TreeNode> arrayList)
```

**参数说明：**
- `arrayList`: `List<kd.TreeNode>` — 设置为null-无子节点；设置为空集合标识子节点还未加载

---

### setChildrenAttr

设置子节点的一些属性。在这里设置，所有子节点都会生效

**方法签名：**
```java
public void setChildrenAttr(Map<String,Object> childrenAttr)
```

**参数说明：**
- `childrenAttr`: `Map<String,Object>`

---

### setColor

设置颜色

**方法签名：**
```java
public void setColor(String color)
```

**参数说明：**
- `color`: `String` — 颜色

---

### setData

设置附加数据

**方法签名：**
```java
public void setData(Object data)
```

**参数说明：**
- `data`: `Object` — 附加数据

---

### setDisabled

设置节点是否禁用

**方法签名：**
```java
public void setDisabled(boolean disabled)
```

**参数说明：**
- `disabled`: `boolean` — 设置为true-禁用

---

### setExpend

设置节点是否展开

**方法签名：**
```java
public void setExpend(boolean isExpend)
```

**参数说明：**
- `isExpend`: `boolean` — 设置为true-展开

---

### setIcon

设置节点图片

**方法签名：**
```java
public void setIcon(String icon)
```

**参数说明：**
- `icon`: `String` — 节点图片

---

### setId

设置节点标识

**方法签名：**
```java
public final void setId(String value)
```

**参数说明：**
- `value`: `String` — 节点标识

---

### setImg

设置图片路径 可传完整路径也可传相对路径

**方法签名：**
```java
public void setImg(String img)
```

**参数说明：**
- `img`: `String`

---

### setIsOpened

设置节点是否默认展开

**方法签名：**
```java
public void setIsOpened(boolean isOpened)
```

**参数说明：**
- `isOpened`: `boolean` — 设为true-默认展开

---

### setLabelPara

设置节点的标签，自动转为客户端控件使用的参数包

**方法签名：**
```java
public void setLabelPara(List<kd.TreeNodeLabel> labelPara)
```

**参数说明：**
- `labelPara`: `List<kd.TreeNodeLabel>` — 标签

---

### setLabelShowType

设置标签的显示风格

**方法签名：**
```java
public void setLabelShowType(int labelShowType)
```

**参数说明：**
- `labelShowType`: `int` — 0：鼠标移动到节点时显示  1：显示在节点右侧(名称后)

---

### setLeaf

设置本节点是否叶子节点

**方法签名：**
```java
public void setLeaf(boolean isLeaf)
```

**参数说明：**
- `isLeaf`: `boolean` — 设置为true是叶子节点

---

### setLongNumber

设置长编码：使用#LNUMBERDLM分割的多节编码

**方法签名：**
```java
public void setLongNumber(String longNumber)
```

**参数说明：**
- `longNumber`: `String` — 长编码

---

### setLongText

设置节点长名称

**方法签名：**
```java
public final void setLongText(String value)
```

**参数说明：**
- `value`: `String` — 长名称

---

### setParentid

设置父节点标识

**方法签名：**
```java
public final void setParentid(String value)
```

**参数说明：**
- `value`: `String` — 父节点标识

---

### setSuffixIconProps

设置树节点后缀小图标属性

**方法签名：**
```java
public void setSuffixIconProps(SuffixIconProps suffixIconProps)
```

**参数说明：**
- `suffixIconProps`: `SuffixIconProps`

---

### setText

设置节点显示内容

**方法签名：**
```java
public final void setText(String value)
```

**参数说明：**
- `value`: `String` — 显示内容

---

### setType

设置节点类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String` — 节点类型

---

### toString

转换为字符串输出，含节点标识、显示内容

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
