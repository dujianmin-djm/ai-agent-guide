---
framework_version: "8.0.1"
api_class: "FilterCondition"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用通用过滤元数据时"
---

# FilterCondition API 说明

## 概述
通用过滤元数据。
主要功能：设置属性、读取属性、添加元素、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.FilterCondition;
```

---

## 方法列表

### addFilterRow

添加过滤元数据

**方法签名：**
```java
public void addFilterRow(SimpleFilterRow simpleFilterRow)
```

**参数说明：**
- `simpleFilterRow`: `SimpleFilterRow` — 过滤元数据

---

### createMetaData

将过滤元数据转为ListMap

**方法签名：**
```java
public List<Map<String,Object>> createMetaData()
```

**返回值：**
- `List<Map<String,Object>>`: 元数据转化后的ListMap

---

### getFilter

获取解析过后的过滤表达式

**方法签名：**
```java
public String getFilter()
```

**返回值：**
- `String`: 解析过后的过滤表达式

---

### getFilterRow

获取元数据行信息

**方法签名：**
```java
public List<kd.SimpleFilterRow> getFilterRow()
```

**返回值：**
- `List<kd.SimpleFilterRow>`: 元数据行信息

---

### isForList

获取是否应用到列表

**方法签名：**
```java
public boolean isForList()
```

**返回值：**
- `boolean`: 是否应用到列表

---

### setFilter

设置过滤表达式

**方法签名：**
```java
public void setFilter(String filter)
```

**参数说明：**
- `filter`: `String` — 过滤表达式

---

### setFilterRow

设置元数据行信息

**方法签名：**
```java
public void setFilterRow(List<kd.SimpleFilterRow> filterRow)
```

**参数说明：**
- `filterRow`: `List<kd.SimpleFilterRow>` — 元数据行信息

---

### setForList

设置是否应用到列表

**方法签名：**
```java
public void setForList(boolean forList)
```

**参数说明：**
- `forList`: `boolean` — 是否应用到列表

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
