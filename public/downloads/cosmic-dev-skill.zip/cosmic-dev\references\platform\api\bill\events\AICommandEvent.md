---
framework_version: "8.0.1"
api_class: "AICommandEvent"
api_package: "kd.bos.bill.events"
when_to_use: "当你需要使用AI指令事件参数时"
---

# AICommandEvent API 说明

## 概述
AI指令事件参数。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.bill.events.AICommandEvent;
```

---

## 方法列表

### getCommand

获取 AI 指令参数

**方法签名：**
```java
public AICommand getCommand()
```

**返回值：**
- `AICommand`: AI 指令参数

---

### getResult

获取 AI 指令事件结果

**方法签名：**
```java
public ApiResult getResult()
```

**返回值：**
- `ApiResult`: AI 指令事件结果

---

### setCommand

设置 AI 指令参数

**方法签名：**
```java
public void setCommand(AICommand cmd)
```

**参数说明：**
- `cmd`: `AICommand` — AI 指令参数

---

### setResult

设置 AI 指令事件结果

**方法签名：**
```java
public void setResult(ApiResult result)
```

**参数说明：**
- `result`: `ApiResult` — AI 指令事件结果

---
