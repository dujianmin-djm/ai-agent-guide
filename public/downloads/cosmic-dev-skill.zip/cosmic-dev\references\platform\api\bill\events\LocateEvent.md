---
framework_version: "8.0.1"
api_class: "LocateEvent"
api_package: "kd.bos.bill.events"
when_to_use: "当你需要使用移动端视图层插件事件参数时"
---

# LocateEvent API 说明

## 概述
移动端视图层插件事件参数。继承自 EventObject，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.bill.events.LocateEvent;
```

---

## 方法列表

### getMobLocation

返回移动位置

**方法签名：**
```java
public MobLocation getMobLocation()
```

**返回值：**
- `MobLocation`: 移动位置

---
