---
framework_version: "8.0.1"
api_class: "ValidateContext"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用校验上下文相关信息时"
---

# ValidateContext API 说明

## 概述
校验上下文相关信息。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.validate.ValidateContext;
```

---

## 方法列表

### getBillEntityType

获取单据主实体，包括了完整的字段；可能比单据数据包中的属性多

**方法签名：**
```java
public MainEntityType getBillEntityType()
```

**返回值：**
- `MainEntityType`: MainEntityType 主实体

---

### getDataEntityLength

获取传入数据的数量

**方法签名：**
```java
public int getDataEntityLength()
```

**返回值：**
- `int`

---

### getDimAssistFldKey

验权辅字段

**方法签名：**
```java
public String getDimAssistFldKey()
```

**返回值：**
- `String`: String

---

### getDimFldKey

验权主字段

**方法签名：**
```java
public String getDimFldKey()
```

**返回值：**
- `String`: String

---

### getDimType

验权维度 组织、体系

**方法签名：**
```java
public String getDimType()
```

**返回值：**
- `String`

---

### getEntityNumber

获取单据主实体编码

**方法签名：**
```java
public String getEntityNumber()
```

**返回值：**
- `String`: String

---

### getExtendedDataEntitySet

待校验的单据数据

**方法签名：**
```java
public ExtendedDataEntitySet getExtendedDataEntitySet()
```

**返回值：**
- `ExtendedDataEntitySet`: ExtendedDataEntitySet

---

### getFuncLib

获取操作校验支持的自定义函数运行实例管理器

**方法签名：**
```java
public FunctionManage getFuncLib()
```

**返回值：**
- `FunctionManage`

---

### getMustInputLang

获取必录语种

**方法签名：**
```java
public List<String> getMustInputLang()
```

**返回值：**
- `List<String>`: 必录语种集合

---

### getOperateKey

获取操作编码：默认使用操作类型名(如audit)，但用户可以修改为wfaudit等

**方法签名：**
```java
public String getOperateKey()
```

**返回值：**
- `String`: String

---

### getOperateMetaMap

获取操作元数据

**方法签名：**
```java
public Map<String,Object> getOperateMetaMap()
```

**返回值：**
- `Map<String,Object>`: Map

---

### getOperateName

操作名称：主要用于提示信息，嵌入操作名称

**方法签名：**
```java
public String getOperateName()
```

**返回值：**
- `String`: String

---

### getOperateProgress

获取操作进度控制接口

**方法签名：**
```java
public OperateProgress getOperateProgress()
```

**返回值：**
- `OperateProgress`

---

### getOperateType

获取操作类型：save, submit, audit等

**方法签名：**
```java
public String getOperateType()
```

**返回值：**
- `String`

---

### getOption

获取操作自定义参数对象

**方法签名：**
```java
public OperateOption getOption()
```

**返回值：**
- `OperateOption`

---

### getSubEntityType

获取单据主实体，只包括本次操作用到的字段，与单据数据包一致

**方法签名：**
```java
public MainEntityType getSubEntityType()
```

**返回值：**
- `MainEntityType`

---

### getValidatePrefix

获取校验前缀

**方法签名：**
```java
public String getValidatePrefix()
```

**返回值：**
- `String`: String

---

### getValidateResults

获取全部校验器的校验结果

**方法签名：**
```java
public ValidateResultCollection getValidateResults()
```

**返回值：**
- `ValidateResultCollection`

---

### getValidationMeta

本操作，配置的校验器元数据，包含了各个校验规则

**方法签名：**
```java
public List<Map<String,Object>> getValidationMeta()
```

**返回值：**
- `List<Map<String,Object>>`: List

---

### isCheckMustInput

是否校验必录

**方法签名：**
```java
public boolean isCheckMustInput()
```

**返回值：**
- `boolean`

---

### isControlFunction

验权开关

**方法签名：**
```java
public boolean isControlFunction()
```

**返回值：**
- `boolean`: boolean

---

### setBillEntityType

设置单据主实体 全量

**方法签名：**
```java
public void setBillEntityType(MainEntityType billEntityType)
```

**参数说明：**
- `billEntityType`: `MainEntityType`

---

### setCheckMustInput

设置是否校验必录

**方法签名：**
```java
public void setCheckMustInput(boolean checkMustInput)
```

**参数说明：**
- `checkMustInput`: `boolean`

---

### setDataEntityLength

设置传入数据的数量

**方法签名：**
```java
public void setDataEntityLength(int dataEntityLength)
```

**参数说明：**
- `dataEntityLength`: `int`

---

### setEntityNumber

设置单据主实体编码

**方法签名：**
```java
public void setEntityNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

---

### setFuncLib

设置操作校验支持的自定义函数运行实例管理器

**方法签名：**
```java
public void setFuncLib(FunctionManage funcLib)
```

**参数说明：**
- `funcLib`: `FunctionManage`

---

### setMustInputLang

设置必录语种

**方法签名：**
```java
public void setMustInputLang(List<String> mustInputLang)
```

**参数说明：**
- `mustInputLang`: `List<String>` — 必录语种

---

### setOperateMetaMap

设置操作元数据

**方法签名：**
```java
public void setOperateMetaMap(Map<String,Object> operateMetaMap)
```

**参数说明：**
- `operateMetaMap`: `Map<String,Object>` — 操作元数据

---

### setOperateName

设置 操作名称

**方法签名：**
```java
public void setOperateName(String operateName)
```

**参数说明：**
- `operateName`: `String` — 操作名称

---

### setOperateProgress

设置操作进度控制接口

**方法签名：**
```java
public void setOperateProgress(OperateProgress operateProgress)
```

**参数说明：**
- `operateProgress`: `OperateProgress`

---

### setOperateType

设置操作类型：save, submit, audit等

**方法签名：**
```java
public void setOperateType(String operateType)
```

**参数说明：**
- `operateType`: `String`

---

### setOption

设置操作自定义对象

**方法签名：**
```java
public void setOption(OperateOption option)
```

**参数说明：**
- `option`: `OperateOption`

---

### setSubEntityType

设置单据主实体，只包括本次操作用到的字段，与单据数据包一致

**方法签名：**
```java
public void setSubEntityType(MainEntityType subEntityType)
```

**参数说明：**
- `subEntityType`: `MainEntityType`

---

### setValidatePrefix

设置校验前缀

**方法签名：**
```java
public void setValidatePrefix(String validatePrefix)
```

**参数说明：**
- `validatePrefix`: `String` — 校验前缀

---

### setValidateResults

设置全部校验器的校验结果

**方法签名：**
```java
public void setValidateResults(ValidateResultCollection validateResults)
```

**参数说明：**
- `validateResults`: `ValidateResultCollection`

---

### switchLang

将语言码转化为对应的名称

**方法签名：**
```java
public static String switchLang(List<String> langBillParams)
```

**参数说明：**
- `langBillParams`: `List<String>` — 单据参数设置多语言字段必录的语种编码

**返回值：**
- `String`

---
