---
framework_version: "8.0.1"
api_class: "PushMessageBuilder"
api_package: "kd.bos.dataentity.message"
when_to_use: "当你需要使用推送消息构造帮助类时"
---

# PushMessageBuilder API 说明

## 概述
推送消息构造帮助类。
主要功能：创建对象、添加元素、设置属性。

## Import 路径
```java
import kd.bos.dataentity.message.PushMessageBuilder;
```

---

## 方法列表

### addProperty

添加推送消息属性

**方法签名：**
```java
public PushMessageBuilder addProperty(String key, String value)
```

**参数说明：**
- `key`: `String` — 推送消息标识
- `value`: `String` — 推送消息值

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### body

设置推送消息体

**方法签名：**
```java
public PushMessageBuilder body(Object body)
```

**参数说明：**
- `body`: `Object` — 推送消息体

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### build

构建前端推送的消息类

**方法签名：**
```java
public PushMessage build()
```

**返回值：**
- `PushMessage`: PushMessage

---

### create

创建一个新的推送消息构造帮助类

**方法签名：**
```java
public static PushMessageBuilder create()
```

**返回值：**
- `PushMessageBuilder`

---

### createTime

设置推送消息生成时间

**方法签名：**
```java
public PushMessageBuilder createTime(ZonedDateTime createTime)
```

**参数说明：**
- `createTime`: `ZonedDateTime` — 推送消息生成时间

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### from

设置消息来源

**方法签名：**
```java
public PushMessageBuilder from(String from)
```

**参数说明：**
- `from`: `String` — 消息来源

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### id

设置对应推送消息的id

**方法签名：**
```java
public PushMessageBuilder id(String id)
```

**参数说明：**
- `id`: `String` — 对应推送消息的id

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### range

设置推送消息的范围（页面，会话，租户，全局）

**方法签名：**
```java
public PushMessageBuilder range(PushMessageRange range)
```

**参数说明：**
- `range`: `PushMessageRange` — PushMessageRange推送消息的范围

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### setProperties

设置推送消息属性

**方法签名：**
```java
public PushMessageBuilder setProperties(Map<String,String> properties)
```

**参数说明：**
- `properties`: `Map<String,String>` — 推送消息属性

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### to

设置消息去向（页面ID，会话ID，租户ID）

**方法签名：**
```java
public PushMessageBuilder to(String to)
```

**参数说明：**
- `to`: `String` — 消息去向

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---

### type

设置推送消息类型（表单指令，更新指令*）

**方法签名：**
```java
public PushMessageBuilder type(PushMessageType type)
```

**参数说明：**
- `type`: `PushMessageType` — PushMessageType推送消息类型

**返回值：**
- `PushMessageBuilder`: 推送消息构造帮助类

---
