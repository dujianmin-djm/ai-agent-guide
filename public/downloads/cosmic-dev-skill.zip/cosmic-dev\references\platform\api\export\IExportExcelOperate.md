---
framework_version: "8.0.1"
api_class: "IExportExcelOperate"
api_package: "kd.bos.export"
when_to_use: "当你需要使用存在导出EXCEL功能的VIEW实现此接口时"
---

# IExportExcelOperate API 说明

## 概述
存在导出EXCEL功能的VIEW实现此接口。
主要功能：导出EXCEL表格、导出PDF文件。

## Import 路径
```java
import kd.bos.export.IExportExcelOperate;
```

---

## 方法列表

### exportExcel

导出EXCEL表格

**方法签名：**
```java
public void exportExcel()
```

---

### exportPdf

导出PDF文件

**方法签名：**
```java
public String exportPdf(PaperSetting info)
```

**参数说明：**
- `info`: `PaperSetting` — 配置信息

**返回值：**
- `String`

---
