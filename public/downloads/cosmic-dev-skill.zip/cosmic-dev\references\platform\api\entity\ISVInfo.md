---
framework_version: "8.0.1"
api_class: "ISVInfo"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用开发商信息时"
---

# ISVInfo API 说明

## 概述
开发商信息。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.ISVInfo;
```

---

## 方法列表

### getDescription

获取开发商描述

**方法签名：**
```java
public String getDescription()
```

**返回值：**
- `String`

---

### getId

获取开发商id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIsvId

获取Isvid

**方法签名：**
```java
public String getIsvId()
```

**返回值：**
- `String`

---

### getName

获取开发商名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getSign

获取开发商签名

**方法签名：**
```java
public String getSign()
```

**返回值：**
- `String`

---

### getType

获取开发商类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### setDescription

获取开发商描述

**方法签名：**
```java
public void setDescription(String description)
```

**参数说明：**
- `description`: `String`

---

### setId

设置开发商id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setIsvId

设置IsvId

**方法签名：**
```java
public void setIsvId(String isvId)
```

**参数说明：**
- `isvId`: `String`

---

### setName

设置开发商名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String`

---

### setSign

设置开发商签名

**方法签名：**
```java
public void setSign(String sign)
```

**参数说明：**
- `sign`: `String`

---

### setType

设置开发商类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---
