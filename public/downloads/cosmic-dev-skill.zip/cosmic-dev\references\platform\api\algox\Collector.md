---
framework_version: "8.0.1"
api_class: "Collector"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用收集器时"
---

# Collector API 说明

## 概述
收集器，为下一个计算节点输出数据。
主要功能：收集RowX。

## Import 路径
```java
import kd.bos.algox.Collector;
```

---

## 方法列表

### collect

收集RowX

**方法签名：**
```java
public void collect(RowX row)
```

**参数说明：**
- `row`: `RowX` — 行数据

---
