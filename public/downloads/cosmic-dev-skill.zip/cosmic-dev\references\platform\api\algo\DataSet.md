---
framework_version: "8.0.1"
api_class: "DataSet"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用DataSet:结果集时"
---

# DataSet API 说明

## 概述
DataSet:结果集，与JDBC 中的ResultSet类似。 模拟数据库的各种基本操作，如select ,where ,groupby等等。。实现 AutoCloseable, Iterable, Iterator。
主要功能：添加元素、状态判断、保存更新、读取属性。

## Import 路径
```java
import kd.bos.algo.DataSet;
```

---

## 方法列表

### addBalanceField

增加余额字段, 该字段的值从上往下累加

**方法签名：**
```java
public DataSet addBalanceField(String expr, String alias)
```

**参数说明：**
- `expr`: `String` — 新增余额字段的表达式处理
- `alias`: `String` — 新增字段的别名

**返回值：**
- `DataSet`: DataSet

---

### addField

增加字段

**方法签名：**
```java
public DataSet addField(String expr, String alias)
```

**参数说明：**
- `expr`: `String` — 新增的字段表达式
- `alias`: `String` — 新增字段的别名

**返回值：**
- `DataSet`: DataSet

---

### addFields

新增多个字段

**方法签名：**
```java
public DataSet addFields(String[] exprs, String[] aliases)
```

**参数说明：**
- `exprs`: `String[]` — 新增的字段表达式
- `aliases`: `String[]` — 新增字段的别名

**返回值：**
- `DataSet`: DataSet

---

### addListener

添加监听器，在关闭datset之前和之后执行

**方法签名：**
```java
public void addListener(DataSet.Listener listener)
```

**参数说明：**
- `listener`: `DataSet.Listener` — 监听器

---

### addNullField

**重载 1**

新增一个空数据字段

**方法签名：**
```java
public DataSet addNullField(String alias)
```

**参数说明：**
- `alias`: `String` — 新增空数据字段别名

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

新增多个空数据字段

**方法签名：**
```java
public DataSet addNullField(String[] aliases)
```

**参数说明：**
- `aliases`: `String[]` — 新增空数据字段别名

**返回值：**
- `DataSet`: DataSet

---

### cache

缓存dataset

**方法签名：**
```java
public CachedDataSet cache(CacheHint cacheHint)
```

**参数说明：**
- `cacheHint`: `CacheHint` — 获取缓存dataset的参数值

**返回值：**
- `CachedDataSet`: CachedDataSet

---

### cacheBuilder

获取缓存dataset的builder

**方法签名：**
```java
public CachedDataSet.Builder cacheBuilder(CacheHint hint)
```

**参数说明：**
- `hint`: `CacheHint` — 获取缓存dataset的参数值

**返回值：**
- `CachedDataSet.Builder`: CachedDataSet.Builder

---

### close

关闭dataset

**方法签名：**
```java
public void close()
```

---

### copy

复制一份DataSet

**方法签名：**
```java
public DataSet copy()
```

**返回值：**
- `DataSet`: DataSet

---

### count

对某字段进行count统计，不包括null值

**方法签名：**
```java
public int count(String field, boolean distinct)
```

**参数说明：**
- `field`: `String` — 统计字段
- `distinct`: `boolean` — 是否去重

**返回值：**
- `int`: count值

---

### distinct

对结果集去重，默认是所有字段

**方法签名：**
```java
public DataSet distinct()
```

**返回值：**
- `DataSet`: DataSet

---

### executeSql

**重载 1**

可以通过写sql的方式进行数据处理

**方法签名：**
```java
public DataSet executeSql(String sql)
```

**参数说明：**
- `sql`: `String` — sql语句

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

可以通过写sql的方式进行数据处理

**方法签名：**
```java
public DataSet executeSql(String sql, SqlHint hint)
```

**参数说明：**
- `sql`: `String` — sql语句
- `hint`: `SqlHint` — kd.bos.algo.SqlHint 执行sql语句时可以执行一些优化信息

**返回值：**
- `DataSet`: DataSet

---

### filter

**重载 1**

使用表达式进行数据过滤

**方法签名：**
```java
public DataSet filter(String expr)
```

**参数说明：**
- `expr`: `String`

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

支持expr中写参数，参数值通过params传递
 比如：
 
     
 params.put("var1", 100);
 filter("fqty>var1", params);

**方法签名：**
```java
public DataSet filter(String expr, Map<String,Object> params)
```

**参数说明：**
- `expr`: `String` — 过滤的表达式，支持变量方式
- `params`: `Map<String,Object>` — 变量对应的参数值

**返回值：**
- `DataSet`: DataSet

---

**重载 3**

支持自定义过滤函数进行过滤

**方法签名：**
```java
public DataSet filter(FilterFunction func)
```

**参数说明：**
- `func`: `FilterFunction` — 自定义过滤函数

**返回值：**
- `DataSet`: DataSet

---

### fullJoin

**重载 1**

全连接

**方法签名：**
```java
public default JoinDataSet fullJoin(DataSet rightDataSet)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 2**

指定join方式的全连接

**方法签名：**
```java
public default JoinDataSet fullJoin(DataSet rightDataSet, JoinHint hint)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `hint`: `JoinHint` — kd.bos.algo.JoinHint Join的提示，可设置一些优化信息

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

### getRowMeta

获取元素据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元素据

---

### groupBy

**重载 1**

默认分组，没有分组字段，默认只有一组

**方法签名：**
```java
public GroupbyDataSet groupBy()
```

**返回值：**
- `GroupbyDataSet`: GroupbyDataSet

---

**重载 2**

根据分组字段对DataSet进行分组，默认升序排列，分组字段不支持表达式

**方法签名：**
```java
public GroupbyDataSet groupBy(String[] groupFields)
```

**参数说明：**
- `groupFields`: `String[]` — 分组字段

**返回值：**
- `GroupbyDataSet`: GroupbyDataSet

---

**重载 3**

根据分组字段对DataSet进行分组，是否进行降序排列

**方法签名：**
```java
public GroupbyDataSet groupBy(String[] groupFields, boolean[] orderByDescs)
```

**参数说明：**
- `groupFields`: `String[]`
- `orderByDescs`: `boolean[]` — 是否根据分组字段进行降序排序

**返回值：**
- `GroupbyDataSet`: GroupbyDataSet

---

### hasNext

判断是否还有下一行

**方法签名：**
```java
public boolean hasNext()
```

**返回值：**
- `boolean`: 是否还有下一行

---

### hashJoin

**重载 1**

将DataSet与HashTable进行hashjoin

**方法签名：**
```java
public HashJoinDataSet hashJoin(HashTable hashTable, String leftJoinKeyField, String[] hashTableSelectFields)
```

**参数说明：**
- `hashTable`: `HashTable` — HashTable
- `leftJoinKeyField`: `String` — join字段
- `hashTableSelectFields`: `String[]` — 选取HashTable中需返回的字段

**返回值：**
- `HashJoinDataSet`: kd.bos.algo.HashJoinDataSet

---

**重载 2**

将DataSet与HashTable进行hashjoin

**方法签名：**
```java
public HashJoinDataSet hashJoin(HashTable hashTable, String leftJoinKeyField, String[] hashTableSelectFields, boolean includeNotExist)
```

**参数说明：**
- `hashTable`: `HashTable` — HashTable
- `leftJoinKeyField`: `String` — join字段
- `hashTableSelectFields`: `String[]` — 选取HashTable中需返回的字段
- `includeNotExist`: `boolean`

**返回值：**
- `HashJoinDataSet`: kd.bos.algo.HashJoinDataSet

---

### isEmpty

判断是否还有数据

**方法签名：**
```java
public boolean isEmpty()
```

**返回值：**
- `boolean`: 是否还有数据

---

### join

**重载 1**

默认进行innerjoin

**方法签名：**
```java
public JoinDataSet join(DataSet rightDataSet)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 2**

默认进行innerjoin ,可以指定join方式

**方法签名：**
```java
public JoinDataSet join(DataSet rightDataSet, JoinHint hint)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `hint`: `JoinHint` — kd.bos.algo.JoinHint Join的提示，可设置一些优化信息

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 3**

可以指定Join类型是left join还是right join

**方法签名：**
```java
public JoinDataSet join(DataSet rightDataSet, JoinType type)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `type`: `JoinType` — kd.bos.algo.JoinType Join的类型

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 4**

可以指定join方式以及join类型

**方法签名：**
```java
public JoinDataSet join(DataSet rightDataSet, JoinType type, JoinHint hint)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `type`: `JoinType` — kd.bos.algo.JoinType Join的类型
- `hint`: `JoinHint` — kd.bos.algo.JoinHint Join的提示，可设置一些优化信息

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

### leftJoin

**重载 1**

左连接

**方法签名：**
```java
public default JoinDataSet leftJoin(DataSet rightDataSet)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 2**

指定join方式的左连接

**方法签名：**
```java
public default JoinDataSet leftJoin(DataSet rightDataSet, JoinHint hint)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `hint`: `JoinHint` — kd.bos.algo.JoinHint Join的提示，可设置一些优化信息

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

### limit

返回某范围数据

**方法签名：**
```java
public default DataSet limit(int start, int length)
```

**参数说明：**
- `start`: `int` — 从start位置开始取值
- `length`: `int` — 取数长度

**返回值：**
- `DataSet`: DataSet

---

### map

自定义map函数，对dataset进行处理，生成新的dataset

**方法签名：**
```java
public DataSet map(MapFunction function)
```

**参数说明：**
- `function`: `MapFunction` — 自定义map函数

**返回值：**
- `DataSet`: DataSet

---

### next

获取下一行

**方法签名：**
```java
public Row next()
```

**返回值：**
- `Row`: 下一行

---

### orderBy

fields语法: field, 或者field desc, field asc

**方法签名：**
```java
public DataSet orderBy(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 排序字段名称

**返回值：**
- `DataSet`: DataSet

---

### print

是否copy一个新的

**方法签名：**
```java
public void print(boolean copy)
```

**参数说明：**
- `copy`: `boolean`

---

### range

返回某范围数据

**方法签名：**
```java
public DataSet range(int start, int length)
```

**参数说明：**
- `start`: `int` — 从start位置开始取值
- `length`: `int` — 取数长度

**返回值：**
- `DataSet`: DataSet

---

### reduceGroup

**重载 1**

对DataSet进行reduce操作

**方法签名：**
```java
public DataSet reduceGroup(ReduceGroupFunction fun)
```

**参数说明：**
- `fun`: `ReduceGroupFunction` — reduce函数

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

对DataSet进行reduce操作后，将数据输出到一个Collector

**方法签名：**
```java
public DataSet reduceGroup(ReduceGroupFunctionWithCollector fun)
```

**参数说明：**
- `fun`: `ReduceGroupFunctionWithCollector` — reduce函数

**返回值：**
- `DataSet`: DataSet

---

### removeFields

批量删除字段

**方法签名：**
```java
public DataSet removeFields(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 需要删除的字段的名称

**返回值：**
- `DataSet`: DataSet

---

### rightJoin

**重载 1**

右连接

**方法签名：**
```java
public default JoinDataSet rightJoin(DataSet rightDataSet)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

**重载 2**

指定join方式的右连接

**方法签名：**
```java
public default JoinDataSet rightJoin(DataSet rightDataSet, JoinHint hint)
```

**参数说明：**
- `rightDataSet`: `DataSet` — join的另外一个结果集
- `hint`: `JoinHint` — kd.bos.algo.JoinHint Join的提示，可设置一些优化信息

**返回值：**
- `JoinDataSet`: JoinDataSet kd.bos.algo.JoinDataSet

---

### select

**重载 1**

expr支持基本四则运算，包括：+,-,*,/,()
    支持常量数字，字符串
    支持逻辑表达式： ,=,<>, and, or, xor, not
    支持宏: NULL, TRUE, FALSE

**方法签名：**
```java
public DataSet select(String[] exprs)
```

**参数说明：**
- `exprs`: `String[]` — 需要选择的列表达式

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

同 select(String... exprs);，提供去重参数。

**方法签名：**
```java
public DataSet select(boolean distinct, String[] exprs)
```

**参数说明：**
- `distinct`: `boolean` — 是否需要去重
- `exprs`: `String[]` — 需要选择的列表达式

**返回值：**
- `DataSet`: DataSet

---

**重载 3**

expr支持基本四则运算，包括：+,-,*,/,()
     支持常量数字，字符串
     支持逻辑表达式： ,=,<>, and, or, xor, not
     支持宏: NULL, TRUE, FALSE

**方法签名：**
```java
public DataSet select(String expr)
```

**参数说明：**
- `expr`: `String` — 单个expr或者用逗号隔开的多个expr

**返回值：**
- `DataSet`: DataSet

---

### splitByFilter

根据过滤条件，每组过滤条件一个dataset，所有不在这些过滤条件的单独作为一个dataset

**方法签名：**
```java
public DataSet[] splitByFilter(String[] filterExprs, boolean includeOthers)
```

**参数说明：**
- `filterExprs`: `String[]` — 过滤条件
- `includeOthers`: `boolean` — 是否返回不在这些条件中的dataset

**返回值：**
- `DataSet[]`: 结果集

---

### splitByGroup

根据分组字段进行分割

**方法签名：**
```java
public DataSet[] splitByGroup(String[] groupFields)
```

**参数说明：**
- `groupFields`: `String[]` — 分组字段

**返回值：**
- `DataSet[]`: DataSet[]

---

### toHashTable

根据某个key，将DataSet转成HashTable

**方法签名：**
```java
public HashTable toHashTable(String keyField)
```

**参数说明：**
- `keyField`: `String` — 某个key值

**返回值：**
- `HashTable`: HashTable

---

### top

返回前length条数据

**方法签名：**
```java
public DataSet top(int length)
```

**参数说明：**
- `length`: `int` — 取数长度

**返回值：**
- `DataSet`: DataSet

---

### topBy

排序后取前几条数据

**方法签名：**
```java
public DataSet topBy(int top, String[] orderBy)
```

**参数说明：**
- `top`: `int` — 取数长度
- `orderBy`: `String[]` — 排序字段

**返回值：**
- `DataSet`: DataSet

---

### union

**重载 1**

simple union,不支持消除重复

**方法签名：**
```java
public DataSet union(DataSet dataSet)
```

**参数说明：**
- `dataSet`: `DataSet` — union的另外一个结果集

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

多个dataset union 不支持消除重复

**方法签名：**
```java
public DataSet union(DataSet[] dataSets)
```

**参数说明：**
- `dataSets`: `DataSet[]` — 多个结果集

**返回值：**
- `DataSet`: DataSet

---

### updateField

更新字段

**方法签名：**
```java
public default DataSet updateField(String field, String expr)
```

**参数说明：**
- `field`: `String` — 需要更新的某个字段
- `expr`: `String` — 更新的表达式处理

**返回值：**
- `DataSet`: DataSet

---

### updateFields

更新多个字段

**方法签名：**
```java
public DataSet updateFields(String[] fields, String[] exprs)
```

**参数说明：**
- `fields`: `String[]` — 需要更新的某个字段
- `exprs`: `String[]` — 更新的表达式处理

**返回值：**
- `DataSet`: DataSet

---

### where

**重载 1**

数据过滤

**方法签名：**
```java
public default DataSet where(String expr)
```

**参数说明：**
- `expr`: `String` — 支持四则运算

**返回值：**
- `DataSet`: DataSet

---

**重载 2**

支持expr中写参数，参数值通过params传递
 比如：
 
     
 params.put("var1", 100);
 filter("fqty>var1", params);

**方法签名：**
```java
public default DataSet where(String expr, Map<String,Object> params)
```

**参数说明：**
- `expr`: `String` — 过滤的表达式，支持变量方式
- `params`: `Map<String,Object>` — 变量对应的参数值

**返回值：**
- `DataSet`: DataSet

---

**重载 3**

支持自定义过滤函数进行过滤

**方法签名：**
```java
public default DataSet where(FilterFunction func)
```

**参数说明：**
- `func`: `FilterFunction` — 自定义过滤函数

**返回值：**
- `DataSet`: DataSet

---
