---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "draft"
---

# 调度任务插件开发参考

> 覆盖：AbstractTask（后台调度任务）
> 适用：定时数据处理、批量检查、外部系统同步、预警通知

## 基础结构

```java
package kd.{isv}.{module}.task;

import java.util.Map;
import kd.bos.context.RequestContext;
import kd.bos.exception.KDException;
import kd.bos.schedule.executor.AbstractTask;
import kd.sdk.plugin.Plugin;
import kd.bos.dataentity.entity.DynamicObject;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

public class XxxTask extends AbstractTask implements Plugin {
    private static final Log log = LogFactory.getLog(XxxTask.class);

    @Override
    public void execute(RequestContext requestContext, Map<String, Object> map) throws KDException {
        // 任务逻辑
    }
}
```

## 生命周期

```
调度触发（定时/手动）
    → execute(requestContext, map)
        → 获取任务参数 (map.get)
        → 查询待处理数据
        → 循环处理每条数据
            → feedbackProgress（反馈进度）
            → isStop / stop（检查停止，需实现 StopTask）
        → feedbackCustomdata（反馈结果）
    → 任务完成
```

| 方法 | 说明 | 典型用途 |
|------|------|---------|
| `execute(RequestContext, Map)` | 任务主入口 | 唯一必须实现的方法 |
| `feedbackProgress(int, String, Object)` | 反馈执行进度 | 列表页显示进度条 |
| `feedbackCustomdata(Map)` | 反馈自定义结果 | 任务完成后展示执行摘要 |
| `isStop()` | 检查停止信号 | 循环中检查是否需要中断（需实现 StopTask） |
| `stop()` | 执行停止 | 配合 isStop() 标记任务为已停止 |

## 可停止任务

```java
import kd.bos.schedule.api.StopTask;

public class XxxTask extends AbstractTask implements Plugin, StopTask {
    @Override
    public void execute(RequestContext ctx, Map<String, Object> map) throws KDException {
        DynamicObject[] dataArray = BusinessDataServiceHelper.load(...);
        int total = dataArray.length;
        for (int i = 0; i < total; i++) {
            processData(dataArray[i]);
            this.feedbackProgress(100 * (i + 1) / total,
                    String.format("已处理 %d/%d", i + 1, total), null);
            if (this.isStop()) {
                log.info("任务被停止，已处理 {} 条", i + 1);
                this.stop();
                break;
            }
        }
    }
}
```

## 常见场景

### 批量数据检查与处理

```java
@Override
public void execute(RequestContext ctx, Map<String, Object> map) throws KDException {
    QFilter filter = new QFilter("status", QCP.equals, "A");
    DynamicObject[] dataArray = BusinessDataServiceHelper.load(entityNumber, "id", new QFilter[]{filter});
    int successCount = 0, failCount = 0;
    for (DynamicObject data : dataArray) {
        data = BusinessDataServiceHelper.loadSingle(data.getPkValue(), entityNumber);
        try {
            boolean pass = checkData(data);
            if (!pass) {
                data.set("status", "error");
                SaveServiceHelper.save(new DynamicObject[]{data});
            }
            successCount++;
        } catch (Exception e) {
            failCount++;
            log.error("处理数据失败：id={}", data.getPkValue(), e);
        }
    }
    log.info("任务执行完毕：成功 {} 条，失败 {} 条", successCount, failCount);
}
```

### 定时预警通知

```java
@Override
public void execute(RequestContext ctx, Map<String, Object> map) throws KDException {
    QFilter filter = new QFilter("expiry_date", QCP.less_equals, DateUtils.addDays(new Date(), 30));
    DynamicObject[] expiring = BusinessDataServiceHelper.load(entityNumber,
            "id,name,expiry_date", new QFilter[]{filter});
    for (DynamicObject item : expiring) {
        sendNotification(item);
    }
}
```

### 外部系统数据同步

```java
@Override
public void execute(RequestContext ctx, Map<String, Object> map) throws KDException {
    try {
        String response = HttpUtils.get(apiUrl);
        List<DataDTO> dataList = parseResponse(response);
        for (DataDTO dto : dataList) {
            DynamicObject obj = BusinessDataServiceHelper.newDynamicObject(entityNumber);
            obj.set("field1", dto.getValue1());
            SaveServiceHelper.save(new DynamicObject[]{obj});
        }
    } catch (Exception e) {
        log.error("数据同步失败", e);
    }
}
```

## 进度反馈

```java
// 反馈进度百分比（0-100）
int progress = 100 * (i + 1) / total;
this.feedbackProgress(progress, String.format("已处理 %d/%d 条", i + 1, total), null);

// 反馈自定义结果（任务完成后在列表页展示）
HashMap<String, Object> result = new HashMap<>();
result.put("成功", successCount);
result.put("失败", failCount);
this.feedbackCustomdata(result);
```

## 注意事项

1. **继承 AbstractTask**：所有调度任务必须继承 `kd.bos.schedule.executor.AbstractTask`
2. **实现 Plugin 接口**：`kd.sdk.plugin.Plugin`（标记接口，使插件可在后台调度配置中被识别）
3. **execute 签名不可变**：`execute(RequestContext, Map<String, Object>)` 是唯一入口，不可遗漏 `throws KDException`
4. **逐条 try-catch**：批量处理时每条数据单独 try-catch，防止单条失败影响全局
5. **大循环必须反馈进度**：使用 `feedbackProgress()` 反馈进度，否则用户无法感知任务状态
6. **长任务支持停止**：大数据量时实现 `StopTask` 接口，循环中检查 `isStop()`
7. **避免内存溢出**：不要一次性加载全量数据，使用分页或流式处理
8. **幂等设计**：任务可能被重复触发，业务逻辑应设计为幂等操作
9. **日志完整**：任务开始、结束、异常、统计结果都要记录日志
10. **事务边界**：`SaveServiceHelper.save()` 不在事务中，大批量保存应分批处理
