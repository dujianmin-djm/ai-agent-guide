---
framework_version: "8.0.1"
api_class: "BeforeSaveAuditLogEvent"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用 BeforeSaveAuditLogEvent 相关功能时"
---

# BeforeSaveAuditLogEvent API 说明

## 概述
BeforeSaveAuditLogEvent 类。继承自 OperationArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.BeforeSaveAuditLogEvent;
```

---

## 方法列表

### getAppId

获取应用id

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用id

---

### getCloudId

获取云id

**方法签名：**
```java
public String getCloudId()
```

**返回值：**
- `String`: 云id

---

### getEntityNumber

获取实体标识

**方法签名：**
```java
public String getEntityNumber()
```

**返回值：**
- `String`: 实体标识

---

### getNeedMonitorFields

{待补充}

**方法签名：**
```java
public List<String> getNeedMonitorFields()
```

**返回值：**
- `List<String>`

---

### setNeedMonitorFields

{待补充}

**方法签名：**
```java
public void setNeedMonitorFields(List<String> needMonitorFields)
```

**参数说明：**
- `needMonitorFields`: `List<String>`

---
