---
framework_version: "8.0.1"
api_class: "FlexType"
api_package: "kd.bos.entity.flex"
when_to_use: "当你需要使用弹性域类型定义时"
---

# FlexType API 说明

## 概述
弹性域类型定义。继承自 ClrDataEntity。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.flex.FlexType;
```

---

## 方法列表

### getBasedataService

获取基础资料服务

**方法签名：**
```java
public String getBasedataService()
```

**返回值：**
- `String`

---

### getDisplayFormat

获取显示格式

**方法签名：**
```java
public int getDisplayFormat()
```

**返回值：**
- `int`: 1:弹出式

---

### getDisplayProperty

获取显示属性

**方法签名：**
```java
public String getDisplayProperty()
```

**返回值：**
- `String`

---

### getFlexDataTable

获取维度数据表

**方法签名：**
```java
public String getFlexDataTable()
```

**返回值：**
- `String`

---

### getFlexTypeId

获取弹性域类型

**方法签名：**
```java
public long getFlexTypeId()
```

**返回值：**
- `long`

---

### getFormNumber

获取表单标识

**方法签名：**
```java
public String getFormNumber()
```

**返回值：**
- `String`: the formNumber

---

### getFormUUID

获取uuid

**方法签名：**
```java
public String getFormUUID()
```

**返回值：**
- `String`

---

### getId

由于int类型的新增可能会重复，导致相互覆盖，故改为long类型主键，废弃getId()接口，改为getFlexTypeId()

**方法签名：**
```java
public int getId()
```

**返回值：**
- `int`

---

### getName

获取弹性域名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: the name

---

### getNumber

获取弹性域编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### getSeparator

获取显示分隔符

**方法签名：**
```java
public String getSeparator()
```

**返回值：**
- `String`

---

### setBasedataService

设置基础资料服务

**方法签名：**
```java
public void setBasedataService(String basedataService)
```

**参数说明：**
- `basedataService`: `String`

---

### setDisplayFormat

设置显示格式

**方法签名：**
```java
public void setDisplayFormat(int displayFormat)
```

**参数说明：**
- `displayFormat`: `int` — 1:弹出式

---

### setDisplayProperty

设置显示属性

**方法签名：**
```java
public void setDisplayProperty(String displayProperty)
```

**参数说明：**
- `displayProperty`: `String`

---

### setFlexDataTable

设置维度数据表

**方法签名：**
```java
public void setFlexDataTable(String flexDataTable)
```

**参数说明：**
- `flexDataTable`: `String`

---

### setFlexTypeId

设置弹性域类型

**方法签名：**
```java
public void setFlexTypeId(long flexTypeId)
```

**参数说明：**
- `flexTypeId`: `long`

---

### setFormNumber

设置表单标识

**方法签名：**
```java
public void setFormNumber(String formNumber)
```

**参数说明：**
- `formNumber`: `String`

---

### setId

设置ID

**方法签名：**
```java
public void setId(int id)
```

**参数说明：**
- `id`: `int`

---

### setName

获取弹性域名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String`

---

### setNumber

设置弹性域属编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---

### setSeparator

设置显示分隔符

**方法签名：**
```java
public void setSeparator(String separator)
```

**参数说明：**
- `separator`: `String`

---
