---
framework_version: "8.0.1"
api_class: "DynamicReportColumnEvent"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表动态字段事件参数时"
---

# DynamicReportColumnEvent API 说明

## 概述
报表动态字段事件参数。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.DynamicReportColumnEvent;
```

---

## 方法列表

### getColumns

获取报表动态字段

**方法签名：**
```java
public List<ReportColumn> getColumns()
```

**返回值：**
- `List<ReportColumn>`

---

### getRptFormId

获取当前报表标识

**方法签名：**
```java
public String getRptFormId()
```

**返回值：**
- `String`: 返回当前报表标识

---

### setColumns

{待补充}

**方法签名：**
```java
public void setColumns(List<ReportColumn> columns)
```

**参数说明：**
- `columns`: `List<ReportColumn>`

---

### setRptFormId

设置当前报表标识

**方法签名：**
```java
public void setRptFormId(String rptFormId)
```

**参数说明：**
- `rptFormId`: `String` — 报表标识

---
