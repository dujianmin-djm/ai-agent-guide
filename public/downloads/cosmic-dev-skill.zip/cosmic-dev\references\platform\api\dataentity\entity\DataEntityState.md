---
framework_version: "8.0.1"
api_class: "DataEntityState"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用数据包的状态时"
---

# DataEntityState API 说明

## 概述
数据包的状态，描述和管理单个实体的脏标志。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.entity.DataEntityState;
```

---

## 方法列表

### GetDirtyProperties

**重载 1**

返回指定实体中所有变更的属性列表

**方法签名：**
```java
public abstract List<kd.IDataEntityProperty> GetDirtyProperties()
```

**返回值：**
- `List<kd.IDataEntityProperty>`: 变更的属性列表

---

**重载 2**

返回指定实体中所有变更的属性列表

**方法签名：**
```java
public abstract List<kd.IDataEntityProperty> GetDirtyProperties(boolean includehasDefualt)
```

**参数说明：**
- `includehasDefualt`: `boolean` — 是否包含默认值

**返回值：**
- `List<kd.IDataEntityProperty>`

---

### getBizChangeFlags

获取改变的所有标记位

**方法签名：**
```java
public final long[] getBizChangeFlags()
```

**返回值：**
- `long[]`

---

### getBizChangedProperties

实体在填写完默认值之后，改动过的业务字段

**方法签名：**
```java
public Iterable<kd.IDataEntityProperty> getBizChangedProperties()
```

**返回值：**
- `Iterable<kd.IDataEntityProperty>`

---

### getCacheState

**重载 1**

获取属性缓存状态标记  （内部使用）

**方法签名：**
```java
public Map<String,Boolean> getCacheState()
```

**返回值：**
- `Map<String,Boolean>`

---

**重载 2**

获取指定属性缓存状态  （内部使用）

**方法签名：**
```java
public Boolean getCacheState(String key)
```

**参数说明：**
- `key`: `String`

**返回值：**
- `Boolean`

---

### getDataEntityDirty

返回整个实体是否已发生变更

**方法签名：**
```java
public abstract boolean getDataEntityDirty()
```

**返回值：**
- `boolean`

---

### getDirtyFlags

获取实体的脏标志位值

**方法签名：**
```java
public abstract long[] getDirtyFlags()
```

**返回值：**
- `long[]`

---

### getEntryInfo

获取分录行状态信息，可能返回null

**方法签名：**
```java
public EntryInfo getEntryInfo(String entryName)
```

**参数说明：**
- `entryName`: `String` — 分录标识

**返回值：**
- `EntryInfo`

---

### getEntryInfos

获取分录行状态信息Map

**方法签名：**
```java
public Map<String,EntryInfo> getEntryInfos()
```

**返回值：**
- `Map<String,EntryInfo>`

---

### getEntryRowCount

获取分录总行数,可能返回null

**方法签名：**
```java
public Integer getEntryRowCount(String entryName)
```

**参数说明：**
- `entryName`: `String` — 分录标识

**返回值：**
- `Integer`

---

### getEntryStartRowIndex

获取分录每页条数

**方法签名：**
```java
public int getEntryStartRowIndex(String entryName)
```

**参数说明：**
- `entryName`: `String` — 分录标识

**返回值：**
- `int`

---

### getFromDatabase

返回此实体是否是从数据库中加载过来
 
 默认情况下，当实体从数据库中加载时，将自动设置Dirty为false

**方法签名：**
```java
public final boolean getFromDatabase()
```

**返回值：**
- `boolean`

---

### getInstanceId

获取内存实例Id

**方法签名：**
```java
public long getInstanceId()
```

**返回值：**
- `long`

---

### getPkSnapshotSet

返回此实体携带的快照对象，可能返回null

**方法签名：**
```java
public final PkSnapshotSet getPkSnapshotSet()
```

**返回值：**
- `PkSnapshotSet`

---

### getRemovedItems

获取是否移除对象标记

**方法签名：**
```java
public Boolean getRemovedItems()
```

**返回值：**
- `Boolean`

---

### isBizChanged

实体在填写完默认值之后，有没有改动过字段值
 
 同方法#isChanged
 实体数据包在创建后，可能会自动创建一些空行，并填写属性默认值，保存时需要删除掉
 填写属性默认值时，会记录脏标志位，因此不能通过脏标志位判断空行
 
 本标志也会监控值变化，并在填写完默认值之后，重置为false，只记录非默认值的改动
         
 特别说明： _bizChanged按属性对象的序号记录对应属性有没有被改变；第0位特殊，特别用来代表的是否下推生成,因此判断字段值有没有被改变过，需要跳过第0位

**方法签名：**
```java
public final boolean isBizChanged()
```

**返回值：**
- `boolean`

---

### isChanged

判断实体是否改动过

**方法签名：**
```java
public final boolean isChanged()
```

**返回值：**
- `boolean`

---

### isPushChanged

是否为下推生成的数据包标记

**方法签名：**
```java
public final boolean isPushChanged()
```

**返回值：**
- `boolean`

---

### isSplitPage

否是分页取数，分析当前单据的单据体数据行是否是分页取数，即只读取了一部分分录行

**方法签名：**
```java
public boolean isSplitPage()
```

**返回值：**
- `boolean`

---

### setBizChangeFlags

设置哪些实体属性动过字段值

**方法签名：**
```java
public final void setBizChangeFlags(long[] values)
```

**参数说明：**
- `values`: `long[]`

---

### setBizChanged

**重载 1**

设置实体有没有改动过字段值

**方法签名：**
```java
public final void setBizChanged(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否改动过值，true:改动过，false:未改动过

---

**重载 2**

设置实体属性有没有改动过字段值

**方法签名：**
```java
public final void setBizChanged(int propOrdinal, boolean value)
```

**参数说明：**
- `propOrdinal`: `int` — 此属性在引用的实体类型中所在的位置
- `value`: `boolean` — 是否改动过值，true:改动过，false:未改动过

---

### setCacheState

**重载 1**

设置缓存状态 （内部使用）

**方法签名：**
```java
public void setCacheState(Map<String,Boolean> cacheState)
```

**参数说明：**
- `cacheState`: `Map<String,Boolean>`

---

**重载 2**

设置指定属性缓存状态标记 （内部使用）

**方法签名：**
```java
public void setCacheState(String key, Boolean state)
```

**参数说明：**
- `key`: `String`
- `state`: `Boolean`

---

### setDirty

**重载 1**

设置实体的所有脏标志位

**方法签名：**
```java
public abstract void setDirty(boolean newValue)
```

**参数说明：**
- `newValue`: `boolean` — 要设置脏标志位

---

**重载 2**

设置实体属性的脏标志

**方法签名：**
```java
public void setDirty(ISimpleProperty prop, boolean newValue)
```

**参数说明：**
- `prop`: `ISimpleProperty` — 实体属性
- `newValue`: `boolean` — 要设置脏标志位

---

### setDirtyFlags

设置实体的脏标志位值

**方法签名：**
```java
public abstract void setDirtyFlags(long[] values)
```

**参数说明：**
- `values`: `long[]` — 要设置脏标志位值

---

### setEntryInfos

设置分录行状态信息Map

**方法签名：**
```java
public void setEntryInfos(Map<String,EntryInfo> entryInfos)
```

**参数说明：**
- `entryInfos`: `Map<String,EntryInfo>` — 分录行状态信息Map

---

### setEntryPageSize

设置分录每页条数

**方法签名：**
```java
public void setEntryPageSize(String entryName, int pageSize)
```

**参数说明：**
- `entryName`: `String` — 分录标识
- `pageSize`: `int` — 每页条数

---

### setEntryRowCount

设置分录总行数

**方法签名：**
```java
public void setEntryRowCount(String entryName, int rowCount)
```

**参数说明：**
- `entryName`: `String` — 分录标识
- `rowCount`: `int` — 分录总行数

---

### setEntryStartRowIndex

设置分录页起始行索引

**方法签名：**
```java
public void setEntryStartRowIndex(String entryName, int startRowIndex)
```

**参数说明：**
- `entryName`: `String` — 分录标识
- `startRowIndex`: `int` — 起始行索引

---

### setFromDatabase

**重载 1**

设置此实体是否是从数据库中加载过来。内部初始化时调用，外部程序勿调用

**方法签名：**
```java
public final void setFromDatabase(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否是从数据库中加载过来

---

**重载 2**

设置此实体是否是从数据库中加载过来

**方法签名：**
```java
public final void setFromDatabase(boolean value, boolean clearDirty)
```

**参数说明：**
- `value`: `boolean` — 是否是从数据库中加载过来
- `clearDirty`: `boolean` — 清除脏标识

---

### setInstanceId

设置数据内存实例Id

**方法签名：**
```java
public void setInstanceId(long instanceId)
```

**参数说明：**
- `instanceId`: `long` — 实例Id名

---

### setPkSnapshotSet

设置此实体携带的快照对象

**方法签名：**
```java
public final void setPkSnapshotSet(PkSnapshotSet value)
```

**参数说明：**
- `value`: `PkSnapshotSet` — 实体携带的快照对象

---

### setPropertyChanged

设置某个属性已经发生改变

**方法签名：**
```java
public abstract void setPropertyChanged(PropertyChangeEvent e)
```

**参数说明：**
- `e`: `PropertyChangeEvent` — 属性改变事件参数

---

### setPushChanged

设置是否为下推生成的数据包标记

**方法签名：**
```java
public final void setPushChanged(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setRemovedItems

设置是否移除对象标记

**方法签名：**
```java
public void setRemovedItems(Boolean removedItems)
```

**参数说明：**
- `removedItems`: `Boolean`

---
