---
framework_version: "8.0.1"
api_class: "JobSession"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分布式任务会话接口时"
---

# JobSession API 说明

## 概述
分布式任务会话接口。
主要功能：设置属性、读取属性。

## Import 路径
```java
import kd.bos.algox.JobSession;
```

---

## 方法列表

### asyncCommit

**重载 1**

提交异步任务

**方法签名：**
```java
public String asyncCommit(int timeout, TimeUnit timeUnit, AlgoXCallBack callback)
```

**参数说明：**
- `timeout`: `int` — 超时时间（同时设置任务提交超时时间及任务运行超时时间）
- `timeUnit`: `TimeUnit` — 超时时间单位
- `callback`: `AlgoXCallBack` — 任务执行完毕后回调接口

**返回值：**
- `String`: 任务ID

---

**重载 2**

提交异步任务

**方法签名：**
```java
public String asyncCommit(int timeout, TimeUnit timeUnit, AlgoXCallBack callback, boolean timeoutAutoCancel)
```

**参数说明：**
- `timeout`: `int` — 超时时间（同时设置任务提交超时时间及任务运行超时时间）
- `timeUnit`: `TimeUnit` — 超时时间单位
- `callback`: `AlgoXCallBack` — 任务执行完毕后回调接口
- `timeoutAutoCancel`: `boolean` — 运行超时自动取消

**返回值：**
- `String`: 任务ID

---

**重载 3**

提交异步任务

**方法签名：**
```java
public String asyncCommit(int commitTimeout, int runningTimeout, TimeUnit timeUnit, AlgoXCallBack callback)
```

**参数说明：**
- `commitTimeout`: `int` — 任务提交超时时间
- `runningTimeout`: `int` — 任务执行超时时间
- `timeUnit`: `TimeUnit` — 超时时间单位
- `callback`: `AlgoXCallBack` — 任务执行完毕后回调接口

**返回值：**
- `String`: 任务ID

---

**重载 4**

提交异步任务

**方法签名：**
```java
public String asyncCommit(int commitTimeout, int runningTimeout, TimeUnit timeUnit, AlgoXCallBack callback, boolean timeoutAutoCancel)
```

**参数说明：**
- `commitTimeout`: `int` — 任务提交超时时间
- `runningTimeout`: `int` — 任务执行超时时间
- `timeUnit`: `TimeUnit` — 超时时间单位
- `callback`: `AlgoXCallBack` — 任务执行完毕后回调接口
- `timeoutAutoCancel`: `boolean` — 运行超时自动取消

**返回值：**
- `String`: 任务ID

---

### cancel

取消任务

**方法签名：**
```java
public void cancel(String jobId, int cancelTimeout, TimeUnit timeUnit)
```

**参数说明：**
- `jobId`: `String` — jobId
- `cancelTimeout`: `int` — 任务取消超时时间
- `timeUnit`: `TimeUnit` — 超时时间单位

---

### commit

**重载 1**

提交同步任务

**方法签名：**
```java
public void commit(int timeout, TimeUnit timeUnit)
```

**参数说明：**
- `timeout`: `int` — 超时时间（同时设置任务提交超时时间及任务运行超时时间）
- `timeUnit`: `TimeUnit` — 超时时间的单位

---

**重载 2**

提交同步任务

**方法签名：**
```java
public void commit(int timeout, TimeUnit timeUnit, boolean timeoutAutoCancel)
```

**参数说明：**
- `timeout`: `int` — 超时时间（同时设置任务提交超时时间及任务运行超时时间）
- `timeUnit`: `TimeUnit` — 超时时间的单位
- `timeoutAutoCancel`: `boolean` — 运行超时自动取消

---

**重载 3**

提交同步任务

**方法签名：**
```java
public void commit(int commitTimeout, int runningTimeout, TimeUnit timeUnit)
```

**参数说明：**
- `commitTimeout`: `int` — 任务提交超时时间
- `runningTimeout`: `int` — 任务执行超时时间
- `timeUnit`: `TimeUnit` — 超时时间单位

---

**重载 4**

提交同步任务

**方法签名：**
```java
public void commit(int commitTimeout, int runningTimeout, TimeUnit timeUnit, boolean timeoutAutoCancel)
```

**参数说明：**
- `commitTimeout`: `int` — 任务提交超时时间
- `runningTimeout`: `int` — 任务执行超时时间
- `timeUnit`: `TimeUnit` — 超时时间单位
- `timeoutAutoCancel`: `boolean` — 运行超时自动取消

---

### fromInput

**重载 1**

创建数据源
 
 Input用来创建数据源，是Job的源头。常见有以下几种：
 
 kd.bos.algo.input.OrmInput： ORM查询
 
 
 kd.bos.algo.input.DbInput： DB KSQL 查询
 
 
 kd.bos.algo.input.DataSetInput： 将Algo DataSet作为Input
 
 
 kd.bos.algo.input.CollectionInput： 集合对象
 
 
 kd.bos.algo.CustomizedInput： 抽象类，可自定义取数逻辑

**方法签名：**
```java
public DataSetX fromInput(Input input)
```

**参数说明：**
- `input`: `Input` — 数据源

**返回值：**
- `DataSetX`: DataSetX

---

**重载 2**

创建数据源

**方法签名：**
```java
public DataSetX fromInput(Input[] inputs)
```

**参数说明：**
- `inputs`: `Input[]` — 多个元数据一致的数据源

**返回值：**
- `DataSetX`: DataSetX

---

### getJobProgress

获取任务执行进度

**方法签名：**
```java
public static int getJobProgress(String jobId)
```

**参数说明：**
- `jobId`: `String` — jobId

**返回值：**
- `int`: 任务进度百分比值，范围[0-100]

---

### readDataSet

获取任务执行结果

**方法签名：**
```java
public DataSet readDataSet(String id)
```

**参数说明：**
- `id`: `String` — OutputId

**返回值：**
- `DataSet`: 结果集

---

### setRegion

为任务设置分区标识
 
 推荐所有的任务都设置分区标识，将同一领域或者模块的任务归为同一分区；该设置只有在AlgoX集群配置了分区集群时才会生效。

**方法签名：**
```java
public void setRegion(String region)
```

**参数说明：**
- `region`: `String` — 分区标识，区分大小写，只能是字符及数字

---

### setTitle

为任务设置标题

**方法签名：**
```java
public void setTitle(String title)
```

**参数说明：**
- `title`: `String` — 标题

---
