---
framework_version: "8.0.1"
api_class: "TimeReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-时间类型列时"
---

# TimeReportColumn API 说明

## 概述
报表列-时间类型列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：创建对象、读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.TimeReportColumn;
```

---

## 方法列表

### createColumn

打包客户端报表列元数据信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`: 返回客户端报表列元数据信息

---

### getMask

获取掩码，用于前端控件展示格式和后端格式化展示数据

**方法签名：**
```java
public String getMask()
```

**返回值：**
- `String`

---

### setMask

设置掩码，用于前端控件展示格式和后端格式化展示数据

**方法签名：**
```java
public void setMask(String mask)
```

**参数说明：**
- `mask`: `String`

---
