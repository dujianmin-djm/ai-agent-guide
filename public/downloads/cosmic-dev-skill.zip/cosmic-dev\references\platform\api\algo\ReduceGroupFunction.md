---
framework_version: "8.0.1"
api_class: "ReduceGroupFunction"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用对DataSet进行reduce处理时"
---

# ReduceGroupFunction API 说明

## 概述
对DataSet进行reduce处理，自定义reduce实现。。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：分组后，对每组的数据进行处理。

## Import 路径
```java
import kd.bos.algo.ReduceGroupFunction;
```

---

## 方法列表

### reduce

分组后，对每组的数据进行处理

**方法签名：**
```java
public abstract Iterator<Object[]> reduce(Iterator<kd.Row> iter)
```

**参数说明：**
- `iter`: `Iterator<kd.Row>` — 分组后，每组数据集的迭代器

**返回值：**
- `Iterator<Object[]>`: 每组数据进行处理后，每组数据集的迭代器

---
