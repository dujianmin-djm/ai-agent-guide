---
framework_version: "8.0.1"
api_class: "ListDcxmlBinder"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用默认实现的DcxmlBinder实现时"
---

# ListDcxmlBinder API 说明

## 概述
默认实现的DcxmlBinder实现，他通过实现给定一批实体类型来构建绑定。。继承自 DcBinder。
主要功能：根据节点的名称确定数据类型。

## Import 路径
```java
import kd.bos.dataentity.serialization.ListDcxmlBinder;
```

---

## 方法列表

### tryBindToType

根据节点的名称确定数据类型

**方法签名：**
```java
public IDataEntityType tryBindToType(String elementName, Map<String,String> attributes)
```

**参数说明：**
- `elementName`: `String`
- `attributes`: `Map<String,String>`

**返回值：**
- `IDataEntityType`: 如果找到返回IDataEntityType，否则返回空

---
