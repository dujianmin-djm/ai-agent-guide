---
framework_version: "8.0.1"
api_class: "Input"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用创建dataset的一种输入源时"
---

# Input API 说明

## 概述
创建dataset的一种输入源，可以是orm,db或者自定义的一些输入。。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.Input;
```

---

## 方法列表

### getRowMeta

获取元素据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: kd.bos.algo.RowMeta

---
