---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "approved"
---

# 操作插件开发参考

> 覆盖：AbstractOperationServicePlugIn（服务端操作插件）
> 适用：保存、提交、审核、反审、删除等操作的前后处理

## 基础结构

```java
package {isv}.{module}.opplugin;

import kd.bos.entity.plugin.AbstractOperationServicePlugIn;
import kd.bos.entity.plugin.args.BeforeOperationArgs;
import kd.bos.entity.plugin.args.AfterOperationArgs;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

public class XxxOperationPlugin extends AbstractOperationServicePlugIn {
    private static final Log logger = LogFactory.getLog(XxxOperationPlugin.class);

    @Override
    public void beforeExecuteOperationTransaction(BeforeOperationArgs args) {
        super.beforeExecuteOperationTransaction(args);
        // 操作执行前（事务内）：数据校验、前置处理
    }

    @Override
    public void afterExecuteOperationTransaction(AfterOperationArgs args) {
        super.afterExecuteOperationTransaction(args);
        // 操作执行后（事务内）：关联数据更新
    }
}
```

## 生命周期

```
onPreparePropertys（声明需要的字段）
→ beforeExecuteOperationTransaction（事务前置，可取消）
→ executeOperationTransaction（核心操作执行）
→ afterExecuteOperationTransaction（事务后置）
→ endOperationTransaction（事务提交后）
```

## 声明需要的字段（onPreparePropertys）

```java
import kd.bos.entity.plugin.PreparePropertysEventArgs;

@Override
public void onPreparePropertys(PreparePropertysEventArgs e) {
    super.onPreparePropertys(e);
    // 声明操作需要用到的字段（不声明则无法读取）
    e.getFieldKeys().add("billno");
    e.getFieldKeys().add("status");
    e.getFieldKeys().add("entryEntity.field1");  // 分录字段
}
```

## 前置校验（beforeExecuteOperationTransaction）

```java
import kd.bos.entity.plugin.args.BeforeOperationArgs;
import kd.bos.dataentity.entity.DynamicObject;

@Override
public void beforeExecuteOperationTransaction(BeforeOperationArgs args) {
    super.beforeExecuteOperationTransaction(args);
    DynamicObject[] dataEntities = args.getDataEntities();
    for (DynamicObject entity : dataEntities) {
        // 校验每个单据
        String billno = entity.getString("billno");
        if (!validateBusiness(entity)) {
            // 取消操作并给出提示
            args.setCancelMessage("单据 " + billno + " 校验失败，请检查数据");
            return;
        }
    }
}
```

## 操作后处理（afterExecuteOperationTransaction）

> **注意**：`afterExecuteOperationTransaction` 在事务成功提交后才会被回调，无需判断操作结果。
> `AfterOperationArgs` **没有** `getOperationResult()` 方法，不要与 `BeforeOperationArgs` 混淆。

```java
import kd.bos.entity.plugin.args.AfterOperationArgs;

@Override
public void afterExecuteOperationTransaction(AfterOperationArgs args) {
    super.afterExecuteOperationTransaction(args);
    // 此方法仅在操作成功后回调，无需判断 operationResult
    DynamicObject[] entities = args.getDataEntities();
    for (DynamicObject entity : entities) {
        // 更新关联数据
        updateRelatedData(entity);
    }
}
```

## 注册操作插件

在设计器中：大纲 → 根节点 → 业务属性 → 操作列表 → 对应操作（保存/提交/审核）→ 插件 → 注册全限定类名
