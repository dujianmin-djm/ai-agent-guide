---
framework_version: "8.0.1"
api_class: "SelectedDisplayField"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用已选显示字段时"
---

# SelectedDisplayField API 说明

## 概述
已选显示字段。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.SelectedDisplayField;
```

---

## 方法列表

### getMainField

获取主显示字段

**方法签名：**
```java
public String getMainField()
```

**返回值：**
- `String`: 主显示字段

---

### getSecondField

获取次显示字段

**方法签名：**
```java
public String getSecondField()
```

**返回值：**
- `String`: 次显示字段

---

### setMainField

设置主显示字段

**方法签名：**
```java
public void setMainField(String mainField)
```

**参数说明：**
- `mainField`: `String` — 主显示字段

---

### setSecondField

设置次显示字段

**方法签名：**
```java
public void setSecondField(String secondField)
```

**参数说明：**
- `secondField`: `String` — 次显示字段

---
