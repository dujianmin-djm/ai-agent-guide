---
framework_version: "8.0.1"
api_class: "MulBasedataReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-多选基础资料类型列时"
---

# MulBasedataReportColumn API 说明

## 概述
报表列-多选基础资料类型列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.report.MulBasedataReportColumn;
```

---

## 方法列表

### getValue

获取多选基础资料值

**方法签名：**
```java
public Object getValue(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject` — 行数据
- `numberFormatProvider`: `NumberFormatProvider` — 格式化信息

**返回值：**
- `Object`

---
