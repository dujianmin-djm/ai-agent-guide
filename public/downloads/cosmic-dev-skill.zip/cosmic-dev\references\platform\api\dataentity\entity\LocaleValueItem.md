---
framework_version: "8.0.1"
api_class: "LocaleValueItem"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用多语言值单项时"
---

# LocaleValueItem API 说明

## 概述
多语言值单项，某特定语言的值。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.entity.LocaleValueItem;
```

---

## 方法列表

### getLocaleId

获取语言代码

**方法签名：**
```java
public int getLocaleId()
```

**返回值：**
- `int`: 语言代码

---

### getValue

获取值

**方法签名：**
```java
public T getValue()
```

**返回值：**
- `T`

---
