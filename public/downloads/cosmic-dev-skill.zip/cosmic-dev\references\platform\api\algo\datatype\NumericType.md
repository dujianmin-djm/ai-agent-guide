---
framework_version: "8.0.1"
api_class: "NumericType"
api_package: "kd.bos.algo.datatype"
when_to_use: "当你需要使用数值类型的父类时"
---

# NumericType API 说明

## 概述
数值类型的父类。继承自 DataType，实现 Serializable。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.algo.datatype.NumericType;
```

---

## 方法列表

### acceptsType

类型比较

**方法签名：**
```java
public boolean acceptsType(DataType other)
```

**参数说明：**
- `other`: `DataType` — 被判断的类型

**返回值：**
- `boolean`: 比较结果

---

### computeCompatibleDown

向上转型

**方法签名：**
```java
public static NumericType computeCompatibleDown(NumericType left, NumericType right)
```

**参数说明：**
- `left`: `NumericType` — 类型1
- `right`: `NumericType` — 类型2

**返回值：**
- `NumericType`: 类型值较大的类型

---

### getJavaType

获取对应的Java类型

**方法签名：**
```java
public Class<?> getJavaType()
```

**返回值：**
- `Class<?>`: 对应的Java类型

---

### getSqlType

获取对应的数据库字段类型

**方法签名：**
```java
public int getSqlType()
```

**返回值：**
- `int`: 对应的数据库字段类型

---

### isAbstract

判断是否是抽象类

**方法签名：**
```java
public boolean isAbstract()
```

**返回值：**
- `boolean`

---
