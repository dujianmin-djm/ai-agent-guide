---
framework_version: "8.0.1"
api_class: "FilterContantParserArgs"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用自定义比较符常量解释参数时"
---

# FilterContantParserArgs API 说明

## 概述
自定义比较符常量解释参数。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterContantParserArgs;
```

---

## 方法列表

### getFieldName

获取ORM字段名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: ORM字段名

---

### getFilterRow

**重载 1**

获取过滤行数据

**方法签名：**
```java
public FilterRow getFilterRow()
```

**返回值：**
- `FilterRow`: 过滤行数据

---

**重载 2**

通过字段名获取FilterRow,如果字段名重复，按照视图摆放顺序，取第一个

**方法签名：**
```java
public FilterRow getFilterRow(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

**返回值：**
- `FilterRow`: 过滤字段

---

### getFilterRows

**重载 1**

获取过滤所有行数据集合

**方法签名：**
```java
public List<kd.FilterRow> getFilterRows()
```

**返回值：**
- `List<kd.FilterRow>`: 过滤所有行数据集合

---

**重载 2**

通过字段名获取过滤字段,存在多个重复字段名的情况下使用

**方法签名：**
```java
public List<kd.FilterRow> getFilterRows(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

**返回值：**
- `List<kd.FilterRow>`: 过滤字段

---

### getMainEntityType

获取过滤对象的实例类型

**方法签名：**
```java
public MainEntityType getMainEntityType()
```

**返回值：**
- `MainEntityType`: 过滤对象的实例类型

---
