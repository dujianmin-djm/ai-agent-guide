---
framework_version: "8.0.1"
api_class: "DcBinder"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用表示一个配置的绑定工具时"
---

# DcBinder API 说明

## 概述
表示一个配置的绑定工具，通过给出一个节点名称，返回此名称对应的配置对象。
主要功能：读取属性、设置属性、状态判断、事件处理。

## Import 路径
```java
import kd.bos.dataentity.serialization.DcBinder;
```

---

## 方法列表

### ThrowException

在序列化或反序列化时发生异常，决定是否抛出异常

**方法签名：**
```java
public void ThrowException(SerializationException serializationException)
```

**参数说明：**
- `serializationException`: `SerializationException`

---

### afterWriteJsonObject

对象json序列化后事件

**方法签名：**
```java
public void afterWriteJsonObject(Object currentEntity, Object baseEntity, Map<String,Object> serObj)
```

**参数说明：**
- `currentEntity`: `Object` — 当前实体
- `baseEntity`: `Object` — 基准实体
- `serObj`: `Map<String,Object>` — 序列化json

---

### bindEqualsFunc

允许定义个性化的相等判断机制，如果不重载此方法，将使用默认的判断机制。

**方法签名：**
```java
public IBindEqualsFunc bindEqualsFunc(Class<?> dataType, IBindEqualsFunc defaultFunc)
```

**参数说明：**
- `dataType`: `Class<?>`
- `defaultFunc`: `IBindEqualsFunc`

**返回值：**
- `IBindEqualsFunc`: 最终的实现

---

### bindJSONReadAction

允许定义某个数据类型的读取XML的机制，如果不重载，可以使用默认的读取方式。

**方法签名：**
```java
public ISetJsonValueAction bindJSONReadAction(Class<?> dataType, ISetJsonValueAction defaultAction)
```

**参数说明：**
- `dataType`: `Class<?>`
- `defaultAction`: `ISetJsonValueAction`

**返回值：**
- `ISetJsonValueAction`: 最终的实现。

---

### bindLocaleReadAction

允许定义多语言对象json反序列化读取器。

**方法签名：**
```java
public ISetJsonValueAction bindLocaleReadAction(ISetJsonValueAction defaultAction)
```

**参数说明：**
- `defaultAction`: `ISetJsonValueAction`

**返回值：**
- `ISetJsonValueAction`: 最终的实现。

---

### bindToName

根据当前的实体类型，返回对应的XML节点名称

**方法签名：**
```java
public String bindToName(IDataEntityType dt)
```

**参数说明：**
- `dt`: `IDataEntityType`

**返回值：**
- `String`: 对应的XML节点名称

---

### bindToStringFunc

允许自定义数据类型转换为字符串的机制，如果不重载，将使用默认的行为。

**方法签名：**
```java
public IBindToStringFunc bindToStringFunc(Class<?> dataType, IBindToStringFunc defaultFunc, RefObject<Boolean> isCData)
```

**参数说明：**
- `dataType`: `Class<?>`
- `defaultFunc`: `IBindToStringFunc`
- `isCData`: `RefObject<Boolean>`

**返回值：**
- `IBindToStringFunc`: 最终的实现。

---

### bindToType

根据节点的名称确定数据类型

**方法签名：**
```java
public IDataEntityType bindToType(String elementName, Map<String,String> attributes)
```

**参数说明：**
- `elementName`: `String`
- `attributes`: `Map<String,String>`

**返回值：**
- `IDataEntityType`: 返回数据类型

---

### createInstance

由Binder创建实例，默认实现是直接调用dt的CreateInstance方法

**方法签名：**
```java
public Object createInstance(IDataEntityType dt)
```

**参数说明：**
- `dt`: `IDataEntityType`

**返回值：**
- `Object`: 新的实例
 
         派生类可以重载此方法，例如标记实例创建的时机，或返回他的代理。

---

### getConvertFunc

获取转换函数

**方法签名：**
```java
public IBindToStringFunc getConvertFunc(ISimpleProperty property, Object dataEntity, Object value, RefObject<Boolean> isCData, IBindToStringFunc func)
```

**参数说明：**
- `property`: `ISimpleProperty` — 属性
- `dataEntity`: `Object` — 实体
- `value`: `Object` — 值
- `isCData`: `RefObject<Boolean>` — 是否写入CDATA
- `func`: `IBindToStringFunc` — 值转换函数

**返回值：**
- `IBindToStringFunc`: 转换函数

---

### getDataEntityAttributes

返回指定实体的附属信息

**方法签名：**
```java
public Map<String,String> getDataEntityAttributes(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Map<String,String>`: 此实体的附属的信息

---

### getDataEntityType

返回指定实体的类型信息

**方法签名：**
```java
public IDataEntityType getDataEntityType(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `IDataEntityType`: 此实体的类型信息

---

### getLCId

返回/设置在执行序列化和反序列化时，对应的时区信息，默认是当前时区。

**方法签名：**
```java
public final String getLCId()
```

**返回值：**
- `String`

---

### getOnlyDbProperty

返回/设置是否仅处理数据库有关的属性，默认为true.

**方法签名：**
```java
public final boolean getOnlyDbProperty()
```

**返回值：**
- `boolean`

---

### getPrimitiveType

{待补充}

**方法签名：**
```java
public static Class<?> getPrimitiveType(String elementName)
```

**参数说明：**
- `elementName`: `String`

**返回值：**
- `Class<?>`

---

### getResourceProvider

{待补充}

**方法签名：**
```java
public IMetadataResourceProvider getResourceProvider()
```

**返回值：**
- `IMetadataResourceProvider`

---

### isIgnoreCase

返回用于比较实体类型的字符串比较策略，默认是忽略大小写

**方法签名：**
```java
public final boolean isIgnoreCase()
```

**返回值：**
- `boolean`

---

### isSerializeDefaultValue

{待补充}

**方法签名：**
```java
public boolean isSerializeDefaultValue()
```

**返回值：**
- `boolean`: the serializeByDefValue

---

### readCustomJsonProperty

json数据写入自定义属性到对象

**方法签名：**
```java
public void readCustomJsonProperty(Map.Entry<String,Object> kv, Object entity)
```

**参数说明：**
- `kv`: `Map.Entry<String,Object>`
- `entity`: `Object`

---

### readCustomXmlProperty

xml数据写入自定义属性到对象

**方法签名：**
```java
public void readCustomXmlProperty(Element element, Object entity)
```

**参数说明：**
- `element`: `Element`
- `entity`: `Object`

---

### readSimpleProperty

反序列化简单属性

**方法签名：**
```java
public boolean readSimpleProperty(ISimpleProperty property, Element propElement, Object entity)
```

**参数说明：**
- `property`: `ISimpleProperty` — 属性描述
- `propElement`: `Element` — xml数据
- `entity`: `Object` — 目标对象

**返回值：**
- `boolean`

---

### setIgnoreCase

设置忽略大小写

**方法签名：**
```java
public final void setIgnoreCase(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setLCId

设置反序列化语种

**方法签名：**
```java
public final void setLCId(String value)
```

**参数说明：**
- `value`: `String`

---

### setOnlyDbProperty

设置仅处理 db存储的属性

**方法签名：**
```java
public final void setOnlyDbProperty(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setResourceProvider

{待补充}

**方法签名：**
```java
public void setResourceProvider(IMetadataResourceProvider resourceProvider)
```

**参数说明：**
- `resourceProvider`: `IMetadataResourceProvider`

---

### setSerializeDefaultValue

{待补充}

**方法签名：**
```java
public void setSerializeDefaultValue(boolean serializeDefaultValue)
```

**参数说明：**
- `serializeDefaultValue`: `boolean`

---

### tryBindToType

根据节点的名称确定数据类型

**方法签名：**
```java
public abstract IDataEntityType tryBindToType(String elementName, Map<String,String> attributes)
```

**参数说明：**
- `elementName`: `String`
- `attributes`: `Map<String,String>`

**返回值：**
- `IDataEntityType`: 如果找到返回true，否则返回false

---

### writeCustomJsonProperties

自定义属性数据写入Json

**方法签名：**
```java
public void writeCustomJsonProperties(Map<String,Object> serObj, Object current, Object base)
```

**参数说明：**
- `serObj`: `Map<String,Object>`
- `current`: `Object`
- `base`: `Object`

---

### writeCustomXmlProperties

自定义属性数据写入xml

**方法签名：**
```java
public void writeCustomXmlProperties(Element serObj, Object current, Object base)
```

**参数说明：**
- `serObj`: `Element`
- `current`: `Object`
- `base`: `Object`

---

### writeSimpleProperty

简单属性对象序列化

**方法签名：**
```java
public boolean writeSimpleProperty(Element serObj, ISimpleProperty property, Object entity)
```

**参数说明：**
- `serObj`: `Element` — xml元素
- `property`: `ISimpleProperty` — 属性
- `entity`: `Object` — 对象

**返回值：**
- `boolean`

---
