---
framework_version: "8.0.1"
api_class: "FilterBuilder"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤条件构造类时"
---

# FilterBuilder API 说明

## 概述
过滤条件构造类。
主要功能：读取属性、添加元素、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterBuilder;
```

---

## 方法列表

### addCustomCompareTypes

添加自定义比较符

**方法签名：**
```java
public void addCustomCompareTypes(String fieldName, List<kd.CompareType> compareTypes)
```

**参数说明：**
- `fieldName`: `String`
- `compareTypes`: `List<kd.CompareType>`

---

### addFilterField

**重载 1**

添加过滤字段

**方法签名：**
```java
public void addFilterField(String fieldName, String compare, String left, String right, List<Object> value, String logic)
```

**参数说明：**
- `fieldName`: `String`
- `compare`: `String`
- `left`: `String`
- `right`: `String`
- `value`: `List<Object>`
- `logic`: `String`

---

**重载 2**

添加过滤字段

**方法签名：**
```java
public void addFilterField(String fieldName, String compare, String left, String right, List<Object> value, String logic, String entityNumber)
```

**参数说明：**
- `fieldName`: `String`
- `compare`: `String`
- `left`: `String`
- `right`: `String`
- `value`: `List<Object>`
- `logic`: `String`
- `entityNumber`: `String`

---

### addFlexField

添加弹性域字段

**方法签名：**
```java
public void addFlexField(String flexField)
```

**参数说明：**
- `flexField`: `String`

---

### buildFilter

**重载 1**

解析过滤元数据

**方法签名：**
```java
public void buildFilter()
```

---

**重载 2**

解析过滤元数据

**方法签名：**
```java
public void buildFilter(boolean returnSql)
```

**参数说明：**
- `returnSql`: `boolean`

---

### buildFilterScript

解析条件，输出脚本表达式与表达式说明

**方法签名：**
```java
public String[] buildFilterScript()
```

**返回值：**
- `String[]`: return[0] =脚本表达式，return[1] = 表达式说明

---

### getConvertFieldsMap

获取转换字段集合

**方法签名：**
```java
public Map<String,String> getConvertFieldsMap()
```

**返回值：**
- `Map<String,String>`

---

### getFilterField

**重载 1**

根据过滤字段工具类缓存对象以及字段名获取工具类对象

**方法签名：**
```java
public static FilterField getFilterField(FilterObject filterObject, String fieldName)
```

**参数说明：**
- `filterObject`: `FilterObject` — 过滤字段工具类缓存对象 FilterObject
- `fieldName`: `String` — 字段名

**返回值：**
- `FilterField`: 过滤工具类对象

---

**重载 2**

获取过滤字段

**方法签名：**
```java
public static FilterField getFilterField(MainEntityType dataType, String fieldName)
```

**参数说明：**
- `dataType`: `MainEntityType`
- `fieldName`: `String`

**返回值：**
- `FilterField`: 字段信息

---

### getFilterObject

获取过滤条件中间缓存对象

**方法签名：**
```java
public FilterObject getFilterObject()
```

**返回值：**
- `FilterObject`: 过滤条件中间缓存对象

---

### getFilterString

获取解析的条件语句描述,SQL形式

**方法签名：**
```java
public String getFilterString()
```

**返回值：**
- `String`: 解析的条件语句描述,SQL形式

---

### getFilterStringDesc

获取解析的条件语句描述,中文形式

**方法签名：**
```java
public String getFilterStringDesc()
```

**返回值：**
- `String`: 解析的条件语句描述,中文形式

---

### getFlexPropExtendResultMap

获取弹性域扩展属性结果集合

**方法签名：**
```java
public Map<String,CreateExtendFilterFieldsResult> getFlexPropExtendResultMap()
```

**返回值：**
- `Map<String,CreateExtendFilterFieldsResult>`

---

### getQFilter

获取过滤条件

**方法签名：**
```java
public QFilter getQFilter()
```

**返回值：**
- `QFilter`: 过滤条件

---

### getQFilters

获取解析的过滤条件，一行是一个QFilter

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`: 解析的过滤条件，一行是一个QFilter

---

### getUsedFilterFields

获取解析的过滤查询相关字段

**方法签名：**
```java
public List<String> getUsedFilterFields()
```

**返回值：**
- `List<String>`

---

### getUsedFilterFieldsWithNotCompare

获取解析的过滤查询相关的不等于字段

**方法签名：**
```java
public List<String> getUsedFilterFieldsWithNotCompare()
```

**返回值：**
- `List<String>`

---

### isContainBillStatus

获取是否包括单据状态

**方法签名：**
```java
public boolean isContainBillStatus()
```

**返回值：**
- `boolean`: 是否包括单据状态

---

### isContainMainOrg

获取是否主业务组织

**方法签名：**
```java
public boolean isContainMainOrg()
```

**返回值：**
- `boolean`: 是否主业务组织

---

### isContainUsedStatus

获取是否包括使用状态

**方法签名：**
```java
public boolean isContainUsedStatus()
```

**返回值：**
- `boolean`: 是否包括使用状态

---

### isMainOrgNoLimit

获取如果包括主业务组织，主业务组织过滤条件是否为不限

**方法签名：**
```java
public boolean isMainOrgNoLimit()
```

**返回值：**
- `boolean`: 如果包括主业务组织，主业务组织过滤条件是否为不限

---

### setFilterObject

设置过滤条件中间缓存对象

**方法签名：**
```java
public void setFilterObject(FilterObject filterObject)
```

**参数说明：**
- `filterObject`: `FilterObject`

---

### setUserService

设置用户获取服务类

**方法签名：**
```java
public void setUserService(IUserService userService)
```

**参数说明：**
- `userService`: `IUserService`

---
