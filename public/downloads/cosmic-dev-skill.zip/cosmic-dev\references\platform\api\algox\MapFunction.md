---
framework_version: "8.0.1"
api_class: "MapFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用用于处理映射的回调接口时"
---

# MapFunction API 说明

## 概述
用于处理映射的回调接口。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：映射函数。

## Import 路径
```java
import kd.bos.algox.MapFunction;
```

---

## 方法列表

### map

映射函数

**方法签名：**
```java
public abstract RowX map(RowX row)
```

**参数说明：**
- `row`: `RowX` — RowX

**返回值：**
- `RowX`: 新RowX

---
