---
framework_version: "8.0.1"
api_class: "RowMeta"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用元素据信息：主要包含当前DataSet的列名称时"
---

# RowMeta API 说明

## 概述
元素据信息：主要包含当前DataSet的列名称，别名，列类型等信息。元数据信息一旦确定，不允许修改!。实现 Serializable。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.algo.RowMeta;
```

---

## 方法列表

### fromResultSet

根据ResultSet返回元素据

**方法签名：**
```java
public static RowMeta fromResultSet(ResultSet rs)
```

**参数说明：**
- `rs`: `ResultSet` — 数据库结果集

**返回值：**
- `RowMeta`: 数据库结果集对应的元素据

---

### getDataType

返回对应索引位置的数据类型

**方法签名：**
```java
public DataType getDataType(int index)
```

**参数说明：**
- `index`: `int` — 列对应的索引值

**返回值：**
- `DataType`: 对应索引位置的数据类型

---

### getDataTypeOrdinals

返回所有属性对应的数据类型的枚举数字值

**方法签名：**
```java
public int[] getDataTypeOrdinals()
```

**返回值：**
- `int[]`: 所有属性对应的数据类型的枚举数字值

---

### getDataTypes

返回所有属性的数据类型

**方法签名：**
```java
public DataType[] getDataTypes()
```

**返回值：**
- `DataType[]`: 所有属性的数据类型

---

### getField

**重载 1**

根据索引获取属性

**方法签名：**
```java
public Field getField(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Field`: 对应属性

---

**重载 2**

根据名称或者别名获取属性

**方法签名：**
```java
public Field getField(String nameOrAlias)
```

**参数说明：**
- `nameOrAlias`: `String` — 名称或别名

**返回值：**
- `Field`: 对应属性

---

**重载 3**

根据名称或者别名获取属性

**方法签名：**
```java
public Field getField(String nameOrAlias, boolean throwException)
```

**参数说明：**
- `nameOrAlias`: `String` — 名称或别名
- `throwException`: `boolean` — 当不存在该字段时，是否抛出异常

**返回值：**
- `Field`: 对应属性

---

### getFieldAlias

返回对应索引值属性的别名

**方法签名：**
```java
public String getFieldAlias(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `String`: 对应索引值属性的别名

---

### getFieldCount

返回属性个数

**方法签名：**
```java
public int getFieldCount()
```

**返回值：**
- `int`: 属性个数

---

### getFieldDataType

返回对应索引值属性的类型

**方法签名：**
```java
public DataType getFieldDataType(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `DataType`: 对应索引值属性的类型

---

### getFieldIndex

**重载 1**

返回属性对应的索引值

**方法签名：**
```java
public int getFieldIndex(String nameOrAlias)
```

**参数说明：**
- `nameOrAlias`: `String` — 名称或别名

**返回值：**
- `int`: 属性对应的索引值

---

**重载 2**

返回属性对应的索引值

**方法签名：**
```java
public int getFieldIndex(String nameOrAlias, boolean throwException)
```

**参数说明：**
- `nameOrAlias`: `String` — 名称或别名
- `throwException`: `boolean` — 当不存在该字段时，是否抛出异常

**返回值：**
- `int`: 属性对应的索引值

---

### getFieldName

返回对应索引值位置属性的名称

**方法签名：**
```java
public String getFieldName(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `String`: 对应索引值位置属性的名称

---

### getFieldNames

返回所有属性别名

**方法签名：**
```java
public String[] getFieldNames()
```

**返回值：**
- `String[]`: 所有属性别名

---

### getFields

**重载 1**

获取所有属性

**方法签名：**
```java
public Field[] getFields()
```

**返回值：**
- `Field[]`: 有属性

---

**重载 2**

返回所有属性

**方法签名：**
```java
public Field[] getFields(String[] fieldNames)
```

**参数说明：**
- `fieldNames`: `String[]` — 字段名称

**返回值：**
- `Field[]`: 所有属性

---

### getTypes

返回所有数据类型

**方法签名：**
```java
public List<kd.DataType> getTypes()
```

**返回值：**
- `List<kd.DataType>`: 所有数据类型

---

### isNullable

返回对应索引值的属性是否为空

**方法签名：**
```java
public final boolean isNullable(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `boolean`: 对应索引值的属性是否为空

---

### toMap

**重载 1**

将Row转成map

**方法签名：**
```java
public Map<String,Object> toMap(Row row)
```

**参数说明：**
- `row`: `Row` — 行数据

**返回值：**
- `Map<String,Object>`: 转换后的map

---

**重载 2**

将Row转成map

**方法签名：**
```java
public void toMap(Row row, Map<String,Object> map)
```

**参数说明：**
- `row`: `Row` — 行数据
- `map`: `Map<String,Object>` — 存放转换后的map

---

### toString

输出所有属性

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 所有属性

---
