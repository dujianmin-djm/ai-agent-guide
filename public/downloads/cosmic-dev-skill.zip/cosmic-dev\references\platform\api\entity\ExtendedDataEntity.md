---
framework_version: "8.0.1"
api_class: "ExtendedDataEntity"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用将垂直的实体数据打平时"
---

# ExtendedDataEntity API 说明

## 概述
将垂直的实体数据打平，便于获取。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.ExtendedDataEntity;
```

---

## 方法列表

### getBillNo

获取单据编号

**方法签名：**
```java
public String getBillNo()
```

**返回值：**
- `String`: 单据编号

---

### getBillPkId

获取单据主键ID

**方法签名：**
```java
public Object getBillPkId()
```

**返回值：**
- `Object`: 单据主键ID

---

### getDataEntity

获取实体数据

**方法签名：**
```java
public DynamicObject getDataEntity()
```

**返回值：**
- `DynamicObject`: 实体数据

---

### getDataEntityIndex

获取单个数据包在整个数据包中索引，列表中的次序

**方法签名：**
```java
public int getDataEntityIndex()
```

**返回值：**
- `int`: 索引

---

### getObjectByName

此方法已废弃，请勿调用

**方法签名：**
```java
public Object getObjectByName(String name)
```

**参数说明：**
- `name`: `String`

**返回值：**
- `Object`

---

### getRowIndex

获取数据行索引

**方法签名：**
```java
public int getRowIndex()
```

**返回值：**
- `int`: 数据行索引

---

### getSubRowIndex

获取数据行索引所在分录索引

**方法签名：**
```java
public int getSubRowIndex()
```

**返回值：**
- `int`: 数据行索引所在分录索引

---

### getValidataErrorCode

获取校验错误码

**方法签名：**
```java
public ValidataErrorCode getValidataErrorCode()
```

**返回值：**
- `ValidataErrorCode`

---

### getValue

获取实体属性数据

**方法签名：**
```java
public Object getValue(String name)
```

**参数说明：**
- `name`: `String` — 实体属性名称

**返回值：**
- `Object`: Object 实体属性数据

---

### setBillNo

设置单据编号

**方法签名：**
```java
public void setBillNo(String billNo)
```

**参数说明：**
- `billNo`: `String` — 单据编号

---

### setDataEntity

设置实体数据

**方法签名：**
```java
public void setDataEntity(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject` — 实体数据

---

### setDataEntityIndex

设置分录索引

**方法签名：**
```java
public void setDataEntityIndex(int dataEntityIndex)
```

**参数说明：**
- `dataEntityIndex`: `int` — 分录索引

---

### setObjectByName

此方法已废弃，请勿调用

**方法签名：**
```java
public void setObjectByName(String name, Object value)
```

**参数说明：**
- `name`: `String`
- `value`: `Object`

---

### setRowIndex

设置数据行索引

**方法签名：**
```java
public void setRowIndex(int rowIndex)
```

**参数说明：**
- `rowIndex`: `int` — 数据行索引

---

### setSubRowIndex

设置数据行索引所在分录索引

**方法签名：**
```java
public void setSubRowIndex(int subRowIndex)
```

**参数说明：**
- `subRowIndex`: `int` — 数据行索引所在分录索引

---

### setValidataErrorCode

设置校验错误码

**方法签名：**
```java
public void setValidataErrorCode(ValidataErrorCode validataErrorCode)
```

**参数说明：**
- `validataErrorCode`: `ValidataErrorCode`

---

### setValue

设置实体属性数据

**方法签名：**
```java
public void setValue(String name, Object value)
```

**参数说明：**
- `name`: `String` — 实体属性名称
- `value`: `Object` — 实体属性数据

---
