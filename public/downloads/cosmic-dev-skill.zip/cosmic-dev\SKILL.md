---
name: cosmic-dev
description: >
  金蝶云苍穹（Kingdee Cloud Cosmic）标品开发 / 各业务线开发全流程助手。
  ALWAYS TRIGGER when 用户提到以下任一场景：
  开发单据时;
  元数据建模（建单据、建基础资料、主数据建模、创建元数据、一键建模）；
  元数据修改（加字段、删字段、改必填、改类型、改字段名、修改元数据）；
  PDM生成（数据模型同步、建表脚本、PDM同步）；
  插件开发，业务逻辑开发（表单插件、操作插件、列表插件、工作流、调度任务、Java代码生成、写插件）；
  单元测试（验证元数据、测试建模、设计测试用例、查看测试结果）；
  苍穹 OpenAPI / 框架问题 / API 用法。
---

**本技能被激活时（对话中首次调用），并行执行：输出以下欢迎信息 + 读取全局配置。**

**轻量启动门：检查 `SKILL_DIR/skills/config.json` 是否存在：**
- **不存在** → 提示用户复制 `SKILL_DIR/skills/config.example.json` 并填写必填项（`javaHome`、`server.baseUrl`），停止执行
- **存在** → 读取配置，静默通过，继续执行用户请求

> 字段完整性校验由子技能按需触发（元数据操作触发 Pre-flight Gate，代码生成仅需 `javaHome`）。

---

## Vibecoding 流水线

金蝶云苍穹标品开发标准流水线（各阶段可独立进入，无需按顺序）：

| 阶段 | 名称 | 关键词 | 执行路径 | 状态 |
|------|------|--------|----------|------|
| Stage 1 | 需求分析 | 需求分析/PRD/功能描述/用户故事 | `skills/requirements/SKILL.md` | 预留 |
| Stage 2 | 架构设计 | 架构设计/模块划分/服务设计 | `skills/architecture/SKILL.md` | 预留 |
| Stage 3 | 元数据建模 | 开发单据/建单据/建基础资料/主数据/一键建模 | 读取 `skills/cosmic-meta-modeling/SKILL.md` | ✅ |
| Stage 3.5 | 应用菜单发布 | 发布菜单/应用菜单/添加菜单/菜单管理/查看菜单/修改菜单/删除菜单/移动菜单 | 读取 `skills/cosmic-meta-modeling/modules/app-menu/SKILL.md` | ✅ |
| Stage 3.6 | 功能分组管理 | 新增分组/删除分组/修改分组/查看分组/功能分组 | 直接执行 `cosmic_api.py` 功能分组命令（见下方「Stage 3.6 详情」） | ✅ |
| Stage 4 | 元数据修改 | 加字段/删字段/改必填/改类型/改字段名/加按钮/删按钮/改按钮/面板调整/布局调整 | 读取 `skills/cosmic-meta-modifier/SKILL.md` | ✅ |
| Stage 4.1 | 表单UI管理 | 面板布局/查看面板/调整布局/面板操作/容器管理/拆分容器/按钮排序/UI校正/改样式/改颜色/改字体/样式调整 | 读取 `skills/cosmic-meta-ui/SKILL.md` | ✅ |
| Stage 4.2 | 操作管理 | 添加操作/修改操作/删除操作/配置审核/操作管理 | 读取 `skills/cosmic-meta-modifier/modules/operation/SKILL.md` | ✅ |
| Stage 4.3 | 插件注册 | 注册插件/绑定插件/删除插件/挂载插件 | 读取 `skills/cosmic-meta-modifier/modules/plugin/SKILL.md` | ✅ |
| Stage 4.4 | 规则管理 | 添加规则/界面规则/业务规则/条件必填/联动公式 | 读取 `skills/cosmic-meta-modifier/modules/rule/SKILL.md` | ✅ |
| Stage 4.5 | 属性精调 | 设置属性/功能控制/过滤条件/引用属性/精调/权限控制 | 读取 `skills/cosmic-meta-modifier/modules/property/SKILL.md` | ✅ |
| Stage 4.6 | 表单操作 | 扩展表单/继承表单/复制表单/移动表单/启用表单/禁用表单/查看视图层级 | 读取 `skills/cosmic-meta-modifier/modules/form-action/SKILL.md` | ✅ |
| Stage 5 | PDM 生成 | 生成PDM/同步数据模型/建表脚本 | 读取 `skills/cosmic-meta-api/modules/pdm/SKILL.md` | ✅ |
| Stage 6 | 插件开发 | 写插件/生成插件/业务逻辑/联动/校验 | 见下方「Stage 6 详情」节 | ✅ |
| Stage 7 | 单元测试 | 跑测试/验证元数据/测试建模 | 读取 `skills/cosmic-meta-test/SKILL.md` | ✅ |

### 流程编排图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Vibecoding 流水线                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│   Stage 3 元数据建模                                                             │
│         │                                                                       │
│         ▼                                                                       │
│   Stage 3.5 应用菜单发布（可选）                                                 │
│         │                                                                       │
│         ▼                                                                       │
│   ┌─────────────────────────────────────────────────────────────────────┐       │
│   │                      Stage 4 元数据修改                              │       │
│   │  ┌──────────────────────────────────────────────────────────────┐   │       │
│   │  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │       │
│   │  │  │ 4.1 UI   │ │ 4.2 操作 │ │ 4.3 插件 │ │ 4.4 规则 │ │ 4.5 属性 │   │       │
│   │  │  │ 管理     │ │ 管理     │ │ 注册     │ │ 管理     │ │ 精调     │   │       │
│   │  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘   │       │
│   │  │                    ↑ 并列，按需选择 ↑                             │   │       │
│   │  └──────────────────────────────────────────────────────────────┘   │       │
│   │                              │                                       │       │
│   │                              ▼                                       │       │
│   │                    ╔═══════════════════╗                             │       │
│   │                    ║ 循环修改直到满足需求 ║◀────────────────────────┐   │       │
│   │                    ╚═══════════════════╝                          │   │       │
│   │                              │                                    │   │       │
│   │                              └────────────────────────────────────┘   │       │
│   └─────────────────────────────────────────────────────────────────────┘       │
│         │                                                                       │
│         ▼                                                                       │
│   Stage 5 PDM 生成 ──▶ Stage 6 插件开发 ──▶ Stage 7 单元测试                     │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**阶段关系说明：**
- **Stage 3 → Stage 3.5**：建模完成后，可选发布为应用菜单（buildMeta 成功后自动引导）
- **Stage 3 → Stage 4.1（按需）**：buildMeta 完成后，若发现 UI 结构异常（如多分录容器共享、按钮归属错位），可手动调用 cosmic-meta-ui reconcile 模块进行 UI 校正
- **Stage 3.5 → Stage 4**：菜单发布后（或跳过），可进入元数据修改
- **Stage 3 → Stage 4**：建模完成后，可直接进入 Stage 4 系列的任何子阶段
- **Stage 4 → Stage 4.1（路由）**：纯 UI 操作（面板增删、按钮位置调整、容器管理、字段可见性等仅涉及 form 层的操作）由 modifier 自动路由到 cosmic-meta-ui 处理
- **Stage 4.1~4.5**：并列关系，用户可按需选择，不必全部执行
- **循环修改**：每个子阶段完成后可循环回到 Stage 4 继续其他修改
- **后续阶段**：元数据修改完成后，可进入 PDM 生成、插件开发、单元测试

### 入口判断规则

1. **关键词命中** → 直接跳入对应阶段，读取执行路径中的 SKILL.md（或执行脚本）
2. **无法判断** → 展示上方阶段表，询问用户处于哪个阶段
3. **阶段上下文传递**：如果 `RUNTIME_DIR/context.md` 存在，可从中读取 entityKey / formId 加速后续阶段；Stage 5/6/7 不强制依赖此文件，各子技能自身已覆盖无 context.md 的场景
4. **预留阶段触发时**：告知用户该阶段尚未实现，并引导：建模类意图（建单据/基础资料）→ Stage 3；开发类意图（插件/代码）→ Stage 6；无法判断 → 展示阶段表询问

## 路由判别决策表

| 用户意图关键词 | 路由目标 | 说明 |
|---------------|---------|------|
| "改字段/加字段/删字段/改必填/改类型" | Stage 4 modifier | 元数据结构修改 |
| "改布局/拖拽/调整位置/移动控件" | Stage 4 modifier → ui 模块 | UI 结构调整 |
| "改标题/改提示/改颜色/改样式/改宽度" | Stage 4 modifier → ui 模块 | UI 展示属性 |
| "建单据/建基础资料/新建表单" | Stage 3 modeling | 新建元数据 |
| "新增分组/删除分组/修改分组/查看分组/功能分组" | Stage 3.6 功能分组管理 | **不走菜单管理**，直接用 `listUnits`/`addUnit` 等命令 |

### Stage 4.1 → cosmic-meta-ui

触发条件：用户明确要求面板/布局管理操作或样式设置，或 modifier 检测到纯 UI 意图时自动路由
关键词：面板布局、查看面板、调整布局、面板操作、容器管理、拆分容器、按钮排序、改样式、改颜色、改字体、样式调整
说明：Stage 4.1 可由用户直接触发，也可由 Stage 4（modifier）内部路由触发。当 modifier 检测到 UI 类意图时，自动路由到 meta-ui 处理。reconcile 模块作为独立的 UI 校正工具，可在需要时手动调用。

**关键词→阶段映射补充：**
- 面板/布局 → Stage 4.1（或由 Stage 4 内部路由）
- 按钮 → Stage 4（modifier 统一入口）→ 内部路由到 meta-ui
- 扩展/继承/复制/移动/启用/禁用 → Stage 4.6
- **功能分组/新增分组/删除分组/修改分组/查看分组 → Stage 3.6**（不走 Stage 3.5 菜单管理）

---

### Stage 3.6 详情：功能分组管理

> **⚠️ 功能分组（bizUnit）≠ 应用菜单（menu）**。功能分组是苍穹应用内的功能模块划分（建模时的目标分组），菜单是用户界面的导航结构。两者独立管理，不可混淆路由。

**触发关键词**：新增分组、删除分组、修改分组、查看分组、功能分组
**不需要单独 SKILL.md**，直接执行 `cosmic_api.py` 的功能分组命令。

#### 可用命令

| 操作 | 命令 | 必填参数 |
|------|------|----------|
| 查看分组列表 | `listUnits` | `--bizAppId` 或 `--bizAppNumber` |
| 查看分组详情 | `getUnit` | `--bizAppId` + `--unitId` |
| 新增分组 | `addUnit` | `--bizAppId`/`--bizAppNumber` + `--name` + `--number` + `--description` + `--seq` |
| 修改分组 | `updateUnit` | `--bizAppId` + `--unitId` + 修改字段 |
| 删除分组 | `deleteUnit` | `--bizAppId` + `--unitId` |

#### 执行流程

1. `listUnits` 查看当前分组列表（了解编码规范和序号情况）
2. 组装参数，向用户确认
3. 执行命令
4. 展示结果
5. **（addUnit 成功后）自动将 bizAppId / bizUnitId / bizUnitName 写入 `RUNTIME_DIR/workspace.json`**，使后续 buildMeta 的 Step G 零交互通过：
   ```bash
   {python} "{cosmic_api}" setConfig --biz-app-id "<bizAppId>" --biz-unit-id "<返回的unitId>" --biz-unit-name "<分组名称>"
   ```
   > 若 setConfig 不支持这些参数，直接用文件写入工具编辑 workspace.json 追加字段。

#### addUnit 参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `--bizAppId` / `--bizAppNumber` | 二选一 | 应用 ID 或编码 |
| `--name` | 是 | 功能分组名称 |
| `--number` | 是 | 功能分组编码（参考已有分组的命名风格） |
| `--description` | 是 | 功能分组描述 |
| `--seq` | 是 | 序号，范围 [0, 1000) |
| `--parentUnitId` | 否 | 上级分组 ID，空 = 一级分组 |
| `--isLeaf` | 否 | 是否叶子节点（默认 true） |

---

**Cosmic DEV — 金蝶苍穹插件开发平台**

直接描述需求或上传需求文档即可开始，支持三种开发模式：

| 模式 | 说明 | 示例 |
|------|------|------|
| **新建** | 从零生成新插件代码 | "费用报销单，选择费用类型后自动带出会计科目" |
| **修改** | 对已有插件补充或修改功能 | "@PurchaseOrderBillPlugin.java 增加供应商信用校验" 或 "@采购订单申请变更.md" |
| **服务** | 开发不属于任何插件的独立服务类 | "封装一个价格计算服务，支持多种折扣策略" |

也可直接调用子技能：`/cosmic-gen`（后端） | `/kwc-react-development`（前端组件）

> 系统自动识别开发模式和前后端需求并路由。

## 全局配置

Skill 启动时，读取配置文件加载全局配置。

> **SKILL_DIR 推算方法**：你在读取本 SKILL.md 时会获得文件的绝对路径（如 `/home/kingdee/.claude/skills/cosmic-dev/SKILL.md`），对该路径取 `dirname` 即为 `SKILL_DIR`（如 `/home/kingdee/.claude/skills/cosmic-dev`）。后续所有 `SKILL_DIR` 引用均指此目录。
>
> **RUNTIME_DIR 推算方法**：`SKILL_DIR/../../runtime/cosmic-dev/`（即 Agent 根目录下的 `runtime/cosmic-dev/`）。存放 workspace.json、context.md、token 缓存等运行时状态，由 Python 脚本自动管理。子技能引用 `RUNTIME_DIR` 时直接使用此处推算后的绝对路径。
>
> **铁律**：所有涉及文件路径的 shell 命令，**必须**使用 SKILL_DIR 的绝对路径拼接，**禁止**在命令中使用 `~` 或未展开的相对路径。SKILL_DIR 在技能激活时从 SKILL.md 的实际读取路径推算并记住，后续直接使用该绝对路径。
>
> **Python 命令**：根据当前操作系统选择正确的 Python 命令——Windows 使用 `python`，Linux/macOS 使用 `python3`。
>
> **配置文件路径**：`SKILL_DIR/skills/config.json`

配置字段说明参见 `SKILL_DIR/skills/config.example.json`。以下为关键配置说明：

| 配置项 | 必填 | 说明 |
|--------|------|------|
| `architecture` | 否 | `plugin`（默认）= 全插件架构；`frontend` = 前后端分离（暂不可用） |
| `isv` | 否 | 开发商标识，由 getDevInfo 动态获取，结果缓存到 config.md；同时作为 API 路径前缀 |
| `javaHome` | 是 | JDK 路径 |
| `enableCompile` | 否 | 编译验证开关，默认关闭 |
| `server.baseUrl` | 是（元数据操作） | 苍穹服务地址 |
| `server.appId/appSecret/accountId/user` | 是（元数据操作） | OpenAPI 凭据 |
| `server.tenantId` | 否 | 租户 ID，默认 `ierp` |
| `pdm.*` | 否 | PDM 工具专用连接，可与 server 不同 |

> `appNumber`（苍穹应用编码）和 `bizCloudName`（业务云名称）存储在 `RUNTIME_DIR/workspace.json` 中（由初始化向导 G4 自动写入），不在 config.json 中。

> 元数据脚本（`SKILL_DIR/skills/cosmic-gen/scripts/search_form_by_token.py`、`SKILL_DIR/skills/cosmic-gen/scripts/run.py`）直接读取此配置文件。
> **编译约束**：执行任何编译命令前，必须先从 `SKILL_DIR/skills/config.json` 读取 `mavenHome`、`javaHome`、`maven.settingsPath`，使用这些绝对路径构造编译命令。**禁止直接调用系统 PATH 中的 `mvn`、`mvn.cmd`、`java`、`gradle` 等命令**——系统 PATH 中的工具可能指向错误的本地仓库（如 `settings.xml` 中 `localRepository` 配置的路径不可用），导致依赖解析失败。详见 `SKILL_DIR/skills/cosmic-gen/references/compile-guide.md`。

## 项目目录

Skill 启动时，将 IDE 当前工作目录（`pwd`）作为**项目目录**。代码生成、`spec/` 存储、包路径推断等操作均基于此目录。

**启动时确认**：加载全局配置后，向用户展示当前项目目录并确认：

```
📁 当前项目目录：{pwd}
代码将生成到此目录下。如需切换请提供目标路径，确认请继续描述需求。
```

**对话中切换**：用户可以随时说"切换到 `xxx`"来变更项目目录。切换后重新确认。

> 项目目录不存储在 `config.json` 中，完全由 IDE 环境和用户对话决定。

## 技能执行原则

一旦根据流水线阶段表选定某个技能，**第一动作必须是：读取该技能的 SKILL.md**，再按技能内规定的步骤执行。

| 原则 | 说明 |
|------|------|
| **先读再做** | 先 `Read(技能/SKILL.md)`，再按 Step 0~N 执行；不凭记忆或直觉跳过读取 |
| **不替技能造轮子** | 技能里已定义流程的，按现有 API/工具完成，不另写一次性脚本替代 |
| **例外允许** | 仅当技能未覆盖该场景、技能内明确允许、或用户明确要求时，才可偏离技能流程 |

---

## Stage 6 详情：插件开发

**Stage 6 入口判断（本节仅适用于插件开发需求，其他阶段见上方流水线阶段表）：**

1. **用户指定了已有插件文件 + 变更需求**（@文件或路径 + 描述修改/新增/删除功能）→ 路由至 cosmic-gen **patch 模式**。
2. **用户描述的是独立服务类需求**（不绑定特定表单/插件，是独立的服务/工具类）→ 路由至 cosmic-gen **service 模式**。
3. **用户提供了新建需求**（上传文档或直接描述新功能）→ 执行「**需求分析与路由**」流程（默认 cosmic-gen **create 模式**）。
4. **用户仅输入 `/cosmic-dev` 无附加内容** → 展示上方帮助菜单，等待用户输入需求。
5. **用户询问苍穹 API / 框架问题**（非代码生成） → 读取 `SKILL_DIR/skills/cosmic-gen/references/` 知识库查找并回答。

> **模式识别原则**：patch 和 service 有明确特征时直接路由（不经过下方的需求分析与路由流程）；不确定时走默认的 create 路径，由 cosmic-gen 内部再做细分。

---

### 需求分析与路由（Stage 6 核心流程）

> **统一流程**：无论需求来自上传文档还是直接文本描述，都走同一套分析与路由逻辑。

### 第一步：获取需求内容

- **用户上传了文档**（Markdown/PDF/Word）→ 读取并解析文档，提取完整需求文本。
- **用户直接描述需求** → 直接使用输入文本。

### 第二步：需求分类（按架构模式）

#### 全插件架构（`plugin`）

通过预检后，功能点**统一归类为 cosmic-gen 需求**，具体插件类型由 cosmic-gen 步骤一确定。

> **全插件架构下不存在前端需求分类**。苍穹全插件架构的 UI 层由框架渲染引擎统一管理，所有交互行为（字段联动、值变更等）都通过服务端 Java 表单插件实现，无需编写前端代码。
>
> **用户显式要求前端开发**（明确提到 React / KWC / 组件开发）→ 提示用户当前为全插件架构，如需前端开发请先将 `architecture` 切换为 `frontend`。

#### 前后端分离架构（`frontend`）

逐条分析功能点，分为**前端需求**和**后端需求**：

**前端需求（路由至 `kwc-react-development`）**——前后端分离架构下，UI 层由 KWC React 组件接管，不再由苍穹渲染引擎生成，因此所有界面交互都需要前端实现：

| 特征 | 示例 |
|------|------|
| React 组件开发 | 开发一个物料选择弹窗组件 |
| 页面/界面构建 | 新建采购订单录入页面 |
| UI 交互逻辑 | 点击按钮弹出选择框、表格行展开 |
| 字段联动/值变更/锁定/显隐 | 选择费用类型后自动带出会计科目 |
| 实时计算/公式 | 数量×单价自动计算金额 |
| 前端字段校验 | 日期先后校验、格式校验等即时反馈 |
| KWC 组件 / React / TypeScript | — |

**后端需求（路由至 `cosmic-gen`）**——服务端逻辑不受架构模式影响，始终由 Java 插件处理：

| 特征 | 示例 |
|------|------|
| 操作校验/操作服务插件 | 提交前校验、审核后自动推单 |
| 工作流 / 调度任务 | 审批流程定制、定时预警 |
| 后台数据处理 | 查询、写入、状态流转 |

> **前后端分离架构下**，字段联动、值变更等 UI 交互由 `kwc-react-development` 处理。cosmic-gen **不生成表单插件（billform/listform）**（因为 UI 已由前端接管），仅接收后端逻辑需求（操作插件、工作流、调度任务）。

**混合需求**：如果一个功能点同时涉及前后端，拆分为两个独立需求分别归类。

### 第三步：输出分析结果并确认

使用以下统一模板，根据架构模式填充对应部分：

```
## 需求分析结果

### 📋 概要
- 开发模式：{create → "新建插件" / patch → "修改已有插件" / service → "独立服务类"}
- 架构模式：{plugin → "全插件架构" / frontend → "前后端分离"}
- 功能点总数：{N} 个

### ⚙️ 后端需求（共 {K} 个，由 cosmic-gen 处理）
1. {功能点描述}
...

<!-- 仅 frontend 架构时显示以下部分 -->
### 🖥️ 前端需求（共 {M} 个，由 kwc-react-development 处理）
1. {功能点描述}
...

### ⚠️ 待确认项（如有）
- {仅列出无法判断应路由至前端还是后端的功能点，请用户指定}

是否确认？确认后将启动代码生成。
```

> plugin 架构下省略"前端需求"和"待确认项"部分，所有需求按插件类型（表单插件类 / 操作插件类 / 其他）分组列出。

**禁止在此步骤做需求澄清或实现方式确认。** cosmic-dev 仅负责分类路由（前端 vs 后端），所有业务逻辑歧义、实现方式选择、字段映射问题，全部交由子技能（cosmic-gen 步骤一/步骤二、kwc-react-development）处理。「待确认项」只用于「无法判断应路由至前端还是后端」的情况，**禁止**用于技术实现方式的选型（如"两种方式都做还是选一种"）。

**必须让用户确认分析结果后才能进入第四步。**

### 第四步：执行

#### 全插件架构 → 直接执行

读取并执行 `skills/cosmic-gen/SKILL.md`，传入**开发模式**（create/patch/service，由入口判断确定）和**第三步分析结论**（功能点清单、插件类型分类）。cosmic-gen 根据模式加载对应的 flow 文件执行完整流程。

> 默认走 create 模式。patch/service 模式在入口判断阶段已确定时直接传入，不经过需求分析与路由的第二步/第三步。

#### 前后端分离架构 → 按需求组成决定执行方式

- **纯后端需求** → 执行 `skills/cosmic-gen/SKILL.md` 完整流程，将第三步分析结论作为上下文传入（同全插件架构）。
- **纯前端需求** → 直接执行 `skills/kwc-react-development/SKILL.md` 流程。
- **前后端混合需求** → 按环境能力选择执行方式：
  - **Agent 工具可用**（Claude Code 等）→ Team 模式并行执行，在同一条消息中同时启动两个 Agent：
  - **Agent 工具不可用**（qoder 等内网环境）→ 串行执行：先读取并执行 `skills/cosmic-gen/SKILL.md` 完成后端开发，再读取并执行 `skills/kwc-react-development/SKILL.md` 完成前端开发，两阶段间将后端产出的接口信息传递给前端阶段。

**Agent 1 — 后端开发（cosmic-gen）**：
```
Agent tool 调用参数：
  description: "苍穹后端插件开发"
  subagent_type: "general-purpose"
  prompt: |
    你是金蝶苍穹后端插件开发专家。

    ## Skill 目录（SKILL_DIR）
    {本 SKILL.md 所在目录的绝对路径，如 /home/kingdee/.claude/skills/cosmic-dev}

    ## 全局配置
    {将当前已加载的 config.json 配置内容完整传入，JSON 格式}

    ## 项目目录
    {当前项目目录路径}

    ## 已完成的需求分析（供步骤一参考）
    {第三步输出的分析结论：功能点与插件类型的对应关系，完整传入}
    注意：粗分类已完成，步骤一直接进行详细需求块划分和字段识别，不重复路由判断。

    ## 开发模式
    {create / patch / service，由入口判断确定}

    ## 任务
    读取 {SKILL_DIR}/skills/cosmic-gen/SKILL.md，根据开发模式加载对应的 flow 文件，严格按照其中定义的步骤顺序执行。
    不可跳过任何步骤。
    注意：SKILL.md 中的 ${COSMIC_DEV_HOME} 等同于上方的 SKILL_DIR 路径。

    ## 后端需求清单（仅后端逻辑，不含表单交互）
    {分类后的后端需求列表，逐条列出}
```

**Agent 2 — 前端开发（kwc-react-development）**：
```
Agent tool 调用参数：
  description: "KWC React 前端开发"
  subagent_type: "general-purpose"
  prompt: |
    你是 KWC React 前端开发专家。

    ## Skill 目录（SKILL_DIR）
    {本 SKILL.md 所在目录的绝对路径，如 /home/kingdee/.claude/skills/cosmic-dev}

    ## 项目目录
    {前端项目目录路径}

    ## 已完成的需求分析（供参考）
    {第三步输出的前端功能点分类结论，完整传入}

    ## 任务
    读取 {SKILL_DIR}/skills/kwc-react-development/SKILL.md，严格按照其中定义的工作流执行。
    必须遵守该目录下 rule.md 中的所有硬性约束。

    ## 前端需求清单
    {分类后的前端需求列表，逐条列出}
```

#### Team 模式关键规则

1. **上下文传递**：每个子 Agent 不继承父对话上下文，必须在 prompt 中传入：**SKILL_DIR 绝对路径**、完整的 config.json 配置内容、项目目录、需求清单、**第三步分析结论**。SKILL_DIR 即本 SKILL.md 所在目录的绝对路径。
2. **执行顺序**：前后端需求相互独立时必须并行（同一消息启动两个 Agent）；若前端明确依赖后端接口定义，先启动后端 Agent，完成后将接口信息注入前端 Agent 的 prompt 再启动。
3. **不使用 worktree 隔离**：前后端代码在不同目录（Java vs React），不会产生文件冲突，两个 Agent 直接在原项目目录并行写入即可。
4. **结果汇总**：两个 Agent 完成后，主对话汇总双方产出，向用户展示：
   - 后端：生成了哪些插件类、文件路径
   - 前端：生成了哪些组件、文件路径
   - 是否有需要前后端协调的事项

---

## 错误恢复

| 异常场景 | 处理方式 |
|----------|----------|
| **子 Agent 执行失败**（仅 Agent 模式） | 向用户报告失败的 Agent（前端/后端）及错误摘要，询问是否重试该部分。成功的另一侧结果保留，无需重新执行 |
| **用户中途修改需求** | 回到第二步重新分类。已生成的代码不自动删除，由用户决定是否保留 |
| **架构模式与需求矛盾** | 如 plugin 模式下用户要求 React 开发，明确提示矛盾并建议切换 `architecture` 为 `frontend` |
| **元数据脚本连接失败** | 提示检查 `server.baseUrl` 是否正确、服务器是否可达，不可跳过元数据获取步骤 |

