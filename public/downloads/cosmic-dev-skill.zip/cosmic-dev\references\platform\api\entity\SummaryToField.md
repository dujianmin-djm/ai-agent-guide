---
framework_version: "8.0.1"
api_class: "SummaryToField"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用汇总至字段映射对象时"
---

# SummaryToField API 说明

## 概述
汇总至字段映射对象。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.SummaryToField;
```

---

## 方法列表

### getFieldId

获取设计器字段属性Id

**方法签名：**
```java
public String getFieldId()
```

**返回值：**
- `String`

---

### getFieldKey

获取字段标识、编辑控件使用

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### getFieldName

获取字段名、设计器插件使用

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`

---

### getSumType

获取汇总类型

**方法签名：**
```java
public int getSumType()
```

**返回值：**
- `int`

---

### setFieldId

设置设计器字段属性Id

**方法签名：**
```java
public void setFieldId(String fieldId)
```

**参数说明：**
- `fieldId`: `String`

---

### setFieldKey

设置字段标识、编辑控件使用

**方法签名：**
```java
public void setFieldKey(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String`

---

### setFieldName

设置字段名、设计器插件使用

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setSumType

设置汇总类型

**方法签名：**
```java
public void setSumType(int sumType)
```

**参数说明：**
- `sumType`: `int`

---
