---
framework_version: "8.0.1"
api_class: "DateColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用日期格式化处理类时"
---

# DateColumnDesc API 说明

## 概述
日期格式化处理类。继承自 DateTimeColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.DateColumnDesc;
```

---

## 方法列表

### getDisplayFormatString

{待补充}

**方法签名：**
```java
public String getDisplayFormatString()
```

**返回值：**
- `String`

---

### getMask

{待补充}

**方法签名：**
```java
public String getMask()
```

**返回值：**
- `String`

---

### setDisplayFormatString

{待补充}

**方法签名：**
```java
public void setDisplayFormatString(String displayFormatString)
```

**参数说明：**
- `displayFormatString`: `String` — 设置格式化字符串

---

### setMask

{待补充}

**方法签名：**
```java
public void setMask(String mask)
```

**参数说明：**
- `mask`: `String` — 设置掩码

---
