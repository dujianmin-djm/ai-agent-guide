---
framework_version: "8.0.1"
api_class: "PlugInPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用插件策略时"
---

# PlugInPolicy API 说明

## 概述
插件策略。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.PlugInPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getPlugins

转换插件

**方法签名：**
```java
public List<CRPlugin> getPlugins()
```

**返回值：**
- `List<CRPlugin>`

---
