---
framework_version: "8.0.1"
api_class: "TX"
api_package: "kd.bos.db.tx"
when_to_use: "当你需要使用标准用法：时"
---

# TX API 说明

## 概述
标准用法：。
主要功能：添加元素、读取属性。

## Import 路径
```java
import kd.bos.db.tx.TX;
```

---

## 方法列表

### addCommitListener

添加事务提交监听器。

**方法签名：**
```java
public static void addCommitListener(CommitListener cl)
```

**参数说明：**
- `cl`: `CommitListener`

---

### getPropagation

获取事务隔离级别。

**方法签名：**
```java
public static Propagation getPropagation()
```

**返回值：**
- `Propagation`: Propagation

---

### nested

嵌套事务。

**方法签名：**
```java
public static TXHandle nested(String tag)
```

**参数说明：**
- `tag`: `String` — 事务标识，格式：应用_表单_功能，用于日志监控，当性能出现问题时可快速定位。

**返回值：**
- `TXHandle`: TXHandle

---

### notSupported

不需要事务。

**方法签名：**
```java
public static TXHandle notSupported(String tag)
```

**参数说明：**
- `tag`: `String` — 事务标识，格式：应用_表单_功能，用于日志监控，当性能出现问题时可快速定位。

**返回值：**
- `TXHandle`: TXHandle

---

### required

若当前已有事务，则使用当前事务，否则开启新事务。

**方法签名：**
```java
public static TXHandle required(String tag)
```

**参数说明：**
- `tag`: `String` — 事务标识，格式：应用_表单_功能，用于日志监控，当性能出现问题时可快速定位。

**返回值：**
- `TXHandle`: TXHandle

---

### requiresNew

开启新事务

**方法签名：**
```java
public static TXHandle requiresNew(String tag)
```

**参数说明：**
- `tag`: `String` — 事务标识，格式：应用_表单_功能，用于日志监控，当性能出现问题时可快速定位。

**返回值：**
- `TXHandle`: TXHandle

---
