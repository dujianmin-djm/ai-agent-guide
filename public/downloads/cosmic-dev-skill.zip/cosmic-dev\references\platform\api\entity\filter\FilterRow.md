---
framework_version: "8.0.1"
api_class: "FilterRow"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤条件行数据时"
---

# FilterRow API 说明

## 概述
过滤条件行数据。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.FilterRow;
```

---

## 方法列表

### getCompareType

{待补充}

**方法签名：**
```java
public CompareType getCompareType()
```

**返回值：**
- `CompareType`: 比较符

---

### getDataType

{待补充}

**方法签名：**
```java
public MainEntityType getDataType()
```

**返回值：**
- `MainEntityType`: 实体

---

### getFilterField

{待补充}

**方法签名：**
```java
public FilterField getFilterField()
```

**返回值：**
- `FilterField`: 过滤字段

---

### getFilterResult

获取过滤条件解析结果

**方法签名：**
```java
public FilterResult getFilterResult()
```

**返回值：**
- `FilterResult`

---

### getLeftBracket

{待补充}

**方法签名：**
```java
public String getLeftBracket()
```

**返回值：**
- `String`: 左括号

---

### getLogic

{待补充}

**方法签名：**
```java
public LogicOperate getLogic()
```

**返回值：**
- `LogicOperate`: 逻辑处理：And,Or

---

### getORMFieldName

获取ORM使用的完整字段名（带单据体标识）

**方法签名：**
```java
public String getORMFieldName()
```

**返回值：**
- `String`

---

### getRightBracket

{待补充}

**方法签名：**
```java
public String getRightBracket()
```

**返回值：**
- `String`: 右括号

---

### getRowIndex

{待补充}

**方法签名：**
```java
public int getRowIndex()
```

**返回值：**
- `int`: 行索引

---

### getValue

{待补充}

**方法签名：**
```java
public List<String> getValue()
```

**返回值：**
- `List<String>`: 过滤值

---

### isInt

是否是int类型

**方法签名：**
```java
public boolean isInt(String value, boolean bThrowErr)
```

**参数说明：**
- `value`: `String`
- `bThrowErr`: `boolean`

**返回值：**
- `boolean`

---

### setCompareType

{待补充}

**方法签名：**
```java
public void setCompareType(CompareType compareType)
```

**参数说明：**
- `compareType`: `CompareType`

---

### setDataType

{待补充}

**方法签名：**
```java
public void setDataType(MainEntityType dataType)
```

**参数说明：**
- `dataType`: `MainEntityType`

---

### setFilterField

{待补充}

**方法签名：**
```java
public void setFilterField(FilterField fieldField)
```

**参数说明：**
- `fieldField`: `FilterField`

---

### setLeftBracket

{待补充}

**方法签名：**
```java
public void setLeftBracket(String leftBracket)
```

**参数说明：**
- `leftBracket`: `String`

---

### setLogic

{待补充}

**方法签名：**
```java
public void setLogic(LogicOperate logic)
```

**参数说明：**
- `logic`: `LogicOperate`

---

### setNeedParse

是否需要解析

**方法签名：**
```java
public void setNeedParse(boolean isNeedParse)
```

**参数说明：**
- `isNeedParse`: `boolean`

---

### setRightBracket

{待补充}

**方法签名：**
```java
public void setRightBracket(String rightBracket)
```

**参数说明：**
- `rightBracket`: `String`

---

### setValue

{待补充}

**方法签名：**
```java
public void setValue(List<String> valueList)
```

**参数说明：**
- `valueList`: `List<String>`

---
