---
framework_version: "8.0.1"
api_class: "FileServiceFactory"
api_package: "kd.bos.fileservice"
when_to_use: "当你需要使用文件服务工厂类时"
---

# FileServiceFactory API 说明

## 概述
文件服务工厂类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.fileservice.FileServiceFactory;
```

---

## 方法列表

### getAttachmentFileService

获取文件服务实现对象

**方法签名：**
```java
public static FileService getAttachmentFileService()
```

**返回值：**
- `FileService`: 文件服务实现类

---

### getImageFileService

获取图片服务实现对象

**方法签名：**
```java
public static FileService getImageFileService()
```

**返回值：**
- `FileService`: 图片服务实现类

---
