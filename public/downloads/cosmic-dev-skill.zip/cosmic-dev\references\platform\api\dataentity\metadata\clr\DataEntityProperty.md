---
framework_version: "8.0.1"
api_class: "DataEntityProperty"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用实体属性基类时"
---

# DataEntityProperty API 说明

## 概述
实体属性基类。实现 IDataEntityProperty, IMetadata, DefinedDbIgnoreAttribute, Cloneable。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.DataEntityProperty;
```

---

## 方法列表

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### getAlias

{待补充}

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getDisplayName

获取显示名称

**方法签名：**
```java
public LocaleString getDisplayName()
```

**返回值：**
- `LocaleString`: 返回显示名称

---

### getName

{待补充}

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getOrdinal

返回属性所在的位置

**方法签名：**
```java
public final int getOrdinal()
```

**返回值：**
- `int`

---

### getParent

{待补充}

**方法签名：**
```java
public IDataEntityType getParent()
```

**返回值：**
- `IDataEntityType`

---

### getPropertyType

{待补充}

**方法签名：**
```java
public final Class<?> getPropertyType()
```

**返回值：**
- `Class<?>`

---

### getReadOnly

{待补充}

**方法签名：**
```java
public final boolean getReadOnly()
```

**返回值：**
- `boolean`

---

### getValue

{待补充}

**方法签名：**
```java
public final Object getValue(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Object`

---

### getValueFast

{待补充}

**方法签名：**
```java
public Object getValueFast(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Object`

---

### hasDefaultValue

{待补充}

**方法签名：**
```java
public boolean hasDefaultValue()
```

**返回值：**
- `boolean`

---

### isDbIgnore

{待补充}

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---

### isDefinedDbIgnoreAttribute

{待补充}

**方法签名：**
```java
public boolean isDefinedDbIgnoreAttribute()
```

**返回值：**
- `boolean`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### setDisplayName

设置显示名称

**方法签名：**
```java
public void setDisplayName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setValue

{待补充}

**方法签名：**
```java
public final void setValue(Object dataEntity, Object value)
```

**参数说明：**
- `dataEntity`: `Object`
- `value`: `Object`

---

### setValueFast

{待补充}

**方法签名：**
```java
public final void setValueFast(Object dataEntity, Object value)
```

**参数说明：**
- `dataEntity`: `Object`
- `value`: `Object`

---
