---
framework_version: "8.0.1"
api_class: "OperationContext"
api_package: "kd.bos.entity.operate"
when_to_use: "当你需要使用操作的上下文信息时"
---

# OperationContext API 说明

## 概述
操作的上下文信息，包括元数据，操作的扩展数据， 操作参数，操作代码等。仅在操作功能内部引用。。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.OperationContext;
```

---

## 方法列表

### getDataEntities

获取数据包

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`: 数据包集合

---

### getEntityTypeId

获取实体编码

**方法签名：**
```java
public String getEntityTypeId()
```

**返回值：**
- `String`

---

### getExtendedDataEntities

获取打平的数据包

**方法签名：**
```java
public List<kd.ExtendedDataEntity> getExtendedDataEntities()
```

**返回值：**
- `List<kd.ExtendedDataEntity>`: 打平的数据包集合

---

### getMutexLocks

获取数据锁记录
    [对象id]

**方法签名：**
```java
public List<String> getMutexLocks()
```

**返回值：**
- `List<String>`: the mutexLocks

---

### getOperateLog

获取操作日志输出对象

**方法签名：**
```java
public OperateLog getOperateLog()
```

**返回值：**
- `OperateLog`

---

### getOperationKey

获取操作编码

**方法签名：**
```java
public String getOperationKey()
```

**返回值：**
- `String`

---

### getParameter

获取操作上下文参数

**方法签名：**
```java
public Map<String,Object> getParameter()
```

**返回值：**
- `Map<String,Object>`

---

### setDataEntities

设置操作上下文的数据包集合

**方法签名：**
```java
public void setDataEntities(DynamicObject[] dataEntities)
```

**参数说明：**
- `dataEntities`: `DynamicObject[]`

---

### setEntityTypeId

设置实体编码

**方法签名：**
```java
public void setEntityTypeId(String entityTypeId)
```

**参数说明：**
- `entityTypeId`: `String`

---

### setOperateLog

设置操作日志输出对象

**方法签名：**
```java
public void setOperateLog(OperateLog operateLog)
```

**参数说明：**
- `operateLog`: `OperateLog`

---

### setOperationKey

设置操作编码

**方法签名：**
```java
public void setOperationKey(String operationKey)
```

**参数说明：**
- `operationKey`: `String` — 操作Key，save,modify,delete等

---

### setParameter

设置操作上下文参数

**方法签名：**
```java
public void setParameter(Map<String,Object> parameter)
```

**参数说明：**
- `parameter`: `Map<String,Object>`

---
