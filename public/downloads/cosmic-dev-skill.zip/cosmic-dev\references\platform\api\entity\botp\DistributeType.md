---
framework_version: "8.0.1"
api_class: "DistributeType"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用反写分配类型时"
---

# DistributeType API 说明

## 概述
反写分配类型。实现 Comparable, Serializable。
主要功能：自上而下。

## Import 路径
```java
import kd.bos.entity.botp.DistributeType;
```

---

## 方法列表

### valueOf

自上而下

**方法签名：**
```java
public static DistributeType valueOf(int value)
```

**参数说明：**
- `value`: `int`

**返回值：**
- `DistributeType`

---
