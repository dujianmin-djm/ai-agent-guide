---
framework_version: "8.0.1"
api_class: "Row"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用DataSet中对应的行数据时"
---

# Row API 说明

## 概述
DataSet中对应的行数据。实现 RowFeature。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.Row;
```

---

## 方法列表

### get

**重载 1**

返回对应索引的值

**方法签名：**
```java
public Object get(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Object`: 对应索引的值

---

**重载 2**

返回对应属性的值

**方法签名：**
```java
public Object get(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Object`: 属性的值

---

### getBigDecimal

**重载 1**

返回对应索引的BigDecimal类型的值

**方法签名：**
```java
public BigDecimal getBigDecimal(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `BigDecimal`: BigDecimal类型的值

---

**重载 2**

返回对应属性的BigDecimal类型的值

**方法签名：**
```java
public BigDecimal getBigDecimal(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `BigDecimal`: igDecimal类型的值

---

### getBoolean

**重载 1**

返回对应索引的boolean类型的值

**方法签名：**
```java
public Boolean getBoolean(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Boolean`: boolean类型的值

---

**重载 2**

返回对应属性的boolean类型的值

**方法签名：**
```java
public Boolean getBoolean(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Boolean`: boolean类型的值

---

### getDate

**重载 1**

返回对应索引的日期类型的值

**方法签名：**
```java
public Date getDate(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Date`: 期类型的值

---

**重载 2**

返回对应属性的日期类型的值

**方法签名：**
```java
public Date getDate(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Date`: 日期类型的值

---

### getDouble

**重载 1**

返回对应索引的Double类型的值

**方法签名：**
```java
public Double getDouble(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Double`: Double类型的值

---

**重载 2**

返回对应属性的Double类型的值

**方法签名：**
```java
public Double getDouble(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Double`: Double类型的值

---

### getInteger

**重载 1**

返回对应索引的整形类型的值

**方法签名：**
```java
public Integer getInteger(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Integer`: 整形类型的值

---

**重载 2**

返回对应属性的整形类型的值

**方法签名：**
```java
public Integer getInteger(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Integer`: 整形类型的值

---

### getLong

**重载 1**

返回对应索引的长整形类型的值

**方法签名：**
```java
public Long getLong(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Long`: 长整形类型的值

---

**重载 2**

返回对应属性的长整形类型的值

**方法签名：**
```java
public Long getLong(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Long`: 长整形类型的值

---

### getString

**重载 1**

返回对应索引的字符串类型的值

**方法签名：**
```java
public String getString(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `String`: 字符串类型的值

---

**重载 2**

返回对应属性的字符串类型的值

**方法签名：**
```java
public String getString(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `String`: 字符串类型的值

---

### getTimestamp

**重载 1**

返回对应索引的Timestamp类型的值

**方法签名：**
```java
public Timestamp getTimestamp(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Timestamp`: Timestamp类型的值

---

**重载 2**

返回对应属性的Timestamp类型的值

**方法签名：**
```java
public Timestamp getTimestamp(String field)
```

**参数说明：**
- `field`: `String` — 属性名

**返回值：**
- `Timestamp`: Timestamp类型的值

---

### size

返回列数

**方法签名：**
```java
public int size()
```

**返回值：**
- `int`: 列的个数

---
