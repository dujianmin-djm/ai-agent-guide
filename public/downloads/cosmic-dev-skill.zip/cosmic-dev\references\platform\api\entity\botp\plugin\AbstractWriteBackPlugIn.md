---
framework_version: "8.0.1"
api_class: "AbstractWriteBackPlugIn"
api_package: "kd.bos.entity.botp.plugin"
when_to_use: "当你需要使用反写插件抽象基类；所有反写插件，均从此类派生，不要直接实现反写插件接口，避免接口时"
---

# AbstractWriteBackPlugIn API 说明

## 概述
反写插件抽象基类；所有反写插件，均从此类派生，不要直接实现反写插件接口，避免接口变动影响。实现 IWriteBackPlugIn。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.AbstractWriteBackPlugIn;
```

---

## 方法列表

### afterCalcWriteValue

{待补充}

**方法签名：**
```java
public void afterCalcWriteValue(AfterCalcWriteValueEventArgs e)
```

**参数说明：**
- `e`: `AfterCalcWriteValueEventArgs`

---

### afterCloseRow

{待补充}

**方法签名：**
```java
public void afterCloseRow(AfterCloseRowEventArgs e)
```

**参数说明：**
- `e`: `AfterCloseRowEventArgs`

---

### afterCommitAmount

{待补充}

**方法签名：**
```java
public void afterCommitAmount(AfterCommitAmountEventArgs e)
```

**参数说明：**
- `e`: `AfterCommitAmountEventArgs`

---

### afterExcessCheck

{待补充}

**方法签名：**
```java
public void afterExcessCheck(AfterExcessCheckEventArgs e)
```

**参数说明：**
- `e`: `AfterExcessCheckEventArgs`

---

### afterReadSourceBill

{待补充}

**方法签名：**
```java
public void afterReadSourceBill(AfterReadSourceBillEventArgs e)
```

**参数说明：**
- `e`: `AfterReadSourceBillEventArgs`

---

### afterSaveSourceBill

{待补充}

**方法签名：**
```java
public void afterSaveSourceBill(AfterSaveSourceBillEventArgs e)
```

**参数说明：**
- `e`: `AfterSaveSourceBillEventArgs`

---

### beforeCloseRow

{待补充}

**方法签名：**
```java
public void beforeCloseRow(BeforeCloseRowEventArgs e)
```

**参数说明：**
- `e`: `BeforeCloseRowEventArgs`

---

### beforeCreateArticulationRow

{待补充}

**方法签名：**
```java
public void beforeCreateArticulationRow(BeforeCreateArticulationRowEventArgs e)
```

**参数说明：**
- `e`: `BeforeCreateArticulationRowEventArgs`

---

### beforeExcessCheck

{待补充}

**方法签名：**
```java
public void beforeExcessCheck(BeforeExcessCheckEventArgs e)
```

**参数说明：**
- `e`: `BeforeExcessCheckEventArgs`

---

### beforeExecWriteBackRule

{待补充}

**方法签名：**
```java
public void beforeExecWriteBackRule(BeforeExecWriteBackRuleEventArgs e)
```

**参数说明：**
- `e`: `BeforeExecWriteBackRuleEventArgs`

---

### beforeReadSourceBill

{待补充}

**方法签名：**
```java
public void beforeReadSourceBill(BeforeReadSourceBillEventArgs e)
```

**参数说明：**
- `e`: `BeforeReadSourceBillEventArgs`

---

### beforeSaveSourceBill

{待补充}

**方法签名：**
```java
public void beforeSaveSourceBill(BeforeSaveSourceBillEventArgs e)
```

**参数说明：**
- `e`: `BeforeSaveSourceBillEventArgs`

---

### beforeTrack

{待补充}

**方法签名：**
```java
public void beforeTrack(BeforeTrackEventArgs e)
```

**参数说明：**
- `e`: `BeforeTrackEventArgs`

---

### finishWriteBack

{待补充}

**方法签名：**
```java
public void finishWriteBack(FinishWriteBackEventArgs e)
```

**参数说明：**
- `e`: `FinishWriteBackEventArgs`

---

### getCurrLinkSetItem

{待补充}

**方法签名：**
```java
public LinkSetItemElement getCurrLinkSetItem()
```

**返回值：**
- `LinkSetItemElement`

---

### getOpType

操作类型：Draft,Save,Audit,UnAudit,Delete,Cancel,UnCancel,Unknown

**方法签名：**
```java
public String getOpType()
```

**返回值：**
- `String`

---

### getTargetSubMainType

下游目标单主实体模型

**方法签名：**
```java
public BillEntityType getTargetSubMainType()
```

**返回值：**
- `BillEntityType`

---

### preparePropertys

{待补充}

**方法签名：**
```java
public void preparePropertys(PreparePropertysEventArgs e)
```

**参数说明：**
- `e`: `PreparePropertysEventArgs`

---

### rollbackSave

{待补充}

**方法签名：**
```java
public void rollbackSave(RollbackSaveEventArgs e)
```

**参数说明：**
- `e`: `RollbackSaveEventArgs`

---

### setContext

{待补充}

**方法签名：**
```java
public void setContext(BillEntityType targetSubMainType, String opType, LinkSetItemElement linkSetItem)
```

**参数说明：**
- `targetSubMainType`: `BillEntityType`
- `opType`: `String`
- `linkSetItem`: `LinkSetItemElement`

---
