---
framework_version: "8.0.1"
api_class: "ParamPublishObject"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用参数查询对象时"
---

# ParamPublishObject API 说明

## 概述
参数查询对象。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.param.ParamPublishObject;
```

---

## 方法列表

### getAppId

获取应用的唯一标识符

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用的ID

---

### getCloudId

获取云服务的唯一标识符

**方法签名：**
```java
public String getCloudId()
```

**返回值：**
- `String`: 云服务的ID

---

### getFormId

获取表单的唯一标识符

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`: 表单的ID

---

### getId

获取参数的唯一标识符

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 参数的ID

---

### getSelectedFields

获取选择的字段

**方法签名：**
```java
public String getSelectedFields()
```

**返回值：**
- `String`: 选择的字段

---

### isActBookEnable

获取是否启用实际账本的标志

**方法签名：**
```java
public boolean isActBookEnable()
```

**返回值：**
- `boolean`: 是否启用实际账本

---

### setActBookEnable

设置是否启用实际账本的标志

**方法签名：**
```java
public void setActBookEnable(boolean actBookEnable)
```

**参数说明：**
- `actBookEnable`: `boolean` — 是否启用实际账本

---

### setAppId

设置应用的唯一标识符

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 应用的ID

---

### setCloudId

设置云服务的唯一标识符

**方法签名：**
```java
public void setCloudId(String cloudId)
```

**参数说明：**
- `cloudId`: `String` — 云服务的ID

---

### setFormId

设置表单的唯一标识符

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 表单的ID

---

### setId

设置参数的唯一标识符

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 参数的ID

---

### setSelectedFields

设置选择的字段

**方法签名：**
```java
public void setSelectedFields(String selectedFields)
```

**参数说明：**
- `selectedFields`: `String` — 选择的字段

---
