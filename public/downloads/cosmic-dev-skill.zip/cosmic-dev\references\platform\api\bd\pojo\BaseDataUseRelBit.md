---
framework_version: "8.0.1"
api_class: "BaseDataUseRelBit"
api_package: "kd.bos.bd.pojo"
when_to_use: "当你需要使用 BaseDataUseRelBit 相关功能时"
---

# BaseDataUseRelBit API 说明

## 概述
BaseDataUseRelBit 类。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.bd.pojo.BaseDataUseRelBit;
```

---

## 方法列表

### getBit

获取使用组织位图

**方法签名：**
```java
public RoaringBitmap getBit()
```

**返回值：**
- `RoaringBitmap`: 使用组织位图信息

---

### getOrgId

获取使用组织

**方法签名：**
```java
public Long getOrgId()
```

**返回值：**
- `Long`: 使用组织

---

### setBit

设置数据位图

**方法签名：**
```java
public void setBit(RoaringBitmap bit)
```

**参数说明：**
- `bit`: `RoaringBitmap` — 位图

---

### setOrgId

设置使用组织

**方法签名：**
```java
public void setOrgId(Long orgId)
```

**参数说明：**
- `orgId`: `Long` — 使用组织

---
