---
framework_version: "8.0.1"
api_class: "FilterItemInfo"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表单个过滤项信息时"
---

# FilterItemInfo API 说明

## 概述
报表单个过滤项信息。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.FilterItemInfo;
```

---

## 方法列表

### clone

拷贝过滤字段信息

**方法签名：**
```java
public FilterItemInfo clone()
```

**返回值：**
- `FilterItemInfo`

---

### getBigDecimal

获取小数值

**方法签名：**
```java
public BigDecimal getBigDecimal()
```

**返回值：**
- `BigDecimal`

---

### getBoolean

获取布尔类型值

**方法签名：**
```java
public boolean getBoolean()
```

**返回值：**
- `boolean`

---

### getCompareType

获取比较符

**方法签名：**
```java
public String getCompareType()
```

**返回值：**
- `String`

---

### getDate

获取日期类型值

**方法签名：**
```java
public Date getDate()
```

**返回值：**
- `Date`

---

### getDynamicObjectPKs

获取字段值

**方法签名：**
```java
public Object[] getDynamicObjectPKs()
```

**返回值：**
- `Object[]`

---

### getInt

获取整形类型值

**方法签名：**
```java
public int getInt()
```

**返回值：**
- `int`

---

### getLong

获取长整形类型值

**方法签名：**
```java
public long getLong()
```

**返回值：**
- `long`

---

### getPropName

获取过滤字段名

**方法签名：**
```java
public String getPropName()
```

**返回值：**
- `String`

---

### getString

获取字符串类型值

**方法签名：**
```java
public String getString()
```

**返回值：**
- `String`

---

### getValue

获取过滤比较值

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`: 返回过滤比较值

---

### setCompareType

设置字段比较符

**方法签名：**
```java
public void setCompareType(String compareType)
```

**参数说明：**
- `compareType`: `String` — 比较符

---

### setPropName

设置过滤字段名

**方法签名：**
```java
public void setPropName(String propName)
```

**参数说明：**
- `propName`: `String` — 过滤字段名

---

### setValue

设置过滤比较值

**方法签名：**
```java
public void setValue(Object value)
```

**参数说明：**
- `value`: `Object` — 过滤比较值

---

### toString

获取字段名 比较符 字段值

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
