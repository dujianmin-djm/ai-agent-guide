---
framework_version: "8.0.1"
api_class: "StdExtPluginProxy"
api_package: "kd.bos.extplugin"
when_to_use: "当你需要使用通用的二次扩展接口 StdExtPlugin 代理对象时"
---

# StdExtPluginProxy API 说明

## 概述
通用的二次扩展接口 StdExtPlugin 代理对象。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.extplugin.StdExtPluginProxy;
```

---

## 方法列表

### create

传入业务扩展场景编码，创建插件代理，内含绑定的二次扩展插件

**方法签名：**
```java
public static StdExtPluginProxy create(String caseName)
```

**参数说明：**
- `caseName`: `String` — 传入业务扩展场景编码，注册业务场景时需指定，唯一编码

**返回值：**
- `StdExtPluginProxy`: 返回插件代理，已包含了绑定的二次扩展插件

---

### fireExtEvent

触发扩展事件

**方法签名：**
```java
public void fireExtEvent(ExtEvent event)
```

**参数说明：**
- `event`: `ExtEvent` — 事件参数

---

### release

关闭释放资源

**方法签名：**
```java
public void release()
```

---
