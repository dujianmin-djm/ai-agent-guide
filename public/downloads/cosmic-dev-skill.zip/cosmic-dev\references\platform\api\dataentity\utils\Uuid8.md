---
framework_version: "8.0.1"
api_class: "Uuid8"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用UUID8生成工具时"
---

# Uuid8 API 说明

## 概述
UUID8生成工具。实现 Serializable。
主要功能：使用JDK标准UUID方法截取替换生成短。

## Import 路径
```java
import kd.bos.dataentity.utils.Uuid8;
```

---

## 方法列表

### generateShortUuid

使用JDK标准UUID方法截取替换生成短UUID

**方法签名：**
```java
public static String generateShortUuid()
```

**返回值：**
- `String`: 生成由a-z、0-9、A-Z组成的8位短UUID

---
