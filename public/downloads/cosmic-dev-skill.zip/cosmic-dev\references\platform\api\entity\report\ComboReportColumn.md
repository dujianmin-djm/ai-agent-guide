---
framework_version: "8.0.1"
api_class: "ComboReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-下拉列表类型列时"
---

# ComboReportColumn API 说明

## 概述
报表列-下拉列表类型列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：读取属性、设置属性、创建对象。

## Import 路径
```java
import kd.bos.entity.report.ComboReportColumn;
```

---

## 方法列表

### createColumn

打包客户端报表列元数据信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`: 返回客户端报表列元数据信息

---

### getComboItems

获取下拉列表值

**方法签名：**
```java
public List<kd.ValueMapItem> getComboItems()
```

**返回值：**
- `List<kd.ValueMapItem>`

---

### getComboShowStyle

获取下拉框风格

**方法签名：**
```java
public int getComboShowStyle()
```

**返回值：**
- `int`

---

### getValue

获取单元格的值（从行数据包中取值并格式化）

**方法签名：**
```java
public Object getValue(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject` — 行数据包
- `numberFormatProvider`: `NumberFormatProvider` — 格式化引擎

**返回值：**
- `Object`: 单元格的值

---

### setComboItems

设置下拉列表值

**方法签名：**
```java
public void setComboItems(List<kd.ValueMapItem> comboItems)
```

**参数说明：**
- `comboItems`: `List<kd.ValueMapItem>` — 下拉列表值集合

---

### setComboShowStyle

设置下拉框风格

**方法签名：**
```java
public void setComboShowStyle(int comboShowStyle)
```

**参数说明：**
- `comboShowStyle`: `int` — 下拉框风格

---
