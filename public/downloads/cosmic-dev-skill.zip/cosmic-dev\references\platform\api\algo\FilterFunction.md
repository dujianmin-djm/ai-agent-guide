---
framework_version: "8.0.1"
api_class: "FilterFunction"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用自定义过滤函数接口时"
---

# FilterFunction API 说明

## 概述
自定义过滤函数接口。继承自 Function，实现 Serializable。
主要功能：使用自定义过滤函数对DataSet每行数。

## Import 路径
```java
import kd.bos.algo.FilterFunction;
```

---

## 方法列表

### test

使用自定义过滤函数对DataSet每行数据进行过滤处理

**方法签名：**
```java
public abstract boolean test(Row row)
```

**参数说明：**
- `row`: `Row` — 每行数据

**返回值：**
- `boolean`: 是否符合过滤条件

---
