---
framework_version: "8.0.1"
api_class: "FlexReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列弹性域列时"
---

# FlexReportColumn API 说明

## 概述
报表列弹性域列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：设置属性、状态判断、读取属性。

## Import 路径
```java
import kd.bos.entity.report.FlexReportColumn;
```

---

## 方法列表

### getFlexMaxShow

获取弹性域列最大拆分列数，缺省值是40

**方法签名：**
```java
public String getFlexMaxShow()
```

**返回值：**
- `String`

---

### isDefaultSplit

获取弹性域列是否默认拆分显示

**方法签名：**
```java
public boolean isDefaultSplit()
```

**返回值：**
- `boolean`

---

### isNeedSplit

获取弹性域列是否需要拆分显示

**方法签名：**
```java
public boolean isNeedSplit()
```

**返回值：**
- `boolean`

---

### setDefaultSplit

设置弹性域列是否默认拆分显示

**方法签名：**
```java
public void setDefaultSplit(boolean defaultSplit)
```

**参数说明：**
- `defaultSplit`: `boolean` — 默认拆分显示

---

### setFlexMaxShow

设置弹性域列最大拆分列数

**方法签名：**
```java
public void setFlexMaxShow(String flexMaxShow)
```

**参数说明：**
- `flexMaxShow`: `String`

---

### setNeedSplit

设置弹性域列是否需要根据类型拆分显示

**方法签名：**
```java
public void setNeedSplit(boolean isNeedSplit)
```

**参数说明：**
- `isNeedSplit`: `boolean`

---
