---
framework_version: "8.0.1"
api_class: "FormatRowData"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用格式化后的行数据时"
---

# FormatRowData API 说明

## 概述
格式化后的行数据，含各字段值。继承自 ArrayList，实现 List, RandomAccess, Cloneable, Serializable, Collection。
主要功能：添加元素、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.list.FormatRowData;
```

---

## 方法列表

### add

{待补充}

**方法签名：**
```java
public boolean add(FormatFieldData formatFieldData)
```

**参数说明：**
- `formatFieldData`: `FormatFieldData`

**返回值：**
- `boolean`

---

### addAll

**重载 1**

{待补充}

**方法签名：**
```java
public boolean addAll(Collection<? extends FormatFieldData> c)
```

**参数说明：**
- `c`: `Collection<? extends FormatFieldData>`

**返回值：**
- `boolean`

---

**重载 2**

{待补充}

**方法签名：**
```java
public boolean addAll(int index, Collection<? extends FormatFieldData> c)
```

**参数说明：**
- `index`: `int`
- `c`: `Collection<? extends FormatFieldData>`

**返回值：**
- `boolean`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### get

根据字段标识获取列表格式化后的字段值

**方法签名：**
```java
public FormatFieldData get(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String`

**返回值：**
- `FormatFieldData`

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---
