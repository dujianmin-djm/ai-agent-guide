---
framework_version: "8.0.1"
api_class: "FileItem"
api_package: "kd.bos.fileservice"
when_to_use: "当你需要使用文件信息实体类时"
---

# FileItem API 说明

## 概述
文件信息实体类，封装文件上传相关元数据和操作。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.fileservice.FileItem;
```

---

## 方法列表

### close

释放资源并清理临时文件
 
 安全关闭文件输入流
 建议在文件处理完成后主动调用以防止资源泄漏

**方法签名：**
```java
public void close()
```

---

### getAppId

getter appId

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`

---

### getEncrypt

getter方法，获取加密存储标识

**方法签名：**
```java
public String getEncrypt()
```

**返回值：**
- `String`: 加密标识字符串（""/"true"/"false"）

---

### getFId

getter fid

**方法签名：**
```java
public String getFId()
```

**返回值：**
- `String`

---

### getFileName

getter方法， 获取文件名（包含扩展名）

**方法签名：**
```java
public String getFileName()
```

**返回值：**
- `String`

---

### getInputStream

getter方法，获取文件输入流

**方法签名：**
```java
public InputStream getInputStream()
```

**返回值：**
- `InputStream`: 当前关联的文件输入流，可能为 null

---

### getKey

{待补充}

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getPageId

getter pageId

**方法签名：**
```java
public String getPageId()
```

**返回值：**
- `String`

---

### getPath

getter方法，获取文件存储相对路径

**方法签名：**
```java
public String getPath()
```

**返回值：**
- `String`

---

### getType

getter type

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### isCreateNewFileWhenExists

getter方法
 仅文件存储为 fileserver 时有效，二开存储（OSS,MinIO等）此参数不生效

**方法签名：**
```java
public boolean isCreateNewFileWhenExists()
```

**返回值：**
- `boolean`: path在服务器已经存在时，是否创建新的文件，true:创建新文件，false:覆盖已存在文件

---

### setAppId

setter appId

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String`

---

### setCreateNewFileWhenExists

当目标路径存在文件时的处理策略：
 
 - true:  创建带后缀的新文件，保留原文件，新文件路径会自动添加后缀（如时间戳/序列号）
          示例：原路径为 /docs/report.txt 将生成类似 /docs/report_1740124672706.txt 的新路径
 
 
 - false: 直接覆盖现有文件，原文件内容将被替换
 
 默认值为 false，即覆盖已有文件

**方法签名：**
```java
public void setCreateNewFileWhenExists(boolean createNewFileWhenExists)
```

**参数说明：**
- `createNewFileWhenExists`: `boolean`

---

### setEncrypt

setter方法，设置加密存储策略

**方法签名：**
```java
public void setEncrypt(String encrypt)
```

**参数说明：**
- `encrypt`: `String` — 加密标识：
                - ""   使用系统默认
                - "true" 强制加密
                - "false" 不加密

---

### setFId

setter fid

**方法签名：**
```java
public void setFId(String fId)
```

**参数说明：**
- `fId`: `String`

---

### setFileName

setter方法，设置文件名（包含扩展名）

**方法签名：**
```java
public void setFileName(String fileName)
```

**参数说明：**
- `fileName`: `String` — 文件名

---

### setInputStream

setter方法，设置文件输入流

**方法签名：**
```java
public void setInputStream(InputStream in)
```

**参数说明：**
- `in`: `InputStream` — 新的文件输入流，设置后会替换原有流

---

### setKey

{待补充}

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String`

---

### setPageId

setter pageId

**方法签名：**
```java
public void setPageId(String pageId)
```

**参数说明：**
- `pageId`: `String`

---

### setPath

setter方法，设置文件存储相对路径

**方法签名：**
```java
public void setPath(String path)
```

**参数说明：**
- `path`: `String` — 文件相对路径

---

### setTempFiles

设置临时文件数组

**方法签名：**
```java
public void setTempFiles(File[] tempFiles)
```

**参数说明：**
- `tempFiles`: `File[]` — 临时文件数组，这些文件会在close()时自动删除

---

### setType

setter type

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---

### setVerified

setter verified

**方法签名：**
```java
public void setVerified(boolean verified)
```

**参数说明：**
- `verified`: `boolean` — 标记是否已调用过 getFileServiceExt().checkFile

---
