---
framework_version: "8.0.1"
api_class: "CachedDataSetBuilder"
api_package: "kd.bos.algo.dataset.cache"
when_to_use: "当你需要使用 CachedDataSetBuilder 相关功能时"
---

# CachedDataSetBuilder API 说明

## 概述
CachedDataSetBuilder 类。实现 CachedDataSet.Builder。
主要功能：添加行、将迭代器中的行信息进行添加、生成缓存DataSet。

## Import 路径
```java
import kd.bos.algo.dataset.cache.CachedDataSetBuilder;
```

---

## 方法列表

### append

**重载 1**

添加行

**方法签名：**
```java
public void append(Row row)
```

**参数说明：**
- `row`: `Row` — 行信息

---

**重载 2**

将迭代器中的行信息进行添加

**方法签名：**
```java
public void append(Iterator<kd.Row> iter)
```

**参数说明：**
- `iter`: `Iterator<kd.Row>`

---

### build

生成缓存DataSet

**方法签名：**
```java
public CachedDataSet build()
```

**返回值：**
- `CachedDataSet`

---
