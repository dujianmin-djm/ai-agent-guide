---
framework_version: "8.0.1"
api_class: "LocaleStringSerializationUtils"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用序列化的辅助工具类时"
---

# LocaleStringSerializationUtils API 说明

## 概述
序列化的辅助工具类。
主要功能：将数据反序列化成指定格式。

## Import 路径
```java
import kd.bos.dataentity.serialization.LocaleStringSerializationUtils;
```

---

## 方法列表

### fromJsonString

将数据反序列化成指定格式

**方法签名：**
```java
public static Object fromJsonString(String content, Class<?> valueType)
```

**参数说明：**
- `content`: `String` — 待反序列化内容
- `valueType`: `Class<?>` — 反序列化类型

**返回值：**
- `Object`

---
