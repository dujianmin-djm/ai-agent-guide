---
framework_version: "8.0.1"
api_class: "FlexEntireData"
api_package: "kd.bos.entity.flex"
when_to_use: "当你需要使用弹性域数据时"
---

# FlexEntireData API 说明

## 概述
弹性域数据。
主要功能：设置属性、读取属性。

## Import 路径
```java
import kd.bos.entity.flex.FlexEntireData;
```

---

## 方法列表

### concatFlexData

合并Flex数据（横表数据）

**方法签名：**
```java
public String concatFlexData()
```

**返回值：**
- `String`

---

### getFlexDatas

获取弹性域数据

**方法签名：**
```java
public List<kd.FlexEntireData.FlexData> getFlexDatas()
```

**返回值：**
- `List<kd.FlexEntireData.FlexData>`

---

### getFlexValue

获取弹性域值

**方法签名：**
```java
public Map<String,Object> getFlexValue()
```

**返回值：**
- `Map<String,Object>`

---

### getId

获取ID

**方法签名：**
```java
public long getId()
```

**返回值：**
- `long`

---

### setFlexData

将当前弹性域数据添加到集合中

**方法签名：**
```java
public void setFlexData(MainEntityType entityType, DynamicObject data)
```

**参数说明：**
- `entityType`: `MainEntityType` — 主实体
- `data`: `DynamicObject` — 数据包

---

### setFlexDatas

设置弹性域数据并根据idndex排序

**方法签名：**
```java
public void setFlexDatas(List<kd.FlexEntireData.FlexData> flexDatas)
```

**参数说明：**
- `flexDatas`: `List<kd.FlexEntireData.FlexData>` — 弹性域数据

---

### setId

设置ID

**方法签名：**
```java
public void setId(long id)
```

**参数说明：**
- `id`: `long`

---

### setSortedFlexDatas

设置排序后的弹性域数据

**方法签名：**
```java
public void setSortedFlexDatas(List<kd.FlexEntireData.FlexData> flexDatasSorted)
```

**参数说明：**
- `flexDatasSorted`: `List<kd.FlexEntireData.FlexData>`

---
