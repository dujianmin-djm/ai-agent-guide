---
framework_version: "8.0.1"
api_class: "DecimalReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-小数类型列时"
---

# DecimalReportColumn API 说明

## 概述
报表列-小数类型列。继承自 ReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：读取属性、设置属性、创建对象。

## Import 路径
```java
import kd.bos.entity.report.DecimalReportColumn;
```

---

## 方法列表

### createColumn

打包客户端报表列元数据信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`

---

### getDisplayFormatString

获取格式化字符串

**方法签名：**
```java
public String getDisplayFormatString()
```

**返回值：**
- `String`

---

### getSummary

获取汇总类型:
 0：无，1:合计

**方法签名：**
```java
public int getSummary()
```

**返回值：**
- `int`

---

### setDisplayFormatString

设置格式化字符串

**方法签名：**
```java
public void setDisplayFormatString(String displayFormatString)
```

**参数说明：**
- `displayFormatString`: `String`

---

### setSummary

设置汇总类型

**方法签名：**
```java
public void setSummary(int summary)
```

**参数说明：**
- `summary`: `int` — 汇总类型

---
