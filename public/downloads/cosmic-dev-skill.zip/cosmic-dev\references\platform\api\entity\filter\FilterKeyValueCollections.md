---
framework_version: "8.0.1"
api_class: "FilterKeyValueCollections"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用字段名与字段过滤元数据映射实体类时"
---

# FilterKeyValueCollections API 说明

## 概述
字段名与字段过滤元数据映射实体类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterKeyValueCollections;
```

---

## 方法列表

### getFilterKey

过滤字段名

**方法签名：**
```java
public String getFilterKey()
```

**返回值：**
- `String`

---

### getFilterValueCollection

获取字段过滤元数据集合

**方法签名：**
```java
public List<kd.FilterKeyValueCollection> getFilterValueCollection()
```

**返回值：**
- `List<kd.FilterKeyValueCollection>`

---
