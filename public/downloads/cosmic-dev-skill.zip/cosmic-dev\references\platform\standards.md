# 苍穹定制化开发规范（提炼版）


**Java 类命名规则：**

| 规则 | 说明 | 正例 | 反例 |
|------|------|------|------|
| 普通类 | UpperCamelCase | `JavaServerlessPlatform`、`XmlService`、`TcpUdpDeal` | `javaserverlessplatform`、`XMLService`、`TCPUDPDeal` |
| DO/BO/DTO/VO/AO/PO/UID | 缩写全大写保留 | `UserDO`、`TaPromotion` | `UserDo`、`TAPromotion` |
| 抽象类 | `Abstract` 开头 | `AbstractBasePlugIn` | `AbsBasePlugin` |
| 异常类 | `Exception` 结尾 | `BusinessException` | - |
| 测试类 | 被测类名 + `Test` 结尾 | `PurchaseServiceTest` | - |
| Service/DAO 接口 | 接口暴露服务，实现类用 `Impl` 后缀 | `CacheServiceImpl` 实现 `CacheService` | - |
| 能力接口 | `-able` 形容词 | `AbstractTranslator` 实现 `Translatable` | - |
| 枚举类 | `Enum` 后缀，成员全大写+下划线 | `StatusEnum`，成员 `AUDIT_PASS` | `Status`，成员 `auditPass` |

> 禁止随意缩写：`AbstractClass` → `AbsClass`、`condition` → `condi` 均不可接受。

**变量 / 常量命名规则：**

- 类型名词放词尾：`startTime`、`workQueue`、`nameList`、`TERMINATED_THREAD_COUNT`（勿用 `startedAt`、`QueueOfWork`、`listName`）
- 避免子父类成员变量同名，避免同一方法不同代码块的局部变量同名
- POJO 布尔字段**禁止加 `is` 前缀**（`Boolean isDeleted` → RPC 反序列化误读为 `deleted` 字段，导致异常），应写 `Boolean deleted`

**方法命名规则：**

- lowerCamelCase 驼峰形式：`getHttpMessage()`
- 属性方法用 `get`/`set` 开头，数据层用 `insert`/`update`/`delete` 开头
- 避免缩写：`setBackgroundImage` 而非 `setBGImage`；名称过长时加注释说明

**注释规范：**

| 位置 | 要求 | 风格 |
|------|------|------|
| 文件头 | 公司版权、产品名、模块名、创建时间、修订记录 | `/* ... */` 实现注释 |
| 类 / 接口 | 必须注释，置于 `class`/`interface` 关键字之前 | Javadoc `/** ... */` |
| public 方法 | 必须完整注释；`@override` / `private` 按复杂度决定 | Javadoc `/** ... */` |
| public 常量 / 属性 | 必须注释，置于定义之前 | Javadoc `/** ... */` |
| 方法内部代码块 | 使用实现注释 | `//` 或 `/* */` |

常用 Javadoc 标签：`@author`、`@version`、`@since`、`@param`、`@return`、`@throws`、`@see`、`@deprecated`

```java
/**
 * 附件上传帮助类
 * @author xxx
 * @since 2020-11-20
 */
public class AttachmentSaveServiceHelper { }

/**
 * 构建附件明细信息
 * @param typeDy   附件类型实体
 * @param targetId 附件 ID
 * @param attach   附件信息
 * @return appendix dynamic object
 * @throws Exception exception
 */
public static DynamicObject buildAttachDetail(DynamicObject typeDy, Long targetId,
        Map<String, Object> attach) throws Exception { ... }

/** The constant FIELD_ATTACHID. */
public static final String FIELD_ATTACHID = "attachId";
```

**插件类名后缀规则：**

| 类型 | 后缀 | 示例 |
|------|------|------|
| 表单插件 | `FormPlugin` | `PurchaseFormPlugin` |
| 单据插件 | `BillPlugin` | `PurchaseBillPlugin` |
| 列表插件 | `ListPlugin` | `PurchaseListPlugin` |
| 操作插件 | `OpPlugin` | `PurchaseOpPlugin` |
| 报表插件 | `RptPlugin` | `PurchaseRptPlugin` |

---

## 插件类型完整表

| 分类 | 场景 | 继承基类 |
|------|------|---------|
| 平台插件 | 单据页面 | `AbstractBillPlugin` |
| 平台插件 | 基础资料页面 | `AbstractBasePlugIn` |
| 平台插件 | 动态表单页面 | `AbstractFormPlugIn` |
| 平台插件 | 列表页面 | `AbstractListPlugIn` |
| 平台插件 | 树型基础资料列表 | `StandardTreeListPlugin` |
| 移动插件 | 移动表单 | `AbstractMobFormPlugin` |
| 移动插件 | 移动单据 | `AbstractMobBillPlugin` |
| 移动插件 | 移动列表 | `AbstractMobListPlugIn` |
| 操作服务 | 操作服务插件 | `AbstractOperationServicePlugIn` |
| 单据转换 | BOTP转换插件 | `AbstractConvertPlugIn` |

---

## 强制禁止项（违反可能导致生产事故）

### 插件开发
- **禁止在 `initialize()` 中注册控件事件或设置控件可见性**
  - 事件注册 → `registerListener()`
  - 界面控制 → `afterBindData()`
- **禁止在 `beforeBindData` / `afterBindData` 中修改数据对象**
  - 原因：每次新建和查看都会执行，会覆盖用户修改的值，且重新绑定效率极低
- **禁止直接访问平台元数据表 `t_meta_xx`**

### 循环操作
- **禁止在循环中访问数据库**（先批量查询，再在循环中处理）
- **禁止在循环中调用 `view.updateView()`**（循环结束后统一局部刷新）
- **大数据包（>100条）禁止在循环中用 `model.setValue`**，改用 `property.setValueFast`：

```java
// 正例：大批量赋值
for (DynamicProperty property : treeEntryProperties) {
    property.setValueFast(newObj, objProps.get(property.getName()).getValueFast(srcObj));
}
this.getView().updateView("entryKey"); // 循环外统一刷新
```

- **禁止在循环中调用 `DB.***()`、`ORM.create`、`DispatchServiceHelper.invoke***()`**

### 数据访问
- **禁止无过滤条件查询大数据量**（默认查询范围要缩小：当月/当天/当前组织）
- **所有脚本必须使用 KSQL 语法**，禁止方言 SQL
- **查询参数禁止拼接 SQL 字符串**，使用参数化查询
- **查询字段层级不超过 4 层**（过深产生笛卡尔积，性能骤降）
- **禁止使用 `Statement`**（用 `PreparedStatement` 防 SQL 注入）

### 多语言
- **禁止在代码中硬编码用户可见的中文字符串**，必须使用 `ResManager.loadKDString` 引用多语言资源文件

### 多线程
- **禁止使用 JDK 原生线程/线程池**，必须使用苍穹平台线程池 `kd.bos.threads.ThreadPools`

```java
// 正例：苍穹线程池
ThreadPools.executeOnce(() -> { /* 异步逻辑 */ });
```

| 平台线程池方法 | 说明 |
|--------------|------|
| `executeOnce` | 执行一次 |
| `newCachedThreadPool` | 创建可缓存线程池（返回 `ThreadPool`） |
| `newFixedThreadPool` | 创建固定线程池（返回 `ThreadPool`） |

### 缓存
- **分布式缓存 key 必须按账套隔离**，前缀加 `accountId`
- **禁止缓存大对象**（会导致 Redis BigKey，阻塞主线程）
- `loadFromCache` 只适合总数据量 < 1000 且不频繁变动的基础资料

### 日志
- **必须使用 `kd.bos.logging.Log` 接口**，禁止用 `System.out.println`
- **禁止用 JSON 序列化打印页面对象**（`SerializationUtils.toJsonString` 极耗 CPU）

```java
// 标准日志写法
private static final Log logger = LogFactory.getLog(MyClass.class);

if (logger.isDebugEnabled()) {
    logger.debug("Debug: " + info);
}
logger.error("操作失败", e); // 必须传入异常对象
```

### 安全
- **代码中禁止硬编码敏感信息**（账号、密码、外链等），敏感信息加密后存 MC
- **禁止页面明文显示敏感信息**（用平台隐私中心配置）
- **禁止使用 XML 外部实体**，过滤 `<!DOCTYPE>`、`<!ENTITY>`、`SYSTEM`

---

## 多语言规范

### 资源文件

- **路径**：`src/main/java/resources/{module-name}_zh_CN.properties`
- **编码**：UTF-8，value 直接写中文，**禁止使用 `\uXXXX` Unicode 转义**
- 每个插件模块一个文件，不跨模块共用

### Key 命名

格式：`{PluginClassName}_{sequential_number}`，序号从 0 开始，同一文件内全局递增。

```properties
PurchaseOrderBillPlugin_0=请选择费用类型
PurchaseOrderBillPlugin_1=金额不能超过预算
PurchaseOrderBillPlugin_2=请按要求填写"列表结果集"
```

### 使用方式

```java
import kd.bos.dataentity.resource.ResManager;

// ResManager.loadKDString(原文, key, module-name)
this.getView().showTipNotification(
    ResManager.loadKDString("请选择费用类型", "PurchaseOrderBillPlugin_0", "bos-aicoding"));
```

---

## 数据访问方法选择指南

| 方法 | 场景 | 缓存 | 可保存 | 说明 |
|------|------|------|--------|------|
| `BusinessDataServiceHelper.loadSingle` | 取单张单据 | 无 | 能 | 实时读库，pk不存在会报错 |
| `BusinessDataServiceHelper.loadSingleFromCache` | 取单条基础资料 | 有 | 否 | 优先缓存，缓存对象少状态信息 |
| `BusinessDataServiceHelper.load` | 取一批单据 | 无 | 能 | 无数据返回空集合，不报错 |
| `BusinessDataServiceHelper.loadFromCache` | 取一批基础资料 | 有 | 否 | 数据量<1000才推荐 |
| `QueryServiceHelper.query` | 取一批数据（只读） | 无 | 否 | 返回 plainObject，性能好 |
| `QueryServiceHelper.queryOne` | 取一行数据（只读） | 无 | 否 | 返回 plainObject |
| `QueryServiceHelper.queryDataSet` | 大数据量查询 | 无 | 否 | **流式，性能最佳，必须 try-with-resources** |
| `QueryServiceHelper.exists` | 判断是否存在 | 无 | 否 | 比 queryOne 后判断更高效 |

**选择原则：**
1. 判断存在 → `exists`（勿用 `queryOne` 后判断）
2. 大数据量 → `queryDataSet`
3. 小量只读 → `query` / `queryOne`
4. 需要保存回库 → `loadSingle` / `load`
5. 高频读取小量基础资料 → `loadSingleFromCache` / `loadFromCache`

**OQL 字段引用规则：**
- 单头字段：直接用字段名，如 `billno`
- 分录字段：加分录实体名前缀，如 `entryentity.cew4_material`

---

## 推荐做法

### 事务
- 避免大事务：将耗时操作拆分为多个小事务
- 需要事务控制和权限控制 → 在**操作插件**中完成（不在表单插件中）

### 微服务调用（跨云/跨应用）
- 跨云跨应用必须通过微服务，禁止直接依赖其他应用的 jar 包
- 服务工厂路由规则：`{isv}.{cloudId}.{appId}.ServiceFactory`

```java
// 调用二开微服务
Object result = DispatchServiceHelper.invokeService(
    "isv.ti.bo",       // Factory 类限定前缀
    "appId",           // 应用 Id
    "xxxService",      // 注册的服务名称
    "methodName",      // 调用方法
    new Object[]{...}  // 入参
);
```

### 引用对象赋值
- 不同实体类型的对象**禁止直接赋值**，需保证对象类型一致

```java
// 反例：customer 属性实体类型与 bd_customer完整实体下级属性集合不同。
// 实体属性规格不同，直接赋值后续取下级属性值可能会报错
DynamicObject customerObj = BusinessDataServiceHelper.loadSingleFromCache(pk, "bd_customer");
prop.setValueFast(dataEntity, customerObj); // 类型不一致！
```

```java
// 正例：通过基础资料字段引用实体类型取数赋值
RefEntityType et = (RefEntityType) prop.getComplexType();
DynamicObject customerObj = BusinessDataServiceHelper.loadSingleFromCache(pk, et);
prop.setValueFast(dataEntity, customerObj);
```

### 第三方 API
- 所有第三方 API 调用必须设置超时时间
- 使用第三方 jar 包前检查安全漏洞（https://nvd.nist.gov/vuln/search）

### 异常处理
- 统一使用 `KDException`（可自定义子异常）
- 有原始异常时必须作为 cause 传入：`throw new KDException(e, new ErrorCode("xxx",e.getMessage()));`
- 禁止直接调用 `Throwable.printStackTrace()`
- 三种处理方式：①UI 层捕获并显示**业务语义**提示（让用户知道下一步怎么处理）；②包装为新异常抛出（必须将原异常作为 cause）；③直接再次抛出
- **禁止直接隐藏异常**（空 catch 块）；有特殊理由必须输出日志并在注释中说明原因

