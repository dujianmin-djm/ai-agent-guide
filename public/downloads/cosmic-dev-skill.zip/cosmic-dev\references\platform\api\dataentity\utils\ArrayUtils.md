---
framework_version: "8.0.1"
api_class: "ArrayUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Operations on arrays, primitive arrays (like ` int[]`) and时"
---

# ArrayUtils API 说明

## 概述
Operations on arrays, primitive arrays (like ` int[]`) and。
主要功能：状态判断、添加元素、移除元素、读取属性。

## Import 路径
```java
import kd.bos.dataentity.utils.ArrayUtils;
```

---

## 方法列表

### add

**重载 1**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static Object add(T[] array, T element)
```

**参数说明：**
- `array`: `T[]` — the array to "add" the element to, may be ` null`
- `element`: `T` — the object to add, may be ` null`

**返回值：**
- `Object`: A new array containing the existing elements plus the new element
 The returned array type will be that of the input array (unless null),
 in which case it will have the same type as the element.
 If both are null, an IllegalArgumentException is thrown

---

**重载 2**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static boolean[] add(boolean[] array, boolean element)
```

**参数说明：**
- `array`: `boolean[]` — the array to copy and add the element to, may be ` null`
- `element`: `boolean` — the object to add at the last index of the new array

**返回值：**
- `boolean[]`: A new array containing the existing elements plus the new element

---

**重载 3**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static byte[] add(byte[] array, byte element)
```

**参数说明：**
- `array`: `byte[]` — the array to copy and add the element to, may be ` null`
- `element`: `byte` — the object to add at the last index of the new array

**返回值：**
- `byte[]`: A new array containing the existing elements plus the new element

---

**重载 4**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static char[] add(char[] array, char element)
```

**参数说明：**
- `array`: `char[]` — the array to copy and add the element to, may be ` null`
- `element`: `char` — the object to add at the last index of the new array

**返回值：**
- `char[]`: A new array containing the existing elements plus the new element

---

**重载 5**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static double[] add(double[] array, double element)
```

**参数说明：**
- `array`: `double[]` — the array to copy and add the element to, may be ` null`
- `element`: `double` — the object to add at the last index of the new array

**返回值：**
- `double[]`: A new array containing the existing elements plus the new element

---

**重载 6**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static float[] add(float[] array, float element)
```

**参数说明：**
- `array`: `float[]` — the array to copy and add the element to, may be ` null`
- `element`: `float` — the object to add at the last index of the new array

**返回值：**
- `float[]`: A new array containing the existing elements plus the new element

---

**重载 7**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static int[] add(int[] array, int element)
```

**参数说明：**
- `array`: `int[]` — the array to copy and add the element to, may be ` null`
- `element`: `int` — the object to add at the last index of the new array

**返回值：**
- `int[]`: A new array containing the existing elements plus the new element

---

**重载 8**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static long[] add(long[] array, long element)
```

**参数说明：**
- `array`: `long[]` — the array to copy and add the element to, may be ` null`
- `element`: `long` — the object to add at the last index of the new array

**返回值：**
- `long[]`: A new array containing the existing elements plus the new element

---

**重载 9**

Copies the given array and adds the given element at the end of the new array.

**方法签名：**
```java
public static short[] add(short[] array, short element)
```

**参数说明：**
- `array`: `short[]` — the array to copy and add the element to, may be ` null`
- `element`: `short` — the object to add at the last index of the new array

**返回值：**
- `short[]`: A new array containing the existing elements plus the new element

---

**重载 10**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static Object add(T[] array, int index, T element)
```

**参数说明：**
- `array`: `T[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `T` — the object to add

**返回值：**
- `Object`: A new array containing the existing elements and the new element

---

**重载 11**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static boolean[] add(boolean[] array, int index, boolean element)
```

**参数说明：**
- `array`: `boolean[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `boolean` — the object to add

**返回值：**
- `boolean[]`: A new array containing the existing elements and the new element

---

**重载 12**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static char[] add(char[] array, int index, char element)
```

**参数说明：**
- `array`: `char[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `char` — the object to add

**返回值：**
- `char[]`: A new array containing the existing elements and the new element

---

**重载 13**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static byte[] add(byte[] array, int index, byte element)
```

**参数说明：**
- `array`: `byte[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `byte` — the object to add

**返回值：**
- `byte[]`: A new array containing the existing elements and the new element

---

**重载 14**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static short[] add(short[] array, int index, short element)
```

**参数说明：**
- `array`: `short[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `short` — the object to add

**返回值：**
- `short[]`: A new array containing the existing elements and the new element

---

**重载 15**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static int[] add(int[] array, int index, int element)
```

**参数说明：**
- `array`: `int[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `int` — the object to add

**返回值：**
- `int[]`: A new array containing the existing elements and the new element

---

**重载 16**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static long[] add(long[] array, int index, long element)
```

**参数说明：**
- `array`: `long[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `long` — the object to add

**返回值：**
- `long[]`: A new array containing the existing elements and the new element

---

**重载 17**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static float[] add(float[] array, int index, float element)
```

**参数说明：**
- `array`: `float[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `float` — the object to add

**返回值：**
- `float[]`: A new array containing the existing elements and the new element

---

**重载 18**

Inserts the specified element at the specified position in the array.
 Shifts the element currently at that position (if any) and any subsequent
 elements to the right (adds one to their indices).

**方法签名：**
```java
public static double[] add(double[] array, int index, double element)
```

**参数说明：**
- `array`: `double[]` — the array to add the element to, may be ` null`
- `index`: `int` — the position of the new object
- `element`: `double` — the object to add

**返回值：**
- `double[]`: A new array containing the existing elements and the new element

---

### addAll

**重载 1**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static Object addAll(T[] array1, T[] array2)
```

**参数说明：**
- `array1`: `T[]` — the first array whose elements are added to the new array, may be ` null`
- `array2`: `T[]` — the second array whose elements are added to the new array, may be ` null`

**返回值：**
- `Object`: The new array, ` null` if both arrays are ` null`.
      The type of the new array is the type of the first array,
      unless the first array is null, in which case the type is the same as the second array.

---

**重载 2**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static boolean[] addAll(boolean[] array1, boolean[] array2)
```

**参数说明：**
- `array1`: `boolean[]` — the first array whose elements are added to the new array.
- `array2`: `boolean[]` — the second array whose elements are added to the new array.

**返回值：**
- `boolean[]`: The new boolean[] array.

---

**重载 3**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static char[] addAll(char[] array1, char[] array2)
```

**参数说明：**
- `array1`: `char[]` — the first array whose elements are added to the new array.
- `array2`: `char[]` — the second array whose elements are added to the new array.

**返回值：**
- `char[]`: The new char[] array.

---

**重载 4**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static byte[] addAll(byte[] array1, byte[] array2)
```

**参数说明：**
- `array1`: `byte[]` — the first array whose elements are added to the new array.
- `array2`: `byte[]` — the second array whose elements are added to the new array.

**返回值：**
- `byte[]`: The new byte[] array.

---

**重载 5**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static short[] addAll(short[] array1, short[] array2)
```

**参数说明：**
- `array1`: `short[]` — the first array whose elements are added to the new array.
- `array2`: `short[]` — the second array whose elements are added to the new array.

**返回值：**
- `short[]`: The new short[] array.

---

**重载 6**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static int[] addAll(int[] array1, int[] array2)
```

**参数说明：**
- `array1`: `int[]` — the first array whose elements are added to the new array.
- `array2`: `int[]` — the second array whose elements are added to the new array.

**返回值：**
- `int[]`: The new int[] array.

---

**重载 7**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static long[] addAll(long[] array1, long[] array2)
```

**参数说明：**
- `array1`: `long[]` — the first array whose elements are added to the new array.
- `array2`: `long[]` — the second array whose elements are added to the new array.

**返回值：**
- `long[]`: The new long[] array.

---

**重载 8**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static float[] addAll(float[] array1, float[] array2)
```

**参数说明：**
- `array1`: `float[]` — the first array whose elements are added to the new array.
- `array2`: `float[]` — the second array whose elements are added to the new array.

**返回值：**
- `float[]`: The new float[] array.

---

**重载 9**

Adds all the elements of the given arrays into a new array.
 The new array contains all of the element of ` array1` followed
 by all of the elements ` array2`. When an array is returned, it is always
 a new array.

**方法签名：**
```java
public static double[] addAll(double[] array1, double[] array2)
```

**参数说明：**
- `array1`: `double[]` — the first array whose elements are added to the new array.
- `array2`: `double[]` — the second array whose elements are added to the new array.

**返回值：**
- `double[]`: The new double[] array.

---

### clone

**重载 1**

Shallow clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static Object clone(T[] array)
```

**参数说明：**
- `array`: `T[]` — the array to shallow clone, may be ` null`

**返回值：**
- `Object`: the cloned array, ` null` if ` null` input

---

**重载 2**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static long[] clone(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to clone, may be ` null`

**返回值：**
- `long[]`: the cloned array, ` null` if ` null` input

---

**重载 3**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static int[] clone(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to clone, may be ` null`

**返回值：**
- `int[]`: the cloned array, ` null` if ` null` input

---

**重载 4**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static short[] clone(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to clone, may be ` null`

**返回值：**
- `short[]`: the cloned array, ` null` if ` null` input

---

**重载 5**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static char[] clone(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to clone, may be ` null`

**返回值：**
- `char[]`: the cloned array, ` null` if ` null` input

---

**重载 6**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static byte[] clone(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to clone, may be ` null`

**返回值：**
- `byte[]`: the cloned array, ` null` if ` null` input

---

**重载 7**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static double[] clone(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to clone, may be ` null`

**返回值：**
- `double[]`: the cloned array, ` null` if ` null` input

---

**重载 8**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static float[] clone(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to clone, may be ` null`

**返回值：**
- `float[]`: the cloned array, ` null` if ` null` input

---

**重载 9**

Clones an array returning a typecast result and handling
 ` null`.

**方法签名：**
```java
public static boolean[] clone(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to clone, may be ` null`

**返回值：**
- `boolean[]`: the cloned array, ` null` if ` null` input

---

### contains

**重载 1**

Checks if the object is in the given array.

**方法签名：**
```java
public static boolean contains(Object[] array, Object objectToFind)
```

**参数说明：**
- `array`: `Object[]` — the array to search through
- `objectToFind`: `Object` — the object to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 2**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(long[] array, long valueToFind)
```

**参数说明：**
- `array`: `long[]` — the array to search through
- `valueToFind`: `long` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 3**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(int[] array, int valueToFind)
```

**参数说明：**
- `array`: `int[]` — the array to search through
- `valueToFind`: `int` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 4**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(short[] array, short valueToFind)
```

**参数说明：**
- `array`: `short[]` — the array to search through
- `valueToFind`: `short` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 5**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(char[] array, char valueToFind)
```

**参数说明：**
- `array`: `char[]` — the array to search through
- `valueToFind`: `char` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 6**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(byte[] array, byte valueToFind)
```

**参数说明：**
- `array`: `byte[]` — the array to search through
- `valueToFind`: `byte` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 7**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(double[] array, double valueToFind)
```

**参数说明：**
- `array`: `double[]` — the array to search through
- `valueToFind`: `double` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 8**

Checks if a value falling within the given tolerance is in the
 given array.  If the array contains a value within the inclusive range
 defined by (value - tolerance) to (value + tolerance).

**方法签名：**
```java
public static boolean contains(double[] array, double valueToFind, double tolerance)
```

**参数说明：**
- `array`: `double[]` — the array to search
- `valueToFind`: `double` — the value to find
- `tolerance`: `double` — the array contains the tolerance of the search

**返回值：**
- `boolean`: true if value falling within tolerance is in array

---

**重载 9**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(float[] array, float valueToFind)
```

**参数说明：**
- `array`: `float[]` — the array to search through
- `valueToFind`: `float` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

**重载 10**

Checks if the value is in the given array.

**方法签名：**
```java
public static boolean contains(boolean[] array, boolean valueToFind)
```

**参数说明：**
- `array`: `boolean[]` — the array to search through
- `valueToFind`: `boolean` — the value to find

**返回值：**
- `boolean`: ` true` if the array contains the object

---

### getLength

Returns the length of the specified array.
 This method can deal with ` Object` arrays and with primitive arrays.

**方法签名：**
```java
public static int getLength(Object array)
```

**参数说明：**
- `array`: `Object` — the array to retrieve the length from, may be null

**返回值：**
- `int`: The length of the array, or ` 0` if the array is ` null`

---

### hashCode

Get a hash code for an array handling multi-dimensional arrays correctly.

**方法签名：**
```java
public static int hashCode(Object array)
```

**参数说明：**
- `array`: `Object` — the array to get a hash code for, ` null` returns zero

**返回值：**
- `int`: a hash code for the array

---

### indexOf

**重载 1**

Finds the index of the given object in the array.

**方法签名：**
```java
public static int indexOf(Object[] array, Object objectToFind)
```

**参数说明：**
- `array`: `Object[]` — the array to search through for the object, may be ` null`
- `objectToFind`: `Object` — the object to find, may be ` null`

**返回值：**
- `int`: the index of the object within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 2**

Finds the index of the given object in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(Object[] array, Object objectToFind, int startIndex)
```

**参数说明：**
- `array`: `Object[]` — the array to search through for the object, may be ` null`
- `objectToFind`: `Object` — the object to find, may be ` null`
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the object within the array starting at the index,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 3**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(long[] array, long valueToFind)
```

**参数说明：**
- `array`: `long[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `long` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 4**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(long[] array, long valueToFind, int startIndex)
```

**参数说明：**
- `array`: `long[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `long` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 5**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(int[] array, int valueToFind)
```

**参数说明：**
- `array`: `int[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `int` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 6**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(int[] array, int valueToFind, int startIndex)
```

**参数说明：**
- `array`: `int[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `int` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 7**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(short[] array, short valueToFind)
```

**参数说明：**
- `array`: `short[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `short` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 8**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(short[] array, short valueToFind, int startIndex)
```

**参数说明：**
- `array`: `short[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `short` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 9**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(char[] array, char valueToFind)
```

**参数说明：**
- `array`: `char[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `char` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 10**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(char[] array, char valueToFind, int startIndex)
```

**参数说明：**
- `array`: `char[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `char` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 11**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(byte[] array, byte valueToFind)
```

**参数说明：**
- `array`: `byte[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `byte` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 12**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(byte[] array, byte valueToFind, int startIndex)
```

**参数说明：**
- `array`: `byte[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `byte` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 13**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(double[] array, double valueToFind)
```

**参数说明：**
- `array`: `double[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `double` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 14**

Finds the index of the given value within a given tolerance in the array.
 This method will return the index of the first value which falls between the region
 defined by valueToFind - tolerance and valueToFind + tolerance.

**方法签名：**
```java
public static int indexOf(double[] array, double valueToFind, double tolerance)
```

**参数说明：**
- `array`: `double[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `tolerance`: `double` — tolerance of the search

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 15**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(double[] array, double valueToFind, int startIndex)
```

**参数说明：**
- `array`: `double[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 16**

Finds the index of the given value in the array starting at the given index.
 This method will return the index of the first value which falls between the region
 defined by valueToFind - tolerance and valueToFind + tolerance.

**方法签名：**
```java
public static int indexOf(double[] array, double valueToFind, int startIndex, double tolerance)
```

**参数说明：**
- `array`: `double[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `startIndex`: `int` — the index to start searching at
- `tolerance`: `double` — tolerance of the search

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 17**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(float[] array, float valueToFind)
```

**参数说明：**
- `array`: `float[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `float` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 18**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(float[] array, float valueToFind, int startIndex)
```

**参数说明：**
- `array`: `float[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `float` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 19**

Finds the index of the given value in the array.

**方法签名：**
```java
public static int indexOf(boolean[] array, boolean valueToFind)
```

**参数说明：**
- `array`: `boolean[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `boolean` — the value to find

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 20**

Finds the index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int indexOf(boolean[] array, boolean valueToFind, int startIndex)
```

**参数说明：**
- `array`: `boolean[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `boolean` — the value to find
- `startIndex`: `int` — the index to start searching at

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null`
  array input

---

### isEmpty

**重载 1**

Checks if an array of Objects is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 2**

Checks if an array of primitive longs is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 3**

Checks if an array of primitive ints is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 4**

Checks if an array of primitive shorts is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 5**

Checks if an array of primitive chars is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 6**

Checks if an array of primitive bytes is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 7**

Checks if an array of primitive doubles is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 8**

Checks if an array of primitive floats is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

**重载 9**

Checks if an array of primitive booleans is empty or ` null`.

**方法签名：**
```java
public static boolean isEmpty(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is empty or ` null`

---

### isNotEmpty

**重载 1**

Checks if an array of Objects is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(T[] array)
```

**参数说明：**
- `array`: `T[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 2**

Checks if an array of primitive longs is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 3**

Checks if an array of primitive ints is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 4**

Checks if an array of primitive shorts is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 5**

Checks if an array of primitive chars is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 6**

Checks if an array of primitive bytes is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 7**

Checks if an array of primitive doubles is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 8**

Checks if an array of primitive floats is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

**重载 9**

Checks if an array of primitive booleans is not empty or not ` null`.

**方法签名：**
```java
public static boolean isNotEmpty(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to test

**返回值：**
- `boolean`: ` true` if the array is not empty or not ` null`

---

### isSameLength

**重载 1**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(Object[] array1, Object[] array2)
```

**参数说明：**
- `array1`: `Object[]` — the first array, may be ` null`
- `array2`: `Object[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 2**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(long[] array1, long[] array2)
```

**参数说明：**
- `array1`: `long[]` — the first array, may be ` null`
- `array2`: `long[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 3**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(int[] array1, int[] array2)
```

**参数说明：**
- `array1`: `int[]` — the first array, may be ` null`
- `array2`: `int[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 4**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(short[] array1, short[] array2)
```

**参数说明：**
- `array1`: `short[]` — the first array, may be ` null`
- `array2`: `short[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 5**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(char[] array1, char[] array2)
```

**参数说明：**
- `array1`: `char[]` — the first array, may be ` null`
- `array2`: `char[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 6**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(byte[] array1, byte[] array2)
```

**参数说明：**
- `array1`: `byte[]` — the first array, may be ` null`
- `array2`: `byte[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 7**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(double[] array1, double[] array2)
```

**参数说明：**
- `array1`: `double[]` — the first array, may be ` null`
- `array2`: `double[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 8**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(float[] array1, float[] array2)
```

**参数说明：**
- `array1`: `float[]` — the first array, may be ` null`
- `array2`: `float[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

**重载 9**

Checks whether two arrays are the same length, treating
 ` null` arrays as length ` 0`.

**方法签名：**
```java
public static boolean isSameLength(boolean[] array1, boolean[] array2)
```

**参数说明：**
- `array1`: `boolean[]` — the first array, may be ` null`
- `array2`: `boolean[]` — the second array, may be ` null`

**返回值：**
- `boolean`: ` true` if length of arrays matches, treating
  ` null` as an empty array

---

### isSameType

Checks whether two arrays are the same type taking into account
 multi-dimensional arrays.

**方法签名：**
```java
public static boolean isSameType(Object array1, Object array2)
```

**参数说明：**
- `array1`: `Object` — the first array, must not be ` null`
- `array2`: `Object` — the second array, must not be ` null`

**返回值：**
- `boolean`: ` true` if type of arrays matches

---

### lastIndexOf

**重载 1**

Finds the last index of the given object within the array.

**方法签名：**
```java
public static int lastIndexOf(Object[] array, Object objectToFind)
```

**参数说明：**
- `array`: `Object[]` — the array to travers backwords looking for the object, may be ` null`
- `objectToFind`: `Object` — the object to find, may be ` null`

**返回值：**
- `int`: the last index of the object within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 2**

Finds the last index of the given object in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(Object[] array, Object objectToFind, int startIndex)
```

**参数说明：**
- `array`: `Object[]` — the array to traverse for looking for the object, may be ` null`
- `objectToFind`: `Object` — the object to find, may be ` null`
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the object within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 3**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(long[] array, long valueToFind)
```

**参数说明：**
- `array`: `long[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `long` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 4**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(long[] array, long valueToFind, int startIndex)
```

**参数说明：**
- `array`: `long[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `long` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 5**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(int[] array, int valueToFind)
```

**参数说明：**
- `array`: `int[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `int` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 6**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(int[] array, int valueToFind, int startIndex)
```

**参数说明：**
- `array`: `int[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `int` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 7**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(short[] array, short valueToFind)
```

**参数说明：**
- `array`: `short[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `short` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 8**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(short[] array, short valueToFind, int startIndex)
```

**参数说明：**
- `array`: `short[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `short` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 9**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(char[] array, char valueToFind)
```

**参数说明：**
- `array`: `char[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `char` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 10**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(char[] array, char valueToFind, int startIndex)
```

**参数说明：**
- `array`: `char[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `char` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 11**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(byte[] array, byte valueToFind)
```

**参数说明：**
- `array`: `byte[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `byte` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 12**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(byte[] array, byte valueToFind, int startIndex)
```

**参数说明：**
- `array`: `byte[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `byte` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 13**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(double[] array, double valueToFind)
```

**参数说明：**
- `array`: `double[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `double` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 14**

Finds the last index of the given value within a given tolerance in the array.
 This method will return the index of the last value which falls between the region
 defined by valueToFind - tolerance and valueToFind + tolerance.

**方法签名：**
```java
public static int lastIndexOf(double[] array, double valueToFind, double tolerance)
```

**参数说明：**
- `array`: `double[]` — the array to search through for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `tolerance`: `double` — tolerance of the search

**返回值：**
- `int`: the index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 15**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(double[] array, double valueToFind, int startIndex)
```

**参数说明：**
- `array`: `double[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 16**

Finds the last index of the given value in the array starting at the given index.
 This method will return the index of the last value which falls between the region
 defined by valueToFind - tolerance and valueToFind + tolerance.

**方法签名：**
```java
public static int lastIndexOf(double[] array, double valueToFind, int startIndex, double tolerance)
```

**参数说明：**
- `array`: `double[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `double` — the value to find
- `startIndex`: `int` — the start index to travers backwards from
- `tolerance`: `double` — search for value within plus/minus this amount

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 17**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(float[] array, float valueToFind)
```

**参数说明：**
- `array`: `float[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `float` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 18**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(float[] array, float valueToFind, int startIndex)
```

**参数说明：**
- `array`: `float[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `float` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 19**

Finds the last index of the given value within the array.

**方法签名：**
```java
public static int lastIndexOf(boolean[] array, boolean valueToFind)
```

**参数说明：**
- `array`: `boolean[]` — the array to travers backwords looking for the object, may be ` null`
- `valueToFind`: `boolean` — the object to find

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

**重载 20**

Finds the last index of the given value in the array starting at the given index.

**方法签名：**
```java
public static int lastIndexOf(boolean[] array, boolean valueToFind, int startIndex)
```

**参数说明：**
- `array`: `boolean[]` — the array to traverse for looking for the object, may be ` null`
- `valueToFind`: `boolean` — the value to find
- `startIndex`: `int` — the start index to travers backwards from

**返回值：**
- `int`: the last index of the value within the array,
  #INDEX_NOT_FOUND (` -1`) if not found or ` null` array input

---

### nullToEmpty

**重载 1**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Object[] nullToEmpty(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — the array to check for ` null` or empty

**返回值：**
- `Object[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 2**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Class<?>[] nullToEmpty(Class<?>[] array)
```

**参数说明：**
- `array`: `Class<?>[]` — the array to check for ` null` or empty

**返回值：**
- `Class<?>[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 3**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static String[] nullToEmpty(String[] array)
```

**参数说明：**
- `array`: `String[]` — the array to check for ` null` or empty

**返回值：**
- `String[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 4**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static long[] nullToEmpty(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to check for ` null` or empty

**返回值：**
- `long[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 5**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static int[] nullToEmpty(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to check for ` null` or empty

**返回值：**
- `int[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 6**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static short[] nullToEmpty(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to check for ` null` or empty

**返回值：**
- `short[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 7**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static char[] nullToEmpty(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to check for ` null` or empty

**返回值：**
- `char[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 8**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static byte[] nullToEmpty(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to check for ` null` or empty

**返回值：**
- `byte[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 9**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static double[] nullToEmpty(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to check for ` null` or empty

**返回值：**
- `double[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 10**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static float[] nullToEmpty(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to check for ` null` or empty

**返回值：**
- `float[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 11**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static boolean[] nullToEmpty(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to check for ` null` or empty

**返回值：**
- `boolean[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 12**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Long[] nullToEmpty(Long[] array)
```

**参数说明：**
- `array`: `Long[]` — the array to check for ` null` or empty

**返回值：**
- `Long[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 13**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Integer[] nullToEmpty(Integer[] array)
```

**参数说明：**
- `array`: `Integer[]` — the array to check for ` null` or empty

**返回值：**
- `Integer[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 14**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Short[] nullToEmpty(Short[] array)
```

**参数说明：**
- `array`: `Short[]` — the array to check for ` null` or empty

**返回值：**
- `Short[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 15**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Character[] nullToEmpty(Character[] array)
```

**参数说明：**
- `array`: `Character[]` — the array to check for ` null` or empty

**返回值：**
- `Character[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 16**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Byte[] nullToEmpty(Byte[] array)
```

**参数说明：**
- `array`: `Byte[]` — the array to check for ` null` or empty

**返回值：**
- `Byte[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 17**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Double[] nullToEmpty(Double[] array)
```

**参数说明：**
- `array`: `Double[]` — the array to check for ` null` or empty

**返回值：**
- `Double[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 18**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Float[] nullToEmpty(Float[] array)
```

**参数说明：**
- `array`: `Float[]` — the array to check for ` null` or empty

**返回值：**
- `Float[]`: the same array, ` public static` empty array if ` null` or empty input

---

**重载 19**

Defensive programming technique to change a ` null`
 reference to an empty one.

**方法签名：**
```java
public static Boolean[] nullToEmpty(Boolean[] array)
```

**参数说明：**
- `array`: `Boolean[]` — the array to check for ` null` or empty

**返回值：**
- `Boolean[]`: the same array, ` public static` empty array if ` null` or empty input

---

### remove

**重载 1**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static Object remove(T[] array, int index)
```

**参数说明：**
- `array`: `T[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `Object`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 2**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static boolean[] remove(boolean[] array, int index)
```

**参数说明：**
- `array`: `boolean[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `boolean[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 3**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static byte[] remove(byte[] array, int index)
```

**参数说明：**
- `array`: `byte[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `byte[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 4**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static char[] remove(char[] array, int index)
```

**参数说明：**
- `array`: `char[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `char[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 5**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static double[] remove(double[] array, int index)
```

**参数说明：**
- `array`: `double[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `double[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 6**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static float[] remove(float[] array, int index)
```

**参数说明：**
- `array`: `float[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `float[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 7**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static int[] remove(int[] array, int index)
```

**参数说明：**
- `array`: `int[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `int[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 8**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static long[] remove(long[] array, int index)
```

**参数说明：**
- `array`: `long[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `long[]`: A new array containing the existing elements except the element
         at the specified position.

---

**重载 9**

Removes the element at the specified position from the specified array.
 All subsequent elements are shifted to the left (subtracts one from
 their indices).

**方法签名：**
```java
public static short[] remove(short[] array, int index)
```

**参数说明：**
- `array`: `short[]` — the array to remove the element from, may not be ` null`
- `index`: `int` — the position of the element to be removed

**返回值：**
- `short[]`: A new array containing the existing elements except the element
         at the specified position.

---

### removeElement

**重载 1**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static Object removeElement(T[] array, Object element)
```

**参数说明：**
- `array`: `T[]` — the array to remove the element from, may be ` null`
- `element`: `Object` — the element to be removed

**返回值：**
- `Object`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 2**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static boolean[] removeElement(boolean[] array, boolean element)
```

**参数说明：**
- `array`: `boolean[]` — the array to remove the element from, may be ` null`
- `element`: `boolean` — the element to be removed

**返回值：**
- `boolean[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 3**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static byte[] removeElement(byte[] array, byte element)
```

**参数说明：**
- `array`: `byte[]` — the array to remove the element from, may be ` null`
- `element`: `byte` — the element to be removed

**返回值：**
- `byte[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 4**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static char[] removeElement(char[] array, char element)
```

**参数说明：**
- `array`: `char[]` — the array to remove the element from, may be ` null`
- `element`: `char` — the element to be removed

**返回值：**
- `char[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 5**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static double[] removeElement(double[] array, double element)
```

**参数说明：**
- `array`: `double[]` — the array to remove the element from, may be ` null`
- `element`: `double` — the element to be removed

**返回值：**
- `double[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 6**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static float[] removeElement(float[] array, float element)
```

**参数说明：**
- `array`: `float[]` — the array to remove the element from, may be ` null`
- `element`: `float` — the element to be removed

**返回值：**
- `float[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 7**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static int[] removeElement(int[] array, int element)
```

**参数说明：**
- `array`: `int[]` — the array to remove the element from, may be ` null`
- `element`: `int` — the element to be removed

**返回值：**
- `int[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 8**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static long[] removeElement(long[] array, long element)
```

**参数说明：**
- `array`: `long[]` — the array to remove the element from, may be ` null`
- `element`: `long` — the element to be removed

**返回值：**
- `long[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

**重载 9**

Removes the first occurrence of the specified element from the
 specified array. All subsequent elements are shifted to the left
 (subtracts one from their indices). If the array doesn't contains
 such an element, no elements are removed from the array.

**方法签名：**
```java
public static short[] removeElement(short[] array, short element)
```

**参数说明：**
- `array`: `short[]` — the array to remove the element from, may be ` null`
- `element`: `short` — the element to be removed

**返回值：**
- `short[]`: A new array containing the existing elements except the first
         occurrence of the specified element.

---

### reverse

**重载 1**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — the array to reverse, may be ` null`

---

**重载 2**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to reverse, may be ` null`

---

**重载 3**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to reverse, may be ` null`

---

**重载 4**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to reverse, may be ` null`

---

**重载 5**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to reverse, may be ` null`

---

**重载 6**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to reverse, may be ` null`

---

**重载 7**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to reverse, may be ` null`

---

**重载 8**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to reverse, may be ` null`

---

**重载 9**

Reverses the order of the given array.

**方法签名：**
```java
public static void reverse(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to reverse, may be ` null`

---

**重载 10**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(boolean[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `boolean[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 11**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(byte[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `byte[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 12**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(char[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `char[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 13**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(double[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `double[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 14**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(float[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `float[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 15**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(int[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `int[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 16**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(long[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `long[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 17**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(Object[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `Object[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

**重载 18**

Reverses the order of the given array in the given range.
 
 
 
 This method does nothing for a ` null` input array.

**方法签名：**
```java
public static void reverse(short[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `short[]`
- `startIndexInclusive`: `int`
- `endIndexExclusive`: `int`

---

### subarray

**重载 1**

Produces a new array containing the elements between
 the start and end indices.

**方法签名：**
```java
public static Object subarray(T[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `T[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `Object`: a new array containing the elements between
      the start and end indices.

---

**重载 2**

Produces a new ` long` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static long[] subarray(long[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `long[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `long[]`: a new array containing the elements between
      the start and end indices.

---

**重载 3**

Produces a new ` int` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static int[] subarray(int[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `int[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `int[]`: a new array containing the elements between
      the start and end indices.

---

**重载 4**

Produces a new ` short` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static short[] subarray(short[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `short[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `short[]`: a new array containing the elements between
      the start and end indices.

---

**重载 5**

Produces a new ` char` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static char[] subarray(char[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `char[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `char[]`: a new array containing the elements between
      the start and end indices.

---

**重载 6**

Produces a new ` byte` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static byte[] subarray(byte[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `byte[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `byte[]`: a new array containing the elements between
      the start and end indices.

---

**重载 7**

Produces a new ` double` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static double[] subarray(double[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `double[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `double[]`: a new array containing the elements between
      the start and end indices.

---

**重载 8**

Produces a new ` float` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static float[] subarray(float[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `float[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `float[]`: a new array containing the elements between
      the start and end indices.

---

**重载 9**

Produces a new ` boolean` array containing the elements
 between the start and end indices.

**方法签名：**
```java
public static boolean[] subarray(boolean[] array, int startIndexInclusive, int endIndexExclusive)
```

**参数说明：**
- `array`: `boolean[]` — the array
- `startIndexInclusive`: `int` — the starting index. Undervalue (<0)
      is promoted to 0, overvalue (>array.length) results
      in an empty array.
- `endIndexExclusive`: `int` — elements up to endIndex-1 are present in the
      returned subarray. Undervalue (< startIndex) produces
      empty array, overvalue (>array.length) is demoted to
      array length.

**返回值：**
- `boolean[]`: a new array containing the elements between
      the start and end indices.

---

### toArray

Create a type-safe generic array.

**方法签名：**
```java
public static Object toArray(T[] items)
```

**参数说明：**
- `items`: `T[]` — the varargs array items, null allowed

**返回值：**
- `Object`: the array, not null unless a null array is passed in

---

### toMap

Converts the given array into a java.util.Map. Each element of the array
 must be either a java.util.Map.Entry or an Array, containing at least two
 elements, where the first element is used as key and the second as
 value.

**方法签名：**
```java
public static Map<Object,Object> toMap(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — an array whose elements are either a java.util.Map.Entry or
  an Array containing at least two elements, may be ` null`

**返回值：**
- `Map<Object,Object>`: a ` Map` that was created from the array

---

### toObject

**重载 1**

Converts an array of primitive chars to objects.

**方法签名：**
```java
public static Character[] toObject(char[] array)
```

**参数说明：**
- `array`: `char[]` — a ` char` array

**返回值：**
- `Character[]`: a ` Character` array, ` null` if null array input

---

**重载 2**

Converts an array of primitive longs to objects.

**方法签名：**
```java
public static Long[] toObject(long[] array)
```

**参数说明：**
- `array`: `long[]` — a ` long` array

**返回值：**
- `Long[]`: a ` Long` array, ` null` if null array input

---

**重载 3**

Converts an array of primitive ints to objects.

**方法签名：**
```java
public static Integer[] toObject(int[] array)
```

**参数说明：**
- `array`: `int[]` — an ` int` array

**返回值：**
- `Integer[]`: an ` Integer` array, ` null` if null array input

---

**重载 4**

Converts an array of primitive shorts to objects.

**方法签名：**
```java
public static Short[] toObject(short[] array)
```

**参数说明：**
- `array`: `short[]` — a ` short` array

**返回值：**
- `Short[]`: a ` Short` array, ` null` if null array input

---

**重载 5**

Converts an array of primitive bytes to objects.

**方法签名：**
```java
public static Byte[] toObject(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — a ` byte` array

**返回值：**
- `Byte[]`: a ` Byte` array, ` null` if null array input

---

**重载 6**

Converts an array of primitive doubles to objects.

**方法签名：**
```java
public static Double[] toObject(double[] array)
```

**参数说明：**
- `array`: `double[]` — a ` double` array

**返回值：**
- `Double[]`: a ` Double` array, ` null` if null array input

---

**重载 7**

Converts an array of primitive floats to objects.

**方法签名：**
```java
public static Float[] toObject(float[] array)
```

**参数说明：**
- `array`: `float[]` — a ` float` array

**返回值：**
- `Float[]`: a ` Float` array, ` null` if null array input

---

**重载 8**

Converts an array of primitive booleans to objects.

**方法签名：**
```java
public static Boolean[] toObject(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — a ` boolean` array

**返回值：**
- `Boolean[]`: a ` Boolean` array, ` null` if null array input

---

### toPrimitive

**重载 1**

Converts an array of object Characters to primitives.

**方法签名：**
```java
public static char[] toPrimitive(Character[] array)
```

**参数说明：**
- `array`: `Character[]` — a ` Character` array, may be ` null`

**返回值：**
- `char[]`: a ` char` array, ` null` if null array input

---

**重载 2**

Converts an array of object Character to primitives handling ` null`.

**方法签名：**
```java
public static char[] toPrimitive(Character[] array, char valueForNull)
```

**参数说明：**
- `array`: `Character[]` — a ` Character` array, may be ` null`
- `valueForNull`: `char` — the value to insert if ` null` found

**返回值：**
- `char[]`: a ` char` array, ` null` if null array input

---

**重载 3**

Converts an array of object Longs to primitives.

**方法签名：**
```java
public static long[] toPrimitive(Long[] array)
```

**参数说明：**
- `array`: `Long[]` — a ` Long` array, may be ` null`

**返回值：**
- `long[]`: a ` long` array, ` null` if null array input

---

**重载 4**

Converts an array of object Long to primitives handling ` null`.

**方法签名：**
```java
public static long[] toPrimitive(Long[] array, long valueForNull)
```

**参数说明：**
- `array`: `Long[]` — a ` Long` array, may be ` null`
- `valueForNull`: `long` — the value to insert if ` null` found

**返回值：**
- `long[]`: a ` long` array, ` null` if null array input

---

**重载 5**

Converts an array of object Integers to primitives.

**方法签名：**
```java
public static int[] toPrimitive(Integer[] array)
```

**参数说明：**
- `array`: `Integer[]` — a ` Integer` array, may be ` null`

**返回值：**
- `int[]`: an ` int` array, ` null` if null array input

---

**重载 6**

Converts an array of object Integer to primitives handling ` null`.

**方法签名：**
```java
public static int[] toPrimitive(Integer[] array, int valueForNull)
```

**参数说明：**
- `array`: `Integer[]` — a ` Integer` array, may be ` null`
- `valueForNull`: `int` — the value to insert if ` null` found

**返回值：**
- `int[]`: an ` int` array, ` null` if null array input

---

**重载 7**

Converts an array of object Shorts to primitives.

**方法签名：**
```java
public static short[] toPrimitive(Short[] array)
```

**参数说明：**
- `array`: `Short[]` — a ` Short` array, may be ` null`

**返回值：**
- `short[]`: a ` byte` array, ` null` if null array input

---

**重载 8**

Converts an array of object Short to primitives handling ` null`.

**方法签名：**
```java
public static short[] toPrimitive(Short[] array, short valueForNull)
```

**参数说明：**
- `array`: `Short[]` — a ` Short` array, may be ` null`
- `valueForNull`: `short` — the value to insert if ` null` found

**返回值：**
- `short[]`: a ` byte` array, ` null` if null array input

---

**重载 9**

Converts an array of object Bytes to primitives.

**方法签名：**
```java
public static byte[] toPrimitive(Byte[] array)
```

**参数说明：**
- `array`: `Byte[]` — a ` Byte` array, may be ` null`

**返回值：**
- `byte[]`: a ` byte` array, ` null` if null array input

---

**重载 10**

Converts an array of object Bytes to primitives handling ` null`.

**方法签名：**
```java
public static byte[] toPrimitive(Byte[] array, byte valueForNull)
```

**参数说明：**
- `array`: `Byte[]` — a ` Byte` array, may be ` null`
- `valueForNull`: `byte` — the value to insert if ` null` found

**返回值：**
- `byte[]`: a ` byte` array, ` null` if null array input

---

**重载 11**

Converts an array of object Doubles to primitives.

**方法签名：**
```java
public static double[] toPrimitive(Double[] array)
```

**参数说明：**
- `array`: `Double[]` — a ` Double` array, may be ` null`

**返回值：**
- `double[]`: a ` double` array, ` null` if null array input

---

**重载 12**

Converts an array of object Doubles to primitives handling ` null`.

**方法签名：**
```java
public static double[] toPrimitive(Double[] array, double valueForNull)
```

**参数说明：**
- `array`: `Double[]` — a ` Double` array, may be ` null`
- `valueForNull`: `double` — the value to insert if ` null` found

**返回值：**
- `double[]`: a ` double` array, ` null` if null array input

---

**重载 13**

Converts an array of object Floats to primitives.

**方法签名：**
```java
public static float[] toPrimitive(Float[] array)
```

**参数说明：**
- `array`: `Float[]` — a ` Float` array, may be ` null`

**返回值：**
- `float[]`: a ` float` array, ` null` if null array input

---

**重载 14**

Converts an array of object Floats to primitives handling ` null`.

**方法签名：**
```java
public static float[] toPrimitive(Float[] array, float valueForNull)
```

**参数说明：**
- `array`: `Float[]` — a ` Float` array, may be ` null`
- `valueForNull`: `float` — the value to insert if ` null` found

**返回值：**
- `float[]`: a ` float` array, ` null` if null array input

---

**重载 15**

Converts an array of object Booleans to primitives.

**方法签名：**
```java
public static boolean[] toPrimitive(Boolean[] array)
```

**参数说明：**
- `array`: `Boolean[]` — a ` Boolean` array, may be ` null`

**返回值：**
- `boolean[]`: a ` boolean` array, ` null` if null array input

---

**重载 16**

Converts an array of object Booleans to primitives handling ` null`.

**方法签名：**
```java
public static boolean[] toPrimitive(Boolean[] array, boolean valueForNull)
```

**参数说明：**
- `array`: `Boolean[]` — a ` Boolean` array, may be ` null`
- `valueForNull`: `boolean` — the value to insert if ` null` found

**返回值：**
- `boolean[]`: a ` boolean` array, ` null` if null array input

---
