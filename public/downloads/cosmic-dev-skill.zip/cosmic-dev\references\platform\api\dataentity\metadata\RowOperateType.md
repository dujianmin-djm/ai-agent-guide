---
framework_version: "8.0.1"
api_class: "RowOperateType"
api_package: "kd.bos.dataentity.metadata"
when_to_use: "当你需要使用行操作类型时"
---

# RowOperateType API 说明

## 概述
行操作类型。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.RowOperateType;
```

---

## 方法列表

### forValue

转换为行操作类型

**方法签名：**
```java
public static RowOperateType forValue(int value)
```

**参数说明：**
- `value`: `int` — 类型枚举值

**返回值：**
- `RowOperateType`

---

### getValue

获取行操作类型枚举值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
