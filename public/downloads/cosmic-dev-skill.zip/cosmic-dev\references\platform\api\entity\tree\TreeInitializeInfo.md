---
framework_version: "8.0.1"
api_class: "TreeInitializeInfo"
api_package: "kd.bos.entity.tree"
when_to_use: "当你需要使用树节点初始化事件, 用于树形列表初始化时时"
---

# TreeInitializeInfo API 说明

## 概述
树节点初始化事件, 用于树形列表初始化时，设置懒加载、展示类型等参数。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.tree.TreeInitializeInfo;
```

---

## 方法列表

### getShowType

获取树形展示类型

**方法签名：**
```java
public TreeInitializeInfo.ShowType getShowType()
```

**返回值：**
- `TreeInitializeInfo.ShowType`

---

### setShowType

设置树形展示类型

**方法签名：**
```java
public void setShowType(TreeInitializeInfo.ShowType showType)
```

**参数说明：**
- `showType`: `TreeInitializeInfo.ShowType`

---
