---
framework_version: "8.0.1"
api_class: "CreateListOperationColumnEvent"
api_package: "kd.bos.entity.list.events"
when_to_use: "当你需要使用列表操作列事件参数时"
---

# CreateListOperationColumnEvent API 说明

## 概述
列表操作列事件参数。继承自 EventObject，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.events.CreateListOperationColumnEvent;
```

---

## 方法列表

### getColumnDesc

获取操作列格式化工具类

**方法签名：**
```java
public AbstractColumnDesc getColumnDesc()
```

**返回值：**
- `AbstractColumnDesc`: 操作列格式化工具类

---

### getColumns

获取字段格式化列表

**方法签名：**
```java
public List<kd.AbstractColumnDesc> getColumns()
```

**返回值：**
- `List<kd.AbstractColumnDesc>`: 字段格式化列表

---

### setColumnDesc

设置操作列格式化工具类

**方法签名：**
```java
public void setColumnDesc(AbstractColumnDesc columnDesc)
```

**参数说明：**
- `columnDesc`: `AbstractColumnDesc` — 操作列格式化工具类

---
