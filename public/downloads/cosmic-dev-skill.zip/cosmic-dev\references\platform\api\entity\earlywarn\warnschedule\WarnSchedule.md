---
framework_version: "8.0.1"
api_class: "WarnSchedule"
api_package: "kd.bos.entity.earlywarn.warnschedule"
when_to_use: "当你需要使用预警监控方案运行时时"
---

# WarnSchedule API 说明

## 概述
预警监控方案运行时。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.earlywarn.warnschedule.WarnSchedule;
```

---

## 方法列表

### getBizAppId

应用id

**方法签名：**
```java
public String getBizAppId()
```

**返回值：**
- `String`

---

### getEarlyWarnId

业务预警对象id

**方法签名：**
```java
public String getEarlyWarnId()
```

**返回值：**
- `String`

---

### getId

唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getJobId

调度中心id

**方法签名：**
```java
public String getJobId()
```

**返回值：**
- `String`

---

### getLastSyncTime

上次同步任务调度中心时间

**方法签名：**
```java
public Date getLastSyncTime()
```

**返回值：**
- `Date`

---

### getMessageConfig

监控消息配置

**方法签名：**
```java
public WarnMessageConfig getMessageConfig()
```

**返回值：**
- `WarnMessageConfig`: WarnMessageConfig 参数详细信息 kd.bos.entity.earlywarn.warnschedule.WarnMessageConfig

---

### getName

名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getNumber

编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### getPlanId

调度计划Id

**方法签名：**
```java
public String getPlanId()
```

**返回值：**
- `String`

---

### getRunCycle

监控周期

**方法签名：**
```java
public RunCycle getRunCycle()
```

**返回值：**
- `RunCycle`: RunCycle 参数详细信息 kd.bos.entity.earlywarn.warnschedule.RunCycle

---

### getWarnCondition

监控条件

**方法签名：**
```java
public WarnCondition getWarnCondition()
```

**返回值：**
- `WarnCondition`: WarnCondition 参数详细信息 kd.bos.entity.earlywarn.warnschedule.WarnCondition

---

### isByEntry

按条件发送分录

**方法签名：**
```java
public boolean isByEntry()
```

**返回值：**
- `boolean`

---

### isDisableIntegrity

禁止校验数据完整性

**方法签名：**
```java
public boolean isDisableIntegrity()
```

**返回值：**
- `boolean`

---

### isEnable

是否启用

**方法签名：**
```java
public boolean isEnable()
```

**返回值：**
- `boolean`

---

### setBizAppId

设置应用id

**方法签名：**
```java
public void setBizAppId(String bizAppId)
```

**参数说明：**
- `bizAppId`: `String`

---

### setByEntry

是否按条件发送分录

**方法签名：**
```java
public void setByEntry(boolean byEntry)
```

**参数说明：**
- `byEntry`: `boolean`

---

### setDisableIntegrity

是否禁止校验数据完整性

**方法签名：**
```java
public void setDisableIntegrity(boolean disableIntegrity)
```

**参数说明：**
- `disableIntegrity`: `boolean`

---

### setEarlyWarnId

设置业务预警对象id

**方法签名：**
```java
public void setEarlyWarnId(String earlyWarnId)
```

**参数说明：**
- `earlyWarnId`: `String`

---

### setEnable

是否启用

**方法签名：**
```java
public void setEnable(boolean enable)
```

**参数说明：**
- `enable`: `boolean`

---

### setId

设置唯一标识

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setJobId

设置调度中心id

**方法签名：**
```java
public void setJobId(String jobId)
```

**参数说明：**
- `jobId`: `String`

---

### setLastSyncTime

设置上次同步任务调度中心时间

**方法签名：**
```java
public void setLastSyncTime(Date lastSyncTime)
```

**参数说明：**
- `lastSyncTime`: `Date`

---

### setMessageConfig

设置监控消息配置

**方法签名：**
```java
public void setMessageConfig(WarnMessageConfig messageConfig)
```

**参数说明：**
- `messageConfig`: `WarnMessageConfig`

---

### setName

设置名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setNumber

设置编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---

### setPlanId

设置调度计划Id

**方法签名：**
```java
public void setPlanId(String planId)
```

**参数说明：**
- `planId`: `String`

---

### setRunCycle

设置监控周期

**方法签名：**
```java
public void setRunCycle(RunCycle runCycle)
```

**参数说明：**
- `runCycle`: `RunCycle`

---

### setWarnCondition

设置监控条件

**方法签名：**
```java
public void setWarnCondition(WarnCondition warnCondition)
```

**参数说明：**
- `warnCondition`: `WarnCondition`

---
