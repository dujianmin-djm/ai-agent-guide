---
framework_version: "8.0.1"
api_class: "Plugin"
api_package: "kd.bos.entity.plugin"
when_to_use: "当你需要使用操作运行时元数据类时"
---

# Plugin API 说明

## 概述
操作运行时元数据类。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.plugin.Plugin;
```

---

## 方法列表

### enableKingScript

**重载 1**

星空旗舰试用版，先加参数发布，星空那边开启

**方法签名：**
```java
public static boolean enableKingScript()
```

**返回值：**
- `boolean`

---

**重载 2**

启用ks

**方法签名：**
```java
public static boolean enableKingScript(String modelType)
```

**参数说明：**
- `modelType`: `String`

**返回值：**
- `boolean`

---

### enableRegisterKingScript

**重载 1**

KingScript 脚本是否支持注册

**方法签名：**
```java
public static boolean enableRegisterKingScript()
```

**返回值：**
- `boolean`

---

**重载 2**

KingScript 脚本是否支持注册 (不确定调用场景, 需通过模型类型判定是否支持 KingScript 脚本)

**方法签名：**
```java
public static boolean enableRegisterKingScript(String modelType)
```

**参数说明：**
- `modelType`: `String` — 模型类型

**返回值：**
- `boolean`

---

### enableRunKingScript

KingScript 脚本是否支持运行

**方法签名：**
```java
public static boolean enableRunKingScript()
```

**返回值：**
- `boolean`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### getClassName

{待补充}

**方法签名：**
```java
public String getClassName()
```

**返回值：**
- `String`: the className 插件对应的实例类

---

### getDescription

插件描述说明

**方法签名：**
```java
public String getDescription()
```

**返回值：**
- `String`

---

### getEvents

插件事件列表

**方法签名：**
```java
public List<kd.Event> getEvents()
```

**返回值：**
- `List<kd.Event>`: 返回插件事件列表

---

### getFpk

插件fpk

**方法签名：**
```java
public String getFpk()
```

**返回值：**
- `String`

---

### getRowKey

插件行号

**方法签名：**
```java
public int getRowKey()
```

**返回值：**
- `int`

---

### getScriptNumber

脚本编码

**方法签名：**
```java
public String getScriptNumber()
```

**返回值：**
- `String`

---

### getSourceNumber

记录插件的表单编码：涉及到记录扩展单，源单的编码

**方法签名：**
```java
public String getSourceNumber()
```

**返回值：**
- `String`

---

### getType

{待补充}

**方法签名：**
```java
public int getType()
```

**返回值：**
- `int`: 插件类型

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isDynamicPlugin

动态插件

**方法签名：**
```java
public boolean isDynamicPlugin()
```

**返回值：**
- `boolean`

---

### isEnabled

启用

**方法签名：**
```java
public boolean isEnabled()
```

**返回值：**
- `boolean`

---

### isInherit

是否本单插件

**方法签名：**
```java
public boolean isInherit()
```

**返回值：**
- `boolean`

---

### setClassName

{待补充}

**方法签名：**
```java
public void setClassName(String className)
```

**参数说明：**
- `className`: `String`

---

### setDescription

插件描述说明

**方法签名：**
```java
public void setDescription(String description)
```

**参数说明：**
- `description`: `String`

---

### setDynamicPlugin

动态插件

**方法签名：**
```java
public void setDynamicPlugin(boolean dynamicPlugin)
```

**参数说明：**
- `dynamicPlugin`: `boolean`

---

### setEnabled

启用

**方法签名：**
```java
public void setEnabled(boolean enabled)
```

**参数说明：**
- `enabled`: `boolean`

---

### setEvents

插件事件列表

**方法签名：**
```java
public void setEvents(List<kd.Event> events)
```

**参数说明：**
- `events`: `List<kd.Event>`

---

### setFpk

插件fpk

**方法签名：**
```java
public void setFpk(String fpk)
```

**参数说明：**
- `fpk`: `String`

---

### setInherit

是否本单插件

**方法签名：**
```java
public void setInherit(boolean inherit)
```

**参数说明：**
- `inherit`: `boolean`

---

### setRowKey

插件行号

**方法签名：**
```java
public void setRowKey(int rowKey)
```

**参数说明：**
- `rowKey`: `int`

---

### setScriptNumber

脚本编码

**方法签名：**
```java
public void setScriptNumber(String scriptNumber)
```

**参数说明：**
- `scriptNumber`: `String`

---

### setSourceNumber

插件表单编码

**方法签名：**
```java
public void setSourceNumber(String sourceNumber)
```

**参数说明：**
- `sourceNumber`: `String`

---

### setType

{待补充}

**方法签名：**
```java
public void setType(int type)
```

**参数说明：**
- `type`: `int` — 插件类型

---
