---
framework_version: "8.0.1"
api_class: "DynamicMetadata"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用动态实体架构的基础元数据对象时"
---

# DynamicMetadata API 说明

## 概述
动态实体架构的基础元数据对象。实现 IMetadata, Serializable, Cloneable。
主要功能：状态判断、读取属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicMetadata;
```

---

## 方法列表

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### equals

判断元数据实例是否和另外的实例相等

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`: 派生类不需要重载本方法，应重载isEquals比较名称等属性是否相等

---

### getName

返回此元数据对象的名称

**方法签名：**
```java
public abstract String getName()
```

**返回值：**
- `String`

---

### hashCode

输出属性对象的hashCode

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isDbIgnore

{待补充}

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---
