---
framework_version: "8.0.1"
api_class: "BatchDownloadRequest.File"
api_package: "kd.bos.fileservice.BatchDownloadRequest"
when_to_use: "当你需要使用定义压缩包内单个文件时"
---

# BatchDownloadRequest.File API 说明

## 概述
定义压缩包内单个文件。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.fileservice.BatchDownloadRequest.BatchDownloadRequest.File;
```

---

## 方法列表

### getName

getter方法，文件在压缩包内的显示名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getUrl

getter方法，下载文件的 URL

**方法签名：**
```java
public String getUrl()
```

**返回值：**
- `String`

---

### setUrl

setter方法，设置下载文件的 URL

**方法签名：**
```java
public void setUrl(String url)
```

**参数说明：**
- `url`: `String`

---
