---
framework_version: "8.0.1"
api_class: "BaseDataUseRelQueryEngine"
api_package: "kd.bos.bd.engine"
when_to_use: "当你需要使用查询服务时"
---

# BaseDataUseRelQueryEngine API 说明

## 概述
查询服务，负责位图数据的查询（从数据库、缓存）。继承自 AbstractBaseDataUseRelEngine。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.bd.engine.BaseDataUseRelQueryEngine;
```

---

## 方法列表

### getAllRelBitMapByEntity

获取所有组织关系位图数据（先从缓存中取）

**方法签名：**
```java
public static Map<Long,BaseDataUseRelBit> getAllRelBitMapByEntity(String entity)
```

**参数说明：**
- `entity`: `String` — 基础资料实体

**返回值：**
- `Map<Long,BaseDataUseRelBit>`: map 组织 / 组织基础资料使用关系位图

---

### getAllUseBitByOrgIds

获取所有组织的所有位图数据

**方法签名：**
```java
public static Set<Integer> getAllUseBitByOrgIds(Collection<Long> orgIds, String entity)
```

**参数说明：**
- `orgIds`: `Collection<Long>` — 组织
- `entity`: `String` — 实体

**返回值：**
- `Set<Integer>`: 位图集合

---

### getCURelBitMapByEntity

获取CU组织关系位图数据（先从缓存取）

**方法签名：**
```java
public static Map<Long,BaseDataUseRelBit> getCURelBitMapByEntity(String entity)
```

**参数说明：**
- `entity`: `String` — 基础资料实体

**返回值：**
- `Map<Long,BaseDataUseRelBit>`: map 组织 / 组织基础资料使用关系位图

---

### getOrgUseRelBitMapByOrgIds

批量查询组织位图信息

**方法签名：**
```java
public static Map<Long,RoaringBitmap> getOrgUseRelBitMapByOrgIds(Collection<Long> orgIds, String entity)
```

**参数说明：**
- `orgIds`: `Collection<Long>` — 组织id集合
- `entity`: `String` — entity

**返回值：**
- `Map<Long,RoaringBitmap>`: 组织 -> 数据位图信息

---

### getRelBitMapByOrgIds

**重载 1**

批量查询组织位图信息

**方法签名：**
```java
public static Map<Long,BaseDataUseRelBit> getRelBitMapByOrgIds(Collection<Long> orgIds, String entity)
```

**参数说明：**
- `orgIds`: `Collection<Long>` — 组织id集合
- `entity`: `String` — entity

**返回值：**
- `Map<Long,BaseDataUseRelBit>`: 组织 -> 数据位图信息

---

**重载 2**

批量查询组织位图信息

**方法签名：**
```java
public static Map<Long,BaseDataUseRelBit> getRelBitMapByOrgIds(Collection<Long> orgIds, String entity, String tableName, DBRoute route)
```

**参数说明：**
- `orgIds`: `Collection<Long>` — 组织id集合
- `entity`: `String` — 基础资料单据实体
- `tableName`: `String` — 位图数据表名
- `route`: `DBRoute` — 数据库路由

**返回值：**
- `Map<Long,BaseDataUseRelBit>`: 组织 -> 数据位图信息

---

### getUseBaseDataIndexArrByOrgId

**重载 1**

获取特定组织在特定类型的基础资料下所能查询到的基础资料

**方法签名：**
```java
public static int[] getUseBaseDataIndexArrByOrgId(Long orgId, String entityId)
```

**参数说明：**
- `orgId`: `Long` — 组织id
- `entityId`: `String` — 实体

**返回值：**
- `int[]`: 基础资料fbitindex集合

---

**重载 2**

获取特定组织在特定类型的基础资料下所能查询到的基础资料

**方法签名：**
```java
public static int[] getUseBaseDataIndexArrByOrgId(List<Long> orgIds, String entityId)
```

**参数说明：**
- `orgIds`: `List<Long>` — 组织id
- `entityId`: `String` — 实体

**返回值：**
- `int[]`: 基础资料fbitindex集合

---

### getUseBaseDataIndexByOrgId

获取特定组织在特定类型的基础资料下所能查询到的基础资料

**方法签名：**
```java
public static List<Integer> getUseBaseDataIndexByOrgId(Long orgId, String entityId)
```

**参数说明：**
- `orgId`: `Long` — 组织id
- `entityId`: `String` — 实体

**返回值：**
- `List<Integer>`: 基础资料fbitindex集合

---
