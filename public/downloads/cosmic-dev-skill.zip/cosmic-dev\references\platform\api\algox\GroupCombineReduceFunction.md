---
framework_version: "8.0.1"
api_class: "GroupCombineReduceFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用combine及reduce操作回调函数时"
---

# GroupCombineReduceFunction API 说明

## 概述
combine及reduce操作回调函数。继承自 Function，实现 ResultAwarable, ResultConvertable, Serializable。
主要功能：combine、reduce。

## Import 路径
```java
import kd.bos.algox.GroupCombineReduceFunction;
```

---

## 方法列表

### combine

combine

**方法签名：**
```java
public abstract void combine(Iterable<kd.RowX> iter, Collector collector)
```

**参数说明：**
- `iter`: `Iterable<kd.RowX>` — 分组后的数据集
- `collector`: `Collector` — collector

---

### reduce

reduce

**方法签名：**
```java
public abstract void reduce(Iterable<kd.RowX> iter, Collector collector)
```

**参数说明：**
- `iter`: `Iterable<kd.RowX>` — combine后的数据集
- `collector`: `Collector` — collector

---
