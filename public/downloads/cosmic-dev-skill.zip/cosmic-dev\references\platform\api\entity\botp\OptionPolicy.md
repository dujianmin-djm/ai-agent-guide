---
framework_version: "8.0.1"
api_class: "OptionPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用单据转换选项控制策略：包含各种可选参数时"
---

# OptionPolicy API 说明

## 概述
单据转换选项控制策略：包含各种可选参数。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.OptionPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getMergeIntoLinkRow

其他单据体也下推到关联主单据体时，直接合并到关联主单据体行中，不生成新行

**方法签名：**
```java
public String getMergeIntoLinkRow()
```

**返回值：**
- `String`

---

### getMulComboBaseEnableStr

开启校验基础资料可用性后, 需选择下游单可用性校验的具体基础资料, 通过下拉框选择多项, 以逗号隔开标识

**方法签名：**
```java
public String getMulComboBaseEnableStr()
```

**返回值：**
- `String`

---

### getMulComboBaseEnables

开启校验基础资料可用性后, 选择的下游单可用性校验的具体基础资料集合

**方法签名：**
```java
public List<String> getMulComboBaseEnables()
```

**返回值：**
- `List<String>`

---

### getOnlyReadBillTable

是否把单据、基础资料分为多次读取

**方法签名：**
```java
public String getOnlyReadBillTable()
```

**返回值：**
- `String`

---

### getReportEndTime

生成结束时间

**方法签名：**
```java
public Date getReportEndTime()
```

**返回值：**
- `Date`

---

### getReportStartTime

生成报告开始时间

**方法签名：**
```java
public Date getReportStartTime()
```

**返回值：**
- `Date`

---

### isCheckBaseEnable

是否校验基础资料可用性, 默认不校验, 可允许已禁用的基础资料继续下推
 (暂时仅控制通过 masterid 检索 id 的方式时, 启用禁用状态的甄别. 直接携带 id 的方式不进行控制)

**方法签名：**
```java
public boolean isCheckBaseEnable()
```

**返回值：**
- `boolean`

---

### isConvertSnapshot

单据转换快照

**方法签名：**
```java
public boolean isConvertSnapshot()
```

**返回值：**
- `boolean`

---

### isCreateReport

是否生成报告

**方法签名：**
```java
public boolean isCreateReport()
```

**返回值：**
- `boolean`

---

### isPushMutex

下推时是否启动网络控制，不允许对源单做其他操作。默认不启动网控，以免影响用户操作

**方法签名：**
```java
public boolean isPushMutex()
```

**返回值：**
- `boolean`

---

### isPushOneTime

是否只允许下推一次：已经下推并保存了下游单据后，不允许再次下推到这种单据（可下推到其他单据）

**方法签名：**
```java
public boolean isPushOneTime()
```

**返回值：**
- `boolean`

---

### isWithoutTrim

条件及表达式是否保留首尾空格

**方法签名：**
```java
public boolean isWithoutTrim()
```

**返回值：**
- `boolean`

---

### setCheckBaseEnable

是否校验基础资料可用性

**方法签名：**
```java
public void setCheckBaseEnable(boolean checkBaseEnable)
```

**参数说明：**
- `checkBaseEnable`: `boolean`

---

### setMulComboBaseEnableStr

开启校验基础资料可用性后

**方法签名：**
```java
public void setMulComboBaseEnableStr(String mulComboBaseEnableStr)
```

**参数说明：**
- `mulComboBaseEnableStr`: `String`

---

### setOnlyReadBillTable

是否把单据、基础资料分为多次读取

**方法签名：**
```java
public void setOnlyReadBillTable(String onlyReadBillTable)
```

**参数说明：**
- `onlyReadBillTable`: `String`

---

### setPushMutex

下推时是否启动网络控制

**方法签名：**
```java
public void setPushMutex(boolean pushMutex)
```

**参数说明：**
- `pushMutex`: `boolean`

---

### setPushOneTime

是否只允许下推一次

**方法签名：**
```java
public void setPushOneTime(boolean pushOneTime)
```

**参数说明：**
- `pushOneTime`: `boolean`

---
