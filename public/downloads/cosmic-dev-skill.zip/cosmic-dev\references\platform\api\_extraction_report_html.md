# API 提取报告（Javadoc HTML）

**时间**: 2026-03-07
**源码路径**: F:\ai-coding\Cosmic V8.0.1\Cosmic V8.0.1\javadoc
**框架版本**: 8.0.1
**目标包**: kd.bos

## 统计

| 指标 | 数值 |
|------|------|
| 扫描 HTML 文件 | 1902 个 |
| 含 @SdkPublic 的类 | 1467 个 |
| 无 @SdkPublic 但有 public 方法 | 53 个 |
| 总计提取 | 1520 个文档 |
| 提取方法总数 | 14720 个（含注释 12276 个） |
| 注释覆盖率 | 83.4% |
| 跳过（无可提取方法） | 435 个 |

## 数据质量对比（HTML vs 反编译源码）

| 维度 | Javadoc HTML | 反编译源码 |
|------|-------------|-----------|
| 方法注释 | 83.4% 有中文注释 | 几乎无注释 |
| 参数名 | 真实参数名（如 entityName） | 混淆名（如 arg0） |
| @param 标签 | 大量保留 | 无 |
| @return 标签 | 大量保留 | 无 |
| 类注释 | 中文类说明 | 无 |
| 继承关系 | 完整 | 完整 |
| 方法体 | 无（仅签名） | 有完整实现 |

## 按包分布

| 包路径 | 类数 | 方法数 |
|-------|------|--------|
| kd.bos.entity.* | 325 | 3288 |
| kd.bos.form.* | 221 | 1652 |
| kd.bos.metadata.* | 195 | 1725 |
| kd.bos.workflow.* | 98 | 1714 |
| kd.bos.list.* | 78 | 898 |
| kd.bos.dataentity.* | 75 | 790 |
| kd.bos.servicehelper.* | 67 | 1043 |
| kd.bos.print.* | 61 | 469 |
| kd.bos.algo.* | 57 | 241 |
| kd.bos.formula.* | 34 | 165 |
| kd.bos.filter.* | 29 | 293 |
| kd.bos.permission.* | 29 | 286 |
| kd.bos.report.* | 26 | 277 |
| kd.bos.schedule.* | 23 | 344 |
| kd.bos.kdtx.* | 22 | 101 |
| kd.bos.openapi.* | 21 | 109 |
| kd.bos.algox.* | 17 | 74 |
| 其他（38 个包） | 182 | 1210 |
| **合计** | **1520** | **14670** |
