---
framework_version: "8.0.1"
api_class: "NumberFormatProvider"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用数值日期格式化工具时"
---

# NumberFormatProvider API 说明

## 概述
数值日期格式化工具。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.NumberFormatProvider;
```

---

## 方法列表

### getColfmt

获取列格式

**方法签名：**
```java
public Map<String,Map<String,Object>> getColfmt()
```

**返回值：**
- `Map<String,Map<String,Object>>`

---

### getCurrencyfmt

获取货币格式

**方法签名：**
```java
public Map<String,Object> getCurrencyfmt()
```

**返回值：**
- `Map<String,Object>`

---

### getDecimalFieldMap

获取所有小数字段集合

**方法签名：**
```java
public Map<String,Map<String,Object>> getDecimalFieldMap()
```

**返回值：**
- `Map<String,Map<String,Object>>`

---

### getFieldControlPropMap

获取所有的字段与控制字段对应关系

**方法签名：**
```java
public Map<String,String> getFieldControlPropMap()
```

**返回值：**
- `Map<String,String>`

---

### getFieldFmtInfo

获取字段的格式化信息

**方法签名：**
```java
public Map<String,Map<String,Map<String,Object>>> getFieldFmtInfo()
```

**返回值：**
- `Map<String,Map<String,Map<String,Object>>>`

---

### getFmtFields

获取需要进行格式化的字段

**方法签名：**
```java
public List<kd.FmtField> getFmtFields()
```

**返回值：**
- `List<kd.FmtField>`

---

### getFormatPrecision

**重载 1**

获取格式化精度

**方法签名：**
```java
public NumberPrecision getFormatPrecision(String scaleFieldKey, DynamicObject rowData)
```

**参数说明：**
- `scaleFieldKey`: `String` — 货币编码或计量单位编码
- `rowData`: `DynamicObject` — 需要格式化的数据包

**返回值：**
- `NumberPrecision`

---

**重载 2**

获取格式化精度

**方法签名：**
```java
public NumberPrecision getFormatPrecision(String scaleFieldName, DynamicObject rowData, DynamicObject fmtRowData)
```

**参数说明：**
- `scaleFieldName`: `String`
- `rowData`: `DynamicObject` — 数据字段所在行
- `fmtRowData`: `DynamicObject` — 币别/计量单位等控制字段所在行

**返回值：**
- `NumberPrecision`

---

### getRowAllFmtInfo

获取所有行的格式化信息
 rowIdex -> (currencyfmt -> fmt)
 rowIdex -> (unitfmt -> fmt)

**方法签名：**
```java
public Map<Integer,Map<String,Map<String,Object>>> getRowAllFmtInfo()
```

**返回值：**
- `Map<Integer,Map<String,Map<String,Object>>>`

---

### getRowFmtInfo

获取行格式信息

**方法签名：**
```java
public Map<Integer,Map<String,Object>> getRowFmtInfo()
```

**返回值：**
- `Map<Integer,Map<String,Object>>`

---

### getTimeZoneFmt

获取时区格式

**方法签名：**
```java
public Map<String,Object> getTimeZoneFmt()
```

**返回值：**
- `Map<String,Object>`

---

### getUnitfmt

获取单位格式

**方法签名：**
```java
public Map<String,Object> getUnitfmt()
```

**返回值：**
- `Map<String,Object>`

---

### setFmtFields

设置需要进行格式化的字段

**方法签名：**
```java
public void setFmtFields(List<kd.FmtField> fmtFields)
```

**参数说明：**
- `fmtFields`: `List<kd.FmtField>`

---
