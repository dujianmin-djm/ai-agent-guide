---
framework_version: "8.0.1"
api_class: "AbstractValidator"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用操作校验器基类时"
---

# AbstractValidator API 说明

## 概述
操作校验器基类。
主要功能：读取属性、设置属性、状态判断、添加元素。

## Import 路径
```java
import kd.bos.entity.validate.AbstractValidator;
```

---

## 方法列表

### addMessage2

添加指定错误级别的提示

**方法签名：**
```java
public void addMessage2(ExtendedDataEntity dataEntity, String content, ErrorLevel errorLevel, List<kd.MsgReplaceHolder> msgReplaceHolders)
```

**参数说明：**
- `dataEntity`: `ExtendedDataEntity` — 数据实体
- `content`: `String` — 报错的提示信息
- `errorLevel`: `ErrorLevel` — 错误级别
- `msgReplaceHolders`: `List<kd.MsgReplaceHolder>`

---

### getDataEntities

获取操作拉平的数据集

**方法签名：**
```java
public ExtendedDataEntity[] getDataEntities()
```

**返回值：**
- `ExtendedDataEntity[]`: 操作拉平的数据集

---

### getEntityKey

获取本校验器，需要校验的实体：由本校验器对外输出

**方法签名：**
```java
public String getEntityKey()
```

**返回值：**
- `String`: String

---

### getErrorLevl

获取本校验器输出的错误级别

**方法签名：**
```java
public ErrorLevel getErrorLevl()
```

**返回值：**
- `ErrorLevel`

---

### getExtendedDataEntitySet

获取待校验的全部单据

**方法签名：**
```java
public ExtendedDataEntitySet getExtendedDataEntitySet()
```

**返回值：**
- `ExtendedDataEntitySet`

---

### getFalseDataEntities

获取校验不通过的数据集

**方法签名：**
```java
public List<kd.ExtendedDataEntity> getFalseDataEntities()
```

**返回值：**
- `List<kd.ExtendedDataEntity>`: 校验不通过的数据集

---

### getOperateKey

获取操作标识

**方法签名：**
```java
public String getOperateKey()
```

**返回值：**
- `String`: 操作标识

---

### getOperateType

获取操作类型

**方法签名：**
```java
public String getOperateType()
```

**返回值：**
- `String`: 操作类型

---

### getOperationName

获取操作名称

**方法签名：**
```java
public String getOperationName()
```

**返回值：**
- `String`: String

---

### getOption

获取操作自定义参数对象

**方法签名：**
```java
public OperateOption getOption()
```

**返回值：**
- `OperateOption`: 操作选项

---

### getPreCondition

获取校验器的前置条件

**方法签名：**
```java
public String getPreCondition()
```

**返回值：**
- `String`: 前置条件

---

### getPreConditionExpr

编译后的前置条件

**方法签名：**
```java
public BOSExpression getPreConditionExpr()
```

**返回值：**
- `BOSExpression`: 前置条件表达式

---

### getSeq

获取执行顺序

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`: 顺序

---

### getValidateContext

获取本次校验上下文信息

**方法签名：**
```java
public ValidateContext getValidateContext()
```

**返回值：**
- `ValidateContext`: 校验上下文

---

### getValidatePriority

获取执行优先级

**方法签名：**
```java
public ValidatePriority getValidatePriority()
```

**返回值：**
- `ValidatePriority`: 获取优先级

---

### getValidateResult

获取校验结果

**方法签名：**
```java
public ValidateResult getValidateResult()
```

**返回值：**
- `ValidateResult`: 校验结果

---

### getValidation

获取校验器原始配置

**方法签名：**
```java
public Map<String,Object> getValidation()
```

**返回值：**
- `Map<String,Object>`: 校验元数据上配置的信息

---

### getValidatorId

校验器实例id （随机生成，在当前操作中区分不同实例）

**方法签名：**
```java
public String getValidatorId()
```

**返回值：**
- `String`

---

### initialize

在校验前，校验系统调用此方法，以便初始化校验器的配置信息

**方法签名：**
```java
public void initialize()
```

---

### initializeConfiguration

在校验前，校验系统调用此方法，以便初始化校验器的配置信息

**方法签名：**
```java
public void initializeConfiguration()
```

---

### isAddBillNoForContent

提示消息前是否加上billNo

**方法签名：**
```java
public boolean isAddBillNoForContent()
```

**返回值：**
- `boolean`: boolean

---

### isSupportSplitPageMode

是否支持单据体分页加载模式

**方法签名：**
```java
public boolean isSupportSplitPageMode()
```

**返回值：**
- `boolean`: 如果已对单据体分页加载进行了针对性的处理，重写此方法，返回true；
 如果返回false，则操作引擎在遇到大单分页时，自动略过本校验器

---

### preparePropertys

输出校验器需要用到的字段

**方法签名：**
```java
public Set<String> preparePropertys()
```

**返回值：**
- `Set<String>`: Set

---

### setAddBillNoForContent

设置提示消息前是否加上billNo

**方法签名：**
```java
public void setAddBillNoForContent(boolean addBillNoForContent)
```

**参数说明：**
- `addBillNoForContent`: `boolean` — 添加单据编码

---

### setDataEntities

设置操作拉平的数据集

**方法签名：**
```java
public void setDataEntities(ExtendedDataEntity[] dataEntities)
```

**参数说明：**
- `dataEntities`: `ExtendedDataEntity[]` — 操作拉平的数据集

---

### setEntityKey

设置本校验器，需要校验的实体：由本校验器对外输出

**方法签名：**
```java
public void setEntityKey(String entityKey)
```

**参数说明：**
- `entityKey`: `String` — 实体标识

---

### setErrorLevel

设置本校验器输出的错误级别

**方法签名：**
```java
public void setErrorLevel(ErrorLevel errorLevel)
```

**参数说明：**
- `errorLevel`: `ErrorLevel` — 错误

---

### setExtendedDataEntitySet

设置待校验的全部单据

**方法签名：**
```java
public void setExtendedDataEntitySet(ExtendedDataEntitySet extendedDataEntitySet)
```

**参数说明：**
- `extendedDataEntitySet`: `ExtendedDataEntitySet`

---

### setOperateKey

设置操作标识

**方法签名：**
```java
public void setOperateKey(String operateKey)
```

**参数说明：**
- `operateKey`: `String` — 操作标识

---

### setOperateType

设置操作类型

**方法签名：**
```java
public void setOperateType(String operateType)
```

**参数说明：**
- `operateType`: `String` — 操作类型

---

### setOperationName

设置操作名称

**方法签名：**
```java
public void setOperationName(String operationName)
```

**参数说明：**
- `operationName`: `String` — 操作名

---

### setSeq

设置执行顺序

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int` — 顺序

---

### setValidateContext

设置操作上下文

**方法签名：**
```java
public void setValidateContext(ValidateContext validateContext)
```

**参数说明：**
- `validateContext`: `ValidateContext` — 校验上下文

---

### setValidatePriority

设置执行优先级

**方法签名：**
```java
public void setValidatePriority(ValidatePriority validatePriority)
```

**参数说明：**
- `validatePriority`: `ValidatePriority` — 优先级

---

### setValidation

设置校验器原始配置

**方法签名：**
```java
public void setValidation(Map<String,Object> validation)
```

**参数说明：**
- `validation`: `Map<String,Object>` — 校验

---

### validate

校验逻辑，由具体的校验器子类自己去实现，例如必录校验，唯一性校验

**方法签名：**
```java
public abstract void validate()
```

---
