---
framework_version: "8.0.1"
api_class: "AfterGetSourceDataEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用取源单数据后事件：根据源单数据时"
---

# AfterGetSourceDataEventArgs API 说明

## 概述
取源单数据后事件：根据源单数据，获取其他定制的引用数据；也可以替换系统自动获取到的数据。继承自 ConvertPluginEventArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterGetSourceDataEventArgs;
```

---

## 方法列表

### getFldProperties

源单字段，与数据包属性对应字典，可以据此到源单数据包中读取字段值

**方法签名：**
```java
public Map<String,DynamicProperty> getFldProperties()
```

**返回值：**
- `Map<String,DynamicProperty>`

---

### getSourceRows

待下推的源单数据行

**方法签名：**
```java
public List<DynamicObject> getSourceRows()
```

**返回值：**
- `List<DynamicObject>`

---
