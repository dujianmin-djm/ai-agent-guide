---
framework_version: "8.0.1"
api_class: "AfterCalcWriteValueEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用计算反写值之后事件时"
---

# AfterCalcWriteValueEventArgs API 说明

## 概述
计算反写值之后事件。继承自 WriteBackEventArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterCalcWriteValueEventArgs;
```

---

## 方法列表

### getActiveRow

关联主实体当前行

**方法签名：**
```java
public DynamicObject getActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getCVal

覆盖反写模式，根据反写公式算出的覆盖值

**方法签名：**
```java
public Object getCVal()
```

**返回值：**
- `Object`

---

### getEntity

关联主实体

**方法签名：**
```java
public EntityType getEntity()
```

**返回值：**
- `EntityType`

---

### getRule

反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getRuleItem

反写公式

**方法签名：**
```java
public WriteBackFormula getRuleItem()
```

**返回值：**
- `WriteBackFormula`

---

### getSrcRowVal

搜索出的源单行，以及其分配的反写量：
 如果有多个源单行，默认每行的反写量为0；需要插件自行给各源单行分配反写量；
 如果插件不处理，则不反写

**方法签名：**
```java
public Map<kd.BFRowId,BigDecimal> getSrcRowVal()
```

**返回值：**
- `Map<kd.BFRowId,BigDecimal>`

---

### getVal

根据反写公式，算出的反写量

**方法签名：**
```java
public BigDecimal getVal()
```

**返回值：**
- `BigDecimal`

---
