---
framework_version: "8.0.1"
api_class: "RefEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用引用实体时"
---

# RefEntityType API 说明

## 概述
引用实体。继承自 BasedataEntityType。
主要功能：添加元素、读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.RefEntityType;
```

---

## 方法列表

### addProperty

{待补充}

**方法签名：**
```java
public void addProperty(DynamicProperty prop)
```

**参数说明：**
- `prop`: `DynamicProperty`

---

### endInit

结束初始化

**方法签名：**
```java
public synchronized void endInit()
```

---

### fillRefEntityTypes

填充引用实体

**方法签名：**
```java
public void fillRefEntityTypes(Map<String,DynamicObjectType> types)
```

**参数说明：**
- `types`: `Map<String,DynamicObjectType>`

---

### getRefBaseEntityIds

获取引用基础资料编码

**方法签名：**
```java
public String getRefBaseEntityIds()
```

**返回值：**
- `String`

---

### setRefBaseEntityIds

设置引用基础资料编码

**方法签名：**
```java
public void setRefBaseEntityIds(String refBaseEntityIds)
```

**参数说明：**
- `refBaseEntityIds`: `String`

---
