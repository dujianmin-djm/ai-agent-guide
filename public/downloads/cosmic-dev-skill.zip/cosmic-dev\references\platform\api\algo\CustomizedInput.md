---
framework_version: "8.0.1"
api_class: "CustomizedInput"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用自定义输入源,用来创建DataSet的输入时"
---

# CustomizedInput API 说明

## 概述
自定义输入源,用来创建DataSet的输入。。实现 Input, Closeable, Serializable, AutoCloseable。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.algo.CustomizedInput;
```

---

## 方法列表

### close

释放资源

**方法签名：**
```java
public abstract void close()
```

---

### createIterator

创建迭代器

**方法签名：**
```java
public abstract Iterator<Object[]> createIterator()
```

**返回值：**
- `Iterator<Object[]>`: 迭代器

---
