---
framework_version: "8.0.1"
api_class: "ConvertPath"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用转换路线时"
---

# ConvertPath API 说明

## 概述
转换路线。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.ConvertPath;
```

---

## 方法列表

### getBizAppId

应用Id

**方法签名：**
```java
public String getBizAppId()
```

**返回值：**
- `String`

---

### getSourceBizAppId

源单应用Id

**方法签名：**
```java
public String getSourceBizAppId()
```

**返回值：**
- `String`

---

### getSourceEntityName

源单主实体名称

**方法签名：**
```java
public String getSourceEntityName()
```

**返回值：**
- `String`

---

### getSourceEntityNumber

源单主实体编码

**方法签名：**
```java
public String getSourceEntityNumber()
```

**返回值：**
- `String`

---

### getTargetBizAppId

目标单应用id

**方法签名：**
```java
public String getTargetBizAppId()
```

**返回值：**
- `String`

---

### getTargetEntityName

目标单主实体名称

**方法签名：**
```java
public String getTargetEntityName()
```

**返回值：**
- `String`

---

### getTargetEntityNumber

目标单主实体编码

**方法签名：**
```java
public String getTargetEntityNumber()
```

**返回值：**
- `String`

---

### setBizAppId

设置应用Id

**方法签名：**
```java
public void setBizAppId(String bizAppId)
```

**参数说明：**
- `bizAppId`: `String`

---

### setSourceBizAppId

设置源单应用Id

**方法签名：**
```java
public void setSourceBizAppId(String sourceBizAppId)
```

**参数说明：**
- `sourceBizAppId`: `String`

---

### setSourceEntityName

设置源单主实体名称

**方法签名：**
```java
public void setSourceEntityName(String sourceEntityName)
```

**参数说明：**
- `sourceEntityName`: `String` — 源单主实体名称

---

### setSourceEntityNumber

设置源单主实体编码

**方法签名：**
```java
public void setSourceEntityNumber(String sourceEntityNumber)
```

**参数说明：**
- `sourceEntityNumber`: `String` — 源单主实体编码

---

### setTargetBizAppId

设置目标单应用id

**方法签名：**
```java
public void setTargetBizAppId(String targetBizAppId)
```

**参数说明：**
- `targetBizAppId`: `String`

---

### setTargetEntityName

设置目标单主实体名称

**方法签名：**
```java
public void setTargetEntityName(String targetEntityName)
```

**参数说明：**
- `targetEntityName`: `String` — 目标单主实体名称

---

### setTargetEntityNumber

设置目标单主实体编码

**方法签名：**
```java
public void setTargetEntityNumber(String targetEntityNumber)
```

**参数说明：**
- `targetEntityNumber`: `String` — 目标单主实体编码

---
