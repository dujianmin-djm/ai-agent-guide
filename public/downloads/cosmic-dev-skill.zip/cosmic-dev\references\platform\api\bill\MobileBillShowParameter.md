---
framework_version: "8.0.1"
api_class: "MobileBillShowParameter"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用移动端单据界面显示参数时"
---

# MobileBillShowParameter API 说明

## 概述
移动端单据界面显示参数。继承自 BillShowParameter，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.bill.MobileBillShowParameter;
```

---

## 方法列表

### getPosition

返回移动单据界面显示位置

**方法签名：**
```java
public MobileFormPosition getPosition()
```

**返回值：**
- `MobileFormPosition`: 显示位置枚举值

---

### setPosition

设置移动单据界面显示位置

**方法签名：**
```java
public void setPosition(MobileFormPosition value)
```

**参数说明：**
- `value`: `MobileFormPosition` — 显示位置枚举值

---
