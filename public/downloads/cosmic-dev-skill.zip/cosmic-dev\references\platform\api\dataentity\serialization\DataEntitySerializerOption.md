---
framework_version: "8.0.1"
api_class: "DataEntitySerializerOption"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用数据包序列化参数时"
---

# DataEntitySerializerOption API 说明

## 概述
数据包序列化参数。
主要功能：设置属性、状态判断、创建对象、读取属性。

## Import 路径
```java
import kd.bos.dataentity.serialization.DataEntitySerializerOption;
```

---

## 方法列表

### createWriter

创建序列化writer

**方法签名：**
```java
public DataEntitySerializerWriter createWriter()
```

**返回值：**
- `DataEntitySerializerWriter`

---

### getDataEntityBinder

获取实体序列化类型绑定接口

**方法签名：**
```java
public IDataEntityBinder getDataEntityBinder()
```

**返回值：**
- `IDataEntityBinder`

---

### isIncludeCollectionProperty

获取数据包中是否包含集合属性

**方法签名：**
```java
public boolean isIncludeCollectionProperty()
```

**返回值：**
- `boolean`

---

### isIncludeComplexProperty

获取是否包含复合属性

**方法签名：**
```java
public boolean isIncludeComplexProperty()
```

**返回值：**
- `boolean`

---

### isIncludeDataEntityState

获取数据包中是否包含state标志

**方法签名：**
```java
public boolean isIncludeDataEntityState()
```

**返回值：**
- `boolean`: true：包含，false：不包含

---

### isIncludeIndex

是否包含属性数组

**方法签名：**
```java
public boolean isIncludeIndex()
```

**返回值：**
- `boolean`

---

### isIncludeType

获取是否包含实体类型

**方法签名：**
```java
public boolean isIncludeType()
```

**返回值：**
- `boolean`

---

### setDataEntityBinder

设置实体序列化类型绑定接口

**方法签名：**
```java
public void setDataEntityBinder(IDataEntityBinder dataEntityBinder)
```

**参数说明：**
- `dataEntityBinder`: `IDataEntityBinder` — 实体序列化类型绑定接口

---

### setIncludeCollectionProperty

设置数据包中是否包含集合属性

**方法签名：**
```java
public void setIncludeCollectionProperty(boolean includeCollectionProperty)
```

**参数说明：**
- `includeCollectionProperty`: `boolean` — 集合属性

---

### setIncludeComplexProperty

设置是否包含复合属性

**方法签名：**
```java
public void setIncludeComplexProperty(boolean includeComplexProperty)
```

**参数说明：**
- `includeComplexProperty`: `boolean` — 复合属性

---

### setIncludeDataEntityState

设置数据包中是否包含state标志

**方法签名：**
```java
public void setIncludeDataEntityState(boolean includeDataEntityState)
```

**参数说明：**
- `includeDataEntityState`: `boolean` — 数据包中是否包含state标志

---

### setIncludeIndex

是否包含属性数组

**方法签名：**
```java
public void setIncludeIndex(boolean includeIndex)
```

**参数说明：**
- `includeIndex`: `boolean`

---

### setIncludeType

设置是否包含实体类型

**方法签名：**
```java
public void setIncludeType(boolean includeType)
```

**参数说明：**
- `includeType`: `boolean` — 是否包含实体类型

---
