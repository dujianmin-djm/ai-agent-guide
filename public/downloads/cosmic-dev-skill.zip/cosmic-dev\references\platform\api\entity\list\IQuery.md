---
framework_version: "8.0.1"
api_class: "IQuery"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用序时簿相关接口时"
---

# IQuery API 说明

## 概述
序时簿相关接口。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.IQuery;
```

---

## 方法列表

### getChildsId

获取长编码id集合

**方法签名：**
```java
public List<String> getChildsId(GroupProp groupProp, String longNumber)
```

**参数说明：**
- `groupProp`: `GroupProp` — 分组属性
- `longNumber`: `String` — 长编码字段标识

**返回值：**
- `List<String>`

---

### getData

取数接口

**方法签名：**
```java
public DynamicObjectCollection getData(QueryBuilder queryBuilder)
```

**参数说明：**
- `queryBuilder`: `QueryBuilder` — 查询上下文

**返回值：**
- `DynamicObjectCollection`

---

### getDataEntityTypes

获取ORM解析的实体列表

**方法签名：**
```java
public List<IDataEntityType> getDataEntityTypes()
```

**返回值：**
- `List<IDataEntityType>`

---

### getGroupNodes

获取树形列表左树结点

**方法签名：**
```java
public List<kd.TreeNode> getGroupNodes(GroupProp groupProp, List<QFilter> filters, String format, Object parentId, String longNumber, Map<String,Object> queryParas)
```

**参数说明：**
- `groupProp`: `GroupProp` — 分组属性
- `filters`: `List<QFilter>` — 过滤条件
- `format`: `String` — 长编码格式化模版
- `parentId`: `Object` — 父结点id
- `longNumber`: `String` — 长编码字段标识
- `queryParas`: `Map<String,Object>` — 查询参数值

**返回值：**
- `List<kd.TreeNode>`

---

### getPreGetPageCount

获取预取数据数量

**方法签名：**
```java
public static int getPreGetPageCount()
```

**返回值：**
- `int`

---

### getQueryResult

获取查询结果

**方法签名：**
```java
public QueryResult getQueryResult()
```

**返回值：**
- `QueryResult`

---

### setDataEntityTypes

设置给ORM解析的实体列表

**方法签名：**
```java
public void setDataEntityTypes(List<IDataEntityType> dataEntityTypes)
```

**参数说明：**
- `dataEntityTypes`: `List<IDataEntityType>`

---
