---
framework_version: "8.0.1"
api_class: "CompareTypeConfig"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用比较符配置时"
---

# CompareTypeConfig API 说明

## 概述
比较符配置。
主要功能：添加元素、读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.CompareTypeConfig;
```

---

## 方法列表

### addCompareTypeField

添加比较符

**方法签名：**
```java
public void addCompareTypeField(CompareTypeField compareTypeField)
```

**参数说明：**
- `compareTypeField`: `CompareTypeField` — 比较符定义

---

### getCompareTypeFields

获取比较符集合

**方法签名：**
```java
public List<kd.CompareTypeField> getCompareTypeFields()
```

**返回值：**
- `List<kd.CompareTypeField>`

---

### setCompareTypeFields

设置比较符集合

**方法签名：**
```java
public void setCompareTypeFields(List<kd.CompareTypeField> compareTypeFields)
```

**参数说明：**
- `compareTypeFields`: `List<kd.CompareTypeField>`

---
