---
framework_version: "8.0.1"
api_class: "BeforeExcessCheckEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用对源单行反写执行完毕时"
---

# BeforeExcessCheckEventArgs API 说明

## 概述
对源单行反写执行完毕，超额检查前，触发此事件：用于取消超额检查。继承自 WriteBackEventArgs。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeExcessCheckEventArgs;
```

---

## 方法列表

### getRule

反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getSrcActiveRow

上游源单，关联主实体数据行

**方法签名：**
```java
public DynamicObject getSrcActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getSrcEntity

上游源单，关联主实体

**方法签名：**
```java
public EntityType getSrcEntity()
```

**返回值：**
- `EntityType`

---

### getSrcSubMainType

上游源单主实体，仅包含需要用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---

### getTargetActiveRow

下游目标单关联主实体，当前数据行；删除行时，这个属性可能没值

**方法签名：**
```java
public DynamicObject getTargetActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getTargetEntity

下游目标单关联主实体

**方法签名：**
```java
public EntityType getTargetEntity()
```

**返回值：**
- `EntityType`

---

### isCancel

插件是否要求略过超额检查

**方法签名：**
```java
public boolean isCancel()
```

**返回值：**
- `boolean`

---

### setCancel

设置插件是否要求略过超额检查

**方法签名：**
```java
public void setCancel(boolean cancel)
```

**参数说明：**
- `cancel`: `boolean`

---
