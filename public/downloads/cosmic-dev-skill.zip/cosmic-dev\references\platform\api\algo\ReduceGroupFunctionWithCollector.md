---
framework_version: "8.0.1"
api_class: "ReduceGroupFunctionWithCollector"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用对分组后的结果集进行reduce处理时"
---

# ReduceGroupFunctionWithCollector API 说明

## 概述
对分组后的结果集进行reduce处理。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：对分组后的结果集进行reduce处理。

## Import 路径
```java
import kd.bos.algo.ReduceGroupFunctionWithCollector;
```

---

## 方法列表

### reduce

对分组后的结果集进行reduce处理

**方法签名：**
```java
public abstract void reduce(Iterator<kd.Row> iter, Collector collector)
```

**参数说明：**
- `iter`: `Iterator<kd.Row>` — 分组后，每组的Iterator
- `collector`: `Collector` — 对处理后的数据进行收集的接口

---
