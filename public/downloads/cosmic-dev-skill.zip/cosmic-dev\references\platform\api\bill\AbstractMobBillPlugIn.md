---
framework_version: "8.0.1"
api_class: "AbstractMobBillPlugIn"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用移动端单据视图层插件抽象基类时"
---

# AbstractMobBillPlugIn API 说明

## 概述
移动端单据视图层插件抽象基类。继承自 AbstractBillPlugIn，实现 IBillPlugin。
主要功能：其他操作。

## Import 路径
```java
import kd.bos.bill.AbstractMobBillPlugIn;
```

---

## 方法列表

### locate

位置定位成功事件

**方法签名：**
```java
public void locate(LocateEvent e)
```

**参数说明：**
- `e`: `LocateEvent` — 事件参数

---

### uploadFile

上传文件成功事件

**方法签名：**
```java
public void uploadFile(EventObject e)
```

**参数说明：**
- `e`: `EventObject` — 文件上传参数 ，kd.bos.form.control.events.UploadEvent 类型实例

---
