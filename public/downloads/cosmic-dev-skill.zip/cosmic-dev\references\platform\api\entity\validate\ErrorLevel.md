---
framework_version: "8.0.1"
api_class: "ErrorLevel"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用错误级别时"
---

# ErrorLevel API 说明

## 概述
错误级别。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.validate.ErrorLevel;
```

---

## 方法列表

### getValue

获取错误值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---

### valueOf

根据错误值取错误级别对象

**方法签名：**
```java
public static ErrorLevel valueOf(int level)
```

**参数说明：**
- `level`: `int`

**返回值：**
- `ErrorLevel`

---
