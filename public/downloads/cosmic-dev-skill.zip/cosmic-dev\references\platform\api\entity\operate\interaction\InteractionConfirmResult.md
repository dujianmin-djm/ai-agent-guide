---
framework_version: "8.0.1"
api_class: "InteractionConfirmResult"
api_package: "kd.bos.entity.operate.interaction"
when_to_use: "当你需要使用操作交互时"
---

# InteractionConfirmResult API 说明

## 概述
操作交互，用户确认结果，以字典存储，区分交互请求来源。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.operate.interaction.InteractionConfirmResult;
```

---

## 方法列表

### fromJsonString

把字符串反序列化为本对象

**方法签名：**
```java
public static InteractionConfirmResult fromJsonString(String json)
```

**参数说明：**
- `json`: `String` — json字符串

**返回值：**
- `InteractionConfirmResult`: 交互结果

---

### getResults

交互结果。操作支持多次交互，每次交互结果使用sponsor为key，存储在字典中

**方法签名：**
```java
public Map<String,String> getResults()
```

**返回值：**
- `Map<String,String>`: 集合

---

### put

添加本次交互结果

**方法签名：**
```java
public void put(String sponsor, String resultString)
```

**参数说明：**
- `sponsor`: `String` — 本次交互标识sponsor，由插件自行指定与识别
- `resultString`: `String` — 交互结果，如果是复杂对象，需要先自行序列化为字符串

---

### toJsonString

把本对象序列化为字符串

**方法签名：**
```java
public String toJsonString()
```

**返回值：**
- `String`: String

---
