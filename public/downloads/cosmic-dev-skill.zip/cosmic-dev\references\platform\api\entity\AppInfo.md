---
framework_version: "8.0.1"
api_class: "AppInfo"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用业务应用时"
---

# AppInfo API 说明

## 概述
业务应用。实现 NodeInfo, Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.AppInfo;
```

---

## 方法列表

### getAppId

获取应用编码

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`

---

### getCloudId

应用所属业务云 id

**方法签名：**
```java
public String getCloudId()
```

**返回值：**
- `String`

---

### getCloudNum

获取应用所属云编码

**方法签名：**
```java
public String getCloudNum()
```

**返回值：**
- `String`

---

### getData

应用元数据

**方法签名：**
```java
public String getData()
```

**返回值：**
- `String`

---

### getDbRoute

获取应用数据库路由标识

**方法签名：**
```java
public String getDbRoute()
```

**返回值：**
- `String`

---

### getDeployStatus

应用部署状态

**方法签名：**
```java
public String getDeployStatus()
```

**返回值：**
- `String`

---

### getDescription

获取应用描述

**方法签名：**
```java
public LocaleString getDescription()
```

**返回值：**
- `LocaleString`

---

### getHomeId

应用首页页面 id

**方法签名：**
```java
public String getHomeId()
```

**返回值：**
- `String`

---

### getHomeNum

应用首页页面编码

**方法签名：**
```java
public String getHomeNum()
```

**返回值：**
- `String`

---

### getHomeURL

获取应用链接地址

**方法签名：**
```java
public String getHomeURL()
```

**返回值：**
- `String`

---

### getId

获取应用 id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getImage

获取应用主题图片

**方法签名：**
```java
public String getImage()
```

**返回值：**
- `String`

---

### getIsv

获取应用开发商标识

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getMainFormType

获取首页类型

**方法签名：**
```java
public String getMainFormType()
```

**返回值：**
- `String`

---

### getName

获取应用名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getNodeType

应用树节点类型：app

**方法签名：**
```java
public String getNodeType()
```

**返回值：**
- `String`

---

### getNumber

获取应用编码

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`

---

### getOpenType

获取应用打开方式

**方法签名：**
```java
public String getOpenType()
```

**返回值：**
- `String`

---

### getOrder

获取应用序号，不参与序列化

**方法签名：**
```java
public int getOrder()
```

**返回值：**
- `int`

---

### getOrgFunc

获取应用职能类型

**方法签名：**
```java
public String getOrgFunc()
```

**返回值：**
- `String`

---

### getSeq

获取应用序号

**方法签名：**
```java
public Short getSeq()
```

**返回值：**
- `Short`

---

### getType

获取应用类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### getUserType

获取应用适用用户

**方法签名：**
```java
public String getUserType()
```

**返回值：**
- `String`

---

### isAllUserApp

是否全员应用

**方法签名：**
```java
public boolean isAllUserApp()
```

**返回值：**
- `boolean`

---

### isRealRuntime

应用是否真正处于运行中

**方法签名：**
```java
public boolean isRealRuntime()
```

**返回值：**
- `boolean`

---

### isVisible

应用是否可见

**方法签名：**
```java
public boolean isVisible()
```

**返回值：**
- `boolean`

---

### setAllUserApp

设置是否全员应用

**方法签名：**
```java
public void setAllUserApp(boolean allUserApp)
```

**参数说明：**
- `allUserApp`: `boolean`

---

### setAppId

设置应用编码

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String`

---

### setCloudId

设置应用所属业务云 id

**方法签名：**
```java
public void setCloudId(String cloudId)
```

**参数说明：**
- `cloudId`: `String`

---

### setCloudNum

设置应用所属云编码

**方法签名：**
```java
public void setCloudNum(String cloudNum)
```

**参数说明：**
- `cloudNum`: `String`

---

### setData

设置应用元数据

**方法签名：**
```java
public void setData(String data)
```

**参数说明：**
- `data`: `String`

---

### setDbRoute

设置应用数据库路由标识

**方法签名：**
```java
public void setDbRoute(String dbRoute)
```

**参数说明：**
- `dbRoute`: `String`

---

### setDeployStatus

设置应用部署状态

**方法签名：**
```java
public void setDeployStatus(String deployStatus)
```

**参数说明：**
- `deployStatus`: `String`

---

### setDescription

设置应用描述

**方法签名：**
```java
public void setDescription(LocaleString description)
```

**参数说明：**
- `description`: `LocaleString`

---

### setHomeId

应用首页页面 id

**方法签名：**
```java
public void setHomeId(String homeId)
```

**参数说明：**
- `homeId`: `String`

---

### setHomeNum

应用首页页面编码

**方法签名：**
```java
public void setHomeNum(String homeNum)
```

**参数说明：**
- `homeNum`: `String`

---

### setId

设置应用 id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setImage

设置应用主题图片

**方法签名：**
```java
public void setImage(String image)
```

**参数说明：**
- `image`: `String`

---

### setIsv

设置应用开发商标识

**方法签名：**
```java
public void setIsv(String isv)
```

**参数说明：**
- `isv`: `String`

---

### setName

设置应用名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setNumber

设置应用编码

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String`

---

### setOpenType

设置应用打开方式

**方法签名：**
```java
public void setOpenType(String openType)
```

**参数说明：**
- `openType`: `String`

---

### setOrgFunc

设置应用职能类型

**方法签名：**
```java
public void setOrgFunc(String orgFunc)
```

**参数说明：**
- `orgFunc`: `String`

---

### setRealRuntime

设置应用是否真正处于运行中

**方法签名：**
```java
public void setRealRuntime(boolean realRuntime)
```

**参数说明：**
- `realRuntime`: `boolean`

---

### setSeq

设置应用序号

**方法签名：**
```java
public void setSeq(Short seq)
```

**参数说明：**
- `seq`: `Short`

---

### setType

设置应用类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---

### setUserType

设置应用适用用户

**方法签名：**
```java
public void setUserType(String userType)
```

**参数说明：**
- `userType`: `String`

---

### setVisible

设置应用是否可见

**方法签名：**
```java
public void setVisible(boolean visible)
```

**参数说明：**
- `visible`: `boolean`

---
