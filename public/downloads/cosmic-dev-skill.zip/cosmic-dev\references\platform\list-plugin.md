---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "approved"
---

# 列表插件开发参考

> 覆盖：AbstractListPlugin
> 来源：kg/output/platform/form/api/list/

## 基础结构

```java
package {isv}.{module}.listplugin;

import java.util.EventObject;
import kd.bos.list.plugin.AbstractListPlugin;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

public class XxxListPlugin extends AbstractListPlugin {
    private static final Log logger = LogFactory.getLog(XxxListPlugin.class);

    @Override
    public void registerListener(EventObject e) {
        super.registerListener(e);
        // 注册按钮监听
        addItemClickListeners("tbmain");
    }

}
```

## 常用事件

| 事件 | 触发时机 | 典型用途 |
|------|---------|---------|
| `itemClick` | 工具栏按钮点击 | 批量操作、打开页面 |
| `setFilter` | 设置过滤条件时 | 注入额外过滤条件 |
| `packageData` | 每行数据包装时 | 列字段格式化显示 |
| `listRowClick` | 列表行被点击时 | 行选中处理、联动刷新、阻止默认行为 |
| `listRowDoubleClick` | 列表行被双击时 | 自定义双击打开行为（如打开详情、弹窗编辑） |
| `billListHyperLinkClick` | 列表超链接字段被点击时 | 自定义跳转目标单据/列表、按状态打开不同布局 |

### 列表按钮操作模式

列表界面的工具栏按钮操作通常遵循：**先获取选中行 → 校验选中状态 → 再执行业务逻辑**。未选中行时应提示用户，禁止直接执行。

涉及数据状态判断的操作（如「审核状态不能删除」「已提交不能修改」），必须在**用户点击按钮时**才根据选中行的数据状态做校验拦截，不要在页面加载或行选中时提前判断。

## 列表数据格式化（packageData）

```java
import kd.bos.list.events.ListPackageDataEvent;

@Override
public void packageData(ListPackageDataEvent e) {
    super.packageData(e);
    // 格式化某列显示值（原始值 → 显示文本）
    Object rawValue = e.getField("targetColumn");
    if ("C".equals(rawValue)) {
        e.setValue("targetColumn", "已审核");
    } else if ("A".equals(rawValue)) {
        e.setValue("targetColumn", "草稿");
    }
}
```

> **注意**：packageData 事件在每个单元格格式化时循环触发，禁止在此事件访问数据库取数-避免大量消耗性能。


## 自定义列表过滤（setFilter）

```java
import kd.bos.list.events.PrepareFilterEvent;

@Override
public void setFilter(PrepareFilterEvent e) {
    super.setFilter(e);
    // 注入额外过滤条件（如限制仅查看本人数据）
    long userId = RequestContext.get().getCurrUserId();
    QFilter myFilter = new QFilter("creator", QCP.equals, userId);
    e.addCustomFilter(myFilter);
}
```

## 获取列表选中行

```java
// 在 itemClick 中获取用户选中的行
@Override
public void itemClick(ItemClickEvent evt) {
    super.itemClick(evt);
    if ("btnExport".equals(evt.getItemKey())) {
        // 获取选中行的主键集合
        Object[] selectedIds = this.getSelectedRows().getPrimaryKeyValues();
        if (selectedIds.length == 0) {
            getView().showTipNotification("请先选择数据");
            return;
        }
        // 处理选中数据
        processSelected(selectedIds);
    }
}
```

## 列表行点击（listRowClick）

```java
import kd.bos.list.events.ListRowClickEvent;

@Override
public void listRowClick(ListRowClickEvent evt) {
    super.listRowClick(evt);
    // 获取当前点击行的选中信息
    ListSelectedRow selectedRow = evt.getCurrentListSelectedRow();
    Object pkId = selectedRow.getPrimaryKeyValue();
    // 示例：根据点击行刷新关联区域
    // evt.setCancel(true); // 如需阻止默认行为
}
```

## 列表行双击（listRowDoubleClick）

通过 `BillList.addListRowDoubleClickListener` 注册监听，回调参数为 `ListRowClickEvent`（与行点击共用事件类型）。

```java
import kd.bos.list.BillList;
import kd.bos.list.events.ListRowClickEvent;

import java.util.EventObject;

@Override
public void registerListener(EventObject e) {
    super.registerListener(e);
    BillList billList = getControl("billlistap");
    billList.addListRowDoubleClickListener(this::listRowDoubleClick);
}

private void listRowDoubleClick(ListRowClickEvent evt) {
    // 阻止默认双击打开行为
    evt.setCancel(true);
    // 获取双击行主键
    Object pkId = evt.getCurrentListSelectedRow().getPrimaryKeyValue();
    // 示例：自定义打开目标单据
    BillShowParameter param = new BillShowParameter();
    param.setFormId("target_bill");
    param.setPkId(pkId);
    param.getOpenStyle().setShowType(ShowType.MainNewTabPage);
    this.getView().showForm(param);
}
```

## 列表超链接点击（billListHyperLinkClick）

> 场景文档：`references/platform/scenes/event/hyperlink-click-jump.md`（含 4 个完整示例）

```java
import kd.bos.form.events.HyperLinkClickArgs;
import kd.bos.list.BillList;
import kd.bos.bill.BillShowParameter;
import kd.bos.bill.BillOperationStatus;
import kd.bos.form.ShowType;

@Override
public void billListHyperLinkClick(HyperLinkClickArgs args) {
    String fieldName = args.getFieldName();
    if ("target_field".equals(fieldName)) {
        // 阻止默认跳转
        args.setCancel(true);
        // 获取当前行主键
        BillList source = (BillList) args.getHyperLinkClickEvent().getSource();
        Long id = (Long) source.getCurrentSelectedRowInfo().getPrimaryKeyValue();
        // 打开目标单据
        BillShowParameter param = new BillShowParameter();
        param.setFormId("target_bill");
        param.setPkId(id);
        param.setBillStatus(BillOperationStatus.VIEW);
        param.getOpenStyle().setShowType(ShowType.Modal);
        this.getView().showForm(param);
    }
}
```

> 完整 API 参考：sync 后查阅 `references/platform/api/list/` 目录
