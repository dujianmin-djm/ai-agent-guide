---
framework_version: "8.0.1"
api_class: "QueryBuilder"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用IdQuery时"
---

# QueryBuilder API 说明

## 概述
IdQuery，SqlQuery使用的查询上下文。继承自 AbstractQueryBuilder，实现 Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.list.QueryBuilder;
```

---

## 方法列表

### getAchiveKey

获取归档信息

**方法签名：**
```java
public String getAchiveKey()
```

**返回值：**
- `String`: 归档信息

---

### getDecimalFields

获取数字类型字段列表

**方法签名：**
```java
public List<kd.ListField> getDecimalFields()
```

**返回值：**
- `List<kd.ListField>`: 数字类型字段列表

---

### getEntityName

获取实体标识名称

**方法签名：**
```java
public String getEntityName()
```

**返回值：**
- `String`: 实体标识名称

---

### getGroupBy

获取分组标识

**方法签名：**
```java
public String getGroupBy()
```

**返回值：**
- `String`

---

### getGroupBySumFields

获取分组汇总字段属性

**方法签名：**
```java
public List<String> getGroupBySumFields()
```

**返回值：**
- `List<String>`

---

### getMaxReturnData

获取最大返回条数

**方法签名：**
```java
public int getMaxReturnData()
```

**返回值：**
- `int`: 最大返回条数

---

### getPkFields

获取PK字段列表

**方法签名：**
```java
public List<kd.ListField> getPkFields()
```

**返回值：**
- `List<kd.ListField>`: PK字段列表

---

### getQuerySumFields

{待补充}

**方法签名：**
```java
public List<String> getQuerySumFields()
```

**返回值：**
- `List<String>`

---

### getReturnEntityType

获取返回的实体类型

**方法签名：**
```java
public DynamicObjectType getReturnEntityType()
```

**返回值：**
- `DynamicObjectType`: 返回的实体类型

---

### getRouteKey

获取路由信息

**方法签名：**
```java
public String getRouteKey()
```

**返回值：**
- `String`: 路由信息

---

### getSeqField

获取排序字段

**方法签名：**
```java
public String getSeqField()
```

**返回值：**
- `String`: 排序字段

---

### getVisibleSelectFieldList

获取可见字段集合

**方法签名：**
```java
public List<kd.ListField> getVisibleSelectFieldList()
```

**返回值：**
- `List<kd.ListField>`: 可见字段集合

---

### isExceedMaxCount

获取是否超过最大条数

**方法签名：**
```java
public boolean isExceedMaxCount()
```

**返回值：**
- `boolean`: 是否超过最大条数

---

### isMergeRow

是否是融合列

**方法签名：**
```java
public boolean isMergeRow()
```

**返回值：**
- `boolean`: 是否是融合列

---

### isNeedResum

获取是否需要重新合计，不要缓存，已选合计使用

**方法签名：**
```java
public boolean isNeedResum()
```

**返回值：**
- `boolean`: 是否需要重新合计

---

### isSelectedAllRows

获取选择全部

**方法签名：**
```java
public boolean isSelectedAllRows()
```

**返回值：**
- `boolean`: 是否选择全部

---

### setAchiveKey

设置归档信息

**方法签名：**
```java
public void setAchiveKey(String achiveKey)
```

**参数说明：**
- `achiveKey`: `String` — 归档信息

---

### setEntityName

设置实体标识名称

**方法签名：**
```java
public void setEntityName(String entityName)
```

**参数说明：**
- `entityName`: `String` — 实体标识名称

---

### setExceedMaxCount

设置取条数是否是取超过最大条数场景

**方法签名：**
```java
public void setExceedMaxCount(boolean isExceedMaxCount)
```

**参数说明：**
- `isExceedMaxCount`: `boolean` — 取条数是否是取超过最大条数场景

---

### setGroupBy

设置分组标识

**方法签名：**
```java
public void setGroupBy(String groupBy)
```

**参数说明：**
- `groupBy`: `String`

---

### setGroupBySumFields

设置分组汇总字段属性

**方法签名：**
```java
public void setGroupBySumFields(List<String> groupBySumFields)
```

**参数说明：**
- `groupBySumFields`: `List<String>`

---

### setMaxReturnData

设置最大返回条数

**方法签名：**
```java
public void setMaxReturnData(int maxReturnData)
```

**参数说明：**
- `maxReturnData`: `int` — 最大返回条数

---

### setRouteKey

设置路由信息

**方法签名：**
```java
public void setRouteKey(String routeKey)
```

**参数说明：**
- `routeKey`: `String` — 路由信息

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
