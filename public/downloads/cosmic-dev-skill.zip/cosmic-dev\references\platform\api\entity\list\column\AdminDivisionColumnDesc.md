---
framework_version: "8.0.1"
api_class: "AdminDivisionColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用行政区划格式化类时"
---

# AdminDivisionColumnDesc API 说明

## 概述
行政区划格式化类。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.AdminDivisionColumnDesc;
```

---

## 方法列表

### getAdminDivisionProp

获取绑定的行政组织字段属性

**方法签名：**
```java
public AdminDivisionProp getAdminDivisionProp()
```

**返回值：**
- `AdminDivisionProp`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---

### setShowStyle

设置显示样式

**方法签名：**
```java
public void setShowStyle(int showStyle)
```

**参数说明：**
- `showStyle`: `int` — 示样式

---
