---
framework_version: "8.0.1"
api_class: "DataEntitySerializer"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用数据包序列化工具类时"
---

# DataEntitySerializer API 说明

## 概述
数据包序列化工具类。
主要功能：将数据包序列化成Map、根据序列化参数将数据包序列化成Map、将Map反序列化转换成数据包、根据反序列化参数将Map反序列化转换成数、将String反序列化成数据包。

## Import 路径
```java
import kd.bos.dataentity.serialization.DataEntitySerializer;
```

---

## 方法列表

### convertDataEntityToMap

**重载 1**

将数据包序列化成Map

**方法签名：**
```java
public static Map<String,Object> convertDataEntityToMap(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object` — 数据包

**返回值：**
- `Map<String,Object>`: Map

---

**重载 2**

根据序列化参数将数据包序列化成Map

**方法签名：**
```java
public static Map<String,Object> convertDataEntityToMap(Object dataEntity, DataEntitySerializerOption option)
```

**参数说明：**
- `dataEntity`: `Object` — 数据包
- `option`: `DataEntitySerializerOption` — DataEntitySerializerOption 序列化参数

**返回值：**
- `Map<String,Object>`

---

### convertMapToDataEntity

**重载 1**

将Map反序列化转换成数据包

**方法签名：**
```java
public static Object convertMapToDataEntity(IDataEntityType dt, Map<String,Object> mapObj)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `mapObj`: `Map<String,Object>` — 数据

**返回值：**
- `Object`

---

**重载 2**

根据反序列化参数将Map反序列化转换成数据包

**方法签名：**
```java
public static Object convertMapToDataEntity(IDataEntityType dt, Map<String,Object> mapObj, DataEntityDeserializerOption option)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `mapObj`: `Map<String,Object>` — 数据
- `option`: `DataEntityDeserializerOption` — DataEntityDeserializerOption 反序列化参数

**返回值：**
- `Object`

---

### deSerializerFromString

**重载 1**

将String反序列化成数据包

**方法签名：**
```java
public static Object deSerializerFromString(String strOrder, IDataEntityType dataEntityType)
```

**参数说明：**
- `strOrder`: `String` — 值
- `dataEntityType`: `IDataEntityType` — 实体类型

**返回值：**
- `Object`

---

**重载 2**

根据反序列化参数将String反序列化成数据包

**方法签名：**
```java
public static Object deSerializerFromString(String strOrder, IDataEntityType dataEntityType, DataEntityDeserializerOption option)
```

**参数说明：**
- `strOrder`: `String` — 值
- `dataEntityType`: `IDataEntityType` — 实体类型
- `option`: `DataEntityDeserializerOption` — DataEntityDeserializerOption 反序列化参数

**返回值：**
- `Object`

---

### deserializerFromListString

**重载 1**

将数组反序列化成数据包集合

**方法签名：**
```java
public static List<kd.DynamicObject> deserializerFromListString(List<kd.DynamicObject> cols, IDataEntityType dt, String[] strList)
```

**参数说明：**
- `cols`: `List<kd.DynamicObject>` — 数据集合
- `dt`: `IDataEntityType` — 实体类型
- `strList`: `String[]` — 需要反序列的值

**返回值：**
- `List<kd.DynamicObject>`

---

**重载 2**

根据反序列化参数将数据反序列成数据包集合

**方法签名：**
```java
public static List<kd.DynamicObject> deserializerFromListString(List<kd.DynamicObject> cols, IDataEntityType dt, String[] strList, DataEntityDeserializerOption option)
```

**参数说明：**
- `cols`: `List<kd.DynamicObject>` — 数据包集合
- `dt`: `IDataEntityType` — 实体类型
- `strList`: `String[]` — 需要反序列的值
- `option`: `DataEntityDeserializerOption` — DataEntityDeserializerOption 反序列化参数

**返回值：**
- `List<kd.DynamicObject>`

---

**重载 3**

将数据反序列化成数据包

**方法签名：**
```java
public static DynamicObject deserializerFromListString(IDataEntityType dt, String strList)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `strList`: `String` — 需要反序列的值

**返回值：**
- `DynamicObject`

---

**重载 4**

根据反序列化参数将数据反序列成数据包集合

**方法签名：**
```java
public static DynamicObject deserializerFromListString(IDataEntityType dt, String strList, DataEntityDeserializerOption option)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `strList`: `String` — 需要反序列的值
- `option`: `DataEntityDeserializerOption` — DataEntityDeserializerOption 反序列化参数

**返回值：**
- `DynamicObject`

---

### deserializerFromMap

数据包反序列

**方法签名：**
```java
public static List<kd.DynamicObject> deserializerFromMap(Map<String,Object> map, List<kd.DynamicObject> cols, IDataEntityType dt, DataEntityDeserializerOption option)
```

**参数说明：**
- `map`: `Map<String,Object>` — 数据包json
- `cols`: `List<kd.DynamicObject>` — 动态对象list
- `dt`: `IDataEntityType` — 动态对象实体属性
- `option`: `DataEntityDeserializerOption` — 反序列化选项

**返回值：**
- `List<kd.DynamicObject>`

---

### serializerToListString

将数据包序列化成数组

**方法签名：**
```java
public static String[] serializerToListString(IDataEntityType dt, List<kd.DynamicObject> cols, DataEntitySerializerOption option)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `cols`: `List<kd.DynamicObject>` — 数据集合
- `option`: `DataEntitySerializerOption` — DataEntitySerializerOption 序列化参数

**返回值：**
- `String[]`

---

### serializerToMap

将数据包序列化成数组

**方法签名：**
```java
public static Map<String,Object> serializerToMap(IDataEntityType dt, List<kd.DynamicObject> cols, DataEntitySerializerOption option)
```

**参数说明：**
- `dt`: `IDataEntityType` — 实体类型
- `cols`: `List<kd.DynamicObject>` — 数据集合
- `option`: `DataEntitySerializerOption` — DataEntitySerializerOption 序列化参数

**返回值：**
- `Map<String,Object>`

---

### serializerToString

**重载 1**

将数据包序列化成String

**方法签名：**
```java
public static String serializerToString(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object` — 数据包

**返回值：**
- `String`

---

**重载 2**

将数据包序列化成String

**方法签名：**
```java
public static String serializerToString(Object dataEntity, boolean includeType, boolean includeComplexProperty)
```

**参数说明：**
- `dataEntity`: `Object` — 数据包
- `includeType`: `boolean` — 是否包含实体类型
- `includeComplexProperty`: `boolean` — 是否包含复合属性

**返回值：**
- `String`

---

**重载 3**

根据序列化参数将数据包序列化成String

**方法签名：**
```java
public static String serializerToString(Object dataEntity, DataEntitySerializerOption option)
```

**参数说明：**
- `dataEntity`: `Object` — 数据包
- `option`: `DataEntitySerializerOption` — DataEntitySerializerOption 序列化参数

**返回值：**
- `String`

---
