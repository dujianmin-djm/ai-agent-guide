---
framework_version: "8.0.1"
api_class: "PictureProp"
api_package: "kd.bos.entity.property"
when_to_use: "当你需要使用图片属性时"
---

# PictureProp API 说明

## 概述
图片属性。继承自 FieldProp。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.PictureProp;
```

---

## 方法列表

### getBackgroundImgKey

获取字段backgroundImgKey的值

**方法签名：**
```java
public String getBackgroundImgKey()
```

**返回值：**
- `String`: backgroundImgKey的值

---

### getDefaultImgKey

获取字段defaultImgKey的值

**方法签名：**
```java
public String getDefaultImgKey()
```

**返回值：**
- `String`: defaultImgKey的值

---

### getListColumnDesc

获取列表字段格式化对象

**方法签名：**
```java
public AbstractColumnDesc getListColumnDesc(ListField col)
```

**参数说明：**
- `col`: `ListField`

**返回值：**
- `AbstractColumnDesc`

---

### getMaxImgSize

获取最大图片大小

**方法签名：**
```java
public int getMaxImgSize()
```

**返回值：**
- `int`: 最大图片大小

---

### getThumbnailsParams

获取字段thumbnailsParams的值

**方法签名：**
```java
public List<ThumbnailsParameter> getThumbnailsParams()
```

**返回值：**
- `List<ThumbnailsParameter>`: thumbnailsParams的值

---

### setBackgroundImgKey

将参数backgroundImgKey的值赋给字段backgroundImgKey

**方法签名：**
```java
public void setBackgroundImgKey(String backgroundImgKey)
```

**参数说明：**
- `backgroundImgKey`: `String`

---

### setDefaultImgKey

将参数defaultImgKey的值赋给字段defaultImgKey

**方法签名：**
```java
public void setDefaultImgKey(String defaultImgKey)
```

**参数说明：**
- `defaultImgKey`: `String`

---

### setMaxImgSize

设置最大图片大小

**方法签名：**
```java
public void setMaxImgSize(int maxImgSize)
```

**参数说明：**
- `maxImgSize`: `int`

---

### setThumbnailsParams

将参数thumbnailsParams的值赋给字段thumbnailsParams

**方法签名：**
```java
public void setThumbnailsParams(List<ThumbnailsParameter> thumbnailsParams)
```

**参数说明：**
- `thumbnailsParams`: `List<ThumbnailsParameter>`

---
