---
framework_version: "8.0.1"
api_class: "RowFeature"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用Row顶层接口时"
---

# RowFeature API 说明

## 概述
Row顶层接口。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.RowFeature;
```

---

## 方法列表

### get

返回对应索引的值

**方法签名：**
```java
public Object get(int index)
```

**参数说明：**
- `index`: `int` — 索引值

**返回值：**
- `Object`: 值

---
