---
framework_version: "8.0.1"
api_class: "RequiredValidator"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用必录校验器时"
---

# RequiredValidator API 说明

## 概述
必录校验器。继承自 SingleFieldValidator。
主要功能：。

## Import 路径
```java
import kd.bos.entity.validate.RequiredValidator;
```

---

## 方法列表

### initializeConfiguration

{待补充}

**方法签名：**
```java
public void initializeConfiguration()
```

---

### preparePropertys

{待补充}

**方法签名：**
```java
public Set<String> preparePropertys()
```

**返回值：**
- `Set<String>`

---

### validate

{待补充}

**方法签名：**
```java
public void validate()
```

---
