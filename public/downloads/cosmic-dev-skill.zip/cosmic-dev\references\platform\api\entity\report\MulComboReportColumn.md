---
framework_version: "8.0.1"
api_class: "MulComboReportColumn"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列-多选下拉列表类型列时"
---

# MulComboReportColumn API 说明

## 概述
报表列-多选下拉列表类型列。继承自 ComboReportColumn，实现 IColumn, IBaseColumn, Serializable。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.entity.report.MulComboReportColumn;
```

---

## 方法列表

### createColumn

打包客户端报表列元数据信息并返回

**方法签名：**
```java
public Map<String,Object> createColumn()
```

**返回值：**
- `Map<String,Object>`: 返回客户端报表列元数据信息

---
