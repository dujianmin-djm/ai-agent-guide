---
framework_version: "8.0.1"
api_class: "ConvertRuleElement"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用转换规则时"
---

# ConvertRuleElement API 说明

## 概述
转换规则。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.ConvertRuleElement;
```

---

## 方法列表

### check

检查规则配置是否合理

**方法签名：**
```java
public boolean check(CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `parentPoint`: `CheckPoint` — 父检查点
- `checkResult`: `CheckResult` — 输出检查结果
- `elementMap`: `Map<Integer,ExtControlElement>`

**返回值：**
- `boolean`

---

### getAttachmentPanelMapPolicy

附件面板映射策略

**方法签名：**
```java
public AttachmentPanelMapPolicy getAttachmentPanelMapPolicy()
```

**返回值：**
- `AttachmentPanelMapPolicy`

---

### getBillTypeMapPolicy

单据类型映射策略

**方法签名：**
```java
public BillTypeMapPolicy getBillTypeMapPolicy()
```

**返回值：**
- `BillTypeMapPolicy`

---

### getBizRulePolicy

业务规则策略

**方法签名：**
```java
public BizRulePolicy getBizRulePolicy()
```

**返回值：**
- `BizRulePolicy`

---

### getCacheVersion

运行时版本，格式：yyyy-MM-dd hh:mm:ss

**方法签名：**
```java
public String getCacheVersion()
```

**返回值：**
- `String`

---

### getCheckVersionTimeMillis

最近一次检查版本时间

**方法签名：**
```java
public long getCheckVersionTimeMillis()
```

**返回值：**
- `long`

---

### getExtElements

开闭策略节点信息

**方法签名：**
```java
public List<kd.ExtControlElement> getExtElements()
```

**返回值：**
- `List<kd.ExtControlElement>`

---

### getFieldMapPolicy

主实体字段映射策略

**方法签名：**
```java
public FieldMapPolicy getFieldMapPolicy()
```

**返回值：**
- `FieldMapPolicy`

---

### getFilterPolicy

过滤策略

**方法签名：**
```java
public FilterPolicy getFilterPolicy()
```

**返回值：**
- `FilterPolicy`

---

### getGroupByPolicy

分单合并策略

**方法签名：**
```java
public GroupByPolicy getGroupByPolicy()
```

**返回值：**
- `GroupByPolicy`

---

### getId

自动生成的唯一标识，永不改变

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getLinkEntityPolicy

关联主实体策略

**方法签名：**
```java
public LinkEntityPolicy getLinkEntityPolicy()
```

**返回值：**
- `LinkEntityPolicy`

---

### getName

规则名称，用户输入

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getOptionPolicy

单据转换选项控制策略

**方法签名：**
```java
public OptionPolicy getOptionPolicy()
```

**返回值：**
- `OptionPolicy`

---

### getPlugInPolicy

插件策略

**方法签名：**
```java
public PlugInPolicy getPlugInPolicy()
```

**返回值：**
- `PlugInPolicy`

---

### getRunCondition

启动条件

**方法签名：**
```java
public CRCondition getRunCondition()
```

**返回值：**
- `CRCondition`

---

### getSourceEntityNumber

源单实体编码

**方法签名：**
```java
public String getSourceEntityNumber()
```

**返回值：**
- `String`

---

### getSysStatus

出厂时的状态：0 = 正常；1 = 禁用；出厂时的禁用状态最优先

**方法签名：**
```java
public String getSysStatus()
```

**返回值：**
- `String`

---

### getTargetEntityNumber

目标单实体编码

**方法签名：**
```java
public String getTargetEntityNumber()
```

**返回值：**
- `String`

---

### isAutoSave

是否自动保存

**方法签名：**
```java
public boolean isAutoSave()
```

**返回值：**
- `boolean`

---

### isBillPush

整单下推

**方法签名：**
```java
public boolean isBillPush()
```

**返回值：**
- `boolean`

---

### isDefRule

是否默认规则

**方法签名：**
```java
public boolean isDefRule()
```

**返回值：**
- `boolean`

---

### isDrawVisibled

选单时是否显示出来供用户选择

**方法签名：**
```java
public boolean isDrawVisibled()
```

**返回值：**
- `boolean`

---

### isEnabled

是否启用

**方法签名：**
```java
public boolean isEnabled()
```

**返回值：**
- `boolean`

---

### isNormual

判断反写规则是否正常启用

**方法签名：**
```java
public boolean isNormual()
```

**返回值：**
- `boolean`

---

### isVisibled

运行时是否显示出来供用户选择

**方法签名：**
```java
public boolean isVisibled()
```

**返回值：**
- `boolean`

---

### isVisibledCtrl

运行时可见控制

**方法签名：**
```java
public boolean isVisibledCtrl()
```

**返回值：**
- `boolean`

---

### setAttachmentPanelMapPolicy

附件面板映射策略

**方法签名：**
```java
public void setAttachmentPanelMapPolicy(AttachmentPanelMapPolicy attachmentPanelMapPolicy)
```

**参数说明：**
- `attachmentPanelMapPolicy`: `AttachmentPanelMapPolicy`

---

### setAutoSave

是否自动保存

**方法签名：**
```java
public void setAutoSave(boolean autoSave)
```

**参数说明：**
- `autoSave`: `boolean`

---

### setBillPush

整单下推

**方法签名：**
```java
public void setBillPush(boolean billPush)
```

**参数说明：**
- `billPush`: `boolean`

---

### setBillTypeMapPolicy

单据类型映射策略

**方法签名：**
```java
public void setBillTypeMapPolicy(BillTypeMapPolicy billTypeMapPolicy)
```

**参数说明：**
- `billTypeMapPolicy`: `BillTypeMapPolicy`

---

### setBizRulePolicy

业务规则策略

**方法签名：**
```java
public void setBizRulePolicy(BizRulePolicy bizRulePolicy)
```

**参数说明：**
- `bizRulePolicy`: `BizRulePolicy`

---

### setCacheVersion

设置运行时版本

**方法签名：**
```java
public void setCacheVersion(String cacheVersion)
```

**参数说明：**
- `cacheVersion`: `String`

---

### setCheckVersionTimeMillis

设置最近一次检查版本时间

**方法签名：**
```java
public void setCheckVersionTimeMillis(long checkVersionTimeMillis)
```

**参数说明：**
- `checkVersionTimeMillis`: `long`

---

### setDefRule

设置是否默认规则

**方法签名：**
```java
public void setDefRule(boolean defRule)
```

**参数说明：**
- `defRule`: `boolean`

---

### setDrawVisibled

选单时是否显示出来供用户选择

**方法签名：**
```java
public void setDrawVisibled(boolean drawVisibled)
```

**参数说明：**
- `drawVisibled`: `boolean`

---

### setEnabled

设置是否启用

**方法签名：**
```java
public void setEnabled(boolean enabled)
```

**参数说明：**
- `enabled`: `boolean`

---

### setExtElements

开闭策略节点信息

**方法签名：**
```java
public void setExtElements(List<kd.ExtControlElement> extElements)
```

**参数说明：**
- `extElements`: `List<kd.ExtControlElement>`

---

### setFieldMapPolicy

主实体字段映射策略

**方法签名：**
```java
public void setFieldMapPolicy(FieldMapPolicy fieldMapPolicy)
```

**参数说明：**
- `fieldMapPolicy`: `FieldMapPolicy`

---

### setFilterPolicy

过滤策略

**方法签名：**
```java
public void setFilterPolicy(FilterPolicy filterPolicy)
```

**参数说明：**
- `filterPolicy`: `FilterPolicy`

---

### setGroupByPolicy

分单合并策略

**方法签名：**
```java
public void setGroupByPolicy(GroupByPolicy groupByPolicy)
```

**参数说明：**
- `groupByPolicy`: `GroupByPolicy`

---

### setId

自动生成的唯一标识，永不改变

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setLinkEntityPolicy

关联主实体策略

**方法签名：**
```java
public void setLinkEntityPolicy(LinkEntityPolicy linkEntityPolicy)
```

**参数说明：**
- `linkEntityPolicy`: `LinkEntityPolicy`

---

### setName

规则名称，用户输入

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setOptionPolicy

单据转换选项控制策略

**方法签名：**
```java
public void setOptionPolicy(OptionPolicy optionPolicy)
```

**参数说明：**
- `optionPolicy`: `OptionPolicy`

---

### setPlugInPolicy

插件策略

**方法签名：**
```java
public void setPlugInPolicy(PlugInPolicy plugInPolicy)
```

**参数说明：**
- `plugInPolicy`: `PlugInPolicy`

---

### setRunCondition

设置启动条件

**方法签名：**
```java
public void setRunCondition(CRCondition runCondition)
```

**参数说明：**
- `runCondition`: `CRCondition`

---

### setSourceEntityNumber

源单实体编码

**方法签名：**
```java
public void setSourceEntityNumber(String sourceEntityNumber)
```

**参数说明：**
- `sourceEntityNumber`: `String`

---

### setSysStatus

设置系统出厂状态

**方法签名：**
```java
public void setSysStatus(String sysStatus)
```

**参数说明：**
- `sysStatus`: `String`

---

### setTargetEntityNumber

目标单实体编码

**方法签名：**
```java
public void setTargetEntityNumber(String targetEntityNumber)
```

**参数说明：**
- `targetEntityNumber`: `String`

---

### setVisibled

运行时是否显示出来供用户选择

**方法签名：**
```java
public void setVisibled(boolean visibled)
```

**参数说明：**
- `visibled`: `boolean`

---

### setVisibledCtrl

设置运行时可见控制

**方法签名：**
```java
public void setVisibledCtrl(boolean visibledCtrl)
```

**参数说明：**
- `visibledCtrl`: `boolean`

---
