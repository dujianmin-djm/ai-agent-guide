---
framework_version: "8.0.1"
api_class: "FieldMapPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用主实体字段映射策略时"
---

# FieldMapPolicy API 说明

## 概述
主实体字段映射策略。
主要功能：状态判断、读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.FieldMapPolicy;
```

---

## 方法列表

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### getFieldMaps

字段映射集合

**方法签名：**
```java
public List<kd.FieldMapItem> getFieldMaps()
```

**返回值：**
- `List<kd.FieldMapItem>`

---

### isAllowCrossEntityMapping

是否允许跨实体映射

**方法签名：**
```java
public boolean isAllowCrossEntityMapping()
```

**返回值：**
- `boolean`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### setAllowCrossEntityMapping

设置是否允许跨实体映射

**方法签名：**
```java
public void setAllowCrossEntityMapping(boolean allowCrossEntityMapping)
```

**参数说明：**
- `allowCrossEntityMapping`: `boolean`

---
