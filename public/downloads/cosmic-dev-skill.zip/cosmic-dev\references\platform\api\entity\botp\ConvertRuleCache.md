---
framework_version: "8.0.1"
api_class: "ConvertRuleCache"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用获取转换规则时"
---

# ConvertRuleCache API 说明

## 概述
获取转换规则。
主要功能：查询数据。

## Import 路径
```java
import kd.bos.entity.botp.ConvertRuleCache;
```

---

## 方法列表

### batchLoadRules

批量读取两个单据之间的全部转换规则

**方法签名：**
```java
public static Map<kd.ConvertRuleKeyPair,List<kd.ConvertRuleElement>> batchLoadRules(List<kd.ConvertRuleKeyPair> keys)
```

**参数说明：**
- `keys`: `List<kd.ConvertRuleKeyPair>`

**返回值：**
- `Map<kd.ConvertRuleKeyPair,List<kd.ConvertRuleElement>>`

---

### clearAllConvertRuleCache

清除全部转换规则的缓存

**方法签名：**
```java
public static synchronized void clearAllConvertRuleCache()
```

---

### clearConvertRuleCache

清除指定规则的缓存

**方法签名：**
```java
public static void clearConvertRuleCache(String ruleId)
```

**参数说明：**
- `ruleId`: `String`

---

### loadDebugRule

输出监视用的规则内容，在出现问题时，使用此方法获取当前内存中的规则详情

**方法签名：**
```java
public static String loadDebugRule(String id, String cacheType)
```

**参数说明：**
- `id`: `String`
- `cacheType`: `String`

**返回值：**
- `String`

---

### loadRule

读取指定的转换规则

**方法签名：**
```java
public static ConvertRuleElement loadRule(String id)
```

**参数说明：**
- `id`: `String`

**返回值：**
- `ConvertRuleElement`

---

### loadRules

**重载 1**

读取指定的转换规则

**方法签名：**
```java
public static List<kd.ConvertRuleElement> loadRules(String[] ids)
```

**参数说明：**
- `ids`: `String[]`

**返回值：**
- `List<kd.ConvertRuleElement>`

---

**重载 2**

读取两个单据之间的全部转换规则

**方法签名：**
```java
public static List<kd.ConvertRuleElement> loadRules(String sourceEntityNumber, String targetEntityNumber)
```

**参数说明：**
- `sourceEntityNumber`: `String`
- `targetEntityNumber`: `String`

**返回值：**
- `List<kd.ConvertRuleElement>`

---
