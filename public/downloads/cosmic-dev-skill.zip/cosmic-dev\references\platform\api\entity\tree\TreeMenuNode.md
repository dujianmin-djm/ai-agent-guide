---
framework_version: "8.0.1"
api_class: "TreeMenuNode"
api_package: "kd.bos.entity.tree"
when_to_use: "当你需要使用树形菜单控件的子节点（菜单项）时"
---

# TreeMenuNode API 说明

## 概述
树形菜单控件的子节点（菜单项）。实现 Serializable。
主要功能：读取属性、设置属性、添加元素、移除元素。

## Import 路径
```java
import kd.bos.entity.tree.TreeMenuNode;
```

---

## 方法列表

### addChild

**重载 1**

添加单个子节点

**方法签名：**
```java
public TreeMenuNode addChild(TreeMenuNode node)
```

**参数说明：**
- `node`: `TreeMenuNode` — 子节点

**返回值：**
- `TreeMenuNode`: 返回当前节点，方便链式操作

---

**重载 2**

特定位置添加单个子节点

**方法签名：**
```java
public TreeMenuNode addChild(int i, TreeMenuNode node)
```

**参数说明：**
- `i`: `int`
- `node`: `TreeMenuNode` — 子节点

**返回值：**
- `TreeMenuNode`: 返回当前节点，方便链式操作

---

### addChildren

添加多个子节点

**方法签名：**
```java
public TreeMenuNode addChildren(List<kd.TreeMenuNode> nodes)
```

**参数说明：**
- `nodes`: `List<kd.TreeMenuNode>` — 子节点集合

**返回值：**
- `TreeMenuNode`: 返回当前节点，方便链式操作

---

### deleteChildNode

递归删除子节点

**方法签名：**
```java
public TreeMenuNode deleteChildNode(String id)
```

**参数说明：**
- `id`: `String` — 子节点

**返回值：**
- `TreeMenuNode`: 删除节点的上一级节点

---

### getActivedIconUrl

返回聚焦后的图标

**方法签名：**
```java
public String getActivedIconUrl()
```

**返回值：**
- `String`: 图标

---

### getChildPath

获取子节点路径

**方法签名：**
```java
public List<String> getChildPath(String id)
```

**参数说明：**
- `id`: `String` — 子节点标识

**返回值：**
- `List<String>`: 返回子节点的全部父级节点，按层级往下排列

---

### getChildren

返回子节点集合

**方法签名：**
```java
public List<kd.TreeMenuNode> getChildren()
```

**返回值：**
- `List<kd.TreeMenuNode>`: 子节点集合

---

### getGrayValid

灰度菜单标识

**方法签名：**
```java
public String getGrayValid()
```

**返回值：**
- `String`

---

### getIconUrl

返回图标

**方法签名：**
```java
public String getIconUrl()
```

**返回值：**
- `String`: 图标

---

### getId

返回本节点标识

**方法签名：**
```java
public final String getId()
```

**返回值：**
- `String`: 节点标识

---

### getMenuType

获取菜单类型，page为页面，link为打开链接

**方法签名：**
```java
public String getMenuType()
```

**返回值：**
- `String`: 菜单类型

---

### getNodeLevel

获取节点的层级，没有找到返回-1

**方法签名：**
```java
public int getNodeLevel(String id, int startLevel)
```

**参数说明：**
- `id`: `String` — 节点标识
- `startLevel`: `int` — 开始层级

**返回值：**
- `int`: 节点的层级

---

### getParentid

返回父节点标识

**方法签名：**
```java
public final String getParentid()
```

**返回值：**
- `String`: 父节点标识

---

### getText

返回节点显示内容

**方法签名：**
```java
public final String getText()
```

**返回值：**
- `String`: 显示内容

---

### getTreeNode

递归查找id所在节点（准确匹配）

**方法签名：**
```java
public TreeMenuNode getTreeNode(String id, int maxLevel)
```

**参数说明：**
- `id`: `String` — 节点标识
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）

**返回值：**
- `TreeMenuNode`: 返回查到的节点

---

### iterate

遍历所有节点

**方法签名：**
```java
public void iterate(int maxLevel, Consumer<kd.TreeMenuNode> callback)
```

**参数说明：**
- `maxLevel`: `int` — 最大遍历深度（子节点算第一层）
- `callback`: `Consumer<kd.TreeMenuNode>` — 回调函数，可以传个lambda表达式

---

### setActivedIconUrl

设置节点聚焦后的图标

**方法签名：**
```java
public void setActivedIconUrl(String activedIconUrl)
```

**参数说明：**
- `activedIconUrl`: `String` — 图标

---

### setChildren

设置子节点集合

**方法签名：**
```java
public void setChildren(List<kd.TreeMenuNode> arrayList)
```

**参数说明：**
- `arrayList`: `List<kd.TreeMenuNode>` — 子节点集合

---

### setGrayValid

设置灰度菜单标识

**方法签名：**
```java
public void setGrayValid(String grayValid)
```

**参数说明：**
- `grayValid`: `String`

---

### setIconUrl

设置图标

**方法签名：**
```java
public void setIconUrl(String iconUrl)
```

**参数说明：**
- `iconUrl`: `String` — 图标

---

### setId

设置本节点标识

**方法签名：**
```java
public final void setId(String value)
```

**参数说明：**
- `value`: `String` — 节点标识

---

### setMenuType

设置菜单类型，page为页面，link为打开链接

**方法签名：**
```java
public void setMenuType(String menuType)
```

**参数说明：**
- `menuType`: `String`

---

### setParentid

设置父节点标识

**方法签名：**
```java
public final void setParentid(String value)
```

**参数说明：**
- `value`: `String` — 父节点标识

---

### setText

设置节点显示内容

**方法签名：**
```java
public final void setText(String value)
```

**参数说明：**
- `value`: `String` — 显示内容

---
