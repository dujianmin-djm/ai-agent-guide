# cosmic-dev 技能包整合设计文档

**日期**：2026-03-24  
**状态**：已批准，待实施  
**范围**：`.cursor/skills/cosmic-dev/`（部署目录），源码同步更新 `cosmic-dev/`

---

## 背景与问题

cosmic-dev 技能包整合了四个原本独立开发的子系统：

| 子技能 | 职责 |
|--------|------|
| `cosmic-meta-api` | 苍穹 Open API 鉴权、接口调用、PDM 自动化 |
| `cosmic-meta-modeling` | 需求文档驱动元数据建模（buildMeta） |
| `cosmic-meta-modifier` | 已有表单元数据增量修改（modifyMeta） |
| `cosmic-gen` | 苍穹 Java 插件代码生成 |

整合后面临以下问题：

1. **Config 重复**：三份 config 文件（`skills/config.json`、`cosmic-meta-api/scripts/config.json`、`pdm-automation/config.json`）均含服务器连接信息，用户须手动配置多次
2. **路径机制割裂**：cosmic-meta-api 使用 `skill_env.json` + `setup.py` 生成机器绝对路径，与 cosmic-dev 的 SKILL_DIR 推算模式不兼容
3. **技能触发干扰**：路由规则未覆盖 cosmic-gen，上传需求文档的歧义场景缺少判断
4. **用户引导缺失**：两套 Pre-flight Gate 各自独立，用户初次使用体验割裂

---

## 设计决策

| 决策 | 选择 | 原因 |
|------|------|------|
| Config 合并 | 合并为一份 `skills/config.json` | 消除重复配置，用户只配一次 |
| 路径机制 | 废弃 `skill_env.json`，改用 SKILL_DIR 推算 | 部署即用，无中间状态文件 |
| `isv` 字段 | 两处合并为同一字段 | 业务确认两处值永远相同 |
| Pre-flight Gate | 两层门控，各自读统一 config | 轻量启动门 + 按需元数据门 |
| 路由规则 | 更新覆盖 cosmic-gen + 歧义消解 | 完整覆盖所有用户场景 |

---

## 节 1：统一 Config 结构

`skills/config.json` 作为整个技能包的唯一配置真源。

### 最终结构

```json
{
  "_initialized": false,
  "_comment": "统一配置文件。_initialized 由初始化向导自动管理。",
  "architecture": "plugin",
  "isv": "",
  "javaHome": "",
  "buildTool": "gradle",
  "enableCompile": false,
  "mavenHome": "",
  "maven": {
    "settingsPath": ""
  },
  "server": {
    "baseUrl": "http://127.0.0.1:8080",
    "tenantId": "ierp",
    "user": "",
    "appId": "",
    "appSecret": "",
    "accountId": "",
    "appNumber": "",
    "bizCloudName": ""
  },
  "pdm": {
    "baseUrl": "",
    "user": "",
    "appId": "",
    "appSecret": "",
    "accountId": "",
    "outputDir": "datamodel"
  }
}
```

### 字段来源与映射

| 新字段 | 原字段（原文件） | 说明 |
|--------|-----------------|------|
| `architecture` / `javaHome` / `buildTool` / `enableCompile` / `mavenHome` / `maven.*` | `skills/config.json`（原） | 不变 |
| `isv` | 两处同名字段合并 | 值相同，取一即可 |
| `server.baseUrl` | `base_url`（meta-api config） / `server.baseUrl`（cosmic-dev config） | 统一为 camelCase |
| `server.tenantId` | `tenant_id` | 默认值 `ierp` |
| `server.user` | `login_user` / `server.user` | 统一 |
| `server.appId` / `appSecret` / `accountId` | 两处同名合并 | 统一 |
| `server.appNumber` | `app_number` | 由 `setConfig` / `getDevInfo` 自动写入 |
| `server.bizCloudName` | `bizCloudName` | 由 `setConfig` 自动写入 |
| `pdm.baseUrl/user/appId/appSecret/accountId` | `datamodel.*`（pdm-automation/config.json） | PDM 专用环境，可与 server 不同 |
| `pdm.outputDir` | `datamodel.output` | 重命名更清晰 |
| `_initialized` | `skill_env.json._initialized` | 迁移至 config.json |

### 硬编码移除

原 `cosmic-meta-api/scripts/config.json` 中以下字段在所有环境值固定，改为脚本内硬编码：

| 字段 | 硬编码值 |
|------|---------|
| `api_base_path` | `/ierp/kapi/v2/devportal/ai-meta` |
| `user_type` | `Mobile` |
| `language` | `zh_CN` |

### 废弃文件

- `skills/cosmic-meta-api/scripts/config.json` ❌
- `skills/cosmic-meta-api/scripts/pdm-automation/config.json` ❌
- `skills/cosmic-meta-api/skill_env.json` ❌
- `skills/cosmic-meta-api/setup.py` ❌

---

## 节 2：脚本路径与 Config 读取迁移

### 路径推算规则

所有脚本通过自身 `__file__` 位置推算路径，零依赖外部状态文件：

```python
from pathlib import Path

# cosmic_api.py / artifact_manager.py / lookup_basedata.py 等
# 位于 skills/cosmic-meta-api/scripts/
SCRIPT_DIR       = Path(__file__).parent
META_API_DIR     = SCRIPT_DIR.parent
CONFIG_PATH      = SCRIPT_DIR.parent.parent / "config.json"  # skills/config.json
RUNTIME_DIR      = META_API_DIR / "runtime"
ARTIFACTS_DIR    = RUNTIME_DIR / "artifacts"
BATCH_DIR        = RUNTIME_DIR / "batch_manifests"
```

```python
# pdm_auto.py / pdm_client.py
# 位于 skills/cosmic-meta-api/scripts/pdm-automation/
CONFIG_PATH = Path(__file__).parent.parent.parent.parent / "config.json"  # skills/config.json
```

### cosmic_api.py 字段映射

读取 `skills/config.json` 后，内部映射到原变量名（脚本内部逻辑不变）：

```python
cfg     = json.load(open(CONFIG_PATH))
server  = cfg.get("server", {})

base_url    = server.get("baseUrl", "")
tenant_id   = server.get("tenantId", "ierp")
account_id  = server.get("accountId", "")
app_id      = server.get("appId", "")
app_secret  = server.get("appSecret", "")
login_user  = server.get("user", "")
isv         = cfg.get("isv", "")
app_number  = server.get("appNumber", "")
biz_cloud   = server.get("bizCloudName", "")

# 硬编码
api_base_path = "/ierp/kapi/v2/devportal/ai-meta"
user_type     = "Mobile"
language      = "zh_CN"
```

### cosmic_api.py 函数级变更清单

除读取路径和字段映射外，以下函数均需重写：

| 函数 | 变更说明 |
|------|---------|
| `_update_config_json()` | 原写平铺字段到 `scripts/config.json`，改为写嵌套 `server.*` 字段到 `skills/config.json` |
| `_clear_main_config_credentials()` | `defaults` 字典从平铺结构改为嵌套 `server.*` 结构，目标文件改为 `skills/config.json` |
| `_clear_pdm_config_credentials()` | 原清空 `pdm-automation/config.json`，整个函数重写为清空 `skills/config.json` 的 `pdm.*` 字段 |
| `_regenerate_skill_env_json()` | 该函数及 `--regenerate-skill-env` 参数整体删除（setup.py 废弃，功能不再需要） |
| `_api_url()` | 读取由 `cfg["base_url"]`（平铺）改为 `server["baseUrl"]`（嵌套） |

变量命名：`CONFIG_FILE` 统一重命名为 `CONFIG_PATH`，与其他脚本保持一致。

### pdm_auto.py / pdm_client.py 架构重写

**背景**：原 `pdm_client.py` 使用双 Config 间接引用机制：
- `env=server`：从 `pdm-automation/config.json._cosmicConfig` 找到 `scripts/config.json`，读平铺字段
- `env=datamodel`：从 `pdm-automation/config.json.datamodel` 读凭据

删除 `pdm-automation/config.json` 后，此机制消失，需整体重写。

**新机制**：直接从统一 `skills/config.json` 的两个节读取：

```python
# pdm_client.py 新的凭据解析（伪代码）
def resolve_credentials(cfg: dict, env: str) -> dict:
    if env == "server":
        s = cfg.get("server", {})
        return {
            "baseUrl":    s.get("baseUrl", ""),
            "user":       s.get("user", ""),
            "appId":      s.get("appId", ""),
            "appSecret":  s.get("appSecret", ""),
            "accountId":  s.get("accountId", ""),
        }
    elif env == "datamodel":
        p = cfg.get("pdm", {})
        return {
            "baseUrl":    p.get("baseUrl", ""),
            "user":       p.get("user", ""),
            "appId":      p.get("appId", ""),
            "appSecret":  p.get("appSecret", ""),
            "accountId":  p.get("accountId", ""),
            "outputDir":  p.get("outputDir", "datamodel"),
        }
```

**pdm_auto.py**：`config.json` 默认路径（原 `os.path.join(script_dir, 'config.json')` 指向 `pdm-automation/config.json`）改为：

```python
CONFIG_PATH = Path(__file__).parent.parent.parent.parent / "config.json"  # skills/config.json
```

**需删除的函数**：`cosmic_config_to_pdm_credentials()`、`datamodel_block_to_pdm_credentials()`（被新 `resolve_credentials()` 统一替代）。

### artifact_manager.py

删除 `_resolve_artifacts_dir()` 函数（含 `skill_env.json` 读取逻辑），改为模块级常量（不再支持自定义路径）：

```python
ARTIFACTS_DIR = Path(__file__).parent.parent / "runtime" / "artifacts"
os.makedirs(ARTIFACTS_DIR, exist_ok=True)
```

### Python 可执行路径

不再从任何配置文件读取，遵循 cosmic-dev 规则：

- Windows → `python`
- Linux/macOS → `python3`

SKILL.md 中统一表述：`{python}` 由 AI 根据操作系统决定。

### SKILL.md 中路径引用规范

```
SKILL_DIR = 本 SKILL.md 文件所在目录（读取时从文件路径推算）

cosmic-meta-api/SKILL.md：
  CONFIG    = SKILL_DIR/../config.json         （= skills/config.json）
  SCRIPTS   = SKILL_DIR/scripts/
  RUNTIME   = SKILL_DIR/runtime/
  cosmic_api = SKILL_DIR/scripts/cosmic_api.py
```

---

## 节 3：Pre-flight Gate 统一

### 两层门控设计

**Layer 1 — cosmic-dev 启动门（轻量，每次技能激活）**

位于 `cosmic-dev/SKILL.md` 开头：

```
检查 skills/config.json 是否存在
  → 不存在：提示复制 config.example.json 并填写必填项，停止执行
  → 存在：读取配置，静默通过，继续执行用户请求
```

不做字段完整性检查，不阻断——字段校验由各子技能按需触发。

**Layer 2 — Meta-API Pre-flight Gate（按需，仅元数据操作时触发）**

位于 `cosmic-meta-api/modules/init/SKILL.md`，保持现有完整流程，改动点：

- 所有路径改为 SKILL_DIR 模式（移除 skill_env.json 引用）
- `_initialized` 标志读写位置改为 `skills/config.json`
- 字段检查改为读 `server.*`（新字段名）
- 引导写入目标改为 `skills/config.json`

```
Step G0：读取 skills/config.json
Step G1：检查 server.appId / appSecret / accountId / user 是否全部非空
  → 全部非空 且 _initialized=true  → 静默通过，执行原始请求
  → 有空字段 且 _initialized=false → 进入引导（G2~G6）
  → 有空字段 且 _initialized=true  → 警告用户字段缺失（"config.json 中 server.* 存在空值"），
                                      提示运行 RST ENV 重新初始化或手动补填，停止执行

引导流程（逻辑不变）：
  G2 引导填写凭据
  G3 auth 鉴权验证
  G4 bizApps 列表选择
  G5 getDevInfo（自动写入 isv、appNumber）
  G6 标记 _initialized=true（写入 skills/config.json）
```

### resetEnv 更新

`cosmic_api.py resetEnv` 命令重置 `_initialized` 时，目标改为 `skills/config.json`（而非原 `skill_env.json`）。

---

## 节 4：技能触发与路由

### 更新后的路由规则（`cosmic-skill-routing.md`）

```
用户说的是...
│
├─ 上传需求文档 / 直接描述需求
│   ├─ 含 "建单据" / "建表单" / "创建元数据" / "建模" / "基础资料" / "主数据"
│   │   → 读取 cosmic-dev/skills/cosmic-meta-modeling/SKILL.md
│   │
│   ├─ 含 "插件" / "业务逻辑" / "联动" / "校验" / "提交" / "代码"
│   │   → 读取 cosmic-dev/SKILL.md（进入 cosmic-gen 流程）
│   │
│   └─ 无法判断
│       → 询问用户：「您是要建元数据（新建单据结构），还是开发插件逻辑（生成 Java 代码）？」
│
├─ "写插件" / "新建插件" / "开发业务逻辑" / "生成代码"
│   → 读取 cosmic-dev/SKILL.md
│
├─ "建单据" / "需求建模" / "创建元数据" / "一键建模" / "建基础资料"
│   → 读取 cosmic-dev/skills/cosmic-meta-modeling/SKILL.md
│
├─ "改单据" / "加字段" / "删字段" / "改必填" / "改类型" / "修改元数据"
│   → 读取 cosmic-dev/skills/cosmic-meta-modifier/SKILL.md
│   ⚠️ 禁止用 buildMeta 代替 modifyMeta
│
├─ "生成PDM" / "同步数据模型" / "生成建表脚本"
│   → 从 runtime/context.md 获取 entityKey → 执行 pdm_auto.py
│
├─ "重置环境" / "RST ENV" / "rst env"
│   → 读取 cosmic-dev/skills/cosmic-meta-api/modules/reset/SKILL.md
│
├─ "跑测试" / "验证元数据" / "测试建模" / "设计测试用例"
│   → 读取 cosmic-meta-test/SKILL.md
│
└─ （其余场景由 cosmic-dev/SKILL.md 的入口判断处理）
```

### Sub-skill 的 SKILL_DIR 说明（各子技能 SKILL.md 开头统一加入）

```
> **路径推算**：SKILL_DIR = 本文件所在目录的绝对路径。
> CONFIG = SKILL_DIR/../config.json（即 skills/config.json）
> 禁止硬编码任何绝对路径；python 命令按 OS 决定（Windows: python，Linux/macOS: python3）。
```

---

## 节 5：变更清单

### 修改文件

| 文件 | 变更内容 |
|------|---------|
| `skills/config.json` | 合并三份 config，新增 `pdm.*`、`_initialized`、字段重命名 |
| `skills/config.example.json` | 与新结构保持一致 |
| `skills/cosmic-meta-api/scripts/cosmic_api.py` | **架构性重写**（见节 2 函数级清单）：CONFIG_FILE→CONFIG_PATH；读取路径改为 skills/config.json；`_update_config_json`、`_clear_main_config_credentials`、`_clear_pdm_config_credentials` 重写；`_regenerate_skill_env_json` 及参数删除；`_api_url` 字段更新 |
| `skills/cosmic-meta-api/scripts/artifact_manager.py` | 删除 `_resolve_artifacts_dir()`，改为模块级常量 `ARTIFACTS_DIR`（不再支持自定义路径） |
| `skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py` | **架构性重写**：默认 config 路径改为 skills/config.json，废弃 `_cosmicConfig` 间接引用机制 |
| `skills/cosmic-meta-api/scripts/pdm-automation/pdm_client.py` | **架构性重写**：删除双 Config 间接引用函数，新增 `resolve_credentials(cfg, env)` 直接读 server/pdm 两节 |
| `skills/cosmic-meta-api/modules/init/SKILL.md` | SKILL_DIR 路径，移除 skill_env.json 引用，字段名更新 |
| `skills/cosmic-meta-api/modules/usage/SKILL.md` | 移除 skill_env.json 字段说明，改为 SKILL_DIR 说明 |
| `skills/cosmic-meta-api/modules/reset/SKILL.md` | `_initialized` 重置说明更新 |
| `skills/cosmic-meta-api/SKILL.md` | 共用资源表 + 目录结构图更新 |
| `skills/cosmic-meta-modeling/SKILL.md` | Step 0 路径改为 SKILL_DIR，移除 skill_env.json 引用 |
| `skills/cosmic-meta-modifier/SKILL.md` | Step 0 路径同上 |
| `skills/cosmic-dev/SKILL.md`（即根 SKILL.md） | 启动门简化，config 字段说明更新 |
| `.cursor/rules/cosmic-skill-routing.md` | 全面重写（路径 + cosmic-gen + 歧义消解） |

### 删除文件

| 文件 | 原因 |
|------|------|
| `skills/cosmic-meta-api/scripts/config.json` | 废弃，内容迁入 `skills/config.json` |
| `skills/cosmic-meta-api/scripts/pdm-automation/config.json` | 废弃，`pdm.*` 迁入 `skills/config.json`；`_git`/`_git_comment` 字段因功能未启用，随文件一同废弃不迁移 |
| `skills/cosmic-meta-api/skill_env.json` | 废弃，改用 SKILL_DIR 模式 |
| `skills/cosmic-meta-api/setup.py` | 废弃，不再需要路径生成文件 |

### 不变范围

- `scripts/ops_manager.py`、`lookup_basedata.py`、`import_basedata_txt_to_sqlite.py`
- `cosmic-meta-modeling/` 的所有 prompts、knowledge、checklists、scripts
- `cosmic-meta-modifier/` 的 metaop-reference、batch-mode、modules/
- `cosmic-gen/` 内部完全不动
- `cosmic-meta-test/` 不动

---

## 实施顺序建议

1. **Config 合并**：先更新 `skills/config.json` + `config.example.json`
2. **Python 脚本**：更新 `cosmic_api.py`、`artifact_manager.py`、`pdm_auto.py`、`pdm_client.py`
3. **SKILL.md 文件**：更新所有路径引用（可并行）
4. **路由规则**：更新 `cosmic-skill-routing.md`
5. **删除废弃文件**：`scripts/config.json`、`pdm-automation/config.json`、`skill_env.json`、`setup.py`
6. **验证**：在 `.cursor/skills/cosmic-dev/` 部署版本上做端到端测试
