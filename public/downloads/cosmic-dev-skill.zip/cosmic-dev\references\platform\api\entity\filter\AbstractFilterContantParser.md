---
framework_version: "8.0.1"
api_class: "AbstractFilterContantParser"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用自定义比较符扩展插件基类时"
---

# AbstractFilterContantParser API 说明

## 概述
自定义比较符扩展插件基类。实现 IConditionVariableAnalysis。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.AbstractFilterContantParser;
```

---

## 方法列表

### getScriptFilter

将常量解析成脚本

**方法签名：**
```java
public void getScriptFilter(ConditionVariableContext ctx)
```

**参数说明：**
- `ctx`: `ConditionVariableContext`

---

### getVariableFilter

将常量解析成QFilter

**方法签名：**
```java
public void getVariableFilter(ConditionVariableContext ctx)
```

**参数说明：**
- `ctx`: `ConditionVariableContext`

---
