---
framework_version: "8.0.1"
api_class: "TypesContainer"
api_package: "kd.bos.dataentity"
when_to_use: "当你需要使用类实例反射构造工具时"
---

# TypesContainer API 说明

## 概述
类实例反射构造工具，可提升构建效率。
主要功能：创建对象、读取属性、移除元素。

## Import 路径
```java
import kd.bos.dataentity.TypesContainer;
```

---

## 方法列表

### createInstance

**重载 1**

通过类全限定名创建对象实例

**方法签名：**
```java
public static Object createInstance(String className)
```

**参数说明：**
- `className`: `String` — 类全限定名

**返回值：**
- `Object`: 返回对象实例

---

**重载 2**

通过类类型创建对象实例

**方法签名：**
```java
public static Object createInstance(Class<?> cls)
```

**参数说明：**
- `cls`: `Class<?>` — 类类型

**返回值：**
- `Object`: 对象实例

---

### getOrRegister

获取或者注册（加载）类

**方法签名：**
```java
public static Class<?> getOrRegister(String type)
```

**参数说明：**
- `type`: `String` — 类全限定名

**返回值：**
- `Class<?>`: 类类型

---

### getOrRegisterSingletonInstance

获取或者注册单例对象

**方法签名：**
```java
public static Object getOrRegisterSingletonInstance(String type)
```

**参数说明：**
- `type`: `String` — 类全限定名

**返回值：**
- `Object`: 单例对象

---

### removeRegister

移除注册（加载）类

**方法签名：**
```java
public static void removeRegister(String type)
```

**参数说明：**
- `type`: `String`

---
