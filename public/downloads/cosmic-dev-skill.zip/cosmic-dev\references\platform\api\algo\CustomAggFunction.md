---
framework_version: "8.0.1"
api_class: "CustomAggFunction"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用自定义聚合函数,在对DataSet分组后使用时"
---

# CustomAggFunction API 说明

## 概述
自定义聚合函数,在对DataSet分组后使用，对分组后的值进行处理得到一个聚合值，譬如sum,min等，。
主要功能：读取属性、添加元素、创建对象。

## Import 路径
```java
import kd.bos.algo.CustomAggFunction;
```

---

## 方法列表

### addValue

两个普通值进行聚合

**方法签名：**
```java
public abstract T addValue(T aggValue, Object value)
```

**参数说明：**
- `aggValue`: `T` — 聚合值
- `value`: `Object` — 原值，非聚合值

**返回值：**
- `T`: 聚合后的值

---

### combineAggValue

对两个聚合值进行聚合

**方法签名：**
```java
public abstract T combineAggValue(T aggValue, T aggValue2)
```

**参数说明：**
- `aggValue`: `T` — 聚合值1
- `aggValue2`: `T` — 聚合值2

**返回值：**
- `T`: 聚合后的值

---

### getFunName

获取函数名称

**方法签名：**
```java
public String getFunName()
```

**返回值：**
- `String`: 函数名称

---

### getResult

获取聚合后的结果

**方法签名：**
```java
public abstract Object getResult(T aggValue)
```

**参数说明：**
- `aggValue`: `T` — 聚合值

**返回值：**
- `Object`: 聚合后的结果

---

### getResultDataType

获取数据类型

**方法签名：**
```java
public DataType getResultDataType()
```

**返回值：**
- `DataType`: 数据类型

---

### newAggValue

获取聚合后的结果

**方法签名：**
```java
public abstract T newAggValue()
```

**返回值：**
- `T`: 聚合后的结果

---
