---
framework_version: "8.0.1"
api_class: "ControlFilters"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用列表过滤条件原始值实例类集合时"
---

# ControlFilters API 说明

## 概述
列表过滤条件原始值实例类集合。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.ControlFilters;
```

---

## 方法列表

### getAndFilter

获取二次过滤条件

**方法签名：**
```java
public List<Map<String,List<Object>>> getAndFilter()
```

**返回值：**
- `List<Map<String,List<Object>>>`

---

### getCurrentControlFilter

获取当前列表过滤条件原始值比较符

**方法签名：**
```java
public ControlFilter getCurrentControlFilter()
```

**返回值：**
- `ControlFilter`

---

### getFastFilter

获取快速搜素过滤值

**方法签名：**
```java
public List<Object> getFastFilter(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

**返回值：**
- `List<Object>`

---

### getFilter

获取搜索内容值，方法不合理，请使用getFiltersListMap

**方法签名：**
```java
public List<Object> getFilter(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

**返回值：**
- `List<Object>`

---

### getFilters

过滤字段名与列表过滤条件原始值映射，方法不合理，请使用getFiltersListMap方法

**方法签名：**
```java
public Map<String,ControlFilter> getFilters()
```

**返回值：**
- `Map<String,ControlFilter>`

---

### getFiltersListMap

过滤字段名与列表过滤条件原始值映射

**方法签名：**
```java
public Map<String,List<kd.ControlFilter>> getFiltersListMap()
```

**返回值：**
- `Map<String,List<kd.ControlFilter>>`

---

### getSearchText

快速搜索内容

**方法签名：**
```java
public String getSearchText()
```

**返回值：**
- `String`

---

### setAndFilter

设置二次过滤条件

**方法签名：**
```java
public void setAndFilter(List<Map<String,List<Object>>> andFilter)
```

**参数说明：**
- `andFilter`: `List<Map<String,List<Object>>>`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
