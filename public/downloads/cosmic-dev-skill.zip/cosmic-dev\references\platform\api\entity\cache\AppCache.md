---
framework_version: "8.0.1"
api_class: "AppCache"
api_package: "kd.bos.entity.cache"
when_to_use: "当你需要使用业务应用缓存时"
---

# AppCache API 说明

## 概述
业务应用缓存。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.cache.AppCache;
```

---

## 方法列表

### get

获取业务应用缓存接口实现类，可基于此访问业务应用缓存

**方法签名：**
```java
public static IAppCache get(String appKey)
```

**参数说明：**
- `appKey`: `String` — 应用标识，如"gl"

**返回值：**
- `IAppCache`: 缓存接口实现类

---
