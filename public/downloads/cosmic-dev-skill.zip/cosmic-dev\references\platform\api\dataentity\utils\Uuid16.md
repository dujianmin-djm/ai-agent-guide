---
framework_version: "8.0.1"
api_class: "Uuid16"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用字符类型ID生成工具时"
---

# Uuid16 API 说明

## 概述
字符类型ID生成工具。实现 Serializable。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.dataentity.utils.Uuid16;
```

---

## 方法列表

### create

创建UUID16对象，与DB.genStringId由Base39（+、/、=、0-9、A-Z）字符集组成的随机ID，长度约12位

**方法签名：**
```java
public static Uuid16 create()
```

**返回值：**
- `Uuid16`: UUID16对象

---

### toString

输出字符串

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 字符串

---
