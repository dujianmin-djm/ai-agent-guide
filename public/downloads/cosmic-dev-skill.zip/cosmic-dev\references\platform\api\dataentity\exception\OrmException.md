---
framework_version: "8.0.1"
api_class: "OrmException"
api_package: "kd.bos.dataentity.exception"
when_to_use: "当你需要使用ORM异常类基类时"
---

# OrmException API 说明

## 概述
ORM异常类基类。继承自 RuntimeException，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.exception.OrmException;
```

---

## 方法列表

### getCode

获取异常编号

**方法签名：**
```java
public final String getCode()
```

**返回值：**
- `String`

---
