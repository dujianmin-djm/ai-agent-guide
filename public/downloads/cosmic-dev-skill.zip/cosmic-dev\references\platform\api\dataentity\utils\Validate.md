---
framework_version: "8.0.1"
api_class: "Validate"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用This class assists in validating arguments. The validation m时"
---

# Validate API 说明

## 概述
This class assists in validating arguments. The validation methods are。
主要功能：状态判断。

## Import 路径
```java
import kd.bos.dataentity.utils.Validate;
```

---

## 方法列表

### exclusiveBetween

**重载 1**

Validate that the specified argument object fall between the two
 exclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void exclusiveBetween(T start, T end, Comparable<T> value)
```

**参数说明：**
- `start`: `T` — the exclusive start value, not null
- `end`: `T` — the exclusive end value, not null
- `value`: `Comparable<T>` — the object to validate, not null

---

**重载 2**

Validate that the specified argument object fall between the two
 exclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void exclusiveBetween(T start, T end, Comparable<T> value, String message, Object[] values)
```

**参数说明：**
- `start`: `T` — the exclusive start value, not null
- `end`: `T` — the exclusive end value, not null
- `value`: `Comparable<T>` — the object to validate, not null
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

**重载 3**

Validate that the specified primitive value falls between the two
 exclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void exclusiveBetween(long start, long end, long value)
```

**参数说明：**
- `start`: `long` — the exclusive start value
- `end`: `long` — the exclusive end value
- `value`: `long` — the value to validate

---

**重载 4**

Validate that the specified primitive value falls between the two
 exclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void exclusiveBetween(long start, long end, long value, String message)
```

**参数说明：**
- `start`: `long` — the exclusive start value
- `end`: `long` — the exclusive end value
- `value`: `long` — the value to validate
- `message`: `String` — the exception message if invalid, not null

---

**重载 5**

Validate that the specified primitive value falls between the two
 exclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void exclusiveBetween(double start, double end, double value)
```

**参数说明：**
- `start`: `double` — the exclusive start value
- `end`: `double` — the exclusive end value
- `value`: `double` — the value to validate

---

**重载 6**

Validate that the specified primitive value falls between the two
 exclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void exclusiveBetween(double start, double end, double value, String message)
```

**参数说明：**
- `start`: `double` — the exclusive start value
- `end`: `double` — the exclusive end value
- `value`: `double` — the value to validate
- `message`: `String` — the exception message if invalid, not null

---

### inclusiveBetween

**重载 1**

Validate that the specified argument object fall between the two
 inclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void inclusiveBetween(T start, T end, Comparable<T> value)
```

**参数说明：**
- `start`: `T` — the inclusive start value, not null
- `end`: `T` — the inclusive end value, not null
- `value`: `Comparable<T>` — the object to validate, not null

---

**重载 2**

Validate that the specified argument object fall between the two
 inclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void inclusiveBetween(T start, T end, Comparable<T> value, String message, Object[] values)
```

**参数说明：**
- `start`: `T` — the inclusive start value, not null
- `end`: `T` — the inclusive end value, not null
- `value`: `Comparable<T>` — the object to validate, not null
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

**重载 3**

Validate that the specified primitive value falls between the two
 inclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void inclusiveBetween(long start, long end, long value)
```

**参数说明：**
- `start`: `long` — the inclusive start value
- `end`: `long` — the inclusive end value
- `value`: `long` — the value to validate

---

**重载 4**

Validate that the specified primitive value falls between the two
 inclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void inclusiveBetween(long start, long end, long value, String message)
```

**参数说明：**
- `start`: `long` — the inclusive start value
- `end`: `long` — the inclusive end value
- `value`: `long` — the value to validate
- `message`: `String` — the exception message if invalid, not null

---

**重载 5**

Validate that the specified primitive value falls between the two
 inclusive values specified; otherwise, throws an exception.

**方法签名：**
```java
public static void inclusiveBetween(double start, double end, double value)
```

**参数说明：**
- `start`: `double` — the inclusive start value
- `end`: `double` — the inclusive end value
- `value`: `double` — the value to validate

---

**重载 6**

Validate that the specified primitive value falls between the two
 inclusive values specified; otherwise, throws an exception with the
 specified message.

**方法签名：**
```java
public static void inclusiveBetween(double start, double end, double value, String message)
```

**参数说明：**
- `start`: `double` — the inclusive start value
- `end`: `double` — the inclusive end value
- `value`: `double` — the value to validate
- `message`: `String` — the exception message if invalid, not null

---

### isAssignableFrom

**重载 1**

Validates that the argument can be converted to the specified class, if not, throws an exception.
 
 This method is useful when validating that there will be no casting errors.

**方法签名：**
```java
public static void isAssignableFrom(Class<?> superType, Class<?> type)
```

**参数说明：**
- `superType`: `Class<?>` — the class the class must be validated against, not null
- `type`: `Class<?>` — the class to check, not null

---

**重载 2**

Validates that the argument can be converted to the specified class, if not throws an exception.
  
 This method is useful when validating if there will be no casting errors.

**方法签名：**
```java
public static void isAssignableFrom(Class<?> superType, Class<?> type, String message, Object[] values)
```

**参数说明：**
- `superType`: `Class<?>` — the class the class must be validated against, not null
- `type`: `Class<?>` — the class to check, not null
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

### isInstanceOf

**重载 1**

Validates that the argument is an instance of the specified class, if not throws an exception.
  
 This method is useful when validating according to an arbitrary class

**方法签名：**
```java
public static void isInstanceOf(Class<?> type, Object obj)
```

**参数说明：**
- `type`: `Class<?>` — the class the object must be validated against, not null
- `obj`: `Object` — the object to check, null throws an exception

---

**重载 2**

Validate that the argument is an instance of the specified class; otherwise
 throwing an exception with the specified message. This method is useful when
 validating according to an arbitrary class

**方法签名：**
```java
public static void isInstanceOf(Class<?> type, Object obj, String message, Object[] values)
```

**参数说明：**
- `type`: `Class<?>` — the class the object must be validated against, not null
- `obj`: `Object` — the object to check, null throws an exception
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

### isTrue

**重载 1**

Validate that the argument condition is ` true`; otherwise
 throwing an exception with the specified message. This method is useful when
 validating according to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void isTrue(boolean expression, String message, long value)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `value`: `long` — the value to append to the message when invalid

---

**重载 2**

Validate that the argument condition is ` true`; otherwise
 throwing an exception with the specified message. This method is useful when
 validating according to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void isTrue(boolean expression, String message, double value)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `value`: `double` — the value to append to the message when invalid

---

**重载 3**

Validate that the argument condition is ` true`; otherwise
 throwing an exception with the specified message. This method is useful when
 validating according to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void isTrue(boolean expression, String message, Object[] values)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

**重载 4**

Validate that the argument condition is ` true`; otherwise
 throwing an exception. This method is useful when validating according
 to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void isTrue(boolean expression)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check

---

### matchesPattern

**重载 1**

Validate that the specified argument character sequence matches the specified regular
 expression pattern; otherwise throwing an exception.

**方法签名：**
```java
public static void matchesPattern(CharSequence input, String pattern)
```

**参数说明：**
- `input`: `CharSequence` — the character sequence to validate, not null
- `pattern`: `String` — the regular expression pattern, not null

---

**重载 2**

Validate that the specified argument character sequence matches the specified regular
 expression pattern; otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static void matchesPattern(CharSequence input, String pattern, String message, Object[] values)
```

**参数说明：**
- `input`: `CharSequence` — the character sequence to validate, not null
- `pattern`: `String` — the regular expression pattern, not null
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---

### noNullElements

**重载 1**

Validate that the specified argument array is neither
 ` null` nor contains any elements that are ` null`;
 otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static Object noNullElements(T[] array, String message, Object[] values)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Object`: the validated array (never ` null` method for chaining)

---

**重载 2**

Validate that the specified argument array is neither
 ` null` nor contains any elements that are ` null`;
 otherwise throwing an exception.

**方法签名：**
```java
public static Object noNullElements(T[] array)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method

**返回值：**
- `Object`: the validated array (never ` null` method for chaining)

---

**重载 3**

Validate that the specified argument iterable is neither
 ` null` nor contains any elements that are ` null`;
 otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static Iterable noNullElements(T iterable, String message, Object[] values)
```

**参数说明：**
- `iterable`: `T` — the iterable to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Iterable`: the validated iterable (never ` null` method for chaining)

---

**重载 4**

Validate that the specified argument iterable is neither
 ` null` nor contains any elements that are ` null`;
 otherwise throwing an exception.

**方法签名：**
```java
public static Iterable noNullElements(T iterable)
```

**参数说明：**
- `iterable`: `T` — the iterable to check, validated not null by this method

**返回值：**
- `Iterable`: the validated iterable (never ` null` method for chaining)

---

### notBlank

**重载 1**

Validate that the specified argument character sequence is
 neither ` null`, a length of zero (no characters), empty
 nor whitespace; otherwise throwing an exception with the specified
 message.

**方法签名：**
```java
public static CharSequence notBlank(T chars, String message, Object[] values)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` method for chaining)

---

**重载 2**

Validate that the specified argument character sequence is
 neither ` null`, a length of zero (no characters), empty
 nor whitespace; otherwise throwing an exception.

**方法签名：**
```java
public static CharSequence notBlank(T chars)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` method for chaining)

---

### notEmpty

**重载 1**

Validate that the specified argument array is neither ` null`
 nor a length of zero (no elements); otherwise throwing an exception
 with the specified message.

**方法签名：**
```java
public static Object notEmpty(T[] array, String message, Object[] values)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Object`: the validated array (never ` null` method for chaining)

---

**重载 2**

Validate that the specified argument array is neither ` null`
 nor a length of zero (no elements); otherwise throwing an exception.

**方法签名：**
```java
public static Object notEmpty(T[] array)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method

**返回值：**
- `Object`: the validated array (never ` null` method for chaining)

---

**重载 3**

Validate that the specified argument collection is neither ` null`
 nor a size of zero (no elements); otherwise throwing an exception
 with the specified message.

**方法签名：**
```java
public static Collection notEmpty(T collection, String message, Object[] values)
```

**参数说明：**
- `collection`: `T` — the collection to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Collection`: the validated collection (never ` null` method for chaining)

---

**重载 4**

Validate that the specified argument collection is neither ` null`
 nor a size of zero (no elements); otherwise throwing an exception.

**方法签名：**
```java
public static Collection notEmpty(T collection)
```

**参数说明：**
- `collection`: `T` — the collection to check, validated not null by this method

**返回值：**
- `Collection`: the validated collection (never ` null` method for chaining)

---

**重载 5**

Validate that the specified argument map is neither ` null`
 nor a size of zero (no elements); otherwise throwing an exception
 with the specified message.

**方法签名：**
```java
public static Map notEmpty(T map, String message, Object[] values)
```

**参数说明：**
- `map`: `T` — the map to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Map`: the validated map (never ` null` method for chaining)

---

**重载 6**

Validate that the specified argument map is neither ` null`
 nor a size of zero (no elements); otherwise throwing an exception.

**方法签名：**
```java
public static Map notEmpty(T map)
```

**参数说明：**
- `map`: `T` — the map to check, validated not null by this method

**返回值：**
- `Map`: the validated map (never ` null` method for chaining)

---

**重载 7**

Validate that the specified argument character sequence is
 neither ` null` nor a length of zero (no characters);
 otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static CharSequence notEmpty(T chars, String message, Object[] values)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` method for chaining)

---

**重载 8**

Validate that the specified argument character sequence is
 neither ` null` nor a length of zero (no characters);
 otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static CharSequence notEmpty(T chars)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` method for chaining)

---

### notNull

**重载 1**

Validate that the specified argument is not ` null`;
 otherwise throwing an exception.

**方法签名：**
```java
public static Object notNull(T object)
```

**参数说明：**
- `object`: `T` — the object to check

**返回值：**
- `Object`: the validated object (never ` null` for method chaining)

---

**重载 2**

Validate that the specified argument is not ` null`;
 otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static Object notNull(T object, String message, Object[] values)
```

**参数说明：**
- `object`: `T` — the object to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message

**返回值：**
- `Object`: the validated object (never ` null` for method chaining)

---

### validIndex

**重载 1**

Validates that the index is within the bounds of the argument
 array; otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static Object validIndex(T[] array, int index, String message, Object[] values)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method
- `index`: `int` — the index to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Object`: the validated array (never ` null` for method chaining)

---

**重载 2**

Validates that the index is within the bounds of the argument
 array; otherwise throwing an exception.

**方法签名：**
```java
public static Object validIndex(T[] array, int index)
```

**参数说明：**
- `array`: `T[]` — the array to check, validated not null by this method
- `index`: `int` — the index to check

**返回值：**
- `Object`: the validated array (never ` null` for method chaining)

---

**重载 3**

Validates that the index is within the bounds of the argument
 collection; otherwise throwing an exception with the specified message.

**方法签名：**
```java
public static Collection validIndex(T collection, int index, String message, Object[] values)
```

**参数说明：**
- `collection`: `T` — the collection to check, validated not null by this method
- `index`: `int` — the index to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `Collection`: the validated collection (never ` null` for chaining)

---

**重载 4**

Validates that the index is within the bounds of the argument
 collection; otherwise throwing an exception.

**方法签名：**
```java
public static Collection validIndex(T collection, int index)
```

**参数说明：**
- `collection`: `T` — the collection to check, validated not null by this method
- `index`: `int` — the index to check

**返回值：**
- `Collection`: the validated collection (never ` null` for method chaining)

---

**重载 5**

Validates that the index is within the bounds of the argument
 character sequence; otherwise throwing an exception with the
 specified message.

**方法签名：**
```java
public static CharSequence validIndex(T chars, int index, String message, Object[] values)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method
- `index`: `int` — the index to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` for method chaining)

---

**重载 6**

Validates that the index is within the bounds of the argument
 character sequence; otherwise throwing an exception.

**方法签名：**
```java
public static CharSequence validIndex(T chars, int index)
```

**参数说明：**
- `chars`: `T` — the character sequence to check, validated not null by this method
- `index`: `int` — the index to check

**返回值：**
- `CharSequence`: the validated character sequence (never ` null` for method chaining)

---

### validState

**重载 1**

Validate that the stateful condition is ` true`; otherwise
 throwing an exception. This method is useful when validating according
 to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void validState(boolean expression)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check

---

**重载 2**

Validate that the stateful condition is ` true`; otherwise
 throwing an exception with the specified message. This method is useful when
 validating according to an arbitrary boolean expression, such as validating a
 primitive number or using your own custom validation expression.

**方法签名：**
```java
public static void validState(boolean expression, String message, Object[] values)
```

**参数说明：**
- `expression`: `boolean` — the boolean expression to check
- `message`: `String` — the Object...) exception message if invalid, not null
- `values`: `Object[]` — the optional values for the formatted exception message, null array not recommended

---
