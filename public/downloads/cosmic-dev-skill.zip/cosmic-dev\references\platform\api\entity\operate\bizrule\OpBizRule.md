---
framework_version: "8.0.1"
api_class: "OpBizRule"
api_package: "kd.bos.entity.operate.bizrule"
when_to_use: "当你需要使用操作服务运行时元数据对象时"
---

# OpBizRule API 说明

## 概述
操作服务运行时元数据对象，存储运行时需要用到的服务属性值。。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.bizrule.OpBizRule;
```

---

## 方法列表

### getKey

获取主键

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getName

获取操作名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getParameter

获取参数字符串，json格式，由各操作服务执行类自行解析

**方法签名：**
```java
public String getParameter()
```

**返回值：**
- `String`

---

### getPreConditionDesc

获取前置条件描述

**方法签名：**
```java
public LocaleString getPreConditionDesc()
```

**返回值：**
- `LocaleString`

---

### getPrecondition

获取前置条件

**方法签名：**
```java
public String getPrecondition()
```

**返回值：**
- `String`

---

### getRuleType

获取服务类型，需要据此取到服务执行类名

**方法签名：**
```java
public String getRuleType()
```

**返回值：**
- `String`

---

### setKey

设置主键

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String`

---

### setName

设置操作名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setParameter

设置参数字符串，json格式，由各操作服务执行类自行解析

**方法签名：**
```java
public void setParameter(String parameter)
```

**参数说明：**
- `parameter`: `String`

---

### setPreConditionDesc

设置前置条件描述

**方法签名：**
```java
public void setPreConditionDesc(LocaleString preConditionDesc)
```

**参数说明：**
- `preConditionDesc`: `LocaleString`

---

### setPrecondition

设置前置条件

**方法签名：**
```java
public void setPrecondition(String precondition)
```

**参数说明：**
- `precondition`: `String`

---

### setRuleType

设置服务类型，需要据此取到服务执行类名

**方法签名：**
```java
public void setRuleType(String ruleType)
```

**参数说明：**
- `ruleType`: `String`

---
