---
framework_version: "8.0.1"
api_class: "IDataEntityBinder"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用实体序列化时"
---

# IDataEntityBinder API 说明

## 概述
实体序列化，类型解析绑定接口。
主要功能：状态判断。

## Import 路径
```java
import kd.bos.dataentity.serialization.IDataEntityBinder;
```

---

## 方法列表

### isSerializProperty

是否序列化目标属性

**方法签名：**
```java
public default boolean isSerializProperty(IDataEntityProperty prop, DataEntitySerializerOption option)
```

**参数说明：**
- `prop`: `IDataEntityProperty` — 目标属性
- `option`: `DataEntitySerializerOption` — 序列化选项

**返回值：**
- `boolean`

---
