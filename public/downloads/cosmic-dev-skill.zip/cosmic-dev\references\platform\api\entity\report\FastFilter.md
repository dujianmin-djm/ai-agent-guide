---
framework_version: "8.0.1"
api_class: "FastFilter"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用过滤容器快速过滤条件时"
---

# FastFilter API 说明

## 概述
过滤容器快速过滤条件。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.report.FastFilter;
```

---

## 方法列表

### getFastFilter

获取快速过滤条件：原始过滤条件设置

**方法签名：**
```java
public List<Map<String,List<Object>>> getFastFilter()
```

**返回值：**
- `List<Map<String,List<Object>>>`: 返回数据字典，过滤字段为Key，比较值集合为Value

---

### getQFilters

获取过滤条件：已把过滤字段和比较值组合起来，生成了最终取数条件

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getValue

根据过滤字段名获取过滤字段值

**方法签名：**
```java
public List<Object> getValue(String propName)
```

**参数说明：**
- `propName`: `String` — 过滤字段名

**返回值：**
- `List<Object>`

---
