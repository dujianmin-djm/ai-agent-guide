---
framework_version: "8.0.1"
api_class: "IReportTreeModel"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用树形报表数据模型接口时"
---

# IReportTreeModel API 说明

## 概述
树形报表数据模型接口。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.report.IReportTreeModel;
```

---

## 方法列表

### getProgress

当前进度信息

**方法签名：**
```java
public int getProgress()
```

**返回值：**
- `int`

---

### getTreeModel

获取树形报表model

**方法签名：**
```java
public TreeModel getTreeModel()
```

**返回值：**
- `TreeModel`

---
