---
framework_version: "8.0.1"
api_class: "DtsConfigOperatorInfo"
api_package: "kd.bos.dts.configoperator"
when_to_use: "当你需要使用配置信息时"
---

# DtsConfigOperatorInfo API 说明

## 概述
配置信息。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.dts.configoperator.DtsConfigOperatorInfo;
```

---

## 方法列表

### getBusinessType

获取业务类型

**方法签名：**
```java
public String getBusinessType()
```

**返回值：**
- `String`

---

### getDtsDestType

获取目标地址类型

**方法签名：**
```java
public DtsDestTypeEnum getDtsDestType()
```

**返回值：**
- `DtsDestTypeEnum`

---

### getEnable

获取启用状态

**方法签名：**
```java
public String getEnable()
```

**返回值：**
- `String`: 0禁用  1启用

---

### getEntityFields

获取同步字段

**方法签名：**
```java
public String[] getEntityFields()
```

**返回值：**
- `String[]`

---

### getEntityNumber

获取实体编码

**方法签名：**
```java
public String getEntityNumber()
```

**返回值：**
- `String`

---

### getMappingRule

获取映射规则

**方法签名：**
```java
public String getMappingRule()
```

**返回值：**
- `String`

---

### getRegion

获取目标地址标识

**方法签名：**
```java
public String getRegion()
```

**返回值：**
- `String`

---

### getTimingSequence

获取时序字段

**方法签名：**
```java
public String getTimingSequence()
```

**返回值：**
- `String`

---

### setBusinessType

设置业务类型

**方法签名：**
```java
public void setBusinessType(String businessType)
```

**参数说明：**
- `businessType`: `String`

---

### setDtsDestType

设置目标地址类型

**方法签名：**
```java
public void setDtsDestType(DtsDestTypeEnum dtsDestType)
```

**参数说明：**
- `dtsDestType`: `DtsDestTypeEnum`

---

### setEnable

设置启用状态

**方法签名：**
```java
public void setEnable(String enable)
```

**参数说明：**
- `enable`: `String` — 0禁用  1启用

---

### setEntityFields

设置同步字段

**方法签名：**
```java
public void setEntityFields(String[] entityFields)
```

**参数说明：**
- `entityFields`: `String[]`

---

### setEntityNumber

设置实体编码

**方法签名：**
```java
public void setEntityNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String`

---

### setMappingRule

设置映射规则

**方法签名：**
```java
public void setMappingRule(String mappingRule)
```

**参数说明：**
- `mappingRule`: `String`

---

### setRegion

设置目标地址标识

**方法签名：**
```java
public void setRegion(String region)
```

**参数说明：**
- `region`: `String`

---

### setTimingSequence

设置时序字段

**方法签名：**
```java
public void setTimingSequence(String timingSequence)
```

**参数说明：**
- `timingSequence`: `String`

---
