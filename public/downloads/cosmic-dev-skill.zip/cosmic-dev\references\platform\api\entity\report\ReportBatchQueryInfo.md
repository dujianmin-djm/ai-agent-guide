---
framework_version: "8.0.1"
api_class: "ReportBatchQueryInfo"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用批量查询信息-分批加载数据时"
---

# ReportBatchQueryInfo API 说明

## 概述
批量查询信息-分批加载数据。实现 Serializable, IReportBatchQueryInfo。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.report.ReportBatchQueryInfo;
```

---

## 方法列表

### getBatchBy

【过滤依据数据】

**方法签名：**
```java
public CachedDataSet getBatchBy()
```

**返回值：**
- `CachedDataSet`

---

### getBatchByDataSetCacheId

获取分批取数的【过滤依据数据】
 eg:以物料为分批依据，接口返回涉及的所有物料，
 然后query接口中通queryParam.getCurrentBatch获取当前分批，
 并可基于该分批过滤取数
 setC
 *ountPerBatch设置每批的个数，没设置时报表框架按【过滤依据数据】总行数的量级大致设置每批个数

**方法签名：**
```java
public String getBatchByDataSetCacheId()
```

**返回值：**
- `String`

---

### getBatchCount

获取总批次

**方法签名：**
```java
public int getBatchCount()
```

**返回值：**
- `int`

---

### getCountPerBatch

获取每批个数
 （-1:表示插件未设置， 没设置时报表框架按【过滤依据数据】总行数的量级大致设置每批个数）

**方法签名：**
```java
public int getCountPerBatch()
```

**返回值：**
- `int`

---

### getCurrentBatchIndex

获取当前批次(0基，起始批次为0)

**方法签名：**
```java
public int getCurrentBatchIndex()
```

**返回值：**
- `int`

---

### getCurrentBatchRows

当前批次的行数据

**方法签名：**
```java
public List<Row> getCurrentBatchRows()
```

**返回值：**
- `List<Row>`

---

### getMaxExcelRowCountPerSheet

获取每个Excel表允许最大行数，超过时拆分文件(默认100w)

**方法签名：**
```java
public int getMaxExcelRowCountPerSheet()
```

**返回值：**
- `int`

---

### getMaxRowCountCached

获取最大缓存行数
 -超过时释放离当前较远的批次
 -翻页到已释放批次时解发query重新取数

**方法签名：**
```java
public int getMaxRowCountCached()
```

**返回值：**
- `int`

---

### isLargeData

获取是否大数据
 （指插件有实现重载AbstractReportListDataPlugin.queryBatchBy，一般数据量超10w考虑用这种分批加载方式）

**方法签名：**
```java
public boolean isLargeData()
```

**返回值：**
- `boolean`

---

### setBatchByDataSetCacheId

设置分批取数的【过滤依据数据】
 eg:以物料为分批依据，接口返回涉及的所有物料，
 然后query接口中通queryParam.getCurrentBatch获取当前分批，
 并可基于该分批过滤取数
 setCountPerBatch设置每批的个数，没设置时报表框架按【过滤依据数据】总行数的量级大致设置每批个数

**方法签名：**
```java
public void setBatchByDataSetCacheId(String batchByDataSetCacheId)
```

**参数说明：**
- `batchByDataSetCacheId`: `String`

---

### setCountPerBatch

设置每批个数（
 -1:表示插件未设置， 没设置时报表框架按【过滤依据数据】总行数的量级大致设置每批个数）

**方法签名：**
```java
public void setCountPerBatch(int countPerBatch)
```

**参数说明：**
- `countPerBatch`: `int` — 每批个数

---

### setCurrentBatchIndex

设置当前批次(0基，起始批次为0)

**方法签名：**
```java
public void setCurrentBatchIndex(int currentBatchIndex)
```

**参数说明：**
- `currentBatchIndex`: `int` — 当前批次

---

### setLargeData

设置是否大数据
 （指插件有实现重载AbstractReportListDataPlugin.queryBatchBy，一般数据量超10w考虑用这种分批加载方式）

**方法签名：**
```java
public void setLargeData(boolean largeData)
```

**参数说明：**
- `largeData`: `boolean` — 大数据

---

### setMaxExcelRowCountPerSheet

每个Excel表允许最大行数，超过时拆分文件(默认100w)

**方法签名：**
```java
public void setMaxExcelRowCountPerSheet(int maxExcelRowCountPerSheet)
```

**参数说明：**
- `maxExcelRowCountPerSheet`: `int` — 最大行数

---

### setMaxRowCountCached

获取最大缓存行数
 -超过时释放离当前较远的批次
 -翻页到已释放批次时解发query重新取数

**方法签名：**
```java
public void setMaxRowCountCached(int maxRowCountCached)
```

**参数说明：**
- `maxRowCountCached`: `int` — 最大缓存行数

---
