---
framework_version: "8.0.1"
api_class: "AnyType"
api_package: "kd.bos.algo.datatype"
when_to_use: "当你需要使用Algo中的一种数据类型时"
---

# AnyType API 说明

## 概述
Algo中的一种数据类型。继承自 DataType，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.datatype.AnyType;
```

---

## 方法列表

### acceptsType

是否是当前类型

**方法签名：**
```java
public boolean acceptsType(DataType other)
```

**参数说明：**
- `other`: `DataType` — 被判断的类型

**返回值：**
- `boolean`

---

### getJavaType

获取对应的Java类型

**方法签名：**
```java
public Class<?> getJavaType()
```

**返回值：**
- `Class<?>`

---

### getSqlType

返回对应的sql类型

**方法签名：**
```java
public int getSqlType()
```

**返回值：**
- `int`

---
