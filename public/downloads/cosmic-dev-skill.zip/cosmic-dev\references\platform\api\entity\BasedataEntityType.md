---
framework_version: "8.0.1"
api_class: "BasedataEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用基础资料实体类型时"
---

# BasedataEntityType API 说明

## 概述
基础资料实体类型。继承自 BillEntityType。
主要功能：读取属性、设置属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.BasedataEntityType;
```

---

## 方法列表

### createEntityTreeNodes

{待补充}

**方法签名：**
```java
public List<Map<String,Object>> createEntityTreeNodes(EntityTreeNode parentEntityTreeNode, boolean isIncludeEntry, boolean isAllNode)
```

**参数说明：**
- `parentEntityTreeNode`: `EntityTreeNode`
- `isIncludeEntry`: `boolean`
- `isAllNode`: `boolean`

**返回值：**
- `List<Map<String,Object>>`

---

### createRefPropsHashValue

计算引用属性的hash值

**方法签名：**
```java
public final void createRefPropsHashValue(boolean force)
```

**参数说明：**
- `force`: `boolean` — 是否强制

---

### getBasedataControllersProp

获取基础资料个性化控制器

**方法签名：**
```java
public List<kd.Plugin> getBasedataControllersProp()
```

**返回值：**
- `List<kd.Plugin>`

---

### getBillNo

获取单据编号

**方法签名：**
```java
public String getBillNo()
```

**返回值：**
- `String`

---

### getCacheFlag

{待补充}

**方法签名：**
```java
public String getCacheFlag()
```

**返回值：**
- `String`

---

### getCustomControllerProperty

获取基础资料自定义控制器

**方法签名：**
```java
public String getCustomControllerProperty()
```

**返回值：**
- `String`: 基础资料自定义控制器

---

### getFlexProperty

获取基础资料弹性域属性

**方法签名：**
```java
public String getFlexProperty()
```

**返回值：**
- `String`: 基础资料弹性域属性

---

### getFullIndexFields

获取全文索引字段

**方法签名：**
```java
public Set<String> getFullIndexFields()
```

**返回值：**
- `Set<String>`

---

### getMasteridPropName

获取主数据内码属性名：如果masterid不填值，此属性返回空

**方法签名：**
```java
public String getMasteridPropName()
```

**返回值：**
- `String`

---

### getMasteridType

获取主数据内码赋值方式：0 = 不赋值；1 = 本身数据id；2 = 关联主资料id

**方法签名：**
```java
public int getMasteridType()
```

**返回值：**
- `int`

---

### getMoblistFormId

获取formID

**方法签名：**
```java
public String getMoblistFormId()
```

**返回值：**
- `String`

---

### getNameProperty

获取基础资料名称属性

**方法签名：**
```java
public String getNameProperty()
```

**返回值：**
- `String`: 基础资料名称属性

---

### getNumberProperty

获取基础资料编码属性

**方法签名：**
```java
public String getNumberProperty()
```

**返回值：**
- `String`: 基础资料编码属性

---

### getSearchNumberKey

根据基础资料类型（主资料、业务政策），输出用于搜索的编码字段名：业务政策，输入编码时，搜索master.number字段

**方法签名：**
```java
public String getSearchNumberKey()
```

**返回值：**
- `String`

---

### isCache

{待补充}

**方法签名：**
```java
public boolean isCache()
```

**返回值：**
- `boolean`

---

### isDataLoadNoCache

获取数据加载时是否不使用缓存的设置
 
 此方法用于确定在加载数据时是否应忽略缓存数据，如果返回true，则表示每次加载数据时先从本地缓存中获取，地缓存不存在则直接从数据库加载

**方法签名：**
```java
public boolean isDataLoadNoCache()
```

**返回值：**
- `boolean`: 如果数据加载时不应使用缓存，则返回true；否则返回false

---

### isEnableNameVersion

是否支持修改产生历史记录

**方法签名：**
```java
public boolean isEnableNameVersion()
```

**返回值：**
- `boolean`

---

### setBasedataControllersProp

设置基础资料个性化控制器

**方法签名：**
```java
public void setBasedataControllersProp(List<kd.Plugin> basedataControllersProp)
```

**参数说明：**
- `basedataControllersProp`: `List<kd.Plugin>`

---

### setCustomControllerProperty

设置基础资料自定义控制器

**方法签名：**
```java
public void setCustomControllerProperty(String customControllerProp)
```

**参数说明：**
- `customControllerProp`: `String` — 基础资料自定义控制器

---

### setDataEntityReferenceSchema

{待补充}

**方法签名：**
```java
public void setDataEntityReferenceSchema(Object dataEntityReferenceSchema)
```

**参数说明：**
- `dataEntityReferenceSchema`: `Object`

---

### setDataLoadNoCache

设置数据加载时是否不使用缓存

**方法签名：**
```java
public void setDataLoadNoCache(boolean dataLoadNoCache)
```

**参数说明：**
- `dataLoadNoCache`: `boolean` — true表示数据加载时不使用缓存，false则使用缓存

---

### setEnableNameVersion

设置是否支持修改产生历史记录

**方法签名：**
```java
public void setEnableNameVersion(boolean enableNameVersion)
```

**参数说明：**
- `enableNameVersion`: `boolean`

---

### setFlexProperty

设置基础资料弹性域属性

**方法签名：**
```java
public void setFlexProperty(String flexProperty)
```

**参数说明：**
- `flexProperty`: `String` — 基础资料弹性域属性

---

### setMasteridPropName

设置主数据内码属性名：如果masterid不填值，此属性返回空

**方法签名：**
```java
public void setMasteridPropName(String masteridPropName)
```

**参数说明：**
- `masteridPropName`: `String`

---

### setMasteridType

设置主数据内码赋值方式：0 = 不赋值；1 = 本身数据id；2 = 关联主资料id

**方法签名：**
```java
public void setMasteridType(int masteridType)
```

**参数说明：**
- `masteridType`: `int`

---

### setMoblistFormId

设置formID

**方法签名：**
```java
public void setMoblistFormId(String moblistFormId)
```

**参数说明：**
- `moblistFormId`: `String`

---

### setNameProperty

设置基础资料名称属性

**方法签名：**
```java
public void setNameProperty(String nameProperty)
```

**参数说明：**
- `nameProperty`: `String` — 基础资料名称属性

---

### setNumberProperty

设置基础资料编码属性

**方法签名：**
```java
public void setNumberProperty(String numberProperty)
```

**参数说明：**
- `numberProperty`: `String` — 基础资料编码属性

---
