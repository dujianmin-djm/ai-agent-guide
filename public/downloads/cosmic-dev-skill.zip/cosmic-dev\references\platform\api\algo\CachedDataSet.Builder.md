---
framework_version: "8.0.1"
api_class: "CachedDataSet.Builder"
api_package: "kd.bos.algo.CachedDataSet"
when_to_use: "当你需要使用创建CacheDataSet的Builder时"
---

# CachedDataSet.Builder API 说明

## 概述
创建CacheDataSet的Builder。
主要功能：添加行、通过迭代器添加行。

## Import 路径
```java
import kd.bos.algo.CachedDataSet.CachedDataSet.Builder;
```

---

## 方法列表

### append

**重载 1**

添加行

**方法签名：**
```java
public void append(Row row)
```

**参数说明：**
- `row`: `Row` — 行信息

---

**重载 2**

通过迭代器添加行

**方法签名：**
```java
public void append(Iterator<kd.Row> rowIterator)
```

**参数说明：**
- `rowIterator`: `Iterator<kd.Row>` — 迭代器

---
