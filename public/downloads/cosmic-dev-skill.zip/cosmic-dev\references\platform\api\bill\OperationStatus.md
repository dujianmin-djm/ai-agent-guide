---
framework_version: "8.0.1"
api_class: "OperationStatus"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用动态表单界面状态时"
---

# OperationStatus API 说明

## 概述
动态表单界面状态。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.bill.OperationStatus;
```

---

## 方法列表

### forValue

枚举类型转换，把整数转成枚举值

**方法签名：**
```java
public static OperationStatus forValue(int value)
```

**参数说明：**
- `value`: `int` — 整数值

**返回值：**
- `OperationStatus`: 枚举值

---

### getValue

返回整数型枚举值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`: 整数型枚举值

---
