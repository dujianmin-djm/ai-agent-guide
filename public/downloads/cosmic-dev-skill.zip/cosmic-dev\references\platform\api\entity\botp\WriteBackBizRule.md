---
framework_version: "8.0.1"
api_class: "WriteBackBizRule"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用反写规则 - 业务规则时"
---

# WriteBackBizRule API 说明

## 概述
反写规则 - 业务规则。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.WriteBackBizRule;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, String srcEntityKey, CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `srcEntityKey`: `String`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

---

### getBizRuleFalse

条件失败时执行的业务规则

**方法签名：**
```java
public CRBizRuleElement getBizRuleFalse()
```

**返回值：**
- `CRBizRuleElement`

---

### getBizRuleTrue

条件成立时执行的业务规则

**方法签名：**
```java
public CRBizRuleElement getBizRuleTrue()
```

**返回值：**
- `CRBizRuleElement`

---

### getId

自动产生的唯一标识，据此与扩展对象，进行差量化对比定位

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getPreCondition

前置条件

**方法签名：**
```java
public CRCondition getPreCondition()
```

**返回值：**
- `CRCondition`

---

### getSeq

执行顺序

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### isEnabled

是否启用

**方法签名：**
```java
public boolean isEnabled()
```

**返回值：**
- `boolean`

---

### setBizRuleFalse

条件失败时执行的业务规则

**方法签名：**
```java
public void setBizRuleFalse(CRBizRuleElement bizRuleFalse)
```

**参数说明：**
- `bizRuleFalse`: `CRBizRuleElement`

---

### setBizRuleTrue

条件成立时执行的业务规则

**方法签名：**
```java
public void setBizRuleTrue(CRBizRuleElement bizRuleTrue)
```

**参数说明：**
- `bizRuleTrue`: `CRBizRuleElement`

---

### setEnabled

是否启用

**方法签名：**
```java
public void setEnabled(boolean enabled)
```

**参数说明：**
- `enabled`: `boolean`

---

### setId

唯一标识

**方法签名：**
```java
public void setId(String value)
```

**参数说明：**
- `value`: `String`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setPreCondition

前置条件

**方法签名：**
```java
public void setPreCondition(CRCondition preCondition)
```

**参数说明：**
- `preCondition`: `CRCondition`

---

### setSeq

执行顺序

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---
