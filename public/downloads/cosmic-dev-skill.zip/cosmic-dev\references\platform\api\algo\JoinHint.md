---
framework_version: "8.0.1"
api_class: "JoinHint"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用可以指定Join的方式时"
---

# JoinHint API 说明

## 概述
可以指定Join的方式，是使用nest,merge还是其他方式。。继承自 Hint，实现 ConcurrentMap, Serializable, Map。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.algo.JoinHint;
```

---

## 方法列表

### isNullAsZero

是否当值为Null时，当做0处理

**方法签名：**
```java
public boolean isNullAsZero()
```

**返回值：**
- `boolean`: 是否当值为Null时，当做0处理

---

### isUseMerge

是否是merge方式的join

**方法签名：**
```java
public boolean isUseMerge()
```

**返回值：**
- `boolean`

---

### isUseNest

join的方式是否为nest

**方法签名：**
```java
public boolean isUseNest()
```

**返回值：**
- `boolean`

---

### setNullAsZero

设置是否当值为Null时，当做0处理

**方法签名：**
```java
public void setNullAsZero(boolean nullAsZero)
```

**参数说明：**
- `nullAsZero`: `boolean`

---

### setUseMerge

设置Join方式为merge

**方法签名：**
```java
public void setUseMerge(boolean useMerge)
```

**参数说明：**
- `useMerge`: `boolean`

---

### setUseNest

设置Join的方式为nest

**方法签名：**
```java
public void setUseNest(boolean useNest)
```

**参数说明：**
- `useNest`: `boolean`

---
