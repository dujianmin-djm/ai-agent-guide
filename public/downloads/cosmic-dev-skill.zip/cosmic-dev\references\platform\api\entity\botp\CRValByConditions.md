---
framework_version: "8.0.1"
api_class: "CRValByConditions"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用单据转换规则时"
---

# CRValByConditions API 说明

## 概述
单据转换规则，字段映射，按条件取值。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.CRValByConditions;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType mainType, CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `mainType`: `MainEntityType`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

---

### getDescription

输出本项配置的取值内容，把各项的取值公式，拼接起来

**方法签名：**
```java
public String getDescription()
```

**返回值：**
- `String`

---

### getItems

取值项集合：
 按顺序，逐项比较条件，满足条件即返回选择项

**方法签名：**
```java
public List<kd.CRValByCondition> getItems()
```

**返回值：**
- `List<kd.CRValByCondition>`

---
