---
framework_version: "8.0.1"
api_class: "EndOperationTransactionArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用调用操作事务结束（事务内）事件参数时"
---

# EndOperationTransactionArgs API 说明

## 概述
调用操作事务结束（事务内）事件参数。继承自 OperationArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.EndOperationTransactionArgs;
```

---

## 方法列表

### getDataEntities

返回单据数据包

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`: 单据数据包

---
