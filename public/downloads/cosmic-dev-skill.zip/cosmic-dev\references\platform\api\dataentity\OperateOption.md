---
framework_version: "8.0.1"
api_class: "OperateOption"
api_package: "kd.bos.dataentity"
when_to_use: "当你需要使用操作选项（自定义参数）时"
---

# OperateOption API 说明

## 概述
操作选项（自定义参数），可以为数据的操作提供额外的选项。实现 Serializable。
主要功能：读取属性、创建对象、移除元素、设置属性。

## Import 路径
```java
import kd.bos.dataentity.OperateOption;
```

---

## 方法列表

### containsVariable

是否包含某个变量

**方法签名：**
```java
public abstract boolean containsVariable(String name)
```

**参数说明：**
- `name`: `String` — 变量名称

**返回值：**
- `boolean`: 是否包含

---

### copy

获取操作对象副本(浅拷贝)

**方法签名：**
```java
public abstract OperateOption copy()
```

**返回值：**
- `OperateOption`: 操作选项

---

### create

构建空的操作选项

**方法签名：**
```java
public static OperateOption create()
```

**返回值：**
- `OperateOption`: 操作选项

---

### getVariableValue

**重载 1**

从选项中获取定义的值

**方法签名：**
```java
public String getVariableValue(String name, String defaultValue)
```

**参数说明：**
- `name`: `String` — 选项的键，不区分大小写
- `defaultValue`: `String` — 如果没有找到选项定义，其缺省值是多少

**返回值：**
- `String`: 如果有定义，返回定义的值，否则返回缺省值

---

**重载 2**

获取某个变量的值，如果没有定义此变量，将抛出异常

**方法签名：**
```java
public String getVariableValue(String name)
```

**参数说明：**
- `name`: `String` — 变量的名称，不区分大小写

**返回值：**
- `String`: 变量值

---

### getVariables

获取所有变量

**方法签名：**
```java
public abstract Map<String,String> getVariables()
```

**返回值：**
- `Map<String,String>`: 以Map返回所有变量

---

### merge

创建一个新的操作选项，以当前的操作选项为优先，如果找不到将使用baseOption基础选项

**方法签名：**
```java
public OperateOption merge(OperateOption baseOption)
```

**参数说明：**
- `baseOption`: `OperateOption` — 基础选项

**返回值：**
- `OperateOption`: 返回一个新的选项对象

---

### mergeValue

合并操作选项

**方法签名：**
```java
public abstract OperateOption mergeValue(OperateOption other)
```

**参数说明：**
- `other`: `OperateOption` — 其它选项

**返回值：**
- `OperateOption`: 操作选项

---

### removeVariable

删除定义的值

**方法签名：**
```java
public abstract boolean removeVariable(String name)
```

**参数说明：**
- `name`: `String` — 变量名称

**返回值：**
- `boolean`: 是否成功删除

---

### setVariableValue

设置定义的值

**方法签名：**
```java
public abstract void setVariableValue(String name, String value)
```

**参数说明：**
- `name`: `String` — 选项的键，不区分大小写
- `value`: `String` — 定义的值

---

### tryGetVariableValue

尝试获取某个变量的值

**方法签名：**
```java
public abstract boolean tryGetVariableValue(String name, RefObject<String> result)
```

**参数说明：**
- `name`: `String` — 变量的名称，不区分大小写
- `result`: `RefObject<String>` — 变量的结果

**返回值：**
- `boolean`: 是否成功获取

---
