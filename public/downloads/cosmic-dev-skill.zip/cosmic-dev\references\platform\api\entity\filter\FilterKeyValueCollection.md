---
framework_version: "8.0.1"
api_class: "FilterKeyValueCollection"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用字段过滤元数据实例集合时"
---

# FilterKeyValueCollection API 说明

## 概述
字段过滤元数据实例集合。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterKeyValueCollection;
```

---

## 方法列表

### getFilterKeyValues

获取字段过滤元数据实例集合

**方法签名：**
```java
public List<kd.FilterKeyValue> getFilterKeyValues()
```

**返回值：**
- `List<kd.FilterKeyValue>`

---
