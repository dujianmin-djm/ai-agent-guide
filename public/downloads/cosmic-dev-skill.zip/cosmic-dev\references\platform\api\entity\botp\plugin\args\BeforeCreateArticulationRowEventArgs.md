---
framework_version: "8.0.1"
api_class: "BeforeCreateArticulationRowEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用构建本关联主实体时"
---

# BeforeCreateArticulationRowEventArgs API 说明

## 概述
构建本关联主实体，单行数据与源单的关联记录前，触发此事件：用于取消本行的关联、反写。继承自 WriteBackEventArgs。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeCreateArticulationRowEventArgs;
```

---

## 方法列表

### getActiveRow

关联主实体当前行

**方法签名：**
```java
public DynamicObject getActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getEntity

当前关联主实体

**方法签名：**
```java
public EntityType getEntity()
```

**返回值：**
- `EntityType`

---

### getLinkRows

关联主实体行下属的关联子实体行，包含了来源单据行信息

**方法签名：**
```java
public DynamicObjectCollection getLinkRows()
```

**返回值：**
- `DynamicObjectCollection`

---

### isCancel

是否取消创建本行的关联记录:
 取消后，相当于本行无源单，不会记录业务流程路线记录与反写源单

**方法签名：**
```java
public boolean isCancel()
```

**返回值：**
- `boolean`

---

### isCancelReDistributeAmount

由插件自行调整控制字段对各源单行的分配量，取消系统的自动分配处理；

**方法签名：**
```java
public boolean isCancelReDistributeAmount()
```

**返回值：**
- `boolean`

---

### setCancel

设置是否取消创建本行的关联记录

**方法签名：**
```java
public void setCancel(boolean cancel)
```

**参数说明：**
- `cancel`: `boolean`

---

### setCancelReDistributeAmount

设置由插件自行调整控制字段对各源单行的分配量，取消系统的自动分配处理

**方法签名：**
```java
public void setCancelReDistributeAmount(boolean cancelReDistributeAmount)
```

**参数说明：**
- `cancelReDistributeAmount`: `boolean`

---
