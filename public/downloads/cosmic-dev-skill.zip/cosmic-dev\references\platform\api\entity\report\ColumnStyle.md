---
framework_version: "8.0.1"
api_class: "ColumnStyle"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表列样式时"
---

# ColumnStyle API 说明

## 概述
报表列样式。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.ColumnStyle;
```

---

## 方法列表

### getBackColor

获取背景色

**方法签名：**
```java
public String getBackColor()
```

**返回值：**
- `String`

---

### getFontSize

获取字体大小

**方法签名：**
```java
public int getFontSize()
```

**返回值：**
- `int`: 字体大小，默认为12

---

### getForeColor

获取前景色

**方法签名：**
```java
public String getForeColor()
```

**返回值：**
- `String`

---

### getRadius

获取圆角半径

**方法签名：**
```java
public String getRadius()
```

**返回值：**
- `String`

---

### getTextAlign

获取文本对齐方式

**方法签名：**
```java
public String getTextAlign()
```

**返回值：**
- `String`: 文本对齐方式，默认为"left"

---

### setBackColor

设置背景色

**方法签名：**
```java
public void setBackColor(String backColor)
```

**参数说明：**
- `backColor`: `String` — 背景色

---

### setFontSize

设置字体大小

**方法签名：**
```java
public void setFontSize(int fontSize)
```

**参数说明：**
- `fontSize`: `int` — 字体大小

---

### setForeColor

设置前景色

**方法签名：**
```java
public void setForeColor(String foreColor)
```

**参数说明：**
- `foreColor`: `String` — 前景色

---

### setRadius

设置圆角半径

**方法签名：**
```java
public void setRadius(String radius)
```

**参数说明：**
- `radius`: `String` — 圆角半径

---

### setTextAlign

设置文本对齐方式

**方法签名：**
```java
public void setTextAlign(String textAlign)
```

**参数说明：**
- `textAlign`: `String` — 文本对齐方式

---
