---
framework_version: "8.0.1"
api_class: "BeforeOperationArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作校验通过时"
---

# BeforeOperationArgs API 说明

## 概述
操作校验通过，开启事务前事件参数。继承自 OperationArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.BeforeOperationArgs;
```

---

## 方法列表

### getDataEntities

返回已通过校验的单据数据包
 本方法和 getValidExtDataEntities()效果相同，只是本方法返回原始数据包，而getValidExtDataEntities()返回再包装后的数据包
 推荐使用 getValidExtDataEntities()方法

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`

---

### getValidExtDataEntities

返回已通过校验的单据数据包：对数据包进行了再包装，包含了数据索引
 插件可以进一步校验，调整此集合中的单据，从而排除不符合要求的单据
 getSelectedRows()有歧义，用此方法替代
 
 示例代码：
```java

**方法签名：**
```java
public List<kd.ExtendedDataEntity> getValidExtDataEntities()
```

**返回值：**
- `List<kd.ExtendedDataEntity>`

---

### setCancel

设置标志，取消操作
 
 示例代码：
```java

**方法签名：**
```java
public void setCancel(boolean cancel)
```

**参数说明：**
- `cancel`: `boolean` — 设为true，则取消操作执行

---

### setCancelMessage

设置取消操作的原因，以提示用户
 需和 ` e.setCancel(true)` 配合使用

**方法签名：**
```java
public void setCancelMessage(String cancelMessage)
```

**参数说明：**
- `cancelMessage`: `String` — 取消操作的原因

---
