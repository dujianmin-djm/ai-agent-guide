---
framework_version: "8.0.1"
api_class: "KDInteractionException"
api_package: "kd.bos.entity.operate.interaction"
when_to_use: "当你需要使用交互错误：插件通过抛出交互错误时"
---

# KDInteractionException API 说明

## 概述
交互错误：插件通过抛出交互错误，要求操作显示交互界面。继承自 KDBizException。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.operate.interaction.KDInteractionException;
```

---

## 方法列表

### getInteractionContext

交互上下文，包含了交互提示内容等

**方法签名：**
```java
public InteractionContext getInteractionContext()
```

**返回值：**
- `InteractionContext`: InteractionContext

---

### getSponsor

本次交互的唯一标识

**方法签名：**
```java
public String getSponsor()
```

**返回值：**
- `String`: String

---
