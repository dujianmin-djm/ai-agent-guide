---
framework_version: "8.0.1"
api_class: "MobileListF7Config"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用移动端F7列表配置时"
---

# MobileListF7Config API 说明

## 概述
移动端F7列表配置。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.param.MobileListF7Config;
```

---

## 方法列表

### getIconField

图标

**方法签名：**
```java
public String getIconField()
```

**返回值：**
- `String`: 图标

---

### getPrimaryField

主标题

**方法签名：**
```java
public String getPrimaryField()
```

**返回值：**
- `String`: 主标题

---

### getSecondField

副标题

**方法签名：**
```java
public String getSecondField()
```

**返回值：**
- `String`: 副标题

---

### isEnabledTree

是否开启树形列表

**方法签名：**
```java
public boolean isEnabledTree()
```

**返回值：**
- `boolean`: 是否开启树形列表

---

### setEnabledTree

设置是否开启树形列表

**方法签名：**
```java
public void setEnabledTree(boolean isEnabledTree)
```

**参数说明：**
- `isEnabledTree`: `boolean` — 是否开启树形列表

---

### setIconField

设置图标

**方法签名：**
```java
public void setIconField(String iconField)
```

**参数说明：**
- `iconField`: `String` — 图标

---

### setPrimaryField

设置主标题

**方法签名：**
```java
public void setPrimaryField(String primaryField)
```

**参数说明：**
- `primaryField`: `String` — 主标题

---

### setSecondField

设置副标题

**方法签名：**
```java
public void setSecondField(String secondField)
```

**参数说明：**
- `secondField`: `String` — 副标题

---
