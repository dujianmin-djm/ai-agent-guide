---
framework_version: "8.0.1"
api_class: "PreparePropertysEventArgs"
api_package: "kd.bos.entity.plugin"
when_to_use: "当你需要使用单据操作插件IOperationServicePlugIn - onPreparePropertys 事件参数时"
---

# PreparePropertysEventArgs API 说明

## 概述
单据操作插件IOperationServicePlugIn - onPreparePropertys 事件参数。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.PreparePropertysEventArgs;
```

---

## 方法列表

### getFieldKeys

获取待加载的字段集合
 插件把需加载的字段，添加到此集合中
 
 示例代码：
```java

**方法签名：**
```java
public List<String> getFieldKeys()
```

**返回值：**
- `List<String>`

---

### getIds

获取数据包的id集合

**方法签名：**
```java
public Object[] getIds()
```

**返回值：**
- `Object[]`

---

### setIds

设置数据包id集合

**方法签名：**
```java
public void setIds(Object[] ids)
```

**参数说明：**
- `ids`: `Object[]`

---
