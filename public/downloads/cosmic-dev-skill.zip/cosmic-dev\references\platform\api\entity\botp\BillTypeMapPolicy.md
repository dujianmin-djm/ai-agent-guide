---
framework_version: "8.0.1"
api_class: "BillTypeMapPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用单据类型映射策略时"
---

# BillTypeMapPolicy API 说明

## 概述
单据类型映射策略。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.BillTypeMapPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getItems

单据类型映射配置项

**方法签名：**
```java
public List<kd.BillTypeMapItem> getItems()
```

**返回值：**
- `List<kd.BillTypeMapItem>`

---
