---
framework_version: "8.0.1"
api_class: "DbInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用使用db作为构建DataSet的输入源,通过传入sql语句时"
---

# DbInput API 说明

## 概述
使用db作为构建DataSet的输入源,通过传入sql语句，从数据库查询数据后输出一个DataSet。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.DbInput;
```

---

## 方法列表

### getAlgoKey

获取algoKey

**方法签名：**
```java
public String getAlgoKey()
```

**返回值：**
- `String`: algoKey

---

### getParams

获取sql参数

**方法签名：**
```java
public Object[] getParams()
```

**返回值：**
- `Object[]`: sql参数

---

### getRequestContext

获取上下文

**方法签名：**
```java
public RequestContext getRequestContext()
```

**返回值：**
- `RequestContext`: 上下文

---

### getRouteKey

获取数据库路由key

**方法签名：**
```java
public String getRouteKey()
```

**返回值：**
- `String`: 数据库路由key

---

### getRowMeta

获取元素据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元素据

---

### getSql

获取sql语句

**方法签名：**
```java
public String getSql()
```

**返回值：**
- `String`: sql语句

---
