---
framework_version: "8.0.1"
api_class: "ObjectConverter"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用类型转换器时"
---

# ObjectConverter API 说明

## 概述
类型转换器。
主要功能：转换原始对象为目标类型 ， 若找不到转换。

## Import 路径
```java
import kd.bos.dataentity.entity.ObjectConverter;
```

---

## 方法列表

### convert

**重载 1**

转换原始对象为目标类型 ， 若找不到转换器会返回原始对象

**方法签名：**
```java
public static Object convert(Object value, Class<T> cls)
```

**参数说明：**
- `value`: `Object` — 原对象
- `cls`: `Class<T>` — 目标类型

**返回值：**
- `Object`: 目标类型对象

---

**重载 2**

转换原始对象为目标类型 ， 若找不到转换器会返回原始对象

**方法签名：**
```java
public static Object convert(Object value, Class<T> cls, boolean enableNull)
```

**参数说明：**
- `value`: `Object` — 原对象
- `cls`: `Class<T>` — 目标类型
- `enableNull`: `boolean` — 不转换null对象

**返回值：**
- `Object`: 目标类型对象

---
