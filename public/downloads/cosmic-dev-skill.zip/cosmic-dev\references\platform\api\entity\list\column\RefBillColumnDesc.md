---
framework_version: "8.0.1"
api_class: "RefBillColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用引用单据格式化字段时"
---

# RefBillColumnDesc API 说明

## 概述
引用单据格式化字段。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.RefBillColumnDesc;
```

---

## 方法列表

### getColumnDesc

获取引用属性格式化工具类

**方法签名：**
```java
public AbstractColumnDesc getColumnDesc()
```

**返回值：**
- `AbstractColumnDesc`

---

### getDesensitizeValue

{待补充}

**方法签名：**
```java
public Object getDesensitizeValue(String localeid, DynamicObject dynamicObject, Object value)
```

**参数说明：**
- `localeid`: `String`
- `dynamicObject`: `DynamicObject`
- `value`: `Object`

**返回值：**
- `Object`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---
