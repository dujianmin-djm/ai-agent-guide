---
framework_version: "8.0.1"
api_class: "TempFileCacheDownloadable"
api_package: "kd.bos.cache.tempfile"
when_to_use: "当你需要使用 TempFileCacheDownloadable 相关功能时"
---

# TempFileCacheDownloadable API 说明

## 概述
TempFileCacheDownloadable 类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.cache.tempfile.TempFileCacheDownloadable;
```

---

## 方法列表

### download

通过HTTP请求下载临时文件

**方法签名：**
```java
public TempFileCacheDownloadable.Content download(HttpServletRequest request)
```

**参数说明：**
- `request`: `HttpServletRequest` — HTTP请求对象，需包含configKey/id等必要参数

**返回值：**
- `TempFileCacheDownloadable.Content`: 文件内容封装对象，包含文件流和元数据

---

### get

通过configKey和id获取文件内容

**方法签名：**
```java
public TempFileCacheDownloadable.Content get(String configKey, String id)
```

**参数说明：**
- `configKey`: `String` — 存储配置标识符
- `id`: `String` — 文件唯一标识符

**返回值：**
- `TempFileCacheDownloadable.Content`: 文件内容封装对象

---
