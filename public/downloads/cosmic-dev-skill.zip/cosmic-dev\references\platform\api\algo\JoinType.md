---
framework_version: "8.0.1"
api_class: "JoinType"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用join类型:包括inner join,left join,right join,full join,cross joi时"
---

# JoinType API 说明

## 概述
join类型:包括inner join,left join,right join,full join,cross join。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.JoinType;
```

---

## 方法列表

### getName

获取JoinType的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---
