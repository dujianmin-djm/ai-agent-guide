---
framework_version: "8.0.1"
api_class: "QueryResult"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用列表查询结果时"
---

# QueryResult API 说明

## 概述
列表查询结果。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.QueryResult;
```

---

## 方法列表

### getBillDataCount

获取单据数量

**方法签名：**
```java
public int getBillDataCount()
```

**返回值：**
- `int`: 单据数量

---

### getCollection

获取结果集合

**方法签名：**
```java
public DynamicObjectCollection getCollection()
```

**返回值：**
- `DynamicObjectCollection`: 结果集合

---

### getDataCount

获取查询记录数量

**方法签名：**
```java
public int getDataCount()
```

**返回值：**
- `int`: 查询记录数量

---

### getFormatRowDatas

获取引出和套打需要的格式数据

**方法签名：**
```java
public List<kd.FormatRowData> getFormatRowDatas()
```

**返回值：**
- `List<kd.FormatRowData>`: 引出和套打需要的格式数据

---

### getSummaryResults

获取汇总结果列表

**方法签名：**
```java
public List<kd.SummaryResult> getSummaryResults()
```

**返回值：**
- `List<kd.SummaryResult>`: 汇总结果列表

---

### setBillDataCount

设置单据数量，IdQuery使用

**方法签名：**
```java
public void setBillDataCount(int billDataCount)
```

**参数说明：**
- `billDataCount`: `int` — 单据数量

---

### setCollection

设置结果集合

**方法签名：**
```java
public void setCollection(DynamicObjectCollection collection)
```

**参数说明：**
- `collection`: `DynamicObjectCollection` — 结果集合

---

### setDataCount

设置条数,IdQuery使用

**方法签名：**
```java
public void setDataCount(int dataCount)
```

**参数说明：**
- `dataCount`: `int` — 条数

---

### setFormatRowDatas

设置引出和套打需要的格式数据

**方法签名：**
```java
public void setFormatRowDatas(List<kd.FormatRowData> formatRowDatas)
```

**参数说明：**
- `formatRowDatas`: `List<kd.FormatRowData>` — 引出和套打需要的格式数据

---

### setSummaryResults

设置汇总结果列表

**方法签名：**
```java
public void setSummaryResults(List<kd.SummaryResult> summaryResults)
```

**参数说明：**
- `summaryResults`: `List<kd.SummaryResult>` — 汇总结果列表

---
