---
framework_version: "8.0.1"
api_class: "IntegerType"
api_package: "kd.bos.algo.datatype"
when_to_use: "当你需要使用Algo中的数据类型,对应Java类型为Integer时"
---

# IntegerType API 说明

## 概述
Algo中的数据类型,对应Java类型为Integer。继承自 IntegralType，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.datatype.IntegerType;
```

---

## 方法列表

### getJavaType

返回对应的Java类型

**方法签名：**
```java
public Class<?> getJavaType()
```

**返回值：**
- `Class<?>`: 对应的Java类型

---

### getSqlType

获取对应的数据库字段类型

**方法签名：**
```java
public int getSqlType()
```

**返回值：**
- `int`: 对应的数据库字段类型

---
