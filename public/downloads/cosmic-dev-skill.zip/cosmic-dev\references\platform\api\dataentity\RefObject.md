---
framework_version: "8.0.1"
api_class: "RefObject"
api_package: "kd.bos.dataentity"
when_to_use: "当你需要使用引用对象包装器时"
---

# RefObject API 说明

## 概述
引用对象包装器。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.dataentity.RefObject;
```

---

## 方法列表

### getValue

获取原始对象

**方法签名：**
```java
public T getValue()
```

**返回值：**
- `T`: 原始对象

---

### setValue

设置原始对象

**方法签名：**
```java
public void setValue(T value)
```

**参数说明：**
- `value`: `T` — 原始对象

---

### toString

输出原始对象的字符串

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 原始对象字符串

---
