---
framework_version: "8.0.1"
api_class: "CompareTypeField"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用比较符到定义时"
---

# CompareTypeField API 说明

## 概述
比较符到定义。实现 Serializable。
主要功能：设置属性、读取属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.CompareTypeField;
```

---

## 方法列表

### createCompareType

把比较符定义转换为运行时实际使用的比较符描述类

**方法签名：**
```java
public CompareType createCompareType()
```

**返回值：**
- `CompareType`

---

### getClassName

获取比较符解析类名，必须实现 kd.bos.entity.filter.IConditionVariableAnalysis

**方法签名：**
```java
public String getClassName()
```

**返回值：**
- `String`: 比较符解析类名

---

### getCompareInputType

获取比较值输入类型

**方法签名：**
```java
public CompareInputType getCompareInputType()
```

**返回值：**
- `CompareInputType`: 输入类型

---

### getId

获取比较符标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 比较服务标识

---

### getName

获取比较符名称（多语言）

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`: 比较符名称

---

### isNeedInput

是否必须输入比较值

**方法签名：**
```java
public boolean isNeedInput()
```

**返回值：**
- `boolean`: 返回true，必须输入比较值

---

### setClassName

设置比较符解析类名

**方法签名：**
```java
public void setClassName(String className)
```

**参数说明：**
- `className`: `String` — 比较服务解析类名

---

### setCompareInputType

设置比较值输入类型

**方法签名：**
```java
public void setCompareInputType(CompareInputType compareInputType)
```

**参数说明：**
- `compareInputType`: `CompareInputType` — 输入类型

---

### setId

设置比较符标识

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 比较服务标识

---

### setName

设置比较符名称（多语言）

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString` — 比较符名称

---

### setNeedInput

设置是否必须输入比较值

**方法签名：**
```java
public void setNeedInput(boolean isNeedInput)
```

**参数说明：**
- `isNeedInput`: `boolean` — 传入true，必须输入比较值

---
