---
framework_version: "8.0.1"
api_class: "AbstractOperationServicePlugIn"
api_package: "kd.bos.entity.plugin"
when_to_use: "当你需要使用单据操作运行时服务层插件抽象基类。时"
---

# AbstractOperationServicePlugIn API 说明

## 概述
单据操作运行时服务层插件抽象基类。。实现 IOperationServicePlugIn, IOperationService。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.AbstractOperationServicePlugIn;
```

---

## 方法列表

### getDataEntities

获取单据数据包
 已废弃，实际返回null
 可从具体事件参数中获取单据数据包

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`

---

### getOperateProgress

获取操作进度控制器
 插件可通过此对象，输出进度提示信息
 示例：
 ` this.getOperateProgress().feedbackProgress("当前正在进行...."); `

**方法签名：**
```java
public OperateProgress getOperateProgress()
```

**返回值：**
- `OperateProgress`

---

### getOperationContext

获取操作上下文对象
 已废弃，实际返回null
 如需获取操作元数据，请使用 ` this.operateMeta`

**方法签名：**
```java
public OperationContext getOperationContext()
```

**返回值：**
- `OperationContext`

---

### getOperationResult

获取单据操作结果
 插件可随时使用 ` this.getOperationResult()` 获取操作结果对象，向其中添加提示信息

**方法签名：**
```java
public OperationResult getOperationResult()
```

**返回值：**
- `OperationResult`

---

### getOption

获取操作可选参数包
 此对象会包含一些自定义的可选参数，使用如下示例代码获取可选参数：
 ` String opVal = this.getOption().getVariableValue(name, defVal); `

**方法签名：**
```java
public OperateOption getOption()
```

**返回值：**
- `OperateOption`

---

### initializeOperationResult

设置操作结果对象
  插件使用 ` this.getOperationResult()` 获取操作结果对象

**方法签名：**
```java
public void initializeOperationResult(OperationResult result)
```

**参数说明：**
- `result`: `OperationResult`

---

### setContext

设置操作上下文对象
 此方法由操作引擎调用，传入操作上下文对象，插件不需要调用

**方法签名：**
```java
public void setContext(MainEntityType billEntityType, Map<String,Object> operateMeta, OperateOption option)
```

**参数说明：**
- `billEntityType`: `MainEntityType`
- `operateMeta`: `Map<String,Object>`
- `option`: `OperateOption`

---

### setDataEntities

设置单据数据包
 这个方法供操作引擎向插件传入对象，插件本身不需要调用
 已废弃，操作引擎未调用此方法

**方法签名：**
```java
public void setDataEntities(DynamicObject[] dataEntities)
```

**参数说明：**
- `dataEntities`: `DynamicObject[]`

---

### setOperateProgress

设置操作进度控制器
 这个方法供操作引擎向插件传入对象，插件本身不需要调用

**方法签名：**
```java
public void setOperateProgress(OperateProgress progress)
```

**参数说明：**
- `progress`: `OperateProgress`

---

### setOperationContext

设置操作上下文对象
 这个方法供操作引擎向插件传入对象，插件本身不需要调用
 已废弃，操作引擎未调用此方法

**方法签名：**
```java
public void setOperationContext(OperationContext operationContext)
```

**参数说明：**
- `operationContext`: `OperationContext`

---

### setOperationResult

设置操作执行结果
 这个方法供操作引擎向插件传入对象，插件本身不需要调用
 已废弃，操作引擎未调用此方法，改用initializeOperationResult方法传入

**方法签名：**
```java
public void setOperationResult(OperationResult operationResult)
```

**参数说明：**
- `operationResult`: `OperationResult`

---
