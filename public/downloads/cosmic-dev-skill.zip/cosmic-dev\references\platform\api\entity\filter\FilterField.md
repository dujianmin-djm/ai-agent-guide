---
framework_version: "8.0.1"
api_class: "FilterField"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤字段信息时"
---

# FilterField API 说明

## 概述
过滤字段信息。
主要功能：读取属性、设置属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.filter.FilterField;
```

---

## 方法列表

### addCustomCompareType

添加自定义比较符

**方法签名：**
```java
public void addCustomCompareType(CompareType compareType)
```

**参数说明：**
- `compareType`: `CompareType`

---

### addCustomCompareTypes

添加自定义比较符

**方法签名：**
```java
public void addCustomCompareTypes(List<kd.CompareType> compareTypes)
```

**参数说明：**
- `compareTypes`: `List<kd.CompareType>`

---

### buildPropORMFullName

输出ORM完整属性名，包含单据体前缀

**方法签名：**
```java
public static String buildPropORMFullName(IDataEntityProperty prop)
```

**参数说明：**
- `prop`: `IDataEntityProperty` — 属性对象

**返回值：**
- `String`: ORM完整属性名，包含单据体前缀

---

### buildPropORMFullNameByName

输出ORM完整属性名，包含单据体前缀

**方法签名：**
```java
public static String buildPropORMFullNameByName(String name, IDataEntityType iDataEntityType)
```

**参数说明：**
- `name`: `String`
- `iDataEntityType`: `IDataEntityType`

**返回值：**
- `String`

---

### convertToId

将基础资料转为id

**方法签名：**
```java
public FilterField convertToId()
```

**返回值：**
- `FilterField`

---

### create

公共静态方法：传入字段标识，创建对应的过滤字段

**方法签名：**
```java
public static FilterField create(MainEntityType mainType, String fieldName)
```

**参数说明：**
- `mainType`: `MainEntityType` — 单据主实体
- `fieldName`: `String` — 字段名，格式：基础资料.引用属性1.引用属性2

**返回值：**
- `FilterField`

---

### createByOrmFieldName

公共静态方法：传入字段标识，创建对应的过滤字段

**方法签名：**
```java
public static FilterField createByOrmFieldName(MainEntityType mainType, String ormFieldName)
```

**参数说明：**
- `mainType`: `MainEntityType` — 单据主实体
- `ormFieldName`: `String` — 字段名，格式：基础资料.单据体.引用属性1.引用属性2

**返回值：**
- `FilterField`

---

### createFilterColumn

**重载 1**

创建过滤列

**方法签名：**
```java
public Map<String,Object> createFilterColumn()
```

**返回值：**
- `Map<String,Object>`

---

**重载 2**

基于本对象，生成前端过滤表格中用到的过滤字段

**方法签名：**
```java
public Map<String,Object> createFilterColumn(boolean isNeedCompareTypeField)
```

**参数说明：**
- `isNeedCompareTypeField`: `boolean`

**返回值：**
- `Map<String,Object>`

---

**重载 3**

基于本对象，生成前端过滤表格中用到的过滤字段

**方法签名：**
```java
public Map<String,Object> createFilterColumn(CreateFilterColumnParameter createFilterColumnParameter)
```

**参数说明：**
- `createFilterColumnParameter`: `CreateFilterColumnParameter`

**返回值：**
- `Map<String,Object>`

---

### createForItemClassProp

根据多类别基础资料创建

**方法签名：**
```java
public static FilterField createForItemClassProp(MainEntityType mainType, String fieldName, String baseEntityId)
```

**参数说明：**
- `mainType`: `MainEntityType` — 单据主实体
- `fieldName`: `String` — 字段名，格式：基础资料.引用属性1.引用属性2
- `baseEntityId`: `String` — 字段名，格式：基础资料.引用属性1.引用属性2

**返回值：**
- `FilterField`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### getAllCompareTypes

获取过滤字段的所有比较符

**方法签名：**
```java
public List<kd.CompareType> getAllCompareTypes()
```

**返回值：**
- `List<kd.CompareType>`

---

### getBaseDataFilterControlType

基础资料字段过滤字段控件类型

**方法签名：**
```java
public String getBaseDataFilterControlType()
```

**返回值：**
- `String`

---

### getCaption

字段名称

**方法签名：**
```java
public LocaleString getCaption()
```

**返回值：**
- `LocaleString`

---

### getComboItems

字段枚举集

**方法签名：**
```java
public List<kd.ValueMapItem> getComboItems()
```

**返回值：**
- `List<kd.ValueMapItem>`

---

### getCompareGroupID

{待补充}

**方法签名：**
```java
public String getCompareGroupID()
```

**返回值：**
- `String`: 比较符组标识

---

### getCompareType

{待补充}

**方法签名：**
```java
public CompareType getCompareType(String compareTypeId)
```

**参数说明：**
- `compareTypeId`: `String`

**返回值：**
- `CompareType`: 比较符

---

### getCompareTypes

{待补充}

**方法签名：**
```java
public List<kd.CompareType> getCompareTypes()
```

**返回值：**
- `List<kd.CompareType>`: 比较符集合

---

### getCustomCompareTypes

获取全部的自定义比较符

**方法签名：**
```java
public List<kd.CompareType> getCustomCompareTypes()
```

**返回值：**
- `List<kd.CompareType>`

---

### getDefaultCompareType

{待补充}

**方法签名：**
```java
public CompareType getDefaultCompareType()
```

**返回值：**
- `CompareType`: // 默认比较符(单个值)

---

### getDefaultCompareTypeId

{待补充}

**方法签名：**
```java
public String getDefaultCompareTypeId()
```

**返回值：**
- `String`: 列表常用过滤条件选择了一个值时使用的比较符

---

### getDefaultMultiCompareType

{待补充}

**方法签名：**
```java
public CompareType getDefaultMultiCompareType()
```

**返回值：**
- `CompareType`: // 默认比较符(多个值)

---

### getDefaultMultiCompareTypeId

{待补充}

**方法签名：**
```java
public String getDefaultMultiCompareTypeId()
```

**返回值：**
- `String`: 列表快速搜索过滤条件或常用过滤条件选择了多个值时使用的比较符（比如文本是LIKE(59)）

---

### getEntityKey

{待补充}

**方法签名：**
```java
public String getEntityKey()
```

**返回值：**
- `String`: 所属分录

---

### getFieldName

字段标识

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`

---

### getFieldProp

过滤字段

**方法签名：**
```java
public IDataEntityProperty getFieldProp()
```

**返回值：**
- `IDataEntityProperty`

---

### getFieldType

{待补充}

**方法签名：**
```java
public int getFieldType()
```

**返回值：**
- `int`: 字段数据类型，DBType, java.sql.Types

---

### getFilterControlType

{待补充}

**方法签名：**
```java
public String getFilterControlType()
```

**返回值：**
- `String`: 过滤字段类型，发给前端

---

### getFullFieldCaption

输出完整的字段名称

**方法签名：**
```java
public String getFullFieldCaption()
```

**返回值：**
- `String`

---

### getFullFieldName

字段完整的ORM属性名，需使用实体名作为前缀

**方法签名：**
```java
public String getFullFieldName()
```

**返回值：**
- `String`

---

### getJoinProperty

获取关联属性

**方法签名：**
```java
public JoinProperty getJoinProperty()
```

**返回值：**
- `JoinProperty`

---

### getLatestParent

获取最后一级属性

**方法签名：**
```java
public IDataEntityProperty getLatestParent()
```

**返回值：**
- `IDataEntityProperty`

---

### getMainType

获取主实体

**方法签名：**
```java
public MainEntityType getMainType()
```

**返回值：**
- `MainEntityType`

---

### getRefEntityId

过滤字段，f7点击时，打开的基础资料

**方法签名：**
```java
public String getRefEntityId()
```

**返回值：**
- `String`

---

### getRefProp1

基础资料引用属性1

**方法签名：**
```java
public IDataEntityProperty getRefProp1()
```

**返回值：**
- `IDataEntityProperty`

---

### getRefProp2

基础资料第二层引用属性

**方法签名：**
```java
public IDataEntityProperty getRefProp2()
```

**返回值：**
- `IDataEntityProperty`

---

### getRefPropKey

基础资料引用属性

**方法签名：**
```java
public String getRefPropKey()
```

**返回值：**
- `String`

---

### getRefPropKey1

基础资料引用属性1

**方法签名：**
```java
public String getRefPropKey1()
```

**返回值：**
- `String`

---

### getRefPropKey2

基础资料引用属性1

**方法签名：**
```java
public String getRefPropKey2()
```

**返回值：**
- `String`

---

### getSeq

{待补充}

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`: 序号

---

### getSrcFieldKey

源字段标识

**方法签名：**
```java
public String getSrcFieldKey()
```

**返回值：**
- `String`

---

### getSrcFieldProp

单据字段

**方法签名：**
```java
public IDataEntityProperty getSrcFieldProp()
```

**返回值：**
- `IDataEntityProperty`

---

### getSubEntityName

获取字段所在实体的标识，对于查询实体来说是子实体或者是子实体.分录的情况

**方法签名：**
```java
public String getSubEntityName()
```

**返回值：**
- `String`

---

### getValueFast

获取字段值

**方法签名：**
```java
public Object getValueFast(DynamicObject dynamicObject)
```

**参数说明：**
- `dynamicObject`: `DynamicObject`

**返回值：**
- `Object`

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isDesenAndNoSearch

是否为脱敏字段且不支持查询

**方法签名：**
```java
public boolean isDesenAndNoSearch()
```

**返回值：**
- `boolean`: 是否为脱敏字段且不支持查询

---

### isDesensitizeField

是否是敏感字段

**方法签名：**
```java
public boolean isDesensitizeField()
```

**返回值：**
- `boolean`

---

### isEncryptField

是否是加密字段

**方法签名：**
```java
public boolean isEncryptField()
```

**返回值：**
- `boolean`

---

### isFieldPropAliasEmpty

检查字段是否有对应的数据库字段

**方法签名：**
```java
public boolean isFieldPropAliasEmpty()
```

**返回值：**
- `boolean`

---

### isMulBasedata

是否是多选基础资料

**方法签名：**
```java
public boolean isMulBasedata()
```

**返回值：**
- `boolean`

---

### isVirtualFilterField

是否是虚拟过滤字段（没有对应的实体字段），默认为false

**方法签名：**
```java
public boolean isVirtualFilterField()
```

**返回值：**
- `boolean`

---

### setCaption

{待补充}

**方法签名：**
```java
public void setCaption(LocaleString caption)
```

**参数说明：**
- `caption`: `LocaleString`

---

### setComboItems

字段枚举集

**方法签名：**
```java
public void setComboItems(List<kd.ValueMapItem> comboItems)
```

**参数说明：**
- `comboItems`: `List<kd.ValueMapItem>`

---

### setCompareGroupID

{待补充}

**方法签名：**
```java
public void setCompareGroupID(String compareGroupID)
```

**参数说明：**
- `compareGroupID`: `String`

---

### setCompareTypes

{待补充}

**方法签名：**
```java
public void setCompareTypes(List<kd.CompareType> compareTypes)
```

**参数说明：**
- `compareTypes`: `List<kd.CompareType>`

---

### setDefaultCompareTypeId

{待补充}

**方法签名：**
```java
public void setDefaultCompareTypeId(String defaultCompareID)
```

**参数说明：**
- `defaultCompareID`: `String`

---

### setDefaultMultiCompareTypeId

{待补充}

**方法签名：**
```java
public void setDefaultMultiCompareTypeId(String defaultCompareID)
```

**参数说明：**
- `defaultCompareID`: `String`

---

### setFieldName

{待补充}

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setFieldType

字段数据类型，DBType, java.sql.Types

**方法签名：**
```java
public void setFieldType(int fieldType)
```

**参数说明：**
- `fieldType`: `int`

---

### setFullFieldName

字段完整的ORM属性名，需使用实体名作为前缀

**方法签名：**
```java
public void setFullFieldName(String fullFieldName)
```

**参数说明：**
- `fullFieldName`: `String`

---

### setMainType

设置主实体

**方法签名：**
```java
public void setMainType(MainEntityType mainType)
```

**参数说明：**
- `mainType`: `MainEntityType`

---

### setRefEntityId

过滤字段，f7点击时，打开的基础资料

**方法签名：**
```java
public void setRefEntityId(String refEntityId)
```

**参数说明：**
- `refEntityId`: `String`

---

### setRefPropKey

基础资料引用属性

**方法签名：**
```java
public void setRefPropKey(String refPropKey)
```

**参数说明：**
- `refPropKey`: `String`

---

### setSeq

{待补充}

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
