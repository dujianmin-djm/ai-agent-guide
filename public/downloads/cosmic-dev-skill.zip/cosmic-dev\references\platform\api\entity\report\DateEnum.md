---
framework_version: "8.0.1"
api_class: "DateEnum"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用日期过滤类型枚举时"
---

# DateEnum API 说明

## 概述
日期过滤类型枚举。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.report.DateEnum;
```

---

## 方法列表

### getValue

获取日期值

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`

---
