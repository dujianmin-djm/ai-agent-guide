---
framework_version: "8.0.1"
api_class: "WarnMessageReceiver"
api_package: "kd.bos.entity.earlywarn.warnschedule.messageconfig"
when_to_use: "当你需要使用消息接收人时"
---

# WarnMessageReceiver API 说明

## 概述
消息接收人。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.earlywarn.warnschedule.messageconfig.WarnMessageReceiver;
```

---

## 方法列表

### getDataSource

所属数据源

**方法签名：**
```java
public String getDataSource()
```

**返回值：**
- `String`

---

### getField

字段

**方法签名：**
```java
public String getField()
```

**返回值：**
- `String`

---

### getFieldName

字段名称

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`

---

### getId

主键

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getName

显示名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getReceiverType

接收人类型

**方法签名：**
```java
public String getReceiverType()
```

**返回值：**
- `String`

---

### getReceiverTypeObj

接收人类型对象

**方法签名：**
```java
public WarnMessageReceiverTypeEnum getReceiverTypeObj()
```

**返回值：**
- `WarnMessageReceiverTypeEnum`: WarnMessageReceiverTypeEnum 参数详细信息 kd.bos.entity.earlywarn.warnschedule.messageconfig.WarnMessageReceiverTypeEnum

---

### getRelation

关系接

**方法签名：**
```java
public String getRelation()
```

**返回值：**
- `String`

---

### getRelationName

关系名称

**方法签名：**
```java
public String getRelationName()
```

**返回值：**
- `String`

---

### getRelationshipType

关系类型（部门：包含下级、不包含下级；变量：RelationReceiverTypeEnum）

**方法签名：**
```java
public String getRelationshipType()
```

**返回值：**
- `String`

---

### getScope

范围

**方法签名：**
```java
public String getScope()
```

**返回值：**
- `String`

---

### setDataSource

设置所属数据源

**方法签名：**
```java
public void setDataSource(String dataSource)
```

**参数说明：**
- `dataSource`: `String`

---

### setField

设置字段

**方法签名：**
```java
public void setField(String field)
```

**参数说明：**
- `field`: `String`

---

### setFieldName

设置字段名称

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setId

设置主键

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setName

设置名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String`

---

### setReceiverType

设置接收人类型

**方法签名：**
```java
public void setReceiverType(String receiverType)
```

**参数说明：**
- `receiverType`: `String`

---

### setRelation

设置关系接

**方法签名：**
```java
public void setRelation(String relation)
```

**参数说明：**
- `relation`: `String`

---

### setRelationName

设置关系名称

**方法签名：**
```java
public void setRelationName(String relationName)
```

**参数说明：**
- `relationName`: `String`

---

### setRelationshipType

设置关系类型（部门：包含下级、不包含下级；变量：RelationReceiverTypeEnum）

**方法签名：**
```java
public void setRelationshipType(String relationshipType)
```

**参数说明：**
- `relationshipType`: `String`

---

### setScope

设置范围

**方法签名：**
```java
public void setScope(String scope)
```

**参数说明：**
- `scope`: `String`

---
