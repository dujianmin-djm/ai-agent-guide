---
framework_version: "8.0.1"
api_class: "FilterFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用自定义用于过滤结果集的函数时"
---

# FilterFunction API 说明

## 概述
自定义用于过滤结果集的函数。继承自 Function，实现 Serializable。
主要功能：判断当前记录是否满足条件。

## Import 路径
```java
import kd.bos.algox.FilterFunction;
```

---

## 方法列表

### test

判断当前记录是否满足条件

**方法签名：**
```java
public abstract boolean test(RowX row)
```

**参数说明：**
- `row`: `RowX` — 当前记录

**返回值：**
- `boolean`: true=满足，进入下一结果集，false=不满足，丢弃

---
