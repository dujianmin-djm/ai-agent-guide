---
framework_version: "8.0.1"
api_class: "FilterInfo"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表过滤信息时"
---

# FilterInfo API 说明

## 概述
报表过滤信息。实现 Serializable。
主要功能：读取属性、设置属性、添加元素。

## Import 路径
```java
import kd.bos.entity.report.FilterInfo;
```

---

## 方法列表

### addBdRightQFilters

条件字段的默认过滤条件，需要在插件中自己获取该条件使用

**方法签名：**
```java
public void addBdRightQFilters(ReportBaseDataFilterInfo info)
```

**参数说明：**
- `info`: `ReportBaseDataFilterInfo`

---

### addCommFilter

增加通用过滤条件

**方法签名：**
```java
public void addCommFilter(String entityId, FilterCondition filter, ITimeService timeService, IUserService userService)
```

**参数说明：**
- `entityId`: `String` — 单据实体编码
- `filter`: `FilterCondition` — 过滤条件
- `timeService`: `ITimeService` — 时间服务接口类
- `userService`: `IUserService` — 用户服务接口类

---

### addDateEnumFilterItem

添加日期类型过滤条件

**方法签名：**
```java
public void addDateEnumFilterItem(String propName, DateEnum dateEnum)
```

**参数说明：**
- `propName`: `String` — 过滤字段名
- `dateEnum`: `DateEnum` — 过滤字段值

---

### addDefaultFilters

添加默认过滤条件

**方法签名：**
```java
public void addDefaultFilters(List<Map<String,List<Object>>> defaultFilterList)
```

**参数说明：**
- `defaultFilterList`: `List<Map<String,List<Object>>>` — 默认过滤条件集合

---

### addFilterItem

**重载 1**

添加过滤条件

**方法签名：**
```java
public void addFilterItem(String propName, Object value)
```

**参数说明：**
- `propName`: `String` — 过滤字段名
- `value`: `Object` — 过滤字段值

---

**重载 2**

添加过滤条件

**方法签名：**
```java
public void addFilterItem(String propName, Object value, String compareType)
```

**参数说明：**
- `propName`: `String` — 过滤字段名
- `value`: `Object` — 过滤字段值
- `compareType`: `String` — 字段比较符

---

### clone

复制本对象

**方法签名：**
```java
public FilterInfo clone()
```

**返回值：**
- `FilterInfo`

---

### containProp

判断过滤条件中是否包含指定字段

**方法签名：**
```java
public boolean containProp(String propName)
```

**参数说明：**
- `propName`: `String` — 字段

**返回值：**
- `boolean`: 返回true包含

---

### copyCol2ndFilterOption

把另一个条件对象上的列头过滤选项，复制到本对象上

**方法签名：**
```java
public void copyCol2ndFilterOption(FilterInfo src)
```

**参数说明：**
- `src`: `FilterInfo` — 来源条件对象

---

### getBdRightQFilters

获取过滤字段未选值时的默认权限过滤条件
 为基础资料字段的原始条件，需要转换成报表字段的过滤条件

**方法签名：**
```java
public List<kd.ReportBaseDataFilterInfo> getBdRightQFilters()
```

**返回值：**
- `List<kd.ReportBaseDataFilterInfo>`

---

### getBigDecimal

获取字段的过滤值

**方法签名：**
```java
public BigDecimal getBigDecimal(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `BigDecimal`: 返回BigDecimal类型的过滤比较值

---

### getBoolean

获取字段的过滤值

**方法签名：**
```java
public boolean getBoolean(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `boolean`: 返回boolean类型的过滤比较值

---

### getCol2ndFilterOption

获取按列头对报表数据进行二次过滤时的参数（内含过滤条件、排序设置）

**方法签名：**
```java
public Col2ndFilterOption getCol2ndFilterOption(String reportListKey)
```

**参数说明：**
- `reportListKey`: `String` — 报表列表控件标识，列头过滤条件，按报表控件隔离存储

**返回值：**
- `Col2ndFilterOption`: 默认返回为null，不需要对报表数据按列头进行二次过滤

---

### getCol2ndFilterOptions

{待补充}

**方法签名：**
```java
public Map<String,Col2ndFilterOption> getCol2ndFilterOptions()
```

**返回值：**
- `Map<String,Col2ndFilterOption>`

---

### getCommFilter

**重载 1**

获取通用过滤条件

**方法签名：**
```java
public QFilter getCommFilter(String entityId)
```

**参数说明：**
- `entityId`: `String` — 单据实体编码

**返回值：**
- `QFilter`

---

**重载 2**

获取通用过滤条件

**方法签名：**
```java
public Map<String,QFilter> getCommFilter()
```

**返回值：**
- `Map<String,QFilter>`

---

### getCommFilters

获取通用过滤条件

**方法签名：**
```java
public Map<String,List<QFilter>> getCommFilters()
```

**返回值：**
- `Map<String,List<QFilter>>`

---

### getDate

获取字段的过滤值

**方法签名：**
```java
public Date getDate(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `Date`: 返回Date类型的过滤比较值

---

### getDynamicObject

获取字段的过滤值

**方法签名：**
```java
public DynamicObject getDynamicObject(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `DynamicObject`: 返回DynamicObject类型的过滤比较值

---

### getDynamicObjectCollection

获取字段的过滤值

**方法签名：**
```java
public DynamicObjectCollection getDynamicObjectCollection(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `DynamicObjectCollection`: 返回DynamicObjectCollection类型的过滤比较值

---

### getFastFilter

获取报表快速过滤条件

**方法签名：**
```java
public FastFilter getFastFilter()
```

**返回值：**
- `FastFilter`

---

### getFilterItem

获取指定字段的默认过滤项

**方法签名：**
```java
public FilterItemInfo getFilterItem(String propName)
```

**参数说明：**
- `propName`: `String` — 字段

**返回值：**
- `FilterItemInfo`

---

### getFilterItems

**重载 1**

获取过滤字段及其比较值

**方法签名：**
```java
public List<kd.FilterItemInfo> getFilterItems()
```

**返回值：**
- `List<kd.FilterItemInfo>`: 返回过滤字段及其比较值集合

---

**重载 2**

获取指定字段的全部过滤项

**方法签名：**
```java
public List<kd.FilterItemInfo> getFilterItems(String propName)
```

**参数说明：**
- `propName`: `String` — 字段

**返回值：**
- `List<kd.FilterItemInfo>`

---

### getFlexFilterItems

获取弹性域过滤字段及其比较值

**方法签名：**
```java
public List<kd.FilterItemInfo> getFlexFilterItems()
```

**返回值：**
- `List<kd.FilterItemInfo>`: 返回弹性域过滤字段及其比较值集合

---

### getHeadFilters

获取报表表头过滤条件，并转成QFilter

**方法签名：**
```java
public List<QFilter> getHeadFilters()
```

**返回值：**
- `List<QFilter>`

---

### getInt

获取字段的过滤值

**方法签名：**
```java
public int getInt(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `int`: 返回int类型的过滤比较值

---

### getLong

获取字段的过滤值

**方法签名：**
```java
public long getLong(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `long`: 返回long类型的过滤比较值

---

### getOtherEntryFilter

获取其他单据体过滤信息

**方法签名：**
```java
public Map<String,List<Object>> getOtherEntryFilter()
```

**返回值：**
- `Map<String,List<Object>>`: 返回其他单据体过滤信息

---

### getQFilters

获取实际的过滤条件

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getReportFilterConfig

获取报表过滤配置

**方法签名：**
```java
public ReportFilterConfig getReportFilterConfig()
```

**返回值：**
- `ReportFilterConfig`: ReportFilterConfig 报表过滤配置对象

---

### getString

获取字段的过滤值

**方法签名：**
```java
public String getString(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 字段

**返回值：**
- `String`: 返回String类型的过滤比较值

---

### getTableHeadFilterItems

获取报表表头过滤条件

**方法签名：**
```java
public List<kd.FilterItemInfo> getTableHeadFilterItems()
```

**返回值：**
- `List<kd.FilterItemInfo>`

---

### getValue

获取字段的过滤值

**方法签名：**
```java
public Object getValue(String propName)
```

**参数说明：**
- `propName`: `String`

**返回值：**
- `Object`: 返回Object类型的过滤比较值

---

### setCol2ndFilterOption

设置按列头二次过滤参数

**方法签名：**
```java
public void setCol2ndFilterOption(String reportListKey, Col2ndFilterOption col2ndFilterOption)
```

**参数说明：**
- `reportListKey`: `String` — 报表列表控件标识，列头过滤条件，按报表控件隔离存储
- `col2ndFilterOption`: `Col2ndFilterOption` — 按列头二次过滤参数

---

### setCommFilter

设置通用过滤条件

**方法签名：**
```java
public void setCommFilter(Map<String,QFilter> commFilters)
```

**参数说明：**
- `commFilters`: `Map<String,QFilter>` — 过滤条件信息

---

### setFastFilter

设置报表快速过滤条件

**方法签名：**
```java
public void setFastFilter(FastFilter fastFilter)
```

**参数说明：**
- `fastFilter`: `FastFilter` — 快速过滤

---

### setFlexFilterItems

设置弹性域过滤字段及其比较值

**方法签名：**
```java
public void setFlexFilterItems(List<kd.FilterItemInfo> flexFilterItems)
```

**参数说明：**
- `flexFilterItems`: `List<kd.FilterItemInfo>` — 弹性域过滤字段及其比较值集合

---

### setOtherEntryFilter

设置其他单据体过滤信息

**方法签名：**
```java
public void setOtherEntryFilter(Map<String,List<Object>> otherEntryFilter)
```

**参数说明：**
- `otherEntryFilter`: `Map<String,List<Object>>` — 其他单据体过滤信息

---

### setQFilters

设置实际过滤条件

**方法签名：**
```java
public void setQFilters(List<QFilter> qFilters)
```

**参数说明：**
- `qFilters`: `List<QFilter>` — 过滤条件集合

---

### setReportFilterConfig

设置报表过滤配置

**方法签名：**
```java
public void setReportFilterConfig(ReportFilterConfig reportFilterConfig)
```

**参数说明：**
- `reportFilterConfig`: `ReportFilterConfig` — ReportFilterConfig 报表过滤配置对象

---

### setTableHeadFilterItems

设置报表表头过滤条件

**方法签名：**
```java
public void setTableHeadFilterItems(List<kd.FilterItemInfo> tableHeadFilterItems)
```

**参数说明：**
- `tableHeadFilterItems`: `List<kd.FilterItemInfo>` — 表头过滤条件集合

---

### toString

把本对象转为字符串输出

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
