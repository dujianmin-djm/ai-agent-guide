---
framework_version: "8.0.1"
api_class: "OrgRelationItemOrg"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用业务单元间协作组织字段（委托组织字段、受托组织字段）时"
---

# OrgRelationItemOrg API 说明

## 概述
业务单元间协作组织字段（委托组织字段、受托组织字段）。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgRelationItemOrg;
```

---

## 方法列表

### getId

获取组织字段内码
 
 即字段的Id属性值，是系统为字段自动生成的随机唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 组织字段内码

---

### getName

获取组织字段名称
 
 即字段的Name属性值，多语言字段名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 组织字段名称

---

### getNumber

获取组织字段标识
 
 即字段的Key属性值

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`: 组织字段标识

---

### getType

获取组织字段类型
 
 即字段的_Type_值，组织字段_Type_值是"OrgField"

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`: 组织字段类型

---

### setId

设置组织字段内码

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 组织字段内码

---

### setName

设置组织字段名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String` — 组织字段名称

---

### setNumber

设置组织字段标识

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String` — 组织字段标识

---

### setType

设置组织字段类型

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String` — 组织字段类型

---
