---
framework_version: "8.0.1"
api_class: "Tuple"
api_package: "kd.bos.dataentity"
when_to_use: "当你需要使用变量值包装器：可含2个有顺序的值对象时"
---

# Tuple API 说明

## 概述
变量值包装器：可含2个有顺序的值对象。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.dataentity.Tuple;
```

---

## 方法列表

### create

变量值包装器创建方法

**方法签名：**
```java
public static Tuple create(S1 item1, S2 item2)
```

**参数说明：**
- `item1`: `S1` — 值对象1
- `item2`: `S2` — 值对象2

**返回值：**
- `Tuple`: 变量值包装器

---
