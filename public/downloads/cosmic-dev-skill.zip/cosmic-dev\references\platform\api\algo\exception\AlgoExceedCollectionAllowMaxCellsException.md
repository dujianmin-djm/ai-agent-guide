---
framework_version: "8.0.1"
api_class: "AlgoExceedCollectionAllowMaxCellsException"
api_package: "kd.bos.algo.exception"
when_to_use: "当你需要使用CollectionInput、CollectionDataSet允许的最大行数时"
---

# AlgoExceedCollectionAllowMaxCellsException API 说明

## 概述
CollectionInput、CollectionDataSet允许的最大行数，因为这些都是纯内存的，无磁盘读写操作。。继承自 AlgoException，实现 Serializable。
主要功能：输出异常信息。

## Import 路径
```java
import kd.bos.algo.exception.AlgoExceedCollectionAllowMaxCellsException;
```

---

## 方法列表

### toString

输出异常信息

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 异常信息

---
