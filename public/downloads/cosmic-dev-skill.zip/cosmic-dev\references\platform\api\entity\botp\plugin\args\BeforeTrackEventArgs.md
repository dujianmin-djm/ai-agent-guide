---
framework_version: "8.0.1"
api_class: "BeforeTrackEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用构建本关联主实体全部关联记录前时"
---

# BeforeTrackEventArgs API 说明

## 概述
构建本关联主实体全部关联记录前，触发此事件：用于取消关联、反写。继承自 WriteBackEventArgs。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeTrackEventArgs;
```

---

## 方法列表

### getDataEntity

当前单据数据包

**方法签名：**
```java
public DynamicObject getDataEntity()
```

**返回值：**
- `DynamicObject`

---

### isCancel

插件取消关联、反写

**方法签名：**
```java
public boolean isCancel()
```

**返回值：**
- `boolean`

---

### setCancel

设置插件取消关联、反写

**方法签名：**
```java
public void setCancel(boolean cancel)
```

**参数说明：**
- `cancel`: `boolean`

---
