---
framework_version: "8.0.1"
api_class: "DBVersion"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用数据中心版本时"
---

# DBVersion API 说明

## 概述
数据中心版本。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.DBVersion;
```

---

## 方法列表

### getAppIteration

根据应用编码获取应用迭代版本

**方法签名：**
```java
public static String getAppIteration(String appId)
```

**参数说明：**
- `appId`: `String` — 应用编码

**返回值：**
- `String`

---

### getAppVer

根据应用编码获取应用数据库版本

**方法签名：**
```java
public static String getAppVer(String appId)
```

**参数说明：**
- `appId`: `String` — 应用编码

**返回值：**
- `String`

---

### getVer

取当前数据库版本

**方法签名：**
```java
public static String getVer()
```

**返回值：**
- `String`: 包含迭代号的版本号，如：1.0.3

---
