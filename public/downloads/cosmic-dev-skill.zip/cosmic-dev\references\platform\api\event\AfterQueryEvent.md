---
framework_version: "8.0.1"
api_class: "AfterQueryEvent"
api_package: "kd.bos.event"
when_to_use: "当你需要使用查询扩展插件功能事件参数时"
---

# AfterQueryEvent API 说明

## 概述
查询扩展插件功能事件参数。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.event.AfterQueryEvent;
```

---

## 方法列表

### getDataSet

获取报表插件返回的数据

**方法签名：**
```java
public DataSet getDataSet()
```

**返回值：**
- `DataSet`

---

### getReportQueryParam

获取报表查询参数

**方法签名：**
```java
public ReportQueryParam getReportQueryParam()
```

**返回值：**
- `ReportQueryParam`

---

### setDataSet

设置报表插件返回的数据

**方法签名：**
```java
public void setDataSet(DataSet dataSet)
```

**参数说明：**
- `dataSet`: `DataSet`

---

### setReportQueryParam

设置报表查询参数

**方法签名：**
```java
public void setReportQueryParam(ReportQueryParam reportQueryParam)
```

**参数说明：**
- `reportQueryParam`: `ReportQueryParam`

---
