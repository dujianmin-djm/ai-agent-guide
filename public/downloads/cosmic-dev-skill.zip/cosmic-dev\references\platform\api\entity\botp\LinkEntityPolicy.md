---
framework_version: "8.0.1"
api_class: "LinkEntityPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用关联主实体策略时"
---

# LinkEntityPolicy API 说明

## 概述
关联主实体策略。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.LinkEntityPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getLinkRecordType

关联关系记录类型：关联、仅复制

**方法签名：**
```java
public LinkRecordType getLinkRecordType()
```

**返回值：**
- `LinkRecordType`

---

### getLinkType

关联关系，用于序列化

**方法签名：**
```java
public String getLinkType()
```

**返回值：**
- `String`

---

### getMobSourceLayout

移动端选单操作，显示源单数据列表时，采用的源单布局。

**方法签名：**
```java
public String getMobSourceLayout()
```

**返回值：**
- `String`

---

### getMobTargetLayout

移动端端下推操作，显示目标单新增界面时，采用的目标单布局。

**方法签名：**
```java
public String getMobTargetLayout()
```

**返回值：**
- `String`

---

### getSourceEntryKey

来源单据关联主实体：可以是单据头、单据体、子单据体

**方法签名：**
```java
public String getSourceEntryKey()
```

**返回值：**
- `String`

---

### getSourceLayout

PC端选单操作，显示源单数据列表时，采用的源单布局。

**方法签名：**
```java
public String getSourceLayout()
```

**返回值：**
- `String`

---

### getSourceSubEntryKey

来源单据子实体：可以是单据体、子单据体，取关联主实体的下属实体

**方法签名：**
```java
public String getSourceSubEntryKey()
```

**返回值：**
- `String`

---

### getSrcLinkEntitys

输出源单关联主实体及其父实体：校验数据筛选、数据分组策略中用到的源单字段，必须来自于关联主实体

**方法签名：**
```java
public HashSet<String> getSrcLinkEntitys(MainEntityType srcMainType)
```

**参数说明：**
- `srcMainType`: `MainEntityType`

**返回值：**
- `HashSet<String>`

---

### getTargetEntryKey

目标单据关联主实体：可以是单据头、单据体、子单据体，在此实体上，记录关联的源单信息

**方法签名：**
```java
public String getTargetEntryKey()
```

**返回值：**
- `String`

---

### getTargetLayout

PC端下推操作，显示目标单新增界面时，采用的目标单布局。

**方法签名：**
```java
public String getTargetLayout()
```

**返回值：**
- `String`

---

### getTargetSubEntryKey

目标单据关联子实体：可以是单据体、子单据体，取关联主实体的下属实体

**方法签名：**
```java
public String getTargetSubEntryKey()
```

**返回值：**
- `String`

---

### setLinkRecordType

关联关系记录类型：关联、仅复制

**方法签名：**
```java
public void setLinkRecordType(LinkRecordType linkRecordType)
```

**参数说明：**
- `linkRecordType`: `LinkRecordType`

---

### setLinkType

关联关系，用于序列化

**方法签名：**
```java
public void setLinkType(String linkType)
```

**参数说明：**
- `linkType`: `String`

---

### setMobSourceLayout

移动端选单操作，显示源单数据列表时，采用的源单布局。

**方法签名：**
```java
public void setMobSourceLayout(String mobSourceLayout)
```

**参数说明：**
- `mobSourceLayout`: `String`

---

### setMobTargetLayout

移动端端下推操作，显示目标单新增界面时，采用的目标单布局。

**方法签名：**
```java
public void setMobTargetLayout(String mobTargetLayout)
```

**参数说明：**
- `mobTargetLayout`: `String`

---

### setSourceEntryKey

来源单据关联主实体：可以是单据头、单据体、子单据体

**方法签名：**
```java
public void setSourceEntryKey(String sourceEntryKey)
```

**参数说明：**
- `sourceEntryKey`: `String`

---

### setSourceLayout

PC端选单操作，显示源单数据列表时，采用的源单布局。

**方法签名：**
```java
public void setSourceLayout(String sourceLayout)
```

**参数说明：**
- `sourceLayout`: `String`

---

### setTargetEntryKey

目标单据关联主实体：可以是单据头、单据体、子单据体，在此实体上，记录关联的源单信息

**方法签名：**
```java
public void setTargetEntryKey(String targetEntryKey)
```

**参数说明：**
- `targetEntryKey`: `String`

---

### setTargetLayout

PC端下推操作，显示目标单新增界面时，采用的目标单布局。

**方法签名：**
```java
public void setTargetLayout(String targetLayout)
```

**参数说明：**
- `targetLayout`: `String`

---

### setTargetSubEntryKey

目标单据关联子实体：可以是单据体、子单据体，取关联主实体的下属实体

**方法签名：**
```java
public void setTargetSubEntryKey(String targetSubEntryKey)
```

**参数说明：**
- `targetSubEntryKey`: `String`

---
