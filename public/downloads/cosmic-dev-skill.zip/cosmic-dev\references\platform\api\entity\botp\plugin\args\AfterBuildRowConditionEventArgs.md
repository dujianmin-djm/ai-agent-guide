---
framework_version: "8.0.1"
api_class: "AfterBuildRowConditionEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用转换规则时"
---

# AfterBuildRowConditionEventArgs API 说明

## 概述
转换规则，数据行筛选条件解析完毕后事件的参数：供插件为解析出来的条件设置条件说明，显示给用户。继承自 ConvertPluginEventArgs。
主要功能：添加元素、读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterBuildRowConditionEventArgs;
```

---

## 方法列表

### addCondition

添加新条件表达式到集合中

**方法签名：**
```java
public void addCondition(String expression)
```

**参数说明：**
- `expression`: `String`

---

### getConditons

拆分后的单据转换数据筛选条件，每个元素都是一个独立的条件

**方法签名：**
```java
public List<kd.AfterBuildRowConditionEventArgs.ConditionInfo> getConditons()
```

**返回值：**
- `List<kd.AfterBuildRowConditionEventArgs.ConditionInfo>`

---
