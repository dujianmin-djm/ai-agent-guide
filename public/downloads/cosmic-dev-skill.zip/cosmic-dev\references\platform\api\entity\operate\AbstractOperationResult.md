---
framework_version: "8.0.1"
api_class: "AbstractOperationResult"
api_package: "kd.bos.entity.operate"
when_to_use: "当你需要使用抽象操作结果时"
---

# AbstractOperationResult API 说明

## 概述
抽象操作结果。实现 IOperationResult, Serializable。
主要功能：设置属性、读取属性、状态判断、添加元素、移除元素。

## Import 路径
```java
import kd.bos.entity.operate.AbstractOperationResult;
```

---

## 方法列表

### addErrorInfo

添加错误信息

**方法签名：**
```java
public void addErrorInfo(OperateErrorInfo operateInfo)
```

**参数说明：**
- `operateInfo`: `OperateErrorInfo` — 操作错误信息

---

### addPromptField

**重载 1**

增加字段提示

**方法签名：**
```java
public void addPromptField(FieldPos fieldPos)
```

**参数说明：**
- `fieldPos`: `FieldPos` — 字段提示对象

---

**重载 2**

批量增加字段提示

**方法签名：**
```java
public void addPromptField(List<kd.FieldPos> fieldPos)
```

**参数说明：**
- `fieldPos`: `List<kd.FieldPos>` — 字段提示对象

---

### addSuccessPkId

添加操作成功的单据主键

**方法签名：**
```java
public void addSuccessPkId(Object pkId)
```

**参数说明：**
- `pkId`: `Object` — 单据内码

---

### getAllErrorInfo

获取所有的错误信息

**方法签名：**
```java
public List<kd.OperateErrorInfo> getAllErrorInfo()
```

**返回值：**
- `List<kd.OperateErrorInfo>`: 操作错误信息集合

---

### getBillCount

获取操作的单据总数，包括全部成功、失败单据

**方法签名：**
```java
public int getBillCount()
```

**返回值：**
- `int`: 操作的单据总数

---

### getBillNos

本次操作的所有单据编号：可用于生成提示信息

**方法签名：**
```java
public Map<Object,String> getBillNos()
```

**返回值：**
- `Map<Object,String>`: 本次操作的所有单据编号

---

### getClearText

获取签名明文

**方法签名：**
```java
public String getClearText()
```

**返回值：**
- `String`: 签名明文

---

### getFormId

获取操作结果展示表单  （表单类型为动态表单，需配合setMessage()使用）
 当设置了操作结果提示信息和展示表单，操作完毕，打开该表单显示结果

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`

---

### getMessage

获取操作结束返回的提示信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`: 操作提示信息

---

### getMessageType

获取消息类型

**方法签名：**
```java
public int getMessageType()
```

**返回值：**
- `int`: 消息类型

---

### getPromptField

获取提示语位置信息

**方法签名：**
```java
public List<kd.FieldPos> getPromptField()
```

**返回值：**
- `List<kd.FieldPos>`

---

### getSuccessPkIds

获取操作成功的单据主键

**方法签名：**
```java
public List<Object> getSuccessPkIds()
```

**返回值：**
- `List<Object>`: 单据主键集合

---

### isCancelWriteLog

是否取消写日志

**方法签名：**
```java
public boolean isCancelWriteLog()
```

**返回值：**
- `boolean`: true:取消 false:不取消

---

### isNeedSign

是否需要签名

**方法签名：**
```java
public boolean isNeedSign()
```

**返回值：**
- `boolean`: true:需要 false:不需要

---

### isNeedWfAssignPersons

是否需要指定下一步参与人

**方法签名：**
```java
public boolean isNeedWfAssignPersons()
```

**返回值：**
- `boolean`: true:需要 false:不需要

---

### isShowMessage

获取是否显示消息

**方法签名：**
```java
public boolean isShowMessage()
```

**返回值：**
- `boolean`: true/false

---

### isSuccess

返回操作结果，是否成功？ 要求全部成功，没有任何错误时才返回true

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`: 如果有错误提示信息，返回false

---

### removeSuccessPkIds

移除 成功处理的数据对象pk

**方法签名：**
```java
public void removeSuccessPkIds(List<Object> pkIds)
```

**参数说明：**
- `pkIds`: `List<Object>`

---

### setAllErrorInfo

设置操作错误信息

**方法签名：**
```java
public void setAllErrorInfo(List<kd.OperateErrorInfo> errorInfoes)
```

**参数说明：**
- `errorInfoes`: `List<kd.OperateErrorInfo>` — 错误信息集合

---

### setBillCount

设置单据总数，包括全部成功、失败单据

**方法签名：**
```java
public void setBillCount(int billCount)
```

**参数说明：**
- `billCount`: `int` — 单据总数

---

### setBillNos

设置本次操作的所有单据编号

**方法签名：**
```java
public void setBillNos(Map<Object,String> billNos)
```

**参数说明：**
- `billNos`: `Map<Object,String>` — 本次操作的所有单据编号

---

### setCancelWriteLog

设置是否取消写日志

**方法签名：**
```java
public void setCancelWriteLog(boolean cancelWriteLog)
```

**参数说明：**
- `cancelWriteLog`: `boolean` — 取消写日志

---

### setClearText

设置签名明文

**方法签名：**
```java
public void setClearText(String clearText)
```

**参数说明：**
- `clearText`: `String` — 签名明文

---

### setFormId

设置操作结果展示表单 （表单类型为动态表单，需配合setMessage()使用）
 当设置了操作结果提示信息和展示表单，操作完毕，打开该表单显示结果

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 表单编码

---

### setMessage

设置操作结束返回的提示信息

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String` — 消息

---

### setMessageType

设置消息类型

**方法签名：**
```java
public void setMessageType(int messageType)
```

**参数说明：**
- `messageType`: `int` — 消息类型

---

### setNeedSign

设置是否需要签名

**方法签名：**
```java
public void setNeedSign(boolean needSign)
```

**参数说明：**
- `needSign`: `boolean` — 是否需要签名

---

### setNeedWfAssignPersons

设置工作流是否需要指定下一步参与人

**方法签名：**
```java
public void setNeedWfAssignPersons(boolean needWfAssignPersons)
```

**参数说明：**
- `needWfAssignPersons`: `boolean` — 工作流指定下一步参与人

---

### setPromptField

设置提示语位置信息

**方法签名：**
```java
public void setPromptField(List<kd.FieldPos> promptField)
```

**参数说明：**
- `promptField`: `List<kd.FieldPos>` — 字段提示对象

---

### setShowMessage

设置是否显示消息

**方法签名：**
```java
public void setShowMessage(boolean showMessage)
```

**参数说明：**
- `showMessage`: `boolean` — 显示消息

---

### setSuccess

设置操作结果

**方法签名：**
```java
public void setSuccess(boolean success)
```

**参数说明：**
- `success`: `boolean` — 操作结果

---

### setSuccessPkIds

设置操作成功的单据主键

**方法签名：**
```java
public void setSuccessPkIds(List<Object> successPkIds)
```

**参数说明：**
- `successPkIds`: `List<Object>` — 操作成功的单据主键集合

---
