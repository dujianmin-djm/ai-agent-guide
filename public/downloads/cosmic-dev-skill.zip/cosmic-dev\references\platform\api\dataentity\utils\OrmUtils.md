---
framework_version: "8.0.1"
api_class: "OrmUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Orm数据对象处理工具时"
---

# OrmUtils API 说明

## 概述
Orm数据对象处理工具。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.utils.OrmUtils;
```

---

## 方法列表

### DataEntityWalker

搜索实体中各个层级的所有数据

**方法签名：**
```java
public static void DataEntityWalker(Collection<? extends Object> dataEntities, IDataEntityType dt, DataEntityWalkerListner callback, boolean onlyDbProperty)
```

**参数说明：**
- `dataEntities`: `Collection<? extends Object>` — 要搜索的实体
- `dt`: `IDataEntityType` — 根实体结构
- `callback`: `DataEntityWalkerListner` — 当搜索到某个级别时发生的回调
- `onlyDbProperty`: `boolean` — 是否仅搜索数据库使用的属性

---

### clone

**重载 1**

克隆当前实体的数据成为一个新的数据。注意他不会复制实体上的脏标识信息和快照信息。

**方法签名：**
```java
public static Object clone(IDataEntityBase dataEntity, boolean onlyDbProperty, boolean clearPrimaryKeyValue)
```

**参数说明：**
- `dataEntity`: `IDataEntityBase` — 要克隆的实体
- `onlyDbProperty`: `boolean` — 是否仅赋值数据库映射的字段。默认为false
- `clearPrimaryKeyValue`: `boolean` — 是否清除主键的值，默认为false

**返回值：**
- `Object`: 新的实体对象，将当前的数据复制到了新的实体。

---

**重载 2**

克隆当前实体的数据成为一个新的数据。注意他不会复制实体上的脏标识信息和快照信息。

**方法签名：**
```java
public static Object clone(Object dataEntity, IDataEntityType dt, boolean onlyDbProperty, boolean clearPrimaryKeyValue)
```

**参数说明：**
- `dataEntity`: `Object` — 要克隆的实体
- `dt`: `IDataEntityType` — 当前实体的类型，不能为空。
- `onlyDbProperty`: `boolean` — 是否仅赋值数据库映射的字段。默认为false
- `clearPrimaryKeyValue`: `boolean` — 是否清除主键的值，默认为false

**返回值：**
- `Object`: 新的实体对象，将当前的数据复制到了新的实体。

---

### getDataEntityType

返回类型的数据描述

**方法签名：**
```java
public static IDataEntityType getDataEntityType(Class<?> type)
```

**参数说明：**
- `type`: `Class<?>` — 类类型

**返回值：**
- `IDataEntityType`: 实体类型的描述

---

### getListEquals

判断两个集合是否相等

**方法签名：**
```java
public static boolean getListEquals(Iterable<T> x, Iterable<T> y)
```

**参数说明：**
- `x`: `Iterable<T>` — 集合1
- `y`: `Iterable<T>` — 集合2

**返回值：**
- `boolean`: 是否相等

---

### getPrimaryKeyValue

获取一个实体类的主键值。

**方法签名：**
```java
public static Object getPrimaryKeyValue(IDataEntityBase dataEntity, boolean throwOnError)
```

**参数说明：**
- `dataEntity`: `IDataEntityBase` — 要获取主键值的实体
- `throwOnError`: `boolean` — 如果实体为空或没有定义主键时是否抛出异常

**返回值：**
- `Object`: 主键值

---

### sync

列表同步操作方法
 源的元素如果在目标列表中存在，将更新目标的数据，否则新增； 如果目标列表的元素在源列表中不存在，将从目标列表中删除。

**方法签名：**
```java
public static void sync(List<SourceT> sourceList, List<TargetT> targetList, IListSyncFunction<SourceT,TargetT> syncFunction, boolean callUpdateFuncWhenCreated)
```

**参数说明：**
- `sourceList`: `List<SourceT>` — 源列表
- `targetList`: `List<TargetT>` — 目标列表
- `syncFunction`: `IListSyncFunction<SourceT,TargetT>` — 同步处理方法
- `callUpdateFuncWhenCreated`: `boolean` — 默认为true

---
