---
framework_version: "8.0.1"
api_class: "BaseShowParameter"
api_package: "kd.bos.base"
when_to_use: "当你需要使用基础资料界面显示参数时"
---

# BaseShowParameter API 说明

## 概述
基础资料界面显示参数。继承自 BillShowParameter，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.base.BaseShowParameter;
```

---

## 方法列表

### getUseOrgId

返回使用组织

**方法签名：**
```java
public long getUseOrgId()
```

**返回值：**
- `long`: 使用组织

---

### getUseOrgIds

返回使用组织集合

**方法签名：**
```java
public List<Long> getUseOrgIds()
```

**返回值：**
- `List<Long>`: 使用组织集合

---

### setUseOrgId

设置使用组织

**方法签名：**
```java
public void setUseOrgId(long useOrgId)
```

**参数说明：**
- `useOrgId`: `long` — 使用组织

---

### setUseOrgIds

设置使用组织集合

**方法签名：**
```java
public void setUseOrgIds(List<Long> useOrgIds)
```

**参数说明：**
- `useOrgIds`: `List<Long>` — 使用组织集合

---
