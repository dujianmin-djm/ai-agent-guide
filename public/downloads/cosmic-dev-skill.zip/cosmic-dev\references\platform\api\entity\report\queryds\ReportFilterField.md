---
framework_version: "8.0.1"
api_class: "ReportFilterField"
api_package: "kd.bos.entity.report.queryds"
when_to_use: "当你需要使用报表过滤字段定义时"
---

# ReportFilterField API 说明

## 概述
报表过滤字段定义。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.report.queryds.ReportFilterField;
```

---

## 方法列表

### getCompareTypeCaption

获取比较符标题

**方法签名：**
```java
public String getCompareTypeCaption()
```

**返回值：**
- `String`: 比较符标题

---

### getCompareTypeId

获取比较符类型

**方法签名：**
```java
public String getCompareTypeId()
```

**返回值：**
- `String`: 比较符类型

---

### getDataSourceCaption

获取数据源标题

**方法签名：**
```java
public String getDataSourceCaption()
```

**返回值：**
- `String`: 数据源标题

---

### getDataSourceId

获取关联的数据源标识

**方法签名：**
```java
public String getDataSourceId()
```

**返回值：**
- `String`: 数据源标识

---

### getFieldCaption

获取绑定字段标题

**方法签名：**
```java
public String getFieldCaption()
```

**返回值：**
- `String`: 字段标题

---

### getFieldName

获取绑定字段

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: 绑定字段

---

### getId

获取唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 唯一标识

---

### getKey

获取过滤字段控件标识

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`: 过滤字段控件标识

---

### getKeyCaption

获取过滤字段控件标题

**方法签名：**
```java
public String getKeyCaption()
```

**返回值：**
- `String`: 标题

---

### setCompareTypeCaption

设置比较符标题

**方法签名：**
```java
public void setCompareTypeCaption(String compareTypeCaption)
```

**参数说明：**
- `compareTypeCaption`: `String` — 比较符标题

---

### setCompareTypeId

设置比较符类型

**方法签名：**
```java
public void setCompareTypeId(String compareTypeId)
```

**参数说明：**
- `compareTypeId`: `String` — 比较符类型

---

### setDataSourceCaption

获取数据源标题

**方法签名：**
```java
public void setDataSourceCaption(String dataSourceCaption)
```

**参数说明：**
- `dataSourceCaption`: `String` — 数据源标题

---

### setDataSourceId

设置关联的数据源标识

**方法签名：**
```java
public void setDataSourceId(String dataSourceId)
```

**参数说明：**
- `dataSourceId`: `String` — 数据源标识

---

### setFieldCaption

设置绑定字段标题

**方法签名：**
```java
public void setFieldCaption(String fieldCaption)
```

**参数说明：**
- `fieldCaption`: `String` — 字段标题

---

### setFieldName

设置绑定字段

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String` — 绑定字段

---

### setId

设置唯一标识

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 唯一标识

---

### setKey

设置过滤字段控件标识

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String` — 过滤字段控件标识

---

### setKeyCaption

设置过滤字段控件标题

**方法签名：**
```java
public void setKeyCaption(String keyCaption)
```

**参数说明：**
- `keyCaption`: `String` — 标题

---
