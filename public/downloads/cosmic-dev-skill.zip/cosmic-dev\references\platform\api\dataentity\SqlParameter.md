---
framework_version: "8.0.1"
api_class: "SqlParameter"
api_package: "kd.bos.dataentity"
when_to_use: "当你需要使用SQL参数时"
---

# SqlParameter API 说明

## 概述
SQL参数。继承自 SqlParameter。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.SqlParameter;
```

---

## 方法列表

### getDbType

获取数据类型。

**方法签名：**
```java
public int getDbType()
```

**返回值：**
- `int`

---

### getName

获取属性名称。

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getValue

获取参数值。

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`

---
