---
framework_version: "8.0.1"
api_class: "CRBizRuleElement"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用单据转换时"
---

# CRBizRuleElement API 说明

## 概述
单据转换，数据更新服务配置类。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.CRBizRuleElement;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType mainType, CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `mainType`: `MainEntityType`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

---

### getActionId

服务类型，据此寻找服务元模型，获取服务执行类，以及配置界面

**方法签名：**
```java
public String getActionId()
```

**返回值：**
- `String`

---

### getDescription

服务描述，介绍服务的用途

**方法签名：**
```java
public LocaleString getDescription()
```

**返回值：**
- `LocaleString`

---

### getId

自动产生的唯一标识，据此与扩展对象，进行差量化对比定位

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getParameters

服务配置参数：各种具体服务的配置参数，包括格式都是不同的；
 这里并不关注这种差异，只是提供存储的载体，由服务执行类自行解析服务配置参数，实现功能

**方法签名：**
```java
public String getParameters()
```

**返回值：**
- `String`

---

### getPreCondition

服务执行条件

**方法签名：**
```java
public CRCondition getPreCondition()
```

**返回值：**
- `CRCondition`

---

### getRunActionClass

服务执行类名，必须派生自CRBizRuleAction

**方法签名：**
```java
public String getRunActionClass()
```

**返回值：**
- `String`

---

### getSeq

执行顺序

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### isEnabled

是否启用

**方法签名：**
```java
public boolean isEnabled()
```

**返回值：**
- `boolean`

---

### setActionId

服务类型

**方法签名：**
```java
public void setActionId(String actionId)
```

**参数说明：**
- `actionId`: `String`

---

### setDescription

服务描述

**方法签名：**
```java
public void setDescription(LocaleString description)
```

**参数说明：**
- `description`: `LocaleString`

---

### setEnabled

是否启用

**方法签名：**
```java
public void setEnabled(boolean enabled)
```

**参数说明：**
- `enabled`: `boolean`

---

### setId

自动产生的唯一标识

**方法签名：**
```java
public void setId(String value)
```

**参数说明：**
- `value`: `String`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setParameters

服务配置参数

**方法签名：**
```java
public void setParameters(String parameters)
```

**参数说明：**
- `parameters`: `String`

---

### setPreCondition

服务执行条件

**方法签名：**
```java
public void setPreCondition(CRCondition preCondition)
```

**参数说明：**
- `preCondition`: `CRCondition`

---

### setRunActionClass

服务执行类名

**方法签名：**
```java
public void setRunActionClass(String runActionClass)
```

**参数说明：**
- `runActionClass`: `String`

---

### setSeq

执行顺序

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---
