---
framework_version: "8.0.1"
api_class: "SerializationUtils"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用序列化的辅助工具类时"
---

# SerializationUtils API 说明

## 概述
序列化的辅助工具类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.serialization.SerializationUtils;
```

---

## 方法列表

### deSerializeFromBase64

将加密值反序列化

**方法签名：**
```java
public static Object deSerializeFromBase64(String base64String)
```

**参数说明：**
- `base64String`: `String` — 加密值

**返回值：**
- `Object`

---

### fromByte

将字节反序列成数据

**方法签名：**
```java
public static Object fromByte(byte[] bytes)
```

**参数说明：**
- `bytes`: `byte[]` — 当前字节值

**返回值：**
- `Object`

---

### fromJsonString

将数据反序列化成指定格式

**方法签名：**
```java
public static Object fromJsonString(String content, Class<?> valueType)
```

**参数说明：**
- `content`: `String` — 待反序列化内容
- `valueType`: `Class<?>` — 反序列化类型

**返回值：**
- `Object`

---

### fromJsonStringToList

将数据反序列化成List

**方法签名：**
```java
public static List<?> fromJsonStringToList(String content, Class<?> itemType)
```

**参数说明：**
- `content`: `String` — 待反序列化内容
- `itemType`: `Class<?>` — 反序列化类型

**返回值：**
- `List<?>`

---

### getObjectMapper2

获取对象序列化器 （null值不输出键值对）

**方法签名：**
```java
public static ObjectMapper getObjectMapper2()
```

**返回值：**
- `ObjectMapper`

---

### intArrayToString

将整形数组转换成字符串

**方法签名：**
```java
public static String intArrayToString(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — 整形数组

**返回值：**
- `String`

---

### serializeToBase64

将当前值序列化成加密值

**方法签名：**
```java
public static String serializeToBase64(Object o)
```

**参数说明：**
- `o`: `Object` — 当前值

**返回值：**
- `String`

---

### serializeToBase64ForTS

KingScript脚本使用接口：把对象序列化

**方法签名：**
```java
public static String serializeToBase64ForTS(Object obj)
```

**参数说明：**
- `obj`: `Object` — 序列化对象

**返回值：**
- `String`

---

### stringToIntArray

将字符串到转换成整数

**方法签名：**
```java
public static byte[] stringToIntArray(String arrayString)
```

**参数说明：**
- `arrayString`: `String` — 当前值

**返回值：**
- `byte[]`

---

### toByte

将当前数据序列化成字节

**方法签名：**
```java
public static byte[] toByte(Object o)
```

**参数说明：**
- `o`: `Object` — 当前值

**返回值：**
- `byte[]`

---

### toJSONStringForTS

KingScript脚本使用接口：把对象转换为JSON字符串

**方法签名：**
```java
public static String toJSONStringForTS(Object obj)
```

**参数说明：**
- `obj`: `Object` — 转换对象

**返回值：**
- `String`

---

### toJsonString

**重载 1**

将数据序列化输出

**方法签名：**
```java
public static String toJsonString(Object o)
```

**参数说明：**
- `o`: `Object` — 待序列化数据

**返回值：**
- `String`

---

**重载 2**

将数据序列化输出

**方法签名：**
```java
public static String toJsonString(Object o, boolean inclusionNON_NULL, OperateOption option)
```

**参数说明：**
- `o`: `Object` — 待序列化数据
- `inclusionNON_NULL`: `boolean` — 是否包含不允许为null
- `option`: `OperateOption` — OperateOption 数据的操作提供额外的选项

**返回值：**
- `String`

---

**重载 3**

将数据序列化输出

**方法签名：**
```java
public static String toJsonString(Object o, boolean inclusionNON_NULL)
```

**参数说明：**
- `o`: `Object` — 待序列化数据
- `inclusionNON_NULL`: `boolean` — 是否包含不允许为null的值

**返回值：**
- `String`

---
