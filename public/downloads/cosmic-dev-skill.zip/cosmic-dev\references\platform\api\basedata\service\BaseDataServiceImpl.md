---
framework_version: "8.0.1"
api_class: "BaseDataServiceImpl"
api_package: "kd.bos.basedata.service"
when_to_use: "当你需要使用 BaseDataServiceImpl 相关功能时"
---

# BaseDataServiceImpl API 说明

## 概述
BaseDataServiceImpl 类。继承自 AbstractBaseDataService。
主要功能：读取属性、状态判断、查询数据、保存更新。

## Import 路径
```java
import kd.bos.basedata.service.BaseDataServiceImpl;
```

---

## 方法列表

### addCtrlTableColumns

给受控资料主表添加特定的字段
  场景一：模板新增属性，对于历史已经发布的资料，DDL语句无该字段，可以用该接口补全
  场景二：历史资料新预置数据时，如果无DDL语句更新，则需要业务线先在beforeExecuteSqlWithResult调用，防止预置数据失败
  场景三：模板新增了属性，对应所有继承模板的历史资料类型，如果需要矫正数据，需要在矫正数据接口中先调用该接口处理新字段不存在的问题

**方法签名：**
```java
public boolean addCtrlTableColumns(String dbKey, String tableName)
```

**参数说明：**
- `dbKey`: `String` — 数据库路由标识
- `tableName`: `String` — 基础资料主表名称

**返回值：**
- `boolean`: 成功true/false

---

### afterSetCtrlUintHandle

设置为管控单元后，清除分配的数据

**方法签名：**
```java
public void afterSetCtrlUintHandle(String orgViewId, List<String> orgIdList)
```

**参数说明：**
- `orgViewId`: `String` — 视图ID
- `orgIdList`: `List<String>` — 组织ID

---

### assign

{待补充}

**方法签名：**
```java
public BaseDataResponse assign(String entityId, Long assignOrgId, String appId, Set<Long> dataIds, Set<Long> orgIds)
```

**参数说明：**
- `entityId`: `String` — 基础资料ID
- `assignOrgId`: `Long` — 分配组织ID
- `appId`: `String` — 基础资料所在应用ID
- `dataIds`: `Set<Long>` — 被分配数据ID
 分配接口
 兼容逐级分配/自由分配、新/旧模型
- `orgIds`: `Set<Long>` — 被分配组织ID

**返回值：**
- `BaseDataResponse`

---

### assignQueryByData

分配查询，查询对应的数据都分配给了哪些组织

**方法签名：**
```java
public AssignQueryResponse assignQueryByData(List<Long> dataIds, String entity, Long orgId, String appId)
```

**参数说明：**
- `dataIds`: `List<Long>` — 数据id集合，orgId能使用的数据
- `entity`: `String` — 受控资料实体
- `orgId`: `Long` — 当前执行分配查询的组织，是数据dataIds的使用组织
- `appId`: `String` — 资料所属应用ID，用于验权

**返回值：**
- `AssignQueryResponse`: 数据分配情况

---

### baseDataAddnewHandler

**重载 1**

描述：基础数据保存时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataAddnewHandler(DynamicObject dataInfo, Long createOrgID)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象
- `createOrgID`: `Long` — 创建组织ID

---

**重载 2**

描述：基础数据保存时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataAddnewHandler(DynamicObject[] objs)
```

**参数说明：**
- `objs`: `DynamicObject[]` — 基础数据信息对象数据

---

### baseDataAssignHandler

描述：基础数据保存时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataAssignHandler(DynamicObject dataInfo, Long orgID, Long createorgId)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象
- `orgID`: `Long` — 分配组织
- `createorgId`: `Long` — 创建组织ID

---

### baseDataAuditHandler

**重载 1**

描述：基础数据批量审核时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataAuditHandler(DynamicObject[] datas)
```

**参数说明：**
- `datas`: `DynamicObject[]` — 基础数据信息对象

---

**重载 2**

描述：基础数据审核时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataAuditHandler(DynamicObject dataInfo, Long createOrgID)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象
- `createOrgID`: `Long` — 创建组织ID

---

### baseDataCtrlChangeHandler

**重载 1**

描述：控制策略变更时，更新对应的使用关系表

**方法签名：**
```java
public void baseDataCtrlChangeHandler(List<DynamicObject> dataList)
```

**参数说明：**
- `dataList`: `List<DynamicObject>` — 基础数据信息对象

---

**重载 2**

描述：控制策略变更时，更新对应的使用关系表

**方法签名：**
```java
public void baseDataCtrlChangeHandler(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象

---

### baseDataDeleteHandler

**重载 1**

描述：删除基础数据时基础数据使用登记表处理
 		 删除数据后需要清除该条基础数据的使用关系表和个性化排除表记录；

**方法签名：**
```java
public void baseDataDeleteHandler(DynamicObject[] dataInfos)
```

**参数说明：**
- `dataInfos`: `DynamicObject[]` — 删除的基础数据

---

**重载 2**

描述：删除基础数据时基础数据使用登记表处理
 		 删除数据后需要清除该条基础数据的使用关系表和个性化排除表记录；

**方法签名：**
```java
public void baseDataDeleteHandler(DynamicObject dataInfo, Long orgID)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 删除的基础数据
- `orgID`: `Long` — 创建组织ID(废弃参数)

---

### baseDataOrgChangeHandler

描述：管理权转让时，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataOrgChangeHandler(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象

---

### baseDataSubmitHandler

**重载 1**

描述：基础数据批量提交时根据基础数据管控策略，确定使用组织并更新对应的使用关系表
 批量处理校验规则：同一批数据的创建组织一致，控制策略一致。

**方法签名：**
```java
public void baseDataSubmitHandler(DynamicObject[] datas)
```

**参数说明：**
- `datas`: `DynamicObject[]` — 基础数据信息对象

---

**重载 2**

描述：基础数据提交时根据基础数据管控策略，确定使用组织并更新对应的使用关系表

**方法签名：**
```java
public void baseDataSubmitHandler(DynamicObject dataInfo, Long createOrgID)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象
- `createOrgID`: `Long` — 创建组织ID

---

### batchAssign

**重载 1**

批量分配

**方法签名：**
```java
public Map<Long,Map<Long,String>> batchAssign(String entityID, List<Long> dataIDs, List<Long> orgIDs)
```

**参数说明：**
- `entityID`: `String` — 实体标志
- `dataIDs`: `List<Long>` — 待分配的基础资料ID
- `orgIDs`: `List<Long>` — 待分配的目标组织ID

**返回值：**
- `Map<Long,Map<Long,String>>`: 检查失败的待分配基础资料及组织信息map,key是基础资料ID，value是目标组织ID集合

---

**重载 2**

批量分配

**方法签名：**
```java
public Map<Long,Map<Long,String>> batchAssign(String entityID, Long assignOrgID, List<Long> dataIDs, List<Long> orgIDs)
```

**参数说明：**
- `entityID`: `String` — 实体标志
- `assignOrgID`: `Long` — 分配组织ID
- `dataIDs`: `List<Long>` — 待分配的基础资料ID
- `orgIDs`: `List<Long>` — 待分配的目标组织ID

**返回值：**
- `Map<Long,Map<Long,String>>`: 检查失败的待分配基础资料及组织信息map,key是基础资料ID，value是目标组织ID集合

---

### batchAssignOnFreeStrategy

批量分配自助游

**方法签名：**
```java
public BaseDataResponse batchAssignOnFreeStrategy(Long assignOrgId, String appId, Set<Long> dataIds, Set<Long> orgIds, String entity)
```

**参数说明：**
- `assignOrgId`: `Long` — 分配组织ID
- `appId`: `String` — 基础资料所在应用ID
- `dataIds`: `Set<Long>` — 被分配数据ID
- `orgIds`: `Set<Long>` — 被分配组织ID
- `entity`: `String` — 实体

**返回值：**
- `BaseDataResponse`: BaseDataResponse 全部校验不通过Success为false，全部成功或者部分成功时为true

---

### batchHandleModify

描述：批量个性化后续处理，如维护相关的使用登记表和个性化排除表记录。

**方法签名：**
```java
public Map<Long,String> batchHandleModify(String entityID, Long orgID, List<DynamicObject[]> dataList)
```

**参数说明：**
- `entityID`: `String` — 受控基础资料类型
- `orgID`: `Long` — 执行批量个性化操作的组织ID
- `dataList`: `List<DynamicObject[]>` — 批量个性化的受控基础资料列表。列表元素是一个长度为2的DynamicObject数组。其中 DynamicObject[0] 是个性化前的数据，DynamicObject[1] 是个性化后的数据。

**返回值：**
- `Map<Long,String>`: 批量个性化后续处理失败的基础资料ID和失败原因映射。

---

### batchModifyVerify

描述：批量个性化前校验。

**方法签名：**
```java
public Map<Long,String> batchModifyVerify(String entityID, Long orgID, List<DynamicObject> dataList)
```

**参数说明：**
- `entityID`: `String` — 受控基础资料类型
- `orgID`: `Long` — 执行批量个性化操作的组织ID
- `dataList`: `List<DynamicObject>` — 需要批量个性化的受控基础资料列表

**返回值：**
- `Map<Long,String>`: 校验失败的基础资料ID和失败原因映射。

---

### batchUnAssign

取消分配，方法未实现，不要使用

**方法签名：**
```java
public void batchUnAssign(String entityID, Long[] dataIDs, Long[] orgIDs)
```

**参数说明：**
- `entityID`: `String` — 实体
- `dataIDs`: `Long[]` — 数据
- `orgIDs`: `Long[]` — 组织

---

### cancelAssign

**重载 1**

取消分配接口

**方法签名：**
```java
public List<CancelAssignResult> cancelAssign(String entityId, Set<Long> dataIds, Set<Long> orgIds)
```

**参数说明：**
- `entityId`: `String` — 基础资料实体ID
- `dataIds`: `Set<Long>` — 数据
- `orgIds`: `Set<Long>` — 组织

**返回值：**
- `List<CancelAssignResult>`: CancelAssignResult 取消分配结果

---

**重载 2**

取消分配接口

**方法签名：**
```java
public List<CancelAssignResult> cancelAssign(String entityId, String appId, Long opOrgId, Set<Long> dataIds, Set<Long> orgIds)
```

**参数说明：**
- `entityId`: `String` — 基础资料实体ID
- `appId`: `String` — 应用ID
- `opOrgId`: `Long` — 执行取消分配的操作组织
- `dataIds`: `Set<Long>` — 待取消分配的数据集合
- `orgIds`: `Set<Long>` — 目标组织集合

**返回值：**
- `List<CancelAssignResult>`: CancelAssignResult 取消分配结果

---

### changeCtrlStrategy

变更控制策略

**方法签名：**
```java
public BaseDataResponse changeCtrlStrategy(String entityId, Set<Long> dataIds, String ctrlStrategy, String appId, Long useOrgId)
```

**参数说明：**
- `entityId`: `String` — 基础资料标识ID
- `dataIds`: `Set<Long>` — 数据ID
- `ctrlStrategy`: `String` — 目标控制策略
- `appId`: `String`
- `useOrgId`: `Long` — 使用组织ID

**返回值：**
- `BaseDataResponse`: BaseDataResponse
  boolean success 成功/失败
  String errorMsg 失败原因

---

### changeManageRight

基础资料管理权转让接口

**方法签名：**
```java
public BaseDataResponse changeManageRight(String entityId, Long useOrgId, String appId, Set<Long> dataIds, Long targetOrgId)
```

**参数说明：**
- `entityId`: `String` — 基础资料标识
- `useOrgId`: `Long` — 使用组织
- `appId`: `String` — 应用ID
- `dataIds`: `Set<Long>` — 基础资料ID
- `targetOrgId`: `Long` — 目标组织ID

**返回值：**
- `BaseDataResponse`: BaseDataResponse 返回实体 success：是否成功 errorMsg：错误信息

---

### checkBaseDataCtrl

描述：检查基础数据是否受控

**方法签名：**
```java
public Boolean checkBaseDataCtrl(String entityID)
```

**参数说明：**
- `entityID`: `String` — 基础数据实体ID

**返回值：**
- `Boolean`: 基础数据是否受控

---

### checkHasAssignData

描述：批量判断基础数据是否被分配过。

**方法签名：**
```java
public List<Long> checkHasAssignData(String entityNumber, List<Long> dataIDs)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识
- `dataIDs`: `List<Long>` — 基础数据ID列表

**返回值：**
- `List<Long>`: List 有分配过的数据的列表

---

### chectDuplicate

**重载 1**

描述：检查基础数据是否存在重复

**方法签名：**
```java
public Boolean chectDuplicate(String entityType, Map<String,String> chectProperties, Long orgID, Long dataID)
```

**参数说明：**
- `entityType`: `String` — 实体类型ID
- `chectProperties`: `Map<String,String>` — 检查属性,如 key = NUMBER, value = "A001";key = "name", value = "AAA"
- `orgID`: `Long` — 使用组织ID
- `dataID`: `Long` — 基础数据ID

**返回值：**
- `Boolean`: Boolean true：有重复；false：没有重复

---

**重载 2**

描述：检查目标组织是否存在相同编码的基础数据

**方法签名：**
```java
public Boolean chectDuplicate(String entityType, Long orgID, List numberList)
```

**参数说明：**
- `entityType`: `String` — 实体类型ID
- `orgID`: `Long` — 使用组织ID
- `numberList`: `List` — 基础数据编码列表

**返回值：**
- `Boolean`: Boolean true：有重复；false：没有重复

---

### clearBaseDataFilterCache

描述：批量个性化后续处理，如维护相关的使用登记表和个性化排除表记录。

**方法签名：**
```java
public void clearBaseDataFilterCache(String entityType, Long orgID)
```

**参数说明：**
- `entityType`: `String`
- `orgID`: `Long`

---

### clearCache

**重载 1**

描述：清除缓存

**方法签名：**
```java
public void clearCache(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据信息对象

---

**重载 2**

描述：批量清除缓存

**方法签名：**
```java
public void clearCache(DynamicObject[] datas)
```

**参数说明：**
- `datas`: `DynamicObject[]` — 基础数据信息对象数组

---

### deleteFormGroup

用于树形列表删除分组节点

**方法签名：**
```java
public IOperationResult deleteFormGroup(Object[] ids, GroupProp prop)
```

**参数说明：**
- `ids`: `Object[]`
- `prop`: `GroupProp`

**返回值：**
- `IOperationResult`: 批量操作结果

---

### executeIndividualizeOnFreeStrategy

自由分配型基础资料个性化接口

**方法签名：**
```java
public Map<Long,String> executeIndividualizeOnFreeStrategy(String entity, Long useOrgId, String appId, Set<Long> dataIds, Object service)
```

**参数说明：**
- `entity`: `String` — 实体标识
- `useOrgId`: `Long` — 使用组织
- `appId`: `String` — 应用ID， 验权使用
- `dataIds`: `Set<Long>` — 基础资料ID
- `service`: `Object` — 业务自定义控制服务，注意：需要实现IBaseDataCtrlPlugin接口

**返回值：**
- `Map<Long,String>`: 失败的数据信息，K：数据ID，V：失败原因

---

### fillCtrlStrategyFieldAfterCopy

给数据重新生成位图、原位图字段的值
  使用场景：通过拷贝数据之后不走保存操作，而且直接执行save方法，此时所保存的是数据是无法正常生成管控范围数据信息，需要先执行该方法后save，再重建使用范围数据

**方法签名：**
```java
public void fillCtrlStrategyFieldAfterCopy(String entity, List<DynamicObject> dataList)
```

**参数说明：**
- `entity`: `String` — 实体
- `dataList`: `List<DynamicObject>` — 数据集合

---

### fixExcTable

补个性化排除表数据

**方法签名：**
```java
public void fixExcTable(String entityID, List<Long> orgIDs)
```

**参数说明：**
- `entityID`: `String`
- `orgIDs`: `List<Long>`

---

### getAccountingSysAcctOrg

根据核算体系id 和 记账范围 获取核算主体

**方法签名：**
```java
public static DynamicObjectCollection getAccountingSysAcctOrg(Long acctSysId, Long[] bizacctorgs)
```

**参数说明：**
- `acctSysId`: `Long`
- `bizacctorgs`: `Long[]`

**返回值：**
- `DynamicObjectCollection`

---

### getAccountingSysBaseInfo

根据核算主体获取基本会计政策

**方法签名：**
```java
public static DynamicObjectCollection getAccountingSysBaseInfo(Long[] orgIds)
```

**参数说明：**
- `orgIds`: `Long[]`

**返回值：**
- `DynamicObjectCollection`

---

### getAccountingSysBizOrg

根据核算体系id 和 核算主体 获取记账范围

**方法签名：**
```java
public static DynamicObjectCollection getAccountingSysBizOrg(Long acctSysId, Long[] acctorgs)
```

**参数说明：**
- `acctSysId`: `Long`
- `acctorgs`: `Long[]`

**返回值：**
- `DynamicObjectCollection`

---

### getAccountingSysView

根据核算体系id获取视图

**方法签名：**
```java
public static Map<String,String> getAccountingSysView(Long acctSysId)
```

**参数说明：**
- `acctSysId`: `Long`

**返回值：**
- `Map<String,String>`

---

### getAllUseOrg

获取所有能显示的使用组织

**方法签名：**
```java
public DynamicObjectCollection getAllUseOrg(String entityType)
```

**参数说明：**
- `entityType`: `String` — 实体

**返回值：**
- `DynamicObjectCollection`: DynamicObjectCollection

---

### getAssignDesOrgs

描述：获取分配目标组织。
 1、按当前基础数据的创建组织查找基础数据对应的基础数据管控策略，获取相关参数；
 2、当控制策略=按管控单元逐级分配时，从基础数据的管控视图中获取当前组织的直接下级控制单元；
   当控制策略=按组织逐级分配时，从基础数据的管控视图中获取当前组织的直接下级组织；
   当控制策略=按管控单元自由分配时，从基础数据的管控视图中获取当前组织以外的所有控制单元；
   当控制策略=按组织自由分配时，从基础数据的管控视图中获取当前组织以外的所有组织；
 3、根据组织在当前基础数据的使用关系表中获取已分配组织；
 4、将第2步的数据排除第3步的数据得到待分配组织；

**方法签名：**
```java
public List<Long> getAssignDesOrgs(Long srcOrgID, String ctrlType, Long orgViewID)
```

**参数说明：**
- `srcOrgID`: `Long` — 分配源组织
- `ctrlType`: `String` — 控制类型
- `orgViewID`: `Long` — 组织视图ID

**返回值：**
- `List<Long>`: List 分配目标组织

---

### getAssignUseOrgSet

获取可分配的使用组织集合

**方法签名：**
```java
public List<Long> getAssignUseOrgSet(DynamicObject dataInfo, Long orgID, Long createorgId)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — dataInfo
- `orgID`: `Long` — orgID
- `createorgId`: `Long` — createorgId

**返回值：**
- `List<Long>`: List

---

### getBaseAccountingInfo

描述：根据业务组织取本位币和汇率表
 1、先根据单据返回的主业务组织获取实体核算组织（已提供接口）；
 2、再从核算组织本位币设置中获取本位币或汇率表；
 3、获取逻辑：优先获取核算组织本身的本位币或汇率表，若没有则往上找上级，直到找到为止；

**方法签名：**
```java
public static Map<String,Long> getBaseAccountingInfo(Long accountOrgID)
```

**参数说明：**
- `accountOrgID`: `Long` — 实体核算组织ID

**返回值：**
- `Map<String,Long>`

---

### getBaseData

获取基础资料

**方法签名：**
```java
public DynamicObject getBaseData(String entityID, Long orgID, String number, String selectFields)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID
- `number`: `String` — 编码
- `selectFields`: `String` — 查询字段

**返回值：**
- `DynamicObject`: dataObj

---

### getBaseDataCreaterOrgFilter

获取基础资料创建组织过滤

**方法签名：**
```java
public QFilter getBaseDataCreaterOrgFilter(String entityID, Long orgID)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于QFilter(CREATEORG, "in", baseDataCreaterOrgSet)

---

### getBaseDataCtrlPlugin

描述：获取基础数据控制插件

**方法签名：**
```java
public IBaseDataCtrlPlugin getBaseDataCtrlPlugin(String entityType)
```

**参数说明：**
- `entityType`: `String` — 实体标识

**返回值：**
- `IBaseDataCtrlPlugin`: IBaseDataCtrlPlugin 基础数据控制插件

---

### getBaseDataFilter

**重载 1**

获取基础资料ID过滤

**方法签名：**
```java
public QFilter getBaseDataFilter(String entityID, Long orgID)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于ctrlstrategy = '5' or fid in(select fdataid from T_BD_BaseData_U where fuseorgid=100000)

---

**重载 2**

获取多个使用组织的基础资料过滤条件

**方法签名：**
```java
public QFilter getBaseDataFilter(String entityID, List<Long> orgIDs, boolean isRemoveDup)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgIDs`: `List<Long>` — 组织机构ID
- `isRemoveDup`: `boolean` — 是否去除重复数据，只返回masterid=fid的数据,默认传true

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于ctrlstrategy = '5' or fid in(select fdataid from T_BD_BaseData_U where fuseorgid in (100000, 1, 2, 3))

---

**重载 3**

获取多个使用组织的基础资料过滤条件，包含基础资料的组织使用范围，以及用户的基础资料数据规则。

**方法签名：**
```java
public QFilter getBaseDataFilter(Long userID, String appID, String entityID, QFilter orgQFilter, boolean isRemoveDup)
```

**参数说明：**
- `userID`: `Long` — 用户ID，用于权限校验
- `appID`: `String` — 应用Id，用于权限校验
- `entityID`: `String` — 实体标识
- `orgQFilter`: `QFilter` — 组织过滤条件，当为空时，表示不限组织
- `isRemoveDup`: `boolean` — 是否去除重复数据，只返回masterid=fid的数据,默认传true

**返回值：**
- `QFilter`: QFilter 过滤条件。

---

### getBaseDataFilterNoAudit

返回不带审核状态的可使用范围的接口

**方法签名：**
```java
public QFilter getBaseDataFilterNoAudit(String entityID, Long orgId)
```

**参数说明：**
- `entityID`: `String`
- `orgId`: `Long`

**返回值：**
- `QFilter`

---

### getBaseDataFilterWithOrgIds

获取组织可用的受控基础资料数据过滤器

**方法签名：**
```java
public QFilter[] getBaseDataFilterWithOrgIds(Long userId, String appId, String entityId, Set<Long> orgIds, boolean isRemoveDup)
```

**参数说明：**
- `userId`: `Long` — 用户Id
- `appId`: `String` — 应用Id
- `entityId`: `String` — 基础资料单据标识
- `orgIds`: `Set<Long>` — 组织Id集合
- `isRemoveDup`: `boolean` — 是否去重

**返回值：**
- `QFilter[]`: 组织可用数据过滤条件

---

### getBaseDataIdInFilter

获取基础资料ID过滤
 在列表查询性能优化后，对于部分暂时不能使用inner join过滤条件的应用场景，调用原来的实现逻辑。

**方法签名：**
```java
public QFilter getBaseDataIdInFilter(String entityID, Long orgID)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于QFilter("id", "in", baseDataIdsSet)

---

### getBaseDataProFilter

获取基础资料过滤

**方法签名：**
```java
public QFilter getBaseDataProFilter(String entityID, Long orgID, String property)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID
- `property`: `String` — 过滤属性

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于QFilter("id", "in", baseDataIdSet)

---

### getBdCtrlAssistDataFilter

获取受控辅助资料过滤条件

**方法签名：**
```java
public static QFilter getBdCtrlAssistDataFilter(Long dataTypeId)
```

**参数说明：**
- `dataTypeId`: `Long` — 受控辅助资料类型id

**返回值：**
- `QFilter`

---

### getBdCtrlAssistantDataFilter

获取受控辅助资料过滤条件

**方法签名：**
```java
public static QFilter getBdCtrlAssistantDataFilter(Long orgID)
```

**参数说明：**
- `orgID`: `Long` — 组织机构ID

**返回值：**
- `QFilter`: QFilter 过滤条件。类似于QFilter("id", "in", baseDataIdsSet)

---

### getBdCtrlOrgs

根据实体获取基础数据管控策略的创建组织

**方法签名：**
```java
public List<Long> getBdCtrlOrgs(String entity)
```

**参数说明：**
- `entity`: `String` — 实体标识

**返回值：**
- `List<Long>`: 基础数据管控策略的创建组织

---

### getBdCtrlStrgy

获取控制策略

**方法签名：**
```java
public String getBdCtrlStrgy(String entity, String createOrg)
```

**参数说明：**
- `entity`: `String` — 实体标识
- `createOrg`: `String` — 组织

**返回值：**
- `String`: 策略

---

### getBdCtrlStrgyBatch

{待补充}

**方法签名：**
```java
public Map<String,String> getBdCtrlStrgyBatch(String entity, List<Long> createOrgs)
```

**参数说明：**
- `entity`: `String`
- `createOrgs`: `List<Long>`

**返回值：**
- `Map<String,String>`

---

### getCreateOrgList

**重载 1**

获取单据可选的创建组织集合

**方法签名：**
```java
public List<Long> getCreateOrgList(String entity, String appid)
```

**参数说明：**
- `entity`: `String` — 实体标识
- `appid`: `String` — 应用id

**返回值：**
- `List<Long>`: 可以创建数据的组织集合

---

**重载 2**

获取单据可选的创建组织集合

**方法签名：**
```java
public List<Long> getCreateOrgList(String entity)
```

**参数说明：**
- `entity`: `String` — 实体标识

**返回值：**
- `List<Long>`: 可以创建数据的组织集合

---

### getCtrlStgyViewSchema

获取控制策略的管控视图

**方法签名：**
```java
public String getCtrlStgyViewSchema(String entity)
```

**参数说明：**
- `entity`: `String` — 实体标识

**返回值：**
- `String`: 管控视图

---

### getCtrlStrtgy

描述：查找基础数据管控策略

**方法签名：**
```java
public DynamicObject getCtrlStrtgy(DynamicObject dataObj)
```

**参数说明：**
- `dataObj`: `DynamicObject` — dataObj

**返回值：**
- `DynamicObject`: 基础数据管控策略

---

### getCtrlview

查询获取视图信息

**方法签名：**
```java
public DynamicObject getCtrlview(String entityID)
```

**参数说明：**
- `entityID`: `String` — 实体标识

**返回值：**
- `DynamicObject`: 视图对象

---

### getDefaultCtrlStrtgy

描述：获取默认控制策略

**方法签名：**
```java
public DynamicObject getDefaultCtrlStrtgy(String entityID)
```

**参数说明：**
- `entityID`: `String` — 基础数据实体ID

**返回值：**
- `DynamicObject`: DynamicObject 默认控制策略

---

### getExchangeRate

**重载 1**

根据汇率表，源币，目标币和日期得到直接汇率
 1.当希望得到最新汇率时，则设date为null;
 2.当该日期的汇率不存在时，就往前找离该日期最近的生效日期的汇率

**方法签名：**
```java
public static BigDecimal getExchangeRate(Long exchangeTableID, Long sourceCurrencyID, Long targetCurrencyID, Date date)
```

**参数说明：**
- `exchangeTableID`: `Long` — 汇率表ID
- `sourceCurrencyID`: `Long` — 源货币ID
- `targetCurrencyID`: `Long` — 目标货币ID
- `date`: `Date` — 日期 格式yyyy-MM-dd

**返回值：**
- `BigDecimal`: exchangeRate 汇率

---

**重载 2**

根据汇率表，源币，目标币和日期得到汇率
 1.当希望得到最新汇率时，则设date为null;
 2.当该日期的汇率不存在时，就往前找离该日期最近的生效日期的汇率

**方法签名：**
```java
public static BigDecimal getExchangeRate(Long exchangeTableID, Long sourceCurrencyID, Long targetCurrencyID, String convertMode, Date date)
```

**参数说明：**
- `exchangeTableID`: `Long` — 汇率表ID
- `sourceCurrencyID`: `Long` — 源货币ID
- `targetCurrencyID`: `Long` — 目标货币ID
- `convertMode`: `String` — 换算方式 1:直接汇率;2:间接汇率
- `date`: `Date` — 日期 格式yyyy-MM-dd

**返回值：**
- `BigDecimal`: exchangeRate 汇率

---

### getFullTextIndex

描述：根据实体编码获取配置的全文索引，未配置则返回null。

**方法签名：**
```java
public static String getFullTextIndex(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `String`: fullTextIndex 对应实体配置的全文索引，未配置则返回null;

---

### getHasCtrlQueryPermOrgIds

获取有基础资料查询权限的组织Id集合

**方法签名：**
```java
public List<Long> getHasCtrlQueryPermOrgIds(Long userId, String entityId, String appId)
```

**参数说明：**
- `userId`: `Long` — 用户Id
- `entityId`: `String` — 基础资料单据标识
- `appId`: `String` — 应用Id

**返回值：**
- `List<Long>`: 有查询权的组织Id集合

---

### getLookUpListFilter

获取快速查询过滤条件

**方法签名：**
```java
public QFilter getLookUpListFilter(String entityId, Long orgId, QFilter customFilter)
```

**参数说明：**
- `entityId`: `String` — 资料实体
- `orgId`: `Long` — 组织id
- `customFilter`: `QFilter` — 过滤条件

**返回值：**
- `QFilter`: 快速查询过滤条件

---

### getMasterIdFieldName

{待补充}

**方法签名：**
```java
public String getMasterIdFieldName(String entityName)
```

**参数说明：**
- `entityName`: `String` — 基础资料实体ID

**返回值：**
- `String`: String 基础资料masterid对应属性名
 获取基础资料配置的masterid字段名
 如果没有配置，返回默认的fmasterId

---

### getMasterIdPropName

{待补充}

**方法签名：**
```java
public String getMasterIdPropName(String entityName)
```

**参数说明：**
- `entityName`: `String` — 基础资料实体ID

**返回值：**
- `String`: String 基础资料masterid对应属性名
 获取基础资料配置的masterid属性名
 如果没有配置，返回默认的masterid

---

### getOpAuthOrgIds

获取验权的组织

**方法签名：**
```java
public List<Long> getOpAuthOrgIds(String pageId)
```

**参数说明：**
- `pageId`: `String` — 页面id

**返回值：**
- `List<Long>`: 执行操作的组织id集合

---

### getUnInsertExcHistory

获取已个性化分配未插入个性化排除表的异常数据

**方法签名：**
```java
public List<Object[]> getUnInsertExcHistory(String entityID, List<Long> uesOrgIDs)
```

**参数说明：**
- `entityID`: `String` — 受控基础资料类型
- `uesOrgIDs`: `List<Long>` — 使用组织

**返回值：**
- `List<Object[]>`: Object[3]:useorgid,dataid,createorgid(使用组织ID，数据ID,创建组织ID)

---

### getUseOrgFunc

获取使用组织的组织职能

**方法签名：**
```java
public String getUseOrgFunc(String entity)
```

**参数说明：**
- `entity`: `String` — 实体标识

**返回值：**
- `String`: 职能

---

### getVerifyOrgPropertyName

描述：获取实体操作的验权组织属性名

**方法签名：**
```java
public String getVerifyOrgPropertyName(String entityType, String operationKey)
```

**参数说明：**
- `entityType`: `String` — 实体标识
- `operationKey`: `String` — 操作标识

**返回值：**
- `String`

---

### getWorkCalendar

**重载 1**

描述：获取指定组织的工作日历。

**方法签名：**
```java
public DynamicObject getWorkCalendar(Long orgId)
```

**参数说明：**
- `orgId`: `Long` — 组织机构

**返回值：**
- `DynamicObject`: DynamicObject 工作日历

---

**重载 2**

描述：获取指定组织,开始日期，结束日期的工作日历。

**方法签名：**
```java
public DynamicObject getWorkCalendar(Long orgId, Date startDate, Date endDate)
```

**参数说明：**
- `orgId`: `Long` — 组织机构
- `startDate`: `Date` — 开始日期
- `endDate`: `Date` — 结束日期

**返回值：**
- `DynamicObject`: DynamicObject 工作日历

---

### handleBatchDisable

描述：批量处理禁用基础资料时相关处理。

**方法签名：**
```java
public void handleBatchDisable(String entityID, List<Object> orgIds, List<Object> masterIds)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgIds`: `List<Object>` — 禁用基础资料组织范围ID集合
- `masterIds`: `List<Object>` — 待禁用的基础数据主ID集合

---

### handleDisable

描述：处理禁用基础资料时相关处理。

**方法签名：**
```java
public void handleDisable(String entityID, DynamicObject[] objs)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `objs`: `DynamicObject[]` — 待禁用的基础数据

---

### handleEnable

描述：处理启用基础资料时相关处理。

**方法签名：**
```java
public boolean handleEnable(String entityID, DynamicObject[] objs)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `objs`: `DynamicObject[]` — 待启用的基础数据

**返回值：**
- `boolean`

---

### handleManageOrg

描述：处理管理费用组织。

**方法签名：**
```java
public void handleManageOrg(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据

---

### handleModify

描述：处理受控基础数据修改。

**方法签名：**
```java
public boolean handleModify(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据

**返回值：**
- `boolean`

---

### individualize

基础资料个性化接口

**方法签名：**
```java
public BaseDataResponse individualize(String entityId, Long useOrgId, String appId, Set<Long> dataIds)
```

**参数说明：**
- `entityId`: `String` — 基础资料ID
- `useOrgId`: `Long` — 使用组织
- `appId`: `String` — 应用ID
- `dataIds`: `Set<Long>` — 基础资料ID

**返回值：**
- `BaseDataResponse`: BaseDataResponse 返回实体 success：是否成功 errorMsg：错误信息

---

### isAlreadyAssign

是否分配的数据

**方法签名：**
```java
public boolean isAlreadyAssign(String entity, Object pkId, Long useOrgId)
```

**参数说明：**
- `entity`: `String` — 受控实体
- `pkId`: `Object` — 数据id
- `useOrgId`: `Long` — 使用组织

**返回值：**
- `boolean`: 已经分配 true / 未分配 false

---

### isAssignData

是否分配的数据

**方法签名：**
```java
public static boolean isAssignData(String number, Object primaryKeyValue, Long useOrgId)
```

**参数说明：**
- `number`: `String`
- `primaryKeyValue`: `Object`
- `useOrgId`: `Long`

**返回值：**
- `boolean`

---

### isDBFulltext

描述：检查实体的属性是否配置全文索引。

**方法签名：**
```java
public static Boolean isDBFulltext(String entityNumber, String propertyNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `propertyNumber`: `String`

**返回值：**
- `Boolean`: isDBFulltextProperty 检查属性在实体中已经配置全文索引则返回true,否则返回false;

---

### isEnableNameVersion

判断entityID是否开启了变更配置

**方法签名：**
```java
public Boolean isEnableNameVersion(String entityID)
```

**参数说明：**
- `entityID`: `String` — entityID

**返回值：**
- `Boolean`: java.lang.Boolean

---

### isHasAssignData

描述：判断基础数据是否被分配过。

**方法签名：**
```java
public boolean isHasAssignData(String entityNumber, Object dataID)
```

**参数说明：**
- `entityNumber`: `String` — 实体标识
- `dataID`: `Object` — 基础数据ID

**返回值：**
- `boolean`: boolean 如果基础数据被分配过，则返回true,否则返回false.

---

### isNoneCustomEntity

描述：判断指定实体是不是不会有个性化的基础资料实体。

**方法签名：**
```java
public Boolean isNoneCustomEntity(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码

**返回值：**
- `Boolean`: true entityNumber 是不会有个性化的基础资料实体

---

### managePermChange

管理权转让接口

**方法签名：**
```java
public void managePermChange(String entityNumber, List<Long> ids, Long orgId)
```

**参数说明：**
- `entityNumber`: `String` — 基础资料实体ID
- `ids`: `List<Long>` — 基础资料ID
- `orgId`: `Long` — 转让目标组织ID

---

### orgAddnewHandler

**重载 1**

1、根据管控视图在基础数据管控策略找到使用该视图的所有基础数据；
 2、从某个基础数据的使用关系表中查找使用组织=新增组织所属管控单元并且控制策略=按管控单元逐级分配或按管控单元自由分配的记录；
 3、如果找到则在使用关系表中增加新增组织的记录，如果没有则不处理；
 4、存在多个基础数据时，按第2，3点逐一处理。

**方法签名：**
```java
public void orgAddnewHandler(Long orgId)
```

**参数说明：**
- `orgId`: `Long` — 组织单元信息对象

---

**重载 2**

1、根据管控视图在基础数据管控策略找到使用该视图的所有基础数据；
 2、从某个基础数据的使用关系表中查找使用组织=新增组织所属管控单元并且控制策略=按管控单元逐级分配或按管控单元自由分配的记录；
 3、如果找到则在使用关系表中增加新增组织的记录，如果没有则不处理；
 4、存在多个基础数据时，按第2，3点逐一处理。

**方法签名：**
```java
public void orgAddnewHandler(Long orgViewId, List<Long> orgs)
```

**参数说明：**
- `orgViewId`: `Long` — 组织视图ID
- `orgs`: `List<Long>` — 组织ID

---

### orgSaveHandler

组织保存后，管控策略使用关系的处理
 绑定的每个受控基础资料调清除缓存，将上级的管控范围共享的数据加到使用关系表,只处理CU组织

**方法签名：**
```java
public void orgSaveHandler(List<Long> orgIds)
```

**参数说明：**
- `orgIds`: `List<Long>` — 组织ID

---

### presetCtrlOrgUseRangData

受控基础资料预置数据自动生成相关使用范围数据
  1、新模型生成位图值，补充位图数据
  2、旧模型补充使用范围表的数据

**方法签名：**
```java
public UpgradeResult presetCtrlOrgUseRangData(String dbKey, String entity, String tableName, Map<Long,Long> dataOrgMap, boolean isTreeType)
```

**参数说明：**
- `dbKey`: `String` — 数据库路由标识
- `entity`: `String` — 受控资料实体
- `tableName`: `String` — 基础资料主表名称
- `dataOrgMap`: `Map<Long,Long>` — 需要预置的数据和组织的信息， K：数据Id，V：创建组织Id
- `isTreeType`: `boolean` — 是否树形基础资料，树形：true， 非树形：false

**返回值：**
- `UpgradeResult`: UpgradeResult

---

### queryBaseData

获取基础资料

**方法签名：**
```java
public DynamicObjectCollection queryBaseData(String entityID, Long orgID, QFilter filter, String selectFields)
```

**参数说明：**
- `entityID`: `String` — 资料实体
- `orgID`: `Long` — 组织id
- `filter`: `QFilter` — 过滤条件
- `selectFields`: `String` — 查询字段

**返回值：**
- `DynamicObjectCollection`: 结果

---

### queryBaseDataByDate

根据查询日期获取基础资料

**方法签名：**
```java
public DynamicObjectCollection queryBaseDataByDate(String entityID, Long orgID, QFilter filter, String selectFields, Date queryDate)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgID`: `Long` — 组织机构ID
- `filter`: `QFilter`
- `selectFields`: `String` — 查询字段列表
- `queryDate`: `Date` — 查询日期

**返回值：**
- `DynamicObjectCollection`: dataObj

---

### queryBaseDataFromCache

从缓存获取基础资料

**方法签名：**
```java
public Map<Object,DynamicObject> queryBaseDataFromCache(String entityID, Long orgID, QFilter filter, String selectFields)
```

**参数说明：**
- `entityID`: `String` — 资料实体
- `orgID`: `Long` — 组织id
- `filter`: `QFilter` — 过滤条件
- `selectFields`: `String` — 查询字段

**返回值：**
- `Map<Object,DynamicObject>`: 组织可以使用的数据信息

---

### refreshBaseDataUseRange

刷新基础资料使用范围

**方法签名：**
```java
public void refreshBaseDataUseRange(String entityID, List<Long> orgIdParamList)
```

**参数说明：**
- `entityID`: `String` — 实体标识
- `orgIdParamList`: `List<Long>` — 组织ID列表

---

### repairNewPropsValue

模板新加入属性，历史数据矫正接口

**方法签名：**
```java
public boolean repairNewPropsValue(String entity)
```

**参数说明：**
- `entity`: `String` — 实体标识

**返回值：**
- `boolean`: 成功true/false

---

### saveBaseDataExc

**重载 1**

描述：保存基础数据修改化排除表

**方法签名：**
```java
public void saveBaseDataExc(String entityID, List<Long> dataIds, Long createOrgID, List<Long> orgIds)
```

**参数说明：**
- `entityID`: `String` — 基础资料实体ID
- `dataIds`: `List<Long>` — 基础数据ID
- `createOrgID`: `Long` — 创建组织ID
- `orgIds`: `List<Long>` — 组织ID集合

---

**重载 2**

描述：保存基础数据修改化排除表

**方法签名：**
```java
public void saveBaseDataExc(DynamicObject dataInfo, Long dataPk, Long createOrgID, List<Long> orgList)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据ID
- `dataPk`: `Long` — 数据id
- `createOrgID`: `Long` — 组织ID
- `orgList`: `List<Long>` — 组织ID集合

---

### saveHistoryInfo

描述：保存版本化数据，处理使用范围表数据。

**方法签名：**
```java
public static boolean saveHistoryInfo(DynamicObject dataInfo)
```

**参数说明：**
- `dataInfo`: `DynamicObject` — 基础数据

**返回值：**
- `boolean`: true

---

### treeNodeUpdate

用于树形列表更新节点

**方法签名：**
```java
public boolean treeNodeUpdate(Object currentId, Object newParentId, GroupProp prop)
```

**参数说明：**
- `currentId`: `Object`
- `newParentId`: `Object`
- `prop`: `GroupProp`

**返回值：**
- `boolean`: 操作结果

---

### validateBeforeBaseDataImport

{待补充}

**方法签名：**
```java
public MulImportCtrlBaseDataResult validateBeforeBaseDataImport(DynamicObject[] dataObjArr)
```

**参数说明：**
- `dataObjArr`: `DynamicObject[]`

**返回值：**
- `MulImportCtrlBaseDataResult`

---
