---
framework_version: "8.0.1"
api_class: "ComplexPropertyAttribute"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用标注实体类的复杂属性时"
---

# ComplexPropertyAttribute API 说明

## 概述
标注实体类的复杂属性。实现 Annotation。
主要功能：界面显示。

## Import 路径
```java
import kd.bos.dataentity.entity.ComplexPropertyAttribute;
```

---

## 方法列表

### displayName

返回/设置元数据的显示名称，例如列的中文名称

**方法签名：**
```java
public String displayName()
```

**返回值：**
- `String`

---

### name

返回/设置属性名称

**方法签名：**
```java
public String name()
```

**返回值：**
- `String`

---

### refIdPropertyName

返回/设置复杂属性对应的引用Id其对应的属性名称

**方法签名：**
```java
public String refIdPropertyName()
```

**返回值：**
- `String`: 复杂属性对应的引用Id其对应的属性名称

---
