---
framework_version: "8.0.1"
api_class: "DynamicTextColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用动态文本格式化处理类时"
---

# DynamicTextColumnDesc API 说明

## 概述
动态文本格式化处理类。继承自 AbstractColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.DynamicTextColumnDesc;
```

---

## 方法列表

### getFormatExpression

{待补充}

**方法签名：**
```java
public String getFormatExpression()
```

**返回值：**
- `String`: 字段格式化表达式

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---

### setFormatExpression

{待补充}

**方法签名：**
```java
public void setFormatExpression(String formatExpression)
```

**参数说明：**
- `formatExpression`: `String` — 字段格式化表达式

---
