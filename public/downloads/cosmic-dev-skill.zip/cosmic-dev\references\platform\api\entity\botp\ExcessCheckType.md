---
framework_version: "8.0.1"
api_class: "ExcessCheckType"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用反写超额检查控制级别时"
---

# ExcessCheckType API 说明

## 概述
反写超额检查控制级别。实现 Comparable, Serializable。
主要功能：获取描述信息。

## Import 路径
```java
import kd.bos.entity.botp.ExcessCheckType;
```

---

## 方法列表

### desc

获取描述信息

**方法签名：**
```java
public static String desc(ExcessCheckType excessCheckType)
```

**参数说明：**
- `excessCheckType`: `ExcessCheckType`

**返回值：**
- `String`

---
