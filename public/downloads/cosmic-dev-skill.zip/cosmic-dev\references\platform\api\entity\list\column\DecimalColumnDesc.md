---
framework_version: "8.0.1"
api_class: "DecimalColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用数字格式化处理类时"
---

# DecimalColumnDesc API 说明

## 概述
数字格式化处理类。继承自 NumberColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.DecimalColumnDesc;
```

---

## 方法列表

### formatCell

**重载 1**

{待补充}

**方法签名：**
```java
public Object formatCell(DynamicObject dr, Object value, boolean forExport)
```

**参数说明：**
- `dr`: `DynamicObject`
- `value`: `Object`
- `forExport`: `boolean`

**返回值：**
- `Object`

---

**重载 2**

通过设计器的格式化字符串来格式化列表内容

**方法签名：**
```java
public Object formatCell(DynamicObject dr, BigDecimal value)
```

**参数说明：**
- `dr`: `DynamicObject` — 行数据
- `value`: `BigDecimal` — 字段值

**返回值：**
- `Object`: 格式化后的结果

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject o)
```

**参数说明：**
- `o`: `DynamicObject`

**返回值：**
- `Object`

---
