---
framework_version: "8.0.1"
api_class: "ValidatePriority"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用校验器执行优先级：枚举值越低的时"
---

# ValidatePriority API 说明

## 概述
校验器执行优先级：枚举值越低的，最先执行。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.validate.ValidatePriority;
```

---

## 方法列表

### getValue

执行顺序等级

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---

### valueOf

根据顺序等级或者对象

**方法签名：**
```java
public static ValidatePriority valueOf(int level)
```

**参数说明：**
- `level`: `int`

**返回值：**
- `ValidatePriority`

---
