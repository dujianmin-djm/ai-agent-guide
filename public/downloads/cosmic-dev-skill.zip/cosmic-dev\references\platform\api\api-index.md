---
last_updated: "2026-03-07"
total_classes: 1510
total_methods: 14496
---

# API 正向索引

> 按类名查找 API 文档。when_to_use 描述该类的使用场景。

---

## A

### AICommand
当你需要使用WepApi请求时
-> api/entity/api/AICommand.md

### AICommandEvent
当你需要使用AI指令事件参数时
-> api/bill/events/AICommandEvent.md

### AbstractAsyncMService
当你需要使用抽象异步微服务时
-> api/entity/operate/bizrule/asyncbizrule/AbstractAsyncMService.md

### AbstractAsyncOpBizRuleAction
当你需要使用 AbstractAsyncOpBizRuleAction 相关功能时
-> api/entity/operate/bizrule/asyncbizrule/AbstractAsyncOpBizRuleAction.md

### AbstractBasedataController
当你需要使用实现基础资料标准功能时
-> api/base/AbstractBasedataController.md

### AbstractBillPlugIn
当你需要使用单据视图层插件抽象基类时
-> api/bill/AbstractBillPlugIn.md

### AbstractBillWebApiPlugin
当你需要使用单据-自定义WebApi服务插件基类时
-> api/bill/AbstractBillWebApiPlugin.md

### AbstractColumnDesc
当你需要使用列表字段格式化抽象类时
-> api/entity/list/column/AbstractColumnDesc.md

### AbstractConvertPlugIn
当你需要使用单据转换插件基类时
-> api/entity/botp/plugin/AbstractConvertPlugIn.md

### AbstractConvertServiceArgs
当你需要使用单据转换服务方法参数基类时
-> api/entity/botp/runtime/AbstractConvertServiceArgs.md

### AbstractDefValueParamPlugIn
当你需要使用字段默认值配置时
-> api/metadata/entity/fielddefvalue/AbstractDefValueParamPlugIn.md

### AbstractElement
当你需要使用领域模型中的“元素”概念时
-> api/metadata/AbstractElement.md

### AbstractFilterContantParser
当你需要使用自定义比较符扩展插件基类时
-> api/entity/filter/AbstractFilterContantParser.md

### AbstractFilterGridView
当你需要使用过滤视图基类时
-> api/filter/AbstractFilterGridView.md

### AbstractFormDataModel
当你需要使用表单数据模型 IDataModel 抽象实现基类时
-> api/entity/datamodel/AbstractFormDataModel.md

### AbstractFormView
当你需要使用表单视图基类时
-> api/form/AbstractFormView.md

### AbstractFuncParamPlugIn
当你需要使用自定义函数配置插件基类时
-> api/form/func/AbstractFuncParamPlugIn.md

### AbstractList
当你需要使用移动列表表格控件基类时
-> api/list/AbstractList.md

### AbstractListColumn
当你需要使用列表字段抽象类时
-> api/list/AbstractListColumn.md

### AbstractListContainerColumn
当你需要使用列表字段基类时
-> api/list/AbstractListContainerColumn.md

### AbstractListPlugin
当你需要使用PC 端列表插件基类时
-> api/list/plugin/AbstractListPlugin.md

### AbstractMessageInfo
当你需要使用 AbstractMessageInfo 相关功能时
-> api/message/api/AbstractMessageInfo.md

### AbstractMobBillPlugIn
当你需要使用移动端单据视图层插件抽象基类时
-> api/bill/AbstractMobBillPlugIn.md

### AbstractMobF7Plugin
当你需要使用移动F7列表插件基类时
-> api/form/plugin/list/AbstractMobF7Plugin.md

### AbstractMobListPlugin
当你需要使用移动端列表插件基类时
-> api/list/plugin/AbstractMobListPlugin.md

### AbstractNotificationClick
当你需要使用全局通知提醒弹窗点击事件处理抽象基类时
-> api/notification/AbstractNotificationClick.md

### AbstractOpBizRuleAction
当你需要使用操作的服务端服务时
-> api/entity/operate/bizrule/AbstractOpBizRuleAction.md

### AbstractOpBizRuleParameterEdit
当你需要使用操作服务时
-> api/metadata/entity/operation/AbstractOpBizRuleParameterEdit.md

### AbstractOpParameterPlugin
当你需要使用操作参数配置界面基类插件时
-> api/metadata/entity/operation/AbstractOpParameterPlugin.md

### AbstractOperate
当你需要使用操作的基类时
-> api/form/operate/AbstractOperate.md

### AbstractOperateWebApi
当你需要使用Api操作基类时
-> api/form/operate/webapi/AbstractOperateWebApi.md

### AbstractOperationResult
当你需要使用抽象操作结果时
-> api/entity/operate/AbstractOperationResult.md

### AbstractOperationServicePlugIn
当你需要使用单据操作运行时服务层插件抽象基类。时
-> api/entity/plugin/AbstractOperationServicePlugIn.md

### AbstractPrintPlugin
当你需要使用打印插件基类。时
-> api/print/core/plugin/AbstractPrintPlugin.md

### AbstractReportColumn
当你需要使用报表列表列信息抽象基类时
-> api/entity/report/AbstractReportColumn.md

### AbstractReportFormPlugin
当你需要使用报表表单插件基类时
-> api/report/plugin/AbstractReportFormPlugin.md

### AbstractReportListDataPlugin
当你需要使用报表查询取数插件时
-> api/entity/report/AbstractReportListDataPlugin.md

### AbstractReportListDataPluginExt
当你需要使用 AbstractReportListDataPluginExt 相关功能时
-> api/entity/report/AbstractReportListDataPluginExt.md

### AbstractReportListModel
当你需要使用报表列表数据模型抽象类时
-> api/report/AbstractReportListModel.md

### AbstractReportModel
当你需要使用报表数据模型抽象类时
-> api/report/AbstractReportModel.md

### AbstractReportTreeDataPlugin
当你需要使用报表树构造插件时
-> api/entity/report/AbstractReportTreeDataPlugin.md

### AbstractSession
当你需要使用分布式事务会话 抽象类时
-> api/kdtx/sdk/session/AbstractSession.md

### AbstractStyle
当你需要使用外观元素的样式时
-> api/metadata/form/AbstractStyle.md

### AbstractTask
当你需要使用任务基类时
-> api/schedule/executor/AbstractTask.md

### AbstractTaskClick
当你需要使用后台任务图标点击事件处理抽象基类时
-> api/schedule/form/AbstractTaskClick.md

### AbstractTreeListPlugin
当你需要使用树形列表插件基类时
-> api/list/plugin/AbstractTreeListPlugin.md

### AbstractTreeListView
当你需要使用树形基础资料列表视图时
-> api/list/AbstractTreeListView.md

### AbstractUpgradePlugin
当你需要使用升级插件抽象类时
-> api/form/upgrade/AbstractUpgradePlugin.md

### AbstractValidationParamPlugin
当你需要使用操作校验器参数配置界面基类时
-> api/metadata/entity/validation/AbstractValidationParamPlugin.md

### AbstractValidator
当你需要使用操作校验器基类时
-> api/entity/validate/AbstractValidator.md

### AbstractWriteBackPlugIn
当你需要使用反写插件抽象基类；所有反写插件，均从此类派生，不要直接实现反写插件接口，避免接口时
-> api/entity/botp/plugin/AbstractWriteBackPlugIn.md

### AddCustomViewEvent
当你需要使用添加自定义视图参数时
-> api/form/events/AddCustomViewEvent.md

### AddFuzzySearchEvent
当你需要使用添加模糊搜索事件参数时
-> api/form/field/events/AddFuzzySearchEvent.md

### AddSignInfo
当你需要使用 AddSignInfo 相关功能时
-> api/workflow/engine/dynprocess/AddSignInfo.md

### AddValidatorsEventArgs
当你需要使用单据操作插件IOperationServicePlugIn - onAddValidators 事件参数时
-> api/entity/plugin/AddValidatorsEventArgs.md

### AdminDivisionColumnDesc
当你需要使用行政区划格式化类时
-> api/entity/list/column/AdminDivisionColumnDesc.md

### AdminType
当你需要使用管理员类型时
-> api/permission/model/AdminType.md

### AduitLogServiceHelper
当你需要使用审计日志服务时
-> api/servicehelper/log/AduitLogServiceHelper.md

### AdvConAp
当你需要使用带菜单、折叠的容器控件时
-> api/metadata/form/container/AdvConAp.md

### AdvConBarItemAp
当你需要使用高级容器-工具栏-按钮时
-> api/metadata/form/container/AdvConBarItemAp.md

### AdvConChildPanelAp
当你需要使用高级面板-内容子面板时
-> api/metadata/form/container/AdvConChildPanelAp.md

### AdvConSummaryPanelAp
当你需要使用高级面板-内容摘要子面板时
-> api/metadata/form/container/AdvConSummaryPanelAp.md

### AdvConToolbarAp
当你需要使用高级面板-工具栏时
-> api/metadata/form/container/AdvConToolbarAp.md

### AfterAddRowEventArgs
当你需要使用添加行后事件参数时
-> api/entity/datamodel/events/AfterAddRowEventArgs.md

### AfterBindingDataEvent
当你需要使用绑定数据之后事件参数时
-> api/form/field/events/AfterBindingDataEvent.md

### AfterBizRuleEventArgs
当你需要使用业务规则后事件时
-> api/entity/botp/plugin/args/AfterBizRuleEventArgs.md

### AfterBuildDrawFilterEventArgs
当你需要使用选单前时
-> api/entity/botp/plugin/args/AfterBuildDrawFilterEventArgs.md

### AfterBuildQueryParemeterEventArgs
当你需要使用构建取数参数后事件：可在正式读取源单数据之前时
-> api/entity/botp/plugin/args/AfterBuildQueryParemeterEventArgs.md

### AfterBuildRowConditionEventArgs
当你需要使用转换规则时
-> api/entity/botp/plugin/args/AfterBuildRowConditionEventArgs.md

### AfterBuildSourceBillIdsEventArgs
当你需要使用建立源单单据内码和分录内码之后, 触发此事件: 用于添加需要加载的源单单据与单据分录行时
-> api/entity/botp/plugin/args/AfterBuildSourceBillIdsEventArgs.md

### AfterCalcWriteValueEventArgs
当你需要使用计算反写值之后事件时
-> api/entity/botp/plugin/args/AfterCalcWriteValueEventArgs.md

### AfterCloseRowEventArgs
当你需要使用对上游行进行了关闭状态填写后调用时
-> api/entity/botp/plugin/args/AfterCloseRowEventArgs.md

### AfterCommitAmountEventArgs
当你需要使用执行反写规则时
-> api/entity/botp/plugin/args/AfterCommitAmountEventArgs.md

### AfterConvertEventArgs
当你需要使用单据转换后事件时
-> api/entity/botp/plugin/args/AfterConvertEventArgs.md

### AfterCreateLinkEventArgs
当你需要使用记录关联关系后事件：根据系统自动记录的关联关系时
-> api/entity/botp/plugin/args/AfterCreateLinkEventArgs.md

### AfterCreateTargetEventArgs
当你需要使用创建目标单据数据包后事件：把根据分单规则创建好的目标单时
-> api/entity/botp/plugin/args/AfterCreateTargetEventArgs.md

### AfterDeleteEntryEventArgs
当你需要使用删除分录后事件参数时
-> api/entity/datamodel/events/AfterDeleteEntryEventArgs.md

### AfterDeleteRowEventArgs
当你需要使用删除行之后事件参数时
-> api/entity/datamodel/events/AfterDeleteRowEventArgs.md

### AfterDoOperationEventArgs
当你需要使用操作之后事件参数时
-> api/form/events/AfterDoOperationEventArgs.md

### AfterExcessCheckEventArgs
当你需要使用对源单行反写执行完毕时
-> api/entity/botp/plugin/args/AfterExcessCheckEventArgs.md

### AfterExportEntryEvent
当你需要使用单据体引出事件参数时
-> api/form/plugin/AfterExportEntryEvent.md

### AfterF7SelectEvent
当你需要使用F7选择后事件参数时
-> api/form/field/events/AfterF7SelectEvent.md

### AfterF7SelectListener
当你需要使用F7选择后事件接口时
-> api/form/field/events/AfterF7SelectListener.md

### AfterFieldMappingEventArgs
当你需要使用目标字段赋值完毕后事件：插件可以在此基础上时
-> api/entity/botp/plugin/args/AfterFieldMappingEventArgs.md

### AfterGetSourceDataEventArgs
当你需要使用取源单数据后事件：根据源单数据时
-> api/entity/botp/plugin/args/AfterGetSourceDataEventArgs.md

### AfterLoadDataEvent
当你需要使用数据加载后事件参数时
-> api/print/core/plugin/event/AfterLoadDataEvent.md

### AfterMoveEntryEventArgs
当你需要使用移动行之后事件参数时
-> api/entity/datamodel/events/AfterMoveEntryEventArgs.md

### AfterOperationArgs
当你需要使用操作事务提交后事件参数时
-> api/entity/plugin/args/AfterOperationArgs.md

### AfterOutputGridEvent
当你需要使用表格时
-> api/print/core/plugin/event/AfterOutputGridEvent.md

### AfterOutputRowEvent
当你需要使用表格时
-> api/print/core/plugin/event/AfterOutputRowEvent.md

### AfterOutputWidgetEvent
当你需要使用控件输出后事件参数时
-> api/print/core/plugin/event/AfterOutputWidgetEvent.md

### AfterQueryEvent
当你需要使用查询扩展插件功能事件参数时
-> api/event/AfterQueryEvent.md

### AfterQueryOfExportEvent
当你需要使用查询引出数据后事件参数时
-> api/form/events/AfterQueryOfExportEvent.md

### AfterReadSourceBillEventArgs
当你需要使用读取源单数据之后时
-> api/entity/botp/plugin/args/AfterReadSourceBillEventArgs.md

### AfterSaveSourceBillEventArgs
当你需要使用源单数据保存到数据库后调用时
-> api/entity/botp/plugin/args/AfterSaveSourceBillEventArgs.md

### AfterTogetherMoveEntryRowEventArgs
当你需要使用聚合分录行移动后事件参数时
-> api/entity/datamodel/events/AfterTogetherMoveEntryRowEventArgs.md

### AgentExecution
当你需要使用 AgentExecution 相关功能时
-> api/workflow/api/AgentExecution.md

### AgentUtil
当你需要使用客户端浏览器识别工具类时
-> api/login/utils/AgentUtil.md

### AggregateInfo
当你需要使用 AggregateInfo 相关功能时
-> api/workflow/engine/extitf/AggregateInfo.md

### AggregateResult
当你需要使用 AggregateResult 相关功能时
-> api/workflow/engine/extitf/AggregateResult.md

### Algo
当你需要使用此类可以用来创建algo上下文信息、DataSetBuilder、DataSet、CacheDataSet等时
-> api/algo/Algo.md

### AlgoExceedAllowMaxDataSetsException
当你需要使用当前线程dataset数量超过最大值异常时
-> api/algo/exception/AlgoExceedAllowMaxDataSetsException.md

### AlgoExceedAllowMaxRows4SortException
当你需要使用排序超过最大行数异常信息时
-> api/algo/exception/AlgoExceedAllowMaxRows4SortException.md

### AlgoExceedAllowMaxRowsException
当你需要使用超过最大行数异常信息时
-> api/algo/exception/AlgoExceedAllowMaxRowsException.md

### AlgoExceedAllowMaxRowsToDiskException
当你需要使用写入磁盘超过最大行数异常信息时
-> api/algo/exception/AlgoExceedAllowMaxRowsToDiskException.md

### AlgoExceedCollectionAllowMaxCellsException
当你需要使用CollectionInput、CollectionDataSet允许的最大行数时
-> api/algo/exception/AlgoExceedCollectionAllowMaxCellsException.md

### AlgoException
当你需要使用Algo异常信息时
-> api/algo/AlgoException.md

### AlgoTimeOutException
当你需要使用Algo超时异常时
-> api/algo/exception/AlgoTimeOutException.md

### AlgoX
当你需要使用分布式计算接口时
-> api/algox/AlgoX.md

### AmountColumnDesc
当你需要使用金额格式化类时
-> api/entity/list/column/AmountColumnDesc.md

### AmountConvertResult
当你需要使用`AmountConvertResult` 金额转换结果类时
-> api/i18n/mservice/utils/AmountConvertResult.md

### AmountDataGridColumn
当你需要使用金额列时
-> api/form/control/grid/column/AmountDataGridColumn.md

### AmountDataGridColumnAp
当你需要使用金额列时
-> api/metadata/form/control/grid/column/AmountDataGridColumnAp.md

### AmountMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/AmountMobTableColumnAp.md

### AnchorItems
当你需要使用锚点数据集合时
-> api/entity/AnchorItems.md

### AnyType
当你需要使用Algo中的一种数据类型时
-> api/algo/datatype/AnyType.md

### ApiController
当你需要使用自定义API 插件类标识注解时
-> api/openapi/common/custom/annotation/ApiController.md

### ApiErrorCode
当你需要使用错误代码注解时
-> api/openapi/common/custom/annotation/ApiErrorCode.md

### ApiErrorCodes
当你需要使用错误代码注解时
-> api/openapi/common/custom/annotation/ApiErrorCodes.md

### ApiGetMapping
当你需要使用GET请求注解时
-> api/openapi/common/custom/annotation/ApiGetMapping.md

### ApiHeader
当你需要使用API请求头信息注解时
-> api/openapi/common/custom/annotation/ApiHeader.md

### ApiHeaders
当你需要使用API请求头信息注解时
-> api/openapi/common/custom/annotation/ApiHeaders.md

### ApiMapping
当你需要使用请求路径（方法映射路径前缀）注解时
-> api/openapi/common/custom/annotation/ApiMapping.md

### ApiParam
当你需要使用参数或model类中属性的注解时
-> api/openapi/common/custom/annotation/ApiParam.md

### ApiPostMapping
当你需要使用POST请求注解时
-> api/openapi/common/custom/annotation/ApiPostMapping.md

### ApiRequestBody
当你需要使用API参数注解时
-> api/openapi/common/custom/annotation/ApiRequestBody.md

### ApiResponseBody
当你需要使用返回值注解时
-> api/openapi/common/custom/annotation/ApiResponseBody.md

### ApiResult
当你需要使用WebAPI 请求返回结果时
-> api/entity/api/ApiResult.md

### AppCache
当你需要使用业务应用缓存时
-> api/entity/cache/AppCache.md

### AppCustomParam
当你需要使用应用参数时
-> api/entity/param/AppCustomParam.md

### AppInfo
当你需要使用业务应用时
-> api/entity/AppInfo.md

### AppMenuInfo
当你需要使用业务应用-首页菜单项时
-> api/entity/AppMenuInfo.md

### AppMetaServiceHelper
当你需要使用应用元数据服务帮助类时
-> api/servicehelper/devportal/AppMetaServiceHelper.md

### AppMetadataCache
当你需要使用应用元数据服务类,用于获取应用元数据的信息时
-> api/entity/AppMetadataCache.md

### AppParam
当你需要使用应用参数实体对象时
-> api/entity/param/AppParam.md

### AppStarter
当你需要使用 AppStarter 相关功能时
-> api/framework/lifecycle/appstart/AppStarter.md

### ApprovalPageTpl
当你需要使用审批处理模板插件_提供数据、逻辑处理时
-> api/workflow/management/plugin/ApprovalPageTpl.md

### ApprovalRecord
当你需要使用 ApprovalRecord 相关功能时
-> api/workflow/engine/impl/persistence/entity/task/component/ApprovalRecord.md

### ApprovalRecordGroup
当你需要使用 ApprovalRecordGroup 相关功能时
-> api/workflow/engine/impl/persistence/entity/task/component/ApprovalRecordGroup.md

### ApprovalRecordItem
当你需要使用 ApprovalRecordItem 相关功能时
-> api/workflow/engine/impl/persistence/entity/task/component/ApprovalRecordItem.md

### ApproverColumnDesc
当你需要使用当前审批人列表字段格式化处理类时
-> api/entity/list/column/ApproverColumnDesc.md

### ApproverListField
当你需要使用列表列字段 - 当前审批人字段列时
-> api/entity/datamodel/ApproverListField.md

### ArchiveInfo
当你需要使用归档路由信息时
-> api/db/archive/ArchiveInfo.md

### ArchiveRoute
当你需要使用归档路由映射，线程上下文生效。时
-> api/db/archive/ArchiveRoute.md

### ArrayUtils
当你需要使用Operations on arrays, primitive arrays (like ` int[]`) and时
-> api/dataentity/utils/ArrayUtils.md

### AssignModEnum
当你需要使用授权的分配模式枚举时
-> api/permission/enums/AssignModEnum.md

### AssistantDataServiceHelper
当你需要使用辅助资料帮助类时
-> api/servicehelper/basedata/AssistantDataServiceHelper.md

### AtomicIncrement
当你需要使用 AtomicIncrement 相关功能时
-> api/atomicincr/AtomicIncrement.md

### AttDto
当你需要使用配置附件绑定到业务单据时所需的映射属性时
-> api/servicehelper/AttDto.md

### AttachmentControlUtil
当你需要使用附件相关控件工具类时
-> api/form/attachment/util/AttachmentControlUtil.md

### AttachmentCountField
当你需要使用附件数量字段时
-> api/metadata/entity/commonfield/AttachmentCountField.md

### AttachmentDownLoadEvent
当你需要使用附件下载事件时
-> api/form/control/events/AttachmentDownLoadEvent.md

### AttachmentDownloadArgs
当你需要使用OpenApi附件下载参数类时
-> api/service/attachment/controller/param/AttachmentDownloadArgs.md

### AttachmentEdit
当你需要使用附件字段运行时编辑对象时
-> api/form/field/AttachmentEdit.md

### AttachmentField
当你需要使用附件字段时
-> api/metadata/entity/commonfield/AttachmentField.md

### AttachmentFieldSaveDto
当你需要使用附件字段持久化附件时所使用的参数对象时
-> api/servicehelper/attachment/AttachmentFieldSaveDto.md

### AttachmentFieldServiceHelper
当你需要使用附件字段服务帮助类时
-> api/servicehelper/attachment/AttachmentFieldServiceHelper.md

### AttachmentMarkEvent
当你需要使用附件备注事件时
-> api/form/control/events/AttachmentMarkEvent.md

### AttachmentMobTableColumn
当你需要使用附件列时
-> api/form/mcontrol/mobtable/tablecolumn/AttachmentMobTableColumn.md

### AttachmentOperaClickEvent
当你需要使用附件自定义按钮点击事件时
-> api/form/control/events/AttachmentOperaClickEvent.md

### AttachmentPanel
当你需要使用附件面板时
-> api/form/control/AttachmentPanel.md

### AttachmentPanelAp
当你需要使用通用控件--附件面板控件时
-> api/metadata/form/control/AttachmentPanelAp.md

### AttachmentPanelMapItem
当你需要使用附件面板对象时
-> api/entity/botp/AttachmentPanelMapItem.md

### AttachmentPanelMapPolicy
当你需要使用附件面板映射策略时
-> api/entity/botp/AttachmentPanelMapPolicy.md

### AttachmentPreviewEvent
当你需要使用附件预览事件时
-> api/form/control/events/AttachmentPreviewEvent.md

### AttachmentProp
当你需要使用附件字段属性时
-> api/entity/property/AttachmentProp.md

### AttachmentServiceHelper
当你需要使用附件帮助服务类 提供附件上传/获取/删除/备注等方法接口时
-> api/servicehelper/AttachmentServiceHelper.md

### AttachmentUploadFileArgs
当你需要使用OpenApi上传附件入参,适用于单据、基础资料实体上的附件字段、附件面板的附件上传和绑定时
-> api/service/attachment/controller/param/AttachmentUploadFileArgs.md

### AttachmentUploadFileResult
当你需要使用OpenApi上传附件结果时
-> api/service/attachment/controller/result/AttachmentUploadFileResult.md

### Avg
当你需要使用平均时
-> api/formula/functions/Avg.md

### Axis
当你需要使用坐标轴类时
-> api/form/chart/Axis.md

---

## B

### BFRow
当你需要使用钩稽行：记录源单、目标单之间的关联关系时
-> api/entity/botp/runtime/BFRow.md

### BFRowId
当你需要使用实体行标识：实体表格编码+实体行内码时
-> api/entity/botp/runtime/BFRowId.md

### BFRowLinkDownNode
当你需要使用业务流程往下追溯树节点时
-> api/entity/botp/runtime/BFRowLinkDownNode.md

### BFRowLinkUpNode
当你需要使用业务流程往上追溯树节点时
-> api/entity/botp/runtime/BFRowLinkUpNode.md

### BFTrackerServiceHelper
当你需要使用单据转换时
-> api/servicehelper/botp/BFTrackerServiceHelper.md

### BOSExpression
当你需要使用解析后的表达式时
-> api/entity/formula/BOSExpression.md

### BRErrorCode
当你需要使用表单业务规则（或界面规则）执行异常编码时
-> api/entity/rule/BRErrorCode.md

### BackPressedEvent
当你需要使用回退点击事件时
-> api/list/events/BackPressedEvent.md

### BadgeInfo
当你需要使用徽章信息时
-> api/entity/BadgeInfo.md

### BarChart
当你需要使用条形图时
-> api/form/chart/BarChart.md

### BarChartAp
当你需要使用条形图时
-> api/metadata/form/chart/BarChartAp.md

### BarSeries
当你需要使用条形图图表序列时
-> api/form/chart/BarSeries.md

### BaseDataColumnDependFieldSetEvent
当你需要使用设置常用过滤的基础资料依赖字段事件参数时
-> api/form/control/events/BaseDataColumnDependFieldSetEvent.md

### BaseDataColumnDesc
当你需要使用基础资料格式化类时
-> api/entity/list/column/BaseDataColumnDesc.md

### BaseDataCommonService
当你需要使用处理其它相对小的业务功能时
-> api/bd/service/BaseDataCommonService.md

### BaseDataCustomControllerEvent
当你需要使用基础资料个性化逻辑控制功能事件参数时
-> api/form/field/events/BaseDataCustomControllerEvent.md

### BaseDataRefColumnDesc
当你需要使用基础资料属性格式化处理类时
-> api/entity/list/column/BaseDataRefColumnDesc.md

### BaseDataRefrenceHelper
当你需要使用基础资料引用检查帮助类时
-> api/servicehelper/basedata/BaseDataRefrenceHelper.md

### BaseDataResponse
当你需要使用返回信息pojo时
-> api/entity/basedata/BaseDataResponse.md

### BaseDataSearchHelper
当你需要使用基础资料搜素帮助类时
-> api/filter/helper/BaseDataSearchHelper.md

### BaseDataService
当你需要使用 BaseDataService 相关功能时
-> api/servicehelper/basedata/BaseDataService.md

### BaseDataServiceHelper
当你需要使用基础数据服务时
-> api/servicehelper/basedata/BaseDataServiceHelper.md

### BaseDataServiceImpl
当你需要使用 BaseDataServiceImpl 相关功能时
-> api/basedata/service/BaseDataServiceImpl.md

### BaseDataUseRelBit
当你需要使用 BaseDataUseRelBit 相关功能时
-> api/bd/pojo/BaseDataUseRelBit.md

### BaseDataUseRelQueryEngine
当你需要使用查询服务时
-> api/bd/engine/BaseDataUseRelQueryEngine.md

### BaseEntity
当你需要使用基础资料对应的实体时
-> api/metadata/entity/BaseEntity.md

### BaseGraphicStyle
当你需要使用原生图形元素的样式时
-> api/form/chart/BaseGraphicStyle.md

### BaseGraphicType
当你需要使用原生图形元素组件类型时
-> api/form/chart/BaseGraphicType.md

### BaseShowParameter
当你需要使用基础资料界面显示参数时
-> api/base/BaseShowParameter.md

### BasedataEditListener
当你需要使用绑定数据之后事件接口时
-> api/form/field/events/BasedataEditListener.md

### BasedataEntityType
当你需要使用基础资料实体类型时
-> api/entity/BasedataEntityType.md

### BasedataFuzzySearchEvent
当你需要使用模糊查询事件参数时
-> api/form/field/events/BasedataFuzzySearchEvent.md

### BasedataFuzzySearchListener
当你需要使用基础资料模糊查询干预api事件接口时
-> api/form/field/events/BasedataFuzzySearchListener.md

### BasedataHelper
当你需要使用 BasedataHelper 相关功能时
-> api/base/BasedataHelper.md

### BasedataItem
当你需要使用基础资料数据条目（基础资料字段 + 基础资料类型 + 组织 + 编码、名称字段值）时
-> api/entity/datamodel/BasedataItem.md

### BatchDownloadRequest
当你需要使用批量下载请求实体时
-> api/fileservice/BatchDownloadRequest.md

### BatchDownloadRequest.Dir
当你需要使用表示压缩包内的虚拟目录结构（支持多级嵌套）时
-> api/fileservice/BatchDownloadRequest.Dir.md

### BatchDownloadRequest.File
当你需要使用定义压缩包内单个文件时
-> api/fileservice/BatchDownloadRequest.File.md

### BatchImportPlugin
当你需要使用导入流程扩展插件时
-> api/form/plugin/impt/BatchImportPlugin.md

### BatchOperateResult
当你需要使用批量操作结果时
-> api/workflow/engine/task/BatchOperateResult.md

### BatchResult
当你需要使用 BatchResult 相关功能时
-> api/workflow/api/BatchResult.md

### BatchResult.ItemResult
当你需要使用 BatchResult.ItemResult 相关功能时
-> api/workflow/api/BatchResult.ItemResult.md

### BeforeAttachmentRemoveEvent
当你需要使用附件删除前时
-> api/form/control/events/BeforeAttachmentRemoveEvent.md

### BeforeAttachmentUploadEvent
当你需要使用附件上传前时
-> api/form/control/events/BeforeAttachmentUploadEvent.md

### BeforeBuildGroupModeEventArgs
当你需要使用构建分单、行合并模式之前事件：调整分单、合并策略及依赖的字段时
-> api/entity/botp/plugin/args/BeforeBuildGroupModeEventArgs.md

### BeforeBuildRowConditionEventArgs
当你需要使用编译数据筛选条件前事件：可追加定制条件时
-> api/entity/botp/plugin/args/BeforeBuildRowConditionEventArgs.md

### BeforeBuildTreeNodeEvent
当你需要使用构建树节点前置处理事件参数时
-> api/form/events/BeforeBuildTreeNodeEvent.md

### BeforeChangeMainOrgEventArgs
当你需要使用新建单据时
-> api/form/field/events/BeforeChangeMainOrgEventArgs.md

### BeforeCloseRowEventArgs
当你需要使用关闭上游行前调用时
-> api/entity/botp/plugin/args/BeforeCloseRowEventArgs.md

### BeforeClosedEvent
当你需要使用窗口关闭前操作事件参数时
-> api/form/events/BeforeClosedEvent.md

### BeforeCreateArticulationRowEventArgs
当你需要使用构建本关联主实体时
-> api/entity/botp/plugin/args/BeforeCreateArticulationRowEventArgs.md

### BeforeCreateLinkEventArgs
当你需要使用记录关联关系前事件：取消记录关联关系时
-> api/entity/botp/plugin/args/BeforeCreateLinkEventArgs.md

### BeforeCreateListColumnsArgs
当你需要使用创建列表前事件参数时
-> api/form/events/BeforeCreateListColumnsArgs.md

### BeforeCreateListDataProviderArgs
当你需要使用创建列表数据访问类前置事件参数时
-> api/form/events/BeforeCreateListDataProviderArgs.md

### BeforeCreateMobTableColumnsEvent
当你需要使用创建移动表格列前事件参数时
-> api/form/mcontrol/mobtable/events/BeforeCreateMobTableColumnsEvent.md

### BeforeDeleteEntryEventArgs
当你需要使用清空分录数据前事件参数时
-> api/entity/datamodel/events/BeforeDeleteEntryEventArgs.md

### BeforeDeleteRowEventArgs
当你需要使用删除分录行之前事件参数时
-> api/entity/datamodel/events/BeforeDeleteRowEventArgs.md

### BeforeDoCheckDataPermissionArgs
当你需要使用操作检查数据权限前事件参数时
-> api/form/events/BeforeDoCheckDataPermissionArgs.md

### BeforeDoOperationEventArgs
当你需要使用操作之前事件参数时
-> api/form/events/BeforeDoOperationEventArgs.md

### BeforeDownloadImportEntryTemplateEvent
当你需要使用单据体导入模板下载前事件时
-> api/form/plugin/importentry/strategy/BeforeDownloadImportEntryTemplateEvent.md

### BeforeDownloadImportTemplateEvent
当你需要使用下载单据引入模板注册事件参数时
-> api/form/plugin/BeforeDownloadImportTemplateEvent.md

### BeforeDrawArgs
当你需要使用选单前服务参数时
-> api/entity/botp/runtime/BeforeDrawArgs.md

### BeforeDrawOpResult
当你需要使用选单前操作结果：输出选单条件、源单主业务组织时
-> api/entity/botp/runtime/BeforeDrawOpResult.md

### BeforeExcessCheckEventArgs
当你需要使用对源单行反写执行完毕时
-> api/entity/botp/plugin/args/BeforeExcessCheckEventArgs.md

### BeforeExecWriteBackRuleEventArgs
当你需要使用开始分析反写规则时
-> api/entity/botp/plugin/args/BeforeExecWriteBackRuleEventArgs.md

### BeforeExportEntryEvent
当你需要使用单据体引出事件参数时
-> api/form/plugin/BeforeExportEntryEvent.md

### BeforeExportEvent
当你需要使用打印引擎输出文件前事件参数时
-> api/print/core/plugin/event/BeforeExportEvent.md

### BeforeExportFileEvent
当你需要使用列表引出文件前事件参数时
-> api/form/events/BeforeExportFileEvent.md

### BeforeF7PrepareUserOrgsEvent
当你需要使用选择基础资料前（弹出过滤窗口前）事件参数, 设置基础资料字段关联的组织时
-> api/form/field/events/BeforeF7PrepareUserOrgsEvent.md

### BeforeF7SelectEvent
当你需要使用选择基础资料前（弹出过滤窗口前）事件参数时
-> api/form/field/events/BeforeF7SelectEvent.md

### BeforeF7SelectListener
当你需要使用选择基础资料前（弹出过滤窗口前）事件接口时
-> api/form/field/events/BeforeF7SelectListener.md

### BeforeF7ViewDetailEvent
当你需要使用查看F7明细事件参数时
-> api/form/field/events/BeforeF7ViewDetailEvent.md

### BeforeFieldPostBackEvent
当你需要使用客户端提交字段值到服务端事件参数时
-> api/form/events/BeforeFieldPostBackEvent.md

### BeforeFilterF7SelectEvent
当你需要使用过滤容器F7弹出之前事件参数时
-> api/form/field/events/BeforeFilterF7SelectEvent.md

### BeforeFilterF7SelectListener
当你需要使用选择基础资料前（弹出过滤窗口前）事件监听器接口时
-> api/form/field/events/BeforeFilterF7SelectListener.md

### BeforeGetSourceDataEventArgs
当你需要使用取源单数据前事件：可在正式读取源单数据之前时
-> api/entity/botp/plugin/args/BeforeGetSourceDataEventArgs.md

### BeforeImageUploadEvent
当你需要使用图片上传前时
-> api/form/control/events/BeforeImageUploadEvent.md

### BeforeImportDataEventArgs
当你需要使用引入前事件参数时
-> api/entity/datamodel/events/BeforeImportDataEventArgs.md

### BeforeImportEntryEventArgs
当你需要使用单据体引入前事件时
-> api/entity/datamodel/events/BeforeImportEntryEventArgs.md

### BeforeInitWidgetEvent
当你需要使用控件初始化前事件类时
-> api/print/core/plugin/event/BeforeInitWidgetEvent.md

### BeforeLoadDataEvent
当你需要使用数据加载前事件参数时
-> api/print/core/plugin/event/BeforeLoadDataEvent.md

### BeforeOperationArgs
当你需要使用操作校验通过时
-> api/entity/plugin/args/BeforeOperationArgs.md

### BeforeOutputGridEvent
当你需要使用表格时
-> api/print/core/plugin/event/BeforeOutputGridEvent.md

### BeforeOutputRowEvent
当你需要使用表格时
-> api/print/core/plugin/event/BeforeOutputRowEvent.md

### BeforeOutputTextEvent
当你需要使用文本控件输出前事件类时
-> api/print/core/plugin/event/BeforeOutputTextEvent.md

### BeforeOutputWidgetEvent
当你需要使用控件输出前事件参数时
-> api/print/core/plugin/event/BeforeOutputWidgetEvent.md

### BeforePackageDataEvent
当你需要使用单据列表控件数据格式化前事件参数时
-> api/entity/datamodel/events/BeforePackageDataEvent.md

### BeforeQueryOfExportEvent
当你需要使用查询引出数据前事件参数时
-> api/form/events/BeforeQueryOfExportEvent.md

### BeforeQuickAddNewEvent
当你需要使用快捷新增前事件参数时
-> api/form/field/events/BeforeQuickAddNewEvent.md

### BeforeQuickAddNewListener
当你需要使用快捷新增前事件接口时
-> api/form/field/events/BeforeQuickAddNewListener.md

### BeforeReadSourceBillEventArgs
当你需要使用读取源单数据之前时
-> api/entity/botp/plugin/args/BeforeReadSourceBillEventArgs.md

### BeforeSaveAuditLogArg
当你需要使用操作完成时
-> api/entity/plugin/args/BeforeSaveAuditLogArg.md

### BeforeSaveAuditLogEvent
当你需要使用 BeforeSaveAuditLogEvent 相关功能时
-> api/entity/plugin/args/BeforeSaveAuditLogEvent.md

### BeforeSaveSourceBillEventArgs
当你需要使用反写规则执行完毕后时
-> api/entity/botp/plugin/args/BeforeSaveSourceBillEventArgs.md

### BeforeSetItemValueEventArgs
当你需要使用基础资料字段赋值前事件参数时
-> api/entity/datamodel/events/BeforeSetItemValueEventArgs.md

### BeforeShowAttachmentsArgs
当你需要使用展示附件前参数信息时
-> api/form/control/events/BeforeShowAttachmentsArgs.md

### BeforeShowBillFormEvent
当你需要使用操作弹窗前事件时
-> api/list/events/BeforeShowBillFormEvent.md

### BeforeShowEmbedFormEvent
当你需要使用嵌入页面控件 EmbedForm时
-> api/form/control/embedform/BeforeShowEmbedFormEvent.md

### BeforeSubmitCustomEventArgs
当你需要使用审批处理提交之前CustomEvent事件时
-> api/workflow/taskcenter/plugin/validate/BeforeSubmitCustomEventArgs.md

### BeforeSubmitCustomEventArgsClosedCallBack
当你需要使用审批处理提交前CustomEvent的回调事件时
-> api/workflow/taskcenter/plugin/validate/BeforeSubmitCustomEventArgsClosedCallBack.md

### BeforeTogetherMoveEntryRowEventArgs
当你需要使用聚合分录行移动前事件参数时
-> api/entity/datamodel/events/BeforeTogetherMoveEntryRowEventArgs.md

### BeforeTrackEventArgs
当你需要使用构建本关联主实体全部关联记录前时
-> api/entity/botp/plugin/args/BeforeTrackEventArgs.md

### BeginOperationTransactionArgs
当你需要使用操作开启事务后事件参数时
-> api/entity/plugin/args/BeginOperationTransactionArgs.md

### BigDecimalType
当你需要使用Algo中的数据类型,对应Java类型为BigDecimal时
-> api/algo/datatype/BigDecimalType.md

### BillCloseType
当你需要使用源单关闭方式时
-> api/entity/botp/BillCloseType.md

### BillClosedCallBackEvent
当你需要使用单据关闭回调事件时
-> api/list/events/BillClosedCallBackEvent.md

### BillEntity
当你需要使用单据体实体时
-> api/metadata/entity/BillEntity.md

### BillEntityType
当你需要使用单据实体类型时
-> api/entity/BillEntityType.md

### BillFormAp
当你需要使用单据界面设计元数据时
-> api/metadata/form/BillFormAp.md

### BillList
当你需要使用单据列表控件时
-> api/list/BillList.md

### BillListAp
当你需要使用设计时时
-> api/metadata/list/BillListAp.md

### BillListHyperLinkClickEvent
当你需要使用单据列表单元格链接点击事件参数时
-> api/form/events/BillListHyperLinkClickEvent.md

### BillOperationStatus
当你需要使用单据界面操作状态时
-> api/bill/BillOperationStatus.md

### BillParam
当你需要使用单据参数对象时
-> api/entity/param/BillParam.md

### BillSetting
当你需要使用单据设置动态模型时
-> api/workflow/bpmn/model/BillSetting.md

### BillShowParameter
当你需要使用单据界面显示参数时
-> api/bill/BillShowParameter.md

### BillStatus
当你需要使用单据状态值时
-> api/entity/validate/BillStatus.md

### BillTypeControlInfo
当你需要使用单据类型时
-> api/entity/BillTypeControlInfo.md

### BillTypeDifferentialHelper
当你需要使用 BillTypeDifferentialHelper 相关功能时
-> api/servicehelper/BillTypeDifferentialHelper.md

### BillTypeFile
当你需要使用单据类型文件实体类时
-> api/servicehelper/billtype/entity/BillTypeFile.md

### BillTypeInfo
当你需要使用单据类型信息时
-> api/metadata/lockvisible/BillTypeInfo.md

### BillTypeMapItem
当你需要使用单据类型映射条目时
-> api/entity/botp/BillTypeMapItem.md

### BillTypeMapPolicy
当你需要使用单据类型映射策略时
-> api/entity/botp/BillTypeMapPolicy.md

### BillTypeServiceHelper
当你需要使用单据类型接口时
-> api/servicehelper/billtype/BillTypeServiceHelper.md

### BinaryExpr
当你需要使用二进制表达式运算时
-> api/formula/excel/BinaryExpr.md

### BindingContext
当你需要使用绑定上下文时
-> api/form/BindingContext.md

### BizAppServiceHelp
当你需要使用开发者门户业务应用的服务类时
-> api/servicehelper/devportal/BizAppServiceHelp.md

### BizCloudServiceHelp
当你需要使用 BizCloudServiceHelp 相关功能时
-> api/servicehelper/devportal/BizCloudServiceHelp.md

### BizDataEventArgs
当你需要使用创建数据包事件参数时
-> api/entity/datamodel/events/BizDataEventArgs.md

### BizProcessStatus
当你需要使用流程中状态时
-> api/workflow/api/BizProcessStatus.md

### BizRulePolicy
当你需要使用业务规则策略时
-> api/entity/botp/BizRulePolicy.md

### BizType
当你需要使用业务类型时
-> api/workflow/engine/task/BizType.md

### BooleanColumnDesc
当你需要使用布尔类型列格式化时
-> api/entity/list/column/BooleanColumnDesc.md

### BooleanType
当你需要使用Algo中的数据类型,对应Java类型为Boolen时
-> api/algo/datatype/BooleanType.md

### BosPrintServiceHelper
当你需要使用打印服务。时
-> api/print/service/BosPrintServiceHelper.md

### BosPrintServiceHelper.TplInfo
当你需要使用打印模板信息时
-> api/print/service/BosPrintServiceHelper.TplInfo.md

### BranchExecuteInfo
当你需要使用分支事务执行结果信息时
-> api/kdtx/common/entity/BranchExecuteInfo.md

### BroadcastService
当你需要使用提供了广播消息的功能时
-> api/mq/broadcast/BroadcastService.md

### BuildTreeListFilterEvent
当你需要使用树形单据列表时
-> api/list/events/BuildTreeListFilterEvent.md

### BusinessDataServiceHelper
当你需要使用数据操作服务类，提供查询、保存等功能时
-> api/servicehelper/BusinessDataServiceHelper.md

### BusinessKeyQueryParams
当你需要使用业务主键查询参数时
-> api/workflow/engine/task/BusinessKeyQueryParams.md

---

## C

### CAModule
当你需要使用CA认证模块SDK时
-> api/svc/ca/CAModule.md

### CRBizRuleElement
当你需要使用单据转换时
-> api/entity/botp/CRBizRuleElement.md

### CRCondition
当你需要使用转换规则时
-> api/entity/botp/CRCondition.md

### CRValByCondition
当你需要使用取值项：单项条件+值的组合时
-> api/entity/botp/CRValByCondition.md

### CRValByConditionType
当你需要使用取值方式枚举时
-> api/entity/botp/CRValByConditionType.md

### CRValByConditions
当你需要使用单据转换规则时
-> api/entity/botp/CRValByConditions.md

### CacheConfigInfo
当你需要使用本地缓存的配置信息载体时
-> api/cache/CacheConfigInfo.md

### CacheFactory
当你需要使用缓存工厂抽象类时
-> api/cache/CacheFactory.md

### CacheHint
当你需要使用与缓存DataSet相关的参数时
-> api/algo/CacheHint.md

### CacheKeyUtil
当你需要使用缓存标识构造工具时
-> api/dataentity/resource/cache/CacheKeyUtil.md

### CachedDataSet
当你需要使用Cached dataset时
-> api/algo/CachedDataSet.md

### CachedDataSet.Builder
当你需要使用创建CacheDataSet的Builder时
-> api/algo/CachedDataSet.Builder.md

### CachedDataSetBuilder
当你需要使用 CachedDataSetBuilder 相关功能时
-> api/algo/dataset/cache/CachedDataSetBuilder.md

### CardCheckBoxListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardCheckBoxListColumnAp.md

### CardColorPickerListColumnAp
当你需要使用设计时列表-卡片视图时
-> api/metadata/list/CardColorPickerListColumnAp.md

### CardComboListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardComboListColumnAp.md

### CardDateListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardDateListColumnAp.md

### CardDecimalListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardDecimalListColumnAp.md

### CardEntry
当你需要使用卡片式单据体控件（卡片分录）时
-> api/form/cardentry/CardEntry.md

### CardEntryAp
当你需要使用卡片分录时
-> api/metadata/form/cardentry/CardEntryAp.md

### CardEntryFieldAp
当你需要使用卡片分录上的字段时
-> api/metadata/form/cardentry/CardEntryFieldAp.md

### CardEntryFixRowAp
当你需要使用卡片分录行时
-> api/metadata/form/cardentry/CardEntryFixRowAp.md

### CardEntryFixRowPanelAp
当你需要使用卡片分录行容器面板时
-> api/metadata/form/cardentry/CardEntryFixRowPanelAp.md

### CardEntryFlexPanelAp
当你需要使用卡片分录用的面板时
-> api/metadata/form/cardentry/CardEntryFlexPanelAp.md

### CardEntryRowAp
当你需要使用卡片分录行设计时
-> api/metadata/form/cardentry/CardEntryRowAp.md

### CardEntryViewAp
当你需要使用卡片分录设计时
-> api/metadata/form/cardentry/CardEntryViewAp.md

### CardFlexListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardFlexListColumnAp.md

### CardFlexPanelAp
当你需要使用 CardFlexPanelAp 相关功能时
-> api/metadata/list/CardFlexPanelAp.md

### CardListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardListColumnAp.md

### CardRowPanelAp
当你需要使用设计时时
-> api/metadata/list/CardRowPanelAp.md

### CardSelectorAp
当你需要使用卡片选择标志时
-> api/metadata/form/cardentry/CardSelectorAp.md

### CardTimeListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardTimeListColumnAp.md

### CardVoucherNoListColumnAp
当你需要使用设计时时
-> api/metadata/list/CardVoucherNoListColumnAp.md

### CellStyle
当你需要使用报表单元格样式时
-> api/entity/report/CellStyle.md

### CellStyleRule
当你需要使用自定义报表单元格规则时
-> api/report/events/CellStyleRule.md

### CellTipsClickEvent
当你需要使用点击Tips按钮事件参数时
-> api/form/field/events/CellTipsClickEvent.md

### CellTipsClickListener
当你需要使用点击Tips按钮事件接口时
-> api/form/field/events/CellTipsClickListener.md

### ChangeData
当你需要使用数据改变实体描述类时
-> api/entity/datamodel/events/ChangeData.md

### CharSequenceUtils
当你需要使用Operations on CharSequence that are时
-> api/dataentity/utils/CharSequenceUtils.md

### CharUtils
当你需要使用Operations on char primitives and Character objects.时
-> api/dataentity/utils/CharUtils.md

### Chart
当你需要使用图表控件时
-> api/form/chart/Chart.md

### ChartAp
当你需要使用图表控件设计时时
-> api/metadata/form/chart/ChartAp.md

### ChartData
当你需要使用图表数据时
-> api/form/chart/ChartData.md

### ChatEvent
当你需要使用云之家聊天信息弹出事件参数时
-> api/list/events/ChatEvent.md

### CheckBoxListColumn
当你需要使用复选框列表字段时
-> api/list/CheckBoxListColumn.md

### CheckBoxListColumnAp
当你需要使用设计时时
-> api/metadata/list/CheckBoxListColumnAp.md

### CheckPermissionReq
当你需要使用 CheckPermissionReq 相关功能时
-> api/permission/model/perm/req/CheckPermissionReq.md

### CheckResultInfo
当你需要使用元数据检查结果时
-> api/metadata/exception/CheckResultInfo.md

### CheckUserBizAppReq
当你需要使用 CheckUserBizAppReq 相关功能时
-> api/permission/model/perm/req/user/CheckUserBizAppReq.md

### CirculateOperationParam
当你需要使用传阅任务操作参数时
-> api/workflow/engine/task/operation/CirculateOperationParam.md

### CityList
当你需要使用城市移动列表控件时
-> api/list/CityList.md

### CityListAp
当你需要使用设计时时
-> api/metadata/list/CityListAp.md

### ClickEventArgs
当你需要使用点击事件参数时
-> api/schedule/form/event/ClickEventArgs.md

### ClientActions
当你需要使用客户端指令-名称常量时
-> api/form/ClientActions.md

### ClientCallBackEvent
当你需要使用客户端回调事件参数时
-> api/form/events/ClientCallBackEvent.md

### ClientMethod
当你需要使用移动端支持的前端方法类型枚举时
-> api/form/ClientMethod.md

### ClientMethodResult
当你需要使用前端回调方法结果集时
-> api/form/ClientMethodResult.md

### CloneUtils
当你需要使用数据包复制工具类时
-> api/dataentity/entity/CloneUtils.md

### CloseCallBack
当你需要使用界面关闭回调参数时
-> api/form/CloseCallBack.md

### CloseCallBackWraper
当你需要使用关闭回调参数包装类时
-> api/form/CloseCallBackWraper.md

### ClosedCallBackEvent
当你需要使用关闭回调事件参数时
-> api/form/events/ClosedCallBackEvent.md

### CloudHubAppServiceHelper
当你需要使用 CloudHubAppServiceHelper 相关功能时
-> api/servicehelper/cloudhub/CloudHubAppServiceHelper.md

### CoGroupDataSetX
当你需要使用分组协作数据集时
-> api/algox/CoGroupDataSetX.md

### CoGroupFunction
当你需要使用分组协作函数时
-> api/algox/CoGroupFunction.md

### CodeRuleEntryInfo
当你需要使用编码规则编码段分录信息对象时
-> api/coderule/api/CodeRuleEntryInfo.md

### CodeRuleInfo
当你需要使用编码规则配置信息类时
-> api/coderule/api/CodeRuleInfo.md

### CodeRuleServiceHelper
当你需要使用编码规则帮助服务类时
-> api/servicehelper/coderule/CodeRuleServiceHelper.md

### CollectionField
当你需要使用打印数据模型-集合类型字段时
-> api/print/core/data/field/CollectionField.md

### CollectionProperty
当你需要使用实体集合型属性时
-> api/dataentity/metadata/clr/CollectionProperty.md

### CollectionPropertyAttribute
当你需要使用标注实体类的集合属性时
-> api/dataentity/entity/CollectionPropertyAttribute.md

### CollectionUtils
当你需要使用集合工具类时
-> api/util/CollectionUtils.md

### Collector
当你需要使用收集器时
-> api/algox/Collector.md

### ColorPickerListColumn
当你需要使用选择颜色列表字段时
-> api/list/ColorPickerListColumn.md

### ColorPickerListColumnAp
当你需要使用设计时-选择颜色字段时
-> api/metadata/list/ColorPickerListColumnAp.md

### ColorUtils
当你需要使用颜色工具类时
-> api/form/ColorUtils.md

### Column
当你需要使用SQL查询列时
-> api/form/plugin/tools/Column.md

### ColumnAp
当你需要使用列时
-> api/metadata/form/container/ColumnAp.md

### ColumnDesc
当你需要使用列表字段格式化基类时
-> api/entity/list/column/ColumnDesc.md

### ColumnPanelAp
当你需要使用列布局面板时
-> api/metadata/form/container/ColumnPanelAp.md

### ColumnStyle
当你需要使用报表列样式时
-> api/entity/report/ColumnStyle.md

### ComboColumnDesc
当你需要使用下拉列表格式化字段处理类时
-> api/entity/list/column/ComboColumnDesc.md

### ComboListColumn
当你需要使用下拉列表字段类型时
-> api/list/ComboListColumn.md

### ComboListColumnAp
当你需要使用设计时时
-> api/metadata/list/ComboListColumnAp.md

### ComboPropShowStyle
当你需要使用下拉列表类型时
-> api/entity/ComboPropShowStyle.md

### ComboReportColumn
当你需要使用报表列-下拉列表类型列时
-> api/entity/report/ComboReportColumn.md

### ComboSearchValue
当你需要使用列表表头下拉列表筛选值时
-> api/list/column/ComboSearchValue.md

### CommDataDto
当你需要使用公共数据时
-> api/openapi/security/model/CommDataDto.md

### CommonBaseDataFilterColumn
当你需要使用通用过滤基础资料字段时
-> api/filter/CommonBaseDataFilterColumn.md

### CommonBaseDataFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/CommonBaseDataFilterColumnAp.md

### CommonCheckBoxFilterColumn
当你需要使用常用过滤复选框过滤字段时
-> api/filter/CommonCheckBoxFilterColumn.md

### CommonCheckBoxGroupFilterColumn
当你需要使用常用复选框组合过滤字段时
-> api/filter/CommonCheckBoxGroupFilterColumn.md

### CommonCheckBoxGroupFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/CommonCheckBoxGroupFilterColumnAp.md

### CommonDateFilterColumn
当你需要使用常用日期过滤字段时
-> api/filter/CommonDateFilterColumn.md

### CommonDateFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/CommonDateFilterColumnAp.md

### CommonDtxResponse
当你需要使用公共事务响应对象时
-> api/kdtx/common/invoke/CommonDtxResponse.md

### CommonFilterColumn
当你需要使用常用过滤字段时
-> api/filter/CommonFilterColumn.md

### CommonFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/CommonFilterColumnAp.md

### CommonParam
当你需要使用通用参数类时
-> api/kdtx/common/CommonParam.md

### CommonSecurityDto
当你需要使用签名认证公用数据模型时
-> api/openapi/security/model/CommonSecurityDto.md

### CompareSearchValue
当你需要使用比较符类型筛选值时
-> api/list/column/CompareSearchValue.md

### CompareType
当你需要使用过滤比较符描述类时
-> api/entity/filter/CompareType.md

### CompareTypeConfig
当你需要使用比较符配置时
-> api/entity/CompareTypeConfig.md

### CompareTypeEnum
当你需要使用过滤比较符枚举时
-> api/entity/filter/CompareTypeEnum.md

### CompareTypeField
当你需要使用比较符到定义时
-> api/entity/CompareTypeField.md

### CompareTypeValue
当你需要使用将字段比较符存下来时
-> api/entity/filter/CompareTypeValue.md

### CompensateResponse
当你需要使用事务重试结果时
-> api/kdtx/common/response/CompensateResponse.md

### CompensateResponse.TxInfo
当你需要使用事务信息：分布式事务ID和名称时
-> api/kdtx/common/response/CompensateResponse.TxInfo.md

### CompleteOperationParam
当你需要使用完成任务操作参数时
-> api/workflow/engine/task/operation/CompleteOperationParam.md

### CompleteTaskParam
当你需要使用 CompleteTaskParam 相关功能时
-> api/workflow/api/model/CompleteTaskParam.md

### ComplexProperty
当你需要使用实体复杂型属性时
-> api/dataentity/metadata/clr/ComplexProperty.md

### ComplexPropertyAttribute
当你需要使用标注实体类的复杂属性时
-> api/dataentity/entity/ComplexPropertyAttribute.md

### CompoundId
当你需要使用 CompoundId 相关功能时
-> api/formula/excel/CompoundId.md

### ConditionVariableContext
当你需要使用常量解析上下文时
-> api/entity/filter/ConditionVariableContext.md

### ConfigServiceHelper
当你需要使用 ConfigServiceHelper 相关功能时
-> api/servicehelper/ConfigServiceHelper.md

### ConfirmCallBackListener
当你需要使用确认提示回调处理参数时
-> api/form/ConfirmCallBackListener.md

### ConfirmTypes
当你需要使用确认提示类别时
-> api/form/ConfirmTypes.md

### Container
当你需要使用容器控件基类；表单也是从此控件中派生的时
-> api/form/container/Container.md

### ContainerAp
当你需要使用容器控件时
-> api/metadata/form/ContainerAp.md

### ContextMenuClickEvent
当你需要使用菜单点击事件参数时
-> api/form/events/ContextMenuClickEvent.md

### ControlAp
当你需要使用对应设计时的“控件”概念时
-> api/metadata/form/ControlAp.md

### ControlColumnDesc
当你需要使用精度控制字段时
-> api/entity/list/column/ControlColumnDesc.md

### ControlFilter
当你需要使用列表过滤条件原始值实例类时
-> api/entity/filter/ControlFilter.md

### ControlFilters
当你需要使用列表过滤条件原始值实例类集合时
-> api/entity/filter/ControlFilters.md

### ControlInfo
当你需要使用字段锁定性可见性、单据类型、设置了锁定字段的界面规则等信息时
-> api/metadata/lockvisible/ControlInfo.md

### ControlLockVisibleInfo
当你需要使用控件信息时
-> api/metadata/lockvisible/ControlLockVisibleInfo.md

### ControlTypes
当你需要使用注册运行时控件类时
-> api/form/ControlTypes.md

### ConvertDataService
当你需要使用转换数据服务时
-> api/botp/ConvertDataService.md

### ConvertMetaServiceHelper
当你需要使用 ConvertMetaServiceHelper 相关功能时
-> api/servicehelper/botp/ConvertMetaServiceHelper.md

### ConvertOpRule
当你需要使用单据转换操作时
-> api/entity/botp/runtime/ConvertOpRule.md

### ConvertOperationResult
当你需要使用转换服务执行结果时
-> api/entity/botp/runtime/ConvertOperationResult.md

### ConvertPath
当你需要使用转换路线时
-> api/entity/botp/ConvertPath.md

### ConvertPkEvent
当你需要使用转换PK事件参数时
-> api/bill/events/ConvertPkEvent.md

### ConvertRuleCache
当你需要使用获取转换规则时
-> api/entity/botp/ConvertRuleCache.md

### ConvertRuleElement
当你需要使用转换规则时
-> api/entity/botp/ConvertRuleElement.md

### ConvertServiceHelper
当你需要使用单据转换微服务调用工具类时
-> api/servicehelper/botp/ConvertServiceHelper.md

### CoreMutexHelper
当你需要使用网络互斥意向锁帮助类时
-> api/form/operate/CoreMutexHelper.md

### CoreShowFormHelper
当你需要使用工具类时
-> api/form/CoreShowFormHelper.md

### Count
当你需要使用计数时
-> api/formula/functions/Count.md

### CreateColumnEvent
当你需要使用列创建事件参数时
-> api/report/events/CreateColumnEvent.md

### CreateFilterInfoEvent
当你需要使用报表过滤信息事件参数时
-> api/report/events/CreateFilterInfoEvent.md

### CreateListOperationColumnEvent
当你需要使用列表操作列事件参数时
-> api/entity/list/events/CreateListOperationColumnEvent.md

### CreateListTemplateTextColumnEvent
当你需要使用列表模式文本接口参数类时
-> api/entity/list/events/CreateListTemplateTextColumnEvent.md

### CreateTreeListViewEvent
当你需要使用创建树形列表视图事件时
-> api/list/events/CreateTreeListViewEvent.md

### CreateUIElementArgs
当你需要使用创建元素参数时
-> api/metadata/CreateUIElementArgs.md

### CronStruct
当你需要使用简单的cron 结构时
-> api/schedule/server/schedulecreator/CronStruct.md

### CtLinkEntryType
当你需要使用关联子实体时
-> api/entity/CtLinkEntryType.md

### CtsyBillShowParameter
当你需要使用多租户协同单据打开参数时
-> api/bill/CtsyBillShowParameter.md

### CtsyFormShowParameter
当你需要使用多租户协同表单打开参数时
-> api/form/CtsyFormShowParameter.md

### CtsyListShowParameter
当你需要使用多租户协同列表打开参数时
-> api/list/CtsyListShowParameter.md

### CurrencyFormat
当你需要使用币别格式时
-> api/print/core/model/CurrencyFormat.md

### CustOpParameterPlugin
当你需要使用自定义操作参数配置界面插件基类时
-> api/metadata/entity/operation/CustOpParameterPlugin.md

### CustValidation
当你需要使用自定义的校验器参数对象时
-> api/metadata/entity/validation/CustValidation.md

### CustValidationParamPlugin
当你需要使用业务扩展的校验器参数配置界面插件基类时
-> api/metadata/entity/validation/CustValidationParamPlugin.md

### CustomAggFunction
当你需要使用自定义聚合函数,在对DataSet分组后使用时
-> api/algo/CustomAggFunction.md

### CustomApiResult
当你需要使用自定义返回结果类时
-> api/openapi/common/result/CustomApiResult.md

### CustomBaseDataFilterColumn
当你需要使用报表常用基础资料过滤字段时
-> api/filter/CustomBaseDataFilterColumn.md

### CustomBaseDataSchemeFilterColumn
当你需要使用报表基础资料方案过滤字段时
-> api/filter/CustomBaseDataSchemeFilterColumn.md

### CustomChartAp
当你需要使用自定义图表时
-> api/metadata/form/chart/CustomChartAp.md

### CustomDataLoadEvent
当你需要使用自定义数据源加载数据事件时
-> api/print/core/plugin/event/CustomDataLoadEvent.md

### CustomDataSource
当你需要使用自定义数据源时
-> api/print/core/data/datasource/CustomDataSource.md

### CustomEventArgs
当你需要使用自定义事件参数时
-> api/form/events/CustomEventArgs.md

### CustomNumberFilterColumn
当你需要使用报表数字类型的方案过滤字段时
-> api/filter/CustomNumberFilterColumn.md

### CustomOrgFilterColumn
当你需要使用报表组织常用过滤字段时
-> api/filter/CustomOrgFilterColumn.md

### CustomOrgSchemeFilterColumn
当你需要使用报表组织方案过滤字段时
-> api/filter/CustomOrgSchemeFilterColumn.md

### CustomParam
当你需要使用系统参数自定义参数接口参数时
-> api/entity/param/CustomParam.md

### CustomizeLink
当你需要使用审批记录(详情)自定义链接时
-> api/workflow/component/approvalrecord/CustomizeLink.md

### CustomizedAuditResult
当你需要使用名称: CustomizedAuditResult时
-> api/workflow/engine/dynprocess/CustomizedAuditResult.md

### CustomizedInput
当你需要使用自定义输入源,用来创建DataSet的输入时
-> api/algo/CustomizedInput.md

### CustomizedOutput
当你需要使用algox使用:在algox处理完输入的Input之后时
-> api/algo/CustomizedOutput.md

---

## D

### DBHintContext
当你需要使用 DBHintContext 相关功能时
-> api/util/dbhint/DBHintContext.md

### DBServiceHelper
当你需要使用 DBServiceHelper 相关功能时
-> api/servicehelper/DBServiceHelper.md

### DBVersion
当你需要使用数据中心版本时
-> api/entity/DBVersion.md

### DLockInfo
当你需要使用分布式锁信息时
-> api/dlock/DLockInfo.md

### DTX
当你需要使用将分布式事务和本地事务包装在一起,使调用者使用时无需先开启本地事务,再开启分布式事务时
-> api/kdtx/sdk/session/DTX.md

### DTXHandle
当你需要使用同时持有本地事务和分布式事务,使本地事务和分布事务同时开启、提交、回滚时
-> api/kdtx/sdk/session/DTXHandle.md

### DataEntityBase
当你需要使用数据包基类时
-> api/dataentity/entity/DataEntityBase.md

### DataEntityCacheType
当你需要使用实体缓存的类型时
-> api/dataentity/metadata/DataEntityCacheType.md

### DataEntityCollection
当你需要使用数据包集合基类时
-> api/dataentity/entity/DataEntityCollection.md

### DataEntityDeserializerOption
当你需要使用数据包反序列化参数时
-> api/dataentity/serialization/DataEntityDeserializerOption.md

### DataEntityProperty
当你需要使用实体属性基类时
-> api/dataentity/metadata/clr/DataEntityProperty.md

### DataEntityPropertyCollection
当你需要使用实体属性集合时
-> api/dataentity/metadata/clr/DataEntityPropertyCollection.md

### DataEntitySerializer
当你需要使用数据包序列化工具类时
-> api/dataentity/serialization/DataEntitySerializer.md

### DataEntitySerializerOption
当你需要使用数据包序列化参数时
-> api/dataentity/serialization/DataEntitySerializerOption.md

### DataEntityState
当你需要使用数据包的状态时
-> api/dataentity/entity/DataEntityState.md

### DataEntityType
当你需要使用实体基类时
-> api/dataentity/metadata/clr/DataEntityType.md

### DataEntityTypeAttribute
当你需要使用标记一个类是实体类时
-> api/dataentity/entity/DataEntityTypeAttribute.md

### DataEntityTypeFlag
当你需要使用定义了实体类型的特征时
-> api/dataentity/metadata/DataEntityTypeFlag.md

### DataGrid
当你需要使用数据表格时
-> api/form/control/grid/DataGrid.md

### DataGridAp
当你需要使用数据表格时
-> api/metadata/form/control/grid/DataGridAp.md

### DataGridBindDataEvent
当你需要使用数据表格绑定数据事件参数时
-> api/form/control/grid/events/DataGridBindDataEvent.md

### DataGridColumn
当你需要使用表格列时
-> api/form/control/grid/column/DataGridColumn.md

### DataGridRow
当你需要使用数据表格行时
-> api/form/control/grid/DataGridRow.md

### DataGridRowBuilder
当你需要使用数据表格行构造器时
-> api/form/control/grid/DataGridRowBuilder.md

### DataMutex
当你需要使用数据级网络控制服务接口时
-> api/mutex/DataMutex.md

### DataRowSet
当你需要使用打印数据集时
-> api/print/core/data/DataRowSet.md

### DataRuleInfo
当你需要使用数据规则方案时
-> api/permission/model/DataRuleInfo.md

### DataRulesInfo
当你需要使用多个实体的整体数据规则方案时
-> api/permission/model/DataRulesInfo.md

### DataSelectEvent
当你需要使用移动端用户选择控件选择数据事件时
-> api/list/events/DataSelectEvent.md

### DataSet
当你需要使用DataSet:结果集时
-> api/algo/DataSet.md

### DataSetBuilder
当你需要使用此接口用来构建DataSet时
-> api/algo/DataSetBuilder.md

### DataSetCacheOutput
当你需要使用将结果输出为Algo CacheDataSet时
-> api/algo/output/DataSetCacheOutput.md

### DataSetInput
当你需要使用使用另外一个DataSet作为构建DataSet的输入源时
-> api/algo/input/DataSetInput.md

### DataSetOutput
当你需要使用将计算结果生成为Algo DataSet时
-> api/algo/output/DataSetOutput.md

### DataSetX
当你需要使用分布式计算数据集操作接口时
-> api/algox/DataSetX.md

### DataType
当你需要使用Algo内存数据库支持的数据类型时
-> api/algo/DataType.md

### DateClickListener
当你需要使用日期事件接口时
-> api/form/field/events/DateClickListener.md

### DateColumnDesc
当你需要使用日期格式化处理类时
-> api/entity/list/column/DateColumnDesc.md

### DateDataGridColumn
当你需要使用日期列时
-> api/form/control/grid/column/DateDataGridColumn.md

### DateDataGridColumnAp
当你需要使用日期列时
-> api/metadata/form/control/grid/column/DateDataGridColumnAp.md

### DateEnum
当你需要使用日期过滤类型枚举时
-> api/entity/report/DateEnum.md

### DateField
当你需要使用打印数据模型-日期字段时
-> api/print/core/data/field/DateField.md

### DateListColumn
当你需要使用日期字段类型时
-> api/list/DateListColumn.md

### DateListColumnAp
当你需要使用设计时时
-> api/metadata/list/DateListColumnAp.md

### DateMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/DateMobTableColumnAp.md

### DateTimeColumnDesc
当你需要使用时间格式化处理类时
-> api/entity/list/column/DateTimeColumnDesc.md

### DateTimeField
当你需要使用打印数据模型-日期时间字段时
-> api/print/core/data/field/DateTimeField.md

### DateTimeReportColumn
当你需要使用报表列-日期类型列时
-> api/entity/report/DateTimeReportColumn.md

### DateType
当你需要使用Algo中的数据类型,对应Java类型为Date时
-> api/algo/datatype/DateType.md

### DbInput
当你需要使用使用db作为构建DataSet的输入源,通过传入sql语句时
-> api/algo/input/DbInput.md

### DbOutput
当你需要使用将计算结果保存到数据库时
-> api/algo/output/DbOutput.md

### DcBinder
当你需要使用表示一个配置的绑定工具时
-> api/dataentity/serialization/DcBinder.md

### DcJsonSerializer
当你需要使用对象序列化工具（JSON）时
-> api/dataentity/serialization/DcJsonSerializer.md

### DcSerializer
当你需要使用对象序列化基类时
-> api/dataentity/serialization/DcSerializer.md

### DcxmlSerializer
当你需要使用对象序列化工具（XML）时
-> api/dataentity/serialization/DcxmlSerializer.md

### DecimalColumnDesc
当你需要使用数字格式化处理类时
-> api/entity/list/column/DecimalColumnDesc.md

### DecimalDataGridColumn
当你需要使用小数列时
-> api/form/control/grid/column/DecimalDataGridColumn.md

### DecimalDataGridColumnAp
当你需要使用数值列时
-> api/metadata/form/control/grid/column/DecimalDataGridColumnAp.md

### DecimalField
当你需要使用打印数据模型-小数字段时
-> api/print/core/data/field/DecimalField.md

### DecimalListColumn
当你需要使用数字类型列表字段时
-> api/list/DecimalListColumn.md

### DecimalListColumnAp
当你需要使用设计时时
-> api/metadata/list/DecimalListColumnAp.md

### DecimalMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/DecimalMobTableColumnAp.md

### DecimalReportColumn
当你需要使用报表列-小数类型列时
-> api/entity/report/DecimalReportColumn.md

### DecisionOption
当你需要使用 DecisionOption 相关功能时
-> api/workflow/bpmn/model/DecisionOption.md

### DefValueDesign
当你需要使用字段默认值设计时元数据时
-> api/metadata/entity/fielddefvalue/DefValueDesign.md

### DefaultValueAttribute
当你需要使用标注属性的默认值时
-> api/dataentity/entity/DefaultValueAttribute.md

### DeleteOperationParam
当你需要使用删除操作参数时
-> api/workflow/engine/task/operation/DeleteOperationParam.md

### DeleteRule
当你需要使用字段提示自动隐藏的规则时
-> api/form/fieldtip/DeleteRule.md

### DeleteServiceHelper
当你需要使用删除实体操作服务类时
-> api/servicehelper/operation/DeleteServiceHelper.md

### DependField
当你需要使用常用过滤依赖字段时
-> api/filter/DependField.md

### DevPortalServiceHelp
当你需要使用开发者门户公共服务类时
-> api/servicehelper/devportal/DevPortalServiceHelp.md

### DimFuncPermReq
当你需要使用 DimFuncPermReq 相关功能时
-> api/permission/model/perm/req/DimFuncPermReq.md

### DimRoleReq
当你需要使用 DimRoleReq 相关功能时
-> api/permission/model/perm/req/DimRoleReq.md

### DingdingMessageInfo
当你需要使用 DingdingMessageInfo 相关功能时
-> api/message/api/DingdingMessageInfo.md

### DingdingTodoInfo
当你需要使用 DingdingTodoInfo 相关功能时
-> api/message/api/DingdingTodoInfo.md

### DisCardUtil
当你需要使用暂无方法实现时
-> api/util/DisCardUtil.md

### DispatchServiceHelper
当你需要使用微服务调用入口：通过动态反射方式调用各种平台、业务封装的各种微服务时
-> api/servicehelper/DispatchServiceHelper.md

### DistributeType
当你需要使用反写分配类型时
-> api/entity/botp/DistributeType.md

### DrawArgs
当你需要使用选单服务参数时
-> api/entity/botp/runtime/DrawArgs.md

### DsType
当你需要使用数据源类型时
-> api/print/core/data/datasource/DsType.md

### DtsAccountPower
当你需要使用 DtsAccountPower 相关功能时
-> api/orm/datasync/DtsAccountPower.md

### DtsConfigOperator
当你需要使用dts配置信息操作api时
-> api/dts/configoperator/DtsConfigOperator.md

### DtsConfigOperatorInfo
当你需要使用配置信息时
-> api/dts/configoperator/DtsConfigOperatorInfo.md

### DtxBranch
当你需要使用对分支事务执行结果的再包装。因为DtxResponse时
-> api/kdtx/common/invoke/DtxBranch.md

### DtxContext
当你需要使用事务全局上下文时
-> api/kdtx/sdk/context/DtxContext.md

### DtxFactory
当你需要使用分布式事务工厂时
-> api/kdtx/sdk/session/DtxFactory.md

### DtxGlobalResult
当你需要使用分布式事务的执行结果时
-> api/kdtx/common/invoke/DtxGlobalResult.md

### DtxResult
当你需要使用分布式事务回调结果：包含了事务的状态等信息时
-> api/kdtx/common/invoke/DtxResult.md

### DynamicCollectionProperty
当你需要使用动态实体的集合属性 集合属性指向另外一个实体类型的引用时
-> api/dataentity/metadata/dynamicobject/DynamicCollectionProperty.md

### DynamicComplexProperty
当你需要使用动态实体复杂属性 复杂属性指向另外一个实体类型的引用时
-> api/dataentity/metadata/dynamicobject/DynamicComplexProperty.md

### DynamicLocaleProperty
当你需要使用实体的多语言子分录属性时
-> api/dataentity/metadata/dynamicobject/DynamicLocaleProperty.md

### DynamicMetadata
当你需要使用动态实体架构的基础元数据对象时
-> api/dataentity/metadata/dynamicobject/DynamicMetadata.md

### DynamicObject
当你需要使用动态实体对象,对应ORM的持久化对象时
-> api/dataentity/entity/DynamicObject.md

### DynamicObjectCollection
当你需要使用动态实体对象集合时
-> api/dataentity/entity/DynamicObjectCollection.md

### DynamicObjectSerializationBinder
当你需要使用为动态实体在序列化和反序列化时时
-> api/dataentity/serialization/DynamicObjectSerializationBinder.md

### DynamicObjectType
当你需要使用DynamicObjectType允许在运行时动态构建一个实体类型时
-> api/dataentity/metadata/dynamicobject/DynamicObjectType.md

### DynamicProperty
当你需要使用动态属性的基类,对实体字段值的操作是通过它来完成的.时
-> api/dataentity/metadata/dynamicobject/DynamicProperty.md

### DynamicPropertyCollection
当你需要使用实体的属性集合时
-> api/dataentity/metadata/dynamicobject/DynamicPropertyCollection.md

### DynamicReportColumnEvent
当你需要使用报表动态字段事件参数时
-> api/entity/report/DynamicReportColumnEvent.md

### DynamicSimpleProperty
当你需要使用简单属性时
-> api/dataentity/metadata/dynamicobject/DynamicSimpleProperty.md

### DynamicTextColumnDesc
当你需要使用动态文本格式化处理类时
-> api/entity/list/column/DynamicTextColumnDesc.md

### DynamicTextListColumn
当你需要使用列表动态文本字段时
-> api/list/DynamicTextListColumn.md

### DynamicTextListColumnAp
当你需要使用设计时时
-> api/metadata/list/DynamicTextListColumnAp.md

### DynamicTextListField
当你需要使用列表的列定义元数据：动态文本列时
-> api/entity/datamodel/DynamicTextListField.md

### DynamicValidation
当你需要使用动态注册自定义校验时
-> api/metadata/entity/validation/DynamicValidation.md

---

## E

### ECGlobalSession
当你需要使用最终一致全局Session:这个类可以对事务跨方法时
-> api/kdtx/sdk/session/ec/ECGlobalSession.md

### ECSession
当你需要使用最终一致Session:时
-> api/kdtx/sdk/session/ec/ECSession.md

### EarlyWarnLogHelper
当你需要使用预警日志帮助类时
-> api/servicehelper/earlywarn/EarlyWarnLogHelper.md

### EarlyWarnMetaServicHelper
当你需要使用业务预警对象元数据帮助类时
-> api/servicehelper/earlywarn/EarlyWarnMetaServicHelper.md

### EarlyWarnServiceImpl
当你需要使用预警微服务实现类时
-> api/service/earlywarn/EarlyWarnServiceImpl.md

### EmailInfo
当你需要使用描述：邮件信息对象时
-> api/message/api/EmailInfo.md

### EmbedForm
当你需要使用【嵌入页面】控件：可嵌入显示其他表单时
-> api/form/control/embedform/EmbedForm.md

### EmbedFormAp
当你需要使用嵌入页面控件：继承自面板时
-> api/metadata/form/control/embedform/EmbedFormAp.md

### EmbedFormShowParam
当你需要使用嵌入表单控件显示参数时
-> api/metadata/form/control/embedform/EmbedFormShowParam.md

### EmbedFormShowParamItem
当你需要使用关联表单时
-> api/form/control/embedform/EmbedFormShowParamItem.md

### EmptyInput
当你需要使用构建一个空的Dataset时时
-> api/algo/input/EmptyInput.md

### EncryptInfo
当你需要使用签名认证-加密信息时
-> api/openapi/security/model/EncryptInfo.md

### EncryptionEnum
当你需要使用加密策略时
-> api/openapi/security/model/EncryptionEnum.md

### EndExportEvent
当你需要使用打印引擎执行完成事件参数时
-> api/print/core/plugin/event/EndExportEvent.md

### EndOperationTransactionArgs
当你需要使用调用操作事务结束（事务内）事件参数时
-> api/entity/plugin/args/EndOperationTransactionArgs.md

### EndSelectEvent
当你需要使用下拉列表选择事件时
-> api/list/events/EndSelectEvent.md

### EntDataRuleInfo
当你需要使用 EntDataRuleInfo 相关功能时
-> api/permission/model/EntDataRuleInfo.md

### EntDataRuleInfo.BdPropsDataRule
当你需要使用基础资料属性的数据规则时
-> api/permission/model/EntDataRuleInfo.BdPropsDataRule.md

### EntDataRuleInfo.PermItemsDataRule
当你需要使用权限项的数据规则时
-> api/permission/model/EntDataRuleInfo.PermItemsDataRule.md

### Entity
当你需要使用实体抽象类时
-> api/metadata/entity/Entity.md

### EntityItem
当你需要使用业务元素的抽象基类时
-> api/metadata/entity/EntityItem.md

### EntityItemTypes
当你需要使用实体属性注册,用于反序列化来创建实体属性时
-> api/entity/EntityItemTypes.md

### EntityMetadata
当你需要使用实体元数据时
-> api/metadata/entity/EntityMetadata.md

### EntityMetadataCache
当你需要使用实体元数据缓存服务类,用于获取实体元数据的各种元素信息时
-> api/entity/EntityMetadataCache.md

### EntityOperate
当你需要使用数据实体操作基类时
-> api/form/operate/EntityOperate.md

### EntityOperateService
当你需要使用 EntityOperateService 相关功能时
-> api/service/operation/EntityOperateService.md

### EntityTraceHint
当你需要使用创建实体运行监控节点时的参数设置时
-> api/dataentity/trace/EntityTraceHint.md

### EntityTracer
当你需要使用实体运行监控-调用链时
-> api/dataentity/trace/EntityTracer.md

### EntityType
当你需要使用抽象实体模型时
-> api/entity/EntityType.md

### EntryEntity
当你需要使用设计时单据体元素对象 添加了单据体需要的一些属性时
-> api/metadata/entity/EntryEntity.md

### EntryInfo
当你需要使用分录行状态信息时
-> api/dataentity/entity/EntryInfo.md

### EntryType
当你需要使用分录实体类型时
-> api/entity/EntryType.md

### EnumsDataChangeType
当你需要使用 EnumsDataChangeType 相关功能时
-> api/permission/enums/EnumsDataChangeType.md

### ErrorCode
当你需要使用错误码时
-> api/exception/ErrorCode.md

### ErrorCode.LangMessage
当你需要使用多语言异常信息类时
-> api/exception/ErrorCode.LangMessage.md

### ErrorInfo
当你需要使用元数据检查异常时
-> api/metadata/exception/ErrorInfo.md

### ErrorLevel
当你需要使用错误级别时
-> api/entity/validate/ErrorLevel.md

### EventServiceHelper
当你需要使用业务事件中心服务时
-> api/servicehelper/workflow/EventServiceHelper.md

### EventualConsistencyService
当你需要使用最终一致抽象,所有实现最终一致的服务都要继承这个类时
-> api/kdtx/sdk/api/EventualConsistencyService.md

### ExcelReader
当你需要使用Excel解析类时
-> api/impt/ExcelReader.md

### ExceptionUtils
当你需要使用异常输出类时
-> api/util/ExceptionUtils.md

### ExcessCheckType
当你需要使用反写超额检查控制级别时
-> api/entity/botp/ExcessCheckType.md

### ExpFileEvent
当你需要使用输出文件事件参数时
-> api/print/core/plugin/event/ExpFileEvent.md

### ExportFileEvent
当你需要使用列表引出文件事件参数时
-> api/form/events/ExportFileEvent.md

### Expr
当你需要使用公式分解后的执行单元时
-> api/formula/excel/Expr.md

### ExprBase
当你需要使用公式分解后的执行单元时
-> api/formula/excel/ExprBase.md

### ExprList
当你需要使用表达式集合时
-> api/formula/excel/ExprList.md

### ExprParser
当你需要使用表达式解析类时
-> api/formula/excel/ExprParser.md

### ExpressionEditHelper
当你需要使用帮助类时
-> api/metadata/treebuilder/ExpressionEditHelper.md

### ExtEvent
当你需要使用预置的插件二次扩展事件参数时
-> api/extplugin/ExtEvent.md

### ExtendedDataEntity
当你需要使用将垂直的实体数据打平时
-> api/entity/ExtendedDataEntity.md

### ExtendedDataEntitySet
当你需要使用将垂直的实体数据打平时
-> api/entity/ExtendedDataEntitySet.md

### ExtractOption
当你需要使用从一个动态实体定义中提取字段的选项 需要注意的是时
-> api/dataentity/metadata/dynamicobject/ExtractOption.md

---

## F

### F7SelectedList
当你需要使用F7已选列表控件时
-> api/list/F7SelectedList.md

### F7SelectedListAp
当你需要使用F7选择时时
-> api/metadata/list/F7SelectedListAp.md

### F7SelectedListRemoveEvent
当你需要使用F7选择的列表被移除事件时
-> api/list/events/F7SelectedListRemoveEvent.md

### F7SelectedListSortEvent
当你需要使用F7已选排序事件时
-> api/list/events/F7SelectedListSortEvent.md

### FastFilter
当你需要使用过滤容器快速过滤条件时
-> api/entity/report/FastFilter.md

### FastSearchGridView
当你需要使用快速过滤视图时
-> api/filter/FastSearchGridView.md

### FastSearchGridViewAp
当你需要使用设计时时
-> api/metadata/filter/FastSearchGridViewAp.md

### FeatureOption
当你需要使用字段功能控制选项时
-> api/entity/FeatureOption.md

### Field
当你需要使用打印数据模型-字段基类时
-> api/print/core/data/field/Field.md

### FieldControlRules2RuleReq
当你需要使用 FieldControlRules2RuleReq 相关功能时
-> api/permission/model/perm/req/field/FieldControlRules2RuleReq.md

### FieldFormatContext
当你需要使用字段格式化时
-> api/form/field/format/FieldFormatContext.md

### FieldMapItem
当你需要使用字段映射配置时
-> api/entity/botp/FieldMapItem.md

### FieldMapPolicy
当你需要使用主实体字段映射策略时
-> api/entity/botp/FieldMapPolicy.md

### FieldTip
当你需要使用字段提示设置时
-> api/form/FieldTip.md

### FieldgroupPanelAp
当你需要使用字段分组面板时
-> api/metadata/form/container/FieldgroupPanelAp.md

### FieldsetPanelAp
当你需要使用字段布局面板时
-> api/metadata/form/container/FieldsetPanelAp.md

### FileItem
当你需要使用文件信息实体类时
-> api/fileservice/FileItem.md

### FileNameUtils
当你需要使用 FileNameUtils 相关功能时
-> api/util/FileNameUtils.md

### FileServiceFactory
当你需要使用文件服务工厂类时
-> api/fileservice/FileServiceFactory.md

### FileStorageConfig
当你需要使用文件存储配置参数时
-> api/filestorage/spi/FileStorageConfig.md

### FilterBuilder
当你需要使用过滤条件构造类时
-> api/entity/filter/FilterBuilder.md

### FilterBuilderParameter
当你需要使用 FilterBuilderParameter 相关功能时
-> api/entity/filter/FilterBuilderParameter.md

### FilterColumn
当你需要使用过滤字段时
-> api/filter/FilterColumn.md

### FilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/FilterColumnAp.md

### FilterColumnSetFilterEvent
当你需要使用将常用过滤字段设置成过滤条件事件参数时
-> api/form/events/FilterColumnSetFilterEvent.md

### FilterCondition
当你需要使用通用过滤元数据时
-> api/entity/filter/FilterCondition.md

### FilterContainer
当你需要使用过滤容器时
-> api/filter/FilterContainer.md

### FilterContainerAp
当你需要使用设计时时
-> api/metadata/filter/FilterContainerAp.md

### FilterContainerFilterValues
当你需要使用过滤容器过滤值集合时
-> api/filter/FilterContainerFilterValues.md

### FilterContainerInitArgs
当你需要使用过滤容器初始化事件参数时
-> api/form/events/FilterContainerInitArgs.md

### FilterContainerInitEvent
当你需要使用容器过滤条件初始化事件参数时
-> api/form/control/events/FilterContainerInitEvent.md

### FilterContainerSearchClickArgs
当你需要使用过滤容器查询点击事件参数时
-> api/form/events/FilterContainerSearchClickArgs.md

### FilterContantParserArgs
当你需要使用自定义比较符常量解释参数时
-> api/entity/filter/FilterContantParserArgs.md

### FilterEditHelper
当你需要使用通用的过滤界面显示帮助类时
-> api/metadata/treebuilder/FilterEditHelper.md

### FilterField
当你需要使用过滤字段信息时
-> api/entity/filter/FilterField.md

### FilterFunction
当你需要使用自定义用于过滤结果集的函数时
-> api/algox/FilterFunction.md

### FilterGridView
当你需要使用常用过滤视图时
-> api/filter/FilterGridView.md

### FilterGridViewAp
当你需要使用设计时时
-> api/metadata/filter/FilterGridViewAp.md

### FilterInfo
当你需要使用报表过滤信息时
-> api/entity/report/FilterInfo.md

### FilterItemInfo
当你需要使用报表单个过滤项信息时
-> api/entity/report/FilterItemInfo.md

### FilterKeyValue
当你需要使用过滤元数据字段名和值实例类时
-> api/entity/filter/FilterKeyValue.md

### FilterKeyValueCollection
当你需要使用字段过滤元数据实例集合时
-> api/entity/filter/FilterKeyValueCollection.md

### FilterKeyValueCollections
当你需要使用字段名与字段过滤元数据映射实体类时
-> api/entity/filter/FilterKeyValueCollections.md

### FilterModel
当你需要使用过滤模型时
-> api/filter/FilterModel.md

### FilterObject
当你需要使用过滤解析中间类时
-> api/entity/filter/FilterObject.md

### FilterParameter
当你需要使用过滤参数时
-> api/entity/filter/FilterParameter.md

### FilterPolicy
当你需要使用分录数据筛选策略时
-> api/entity/botp/FilterPolicy.md

### FilterResult
当你需要使用过滤条件解析结果类时
-> api/entity/filter/FilterResult.md

### FilterRow
当你需要使用过滤条件行数据时
-> api/entity/filter/FilterRow.md

### FilterScheme
当你需要使用方案过滤存储类时
-> api/entity/filter/FilterScheme.md

### FilterSchemeService
当你需要使用过滤方案服务时
-> api/filter/FilterSchemeService.md

### FilterScriptBuilder
当你需要使用把条件时
-> api/entity/filter/FilterScriptBuilder.md

### FilterServiceHelper
当你需要使用过滤方案服务帮助类时
-> api/servicehelper/filter/FilterServiceHelper.md

### FilterValue
当你需要使用过滤值对象时
-> api/entity/filter/FilterValue.md

### FlatMapFunction
当你需要使用展开RowX时
-> api/algox/FlatMapFunction.md

### FlexBDValueCondition
当你需要使用弹性域维度定义时配置基础资料过滤条件的时
-> api/entity/flex/FlexBDValueCondition.md

### FlexBeforeClosedEvent
当你需要使用弹性域界面关闭之前事件参数时
-> api/form/events/FlexBeforeClosedEvent.md

### FlexColumnDesc
当你需要使用弹性域格式化处理类时
-> api/entity/list/column/FlexColumnDesc.md

### FlexControlMetaPreRenderEvent
当你需要使用 FlexControlMetaPreRenderEvent 相关功能时
-> api/form/flex/event/FlexControlMetaPreRenderEvent.md

### FlexControlMetaPreRenderListener
当你需要使用弹性域元数据监听时
-> api/form/field/events/FlexControlMetaPreRenderListener.md

### FlexEntireData
当你需要使用弹性域数据时
-> api/entity/flex/FlexEntireData.md

### FlexEntityMetaUtils
当你需要使用弹性域实体元数据工具时
-> api/entity/flex/FlexEntityMetaUtils.md

### FlexEntityType
当你需要使用弹性域主实体时
-> api/entity/FlexEntityType.md

### FlexEvent
当你需要使用 FlexEvent 相关功能时
-> api/report/events/FlexEvent.md

### FlexHelper
当你需要使用弹性域帮助类时
-> api/servicehelper/flex/FlexHelper.md

### FlexListColumn
当你需要使用弹性域列表字段时
-> api/list/FlexListColumn.md

### FlexListColumnAp
当你需要使用设计时时
-> api/metadata/list/FlexListColumnAp.md

### FlexPanelAp
当你需要使用1,布局方向flex-direction:水平(默认),垂直时
-> api/metadata/form/container/FlexPanelAp.md

### FlexProperty
当你需要使用弹性域维度定义时
-> api/entity/flex/FlexProperty.md

### FlexReportColumn
当你需要使用报表列弹性域列时
-> api/entity/report/FlexReportColumn.md

### FlexService
当你需要使用弹性域服务类时
-> api/flex/FlexService.md

### FlexType
当你需要使用弹性域类型定义时
-> api/entity/flex/FlexType.md

### FlexValueFormatUtils
当你需要使用弹性域维度值格式化工具类时
-> api/form/flex/FlexValueFormatUtils.md

### FlexValueFormatter
当你需要使用弹性域维度值格式化时
-> api/form/field/format/FlexValueFormatter.md

### FloatingDirection
当你需要使用界面显示风格时
-> api/form/FloatingDirection.md

### FlowElement
当你需要使用 FlowElement 相关功能时
-> api/workflow/bpmn/model/FlowElement.md

### FmtField
当你需要使用字段格式化时
-> api/entity/datamodel/FmtField.md

### FmtInfoUtils
当你需要使用字段格式化工具时
-> api/entity/datamodel/FmtInfoUtils.md

### FormAp
当你需要使用代表表单这个控件 记录着表单的许多外观元素时
-> api/metadata/form/FormAp.md

### FormConfig
当你需要使用界面配置参数类时
-> api/form/FormConfig.md

### FormDataSource
当你需要使用表单数据源时
-> api/print/core/data/datasource/FormDataSource.md

### FormMetadata
当你需要使用表单元数据：用于描述界面元数据时
-> api/metadata/form/FormMetadata.md

### FormMetadataCache
当你需要使用动态表单运行时视图层元数据获取工具时
-> api/form/FormMetadataCache.md

### FormOperate
当你需要使用表单操作时
-> api/form/operate/FormOperate.md

### FormRoot
当你需要使用运行期时
-> api/form/container/FormRoot.md

### FormShowParameter
当你需要使用表单显示参数时
-> api/form/FormShowParameter.md

### FormVariable
当你需要使用前端变量时
-> api/entity/rule/FormVariable.md

### FormatFieldData
当你需要使用列表格式化后的字段值,提供一个时机给插件获取列表格式化之后的结构化数据时
-> api/entity/list/FormatFieldData.md

### FormatRowData
当你需要使用格式化后的行数据时
-> api/entity/list/FormatRowData.md

### FormatShowFilterEvent
当你需要使用报表格式化条件事件参数时
-> api/report/events/FormatShowFilterEvent.md

### FormulaDesigner
当你需要使用公式平台时
-> api/formula/platform/builder/FormulaDesigner.md

### FormulaDesignerParameter
当你需要使用公式平台设计界面时
-> api/formula/platform/builder/FormulaDesignerParameter.md

### FormulaDesignerResult
当你需要使用公式编辑结果时
-> api/formula/platform/builder/FormulaDesignerResult.md

### FormulaEngine
当你需要使用公式运行引擎时
-> api/formula/platform/engine/FormulaEngine.md

### FunCall
当你需要使用函数调用时
-> api/formula/excel/FunCall.md

### FunDef
当你需要使用默认函数集合时
-> api/formula/excel/FunDef.md

### FuncInfo
当你需要使用函数信息时
-> api/formula/platform/api/FuncInfo.md

### FuncSettingHelper
当你需要使用函数配置帮助类时
-> api/form/func/FuncSettingHelper.md

### FunctionMutex
当你需要使用功能级网络控制服务接口时
-> api/mutex/FunctionMutex.md

### FuzzySearch
当你需要使用模糊查询对象时
-> api/entity/param/FuzzySearch.md

---

## G

### GaugeChart
当你需要使用仪表盘时
-> api/form/chart/GaugeChart.md

### GaugeChartAp
当你需要使用仪表盘时
-> api/metadata/form/chart/GaugeChartAp.md

### GaugeSeries
当你需要使用仪表盘序列时
-> api/form/chart/GaugeSeries.md

### GetAdminChargeUserReq
当你需要使用 GetAdminChargeUserReq 相关功能时
-> api/permission/model/perm/req/admin/GetAdminChargeUserReq.md

### GetEntityTypeEventArgs
当你需要使用获取主实体事件参数时
-> api/entity/datamodel/events/GetEntityTypeEventArgs.md

### GetFieldControlRulesReq
当你需要使用 GetFieldControlRulesReq 相关功能时
-> api/permission/model/perm/req/field/GetFieldControlRulesReq.md

### GetMonitorAppIdArgs
当你需要使用 GetMonitorAppIdArgs 相关功能时
-> api/entity/plugin/args/GetMonitorAppIdArgs.md

### GetTargetOptionalOrgsResult
当你需要使用获取下游可选受托主组织的服务结果时
-> api/entity/botp/runtime/GetTargetOptionalOrgsResult.md

### GetUsableEntitiesInfoReq
当你需要使用 GetUsableEntitiesInfoReq 相关功能时
-> api/permission/model/perm/req/user/GetUsableEntitiesInfoReq.md

### GradientItem
当你需要使用颜色渐变子项时
-> api/form/chart/GradientItem.md

### GraphModelParseHelper
当你需要使用获取流程节点相关条件时
-> api/workflow/service/GraphModelParseHelper.md

### GridFlatPanelAp
当你需要使用表格平铺面板时
-> api/metadata/form/container/GridFlatPanelAp.md

### GroupByPolicy
当你需要使用分单合并策略时
-> api/entity/botp/GroupByPolicy.md

### GroupCombineFunction
当你需要使用combine操作回调函数时
-> api/algox/GroupCombineFunction.md

### GroupCombineReduceFunction
当你需要使用combine及reduce操作回调函数时
-> api/algox/GroupCombineReduceFunction.md

### GroupFieldsUniqueValidateResult
当你需要使用组合性唯一校验结果时
-> api/entity/validate/GroupFieldsUniqueValidateResult.md

### GroupReduceFunction
当你需要使用reduce操作回调函数时
-> api/algox/GroupReduceFunction.md

### GroupReportFormPlugin
当你需要使用分组报表插件基类时
-> api/report/plugin/GroupReportFormPlugin.md

### Grouper
当你需要使用分组后的聚合操作时
-> api/algox/Grouper.md

### GrpUsrFromTypeEnum
当你需要使用用户组中用户来源类型 - 枚举类时
-> api/permission/enums/GrpUsrFromTypeEnum.md

### GuideItem
当你需要使用向导项时
-> api/form/userguide/GuideItem.md

### GuideItemAp
当你需要使用向导项时
-> api/metadata/form/userguide/GuideItemAp.md

### GuidePage
当你需要使用向导页时
-> api/form/userguide/GuidePage.md

### GuidePageAp
当你需要使用向导页时
-> api/metadata/form/userguide/GuidePageAp.md

---

## H

### HZPinyin
当你需要使用将汉字转化为拼音时
-> api/lang/HZPinyin.md

### HashTable
当你需要使用hash表接口时
-> api/algo/HashTable.md

### HistogramChart
当你需要使用柱状图时
-> api/form/chart/HistogramChart.md

### HistogramChartAp
当你需要使用柱状图时
-> api/metadata/form/chart/HistogramChartAp.md

### HomePageTabAp
当你需要使用首页页签时
-> api/metadata/form/container/HomePageTabAp.md

### HomePageTabItemAp
当你需要使用 HomePageTabItemAp 相关功能时
-> api/metadata/form/container/HomePageTabItemAp.md

### HttpUtils
当你需要使用用于发起Http请求的工具类时
-> api/util/HttpUtils.md

### HyperLinkClickArgs
当你需要使用超链接点击事件参数时
-> api/form/events/HyperLinkClickArgs.md

### HyperLinkClickEvent
当你需要使用超链接点击事件参数时
-> api/form/events/HyperLinkClickEvent.md

---

## I

### I18nServiceHelper
当你需要使用`I18nServiceHelper` 国际化公共服务类时
-> api/i18n/mservice/I18nServiceHelper.md

### IApprovalRecord
当你需要使用 IApprovalRecord 相关功能时
-> api/workflow/component/approvalrecord/IApprovalRecord.md

### IApprovalRecordGroup
当你需要使用审批记录时
-> api/workflow/component/approvalrecord/IApprovalRecordGroup.md

### IApprovalRecordItem
当你需要使用审批人具体信息时
-> api/workflow/component/approvalrecord/IApprovalRecordItem.md

### IBaseDataCtrlPlugin
当你需要使用 IBaseDataCtrlPlugin 相关功能时
-> api/servicehelper/basedata/IBaseDataCtrlPlugin.md

### IBasedataController
当你需要使用基础资料个性化逻辑控制功能接口时
-> api/base/IBasedataController.md

### IClientViewProxy
当你需要使用前端交互代理时
-> api/form/IClientViewProxy.md

### ICodeRuleService
当你需要使用编码规则服务接口时
-> api/coderule/api/ICodeRuleService.md

### IColumn
当你需要使用列定义时
-> api/entity/IColumn.md

### IConditionalRuleParser
当你需要使用 IConditionalRuleParser 相关功能时
-> api/workflow/api/IConditionalRuleParser.md

### IConfirmCallBack
当你需要使用确认提示回调处理接口时
-> api/form/IConfirmCallBack.md

### IDataEntityBinder
当你需要使用实体序列化时
-> api/dataentity/serialization/IDataEntityBinder.md

### IExportExcelOperate
当你需要使用存在导出EXCEL功能的VIEW实现此接口时
-> api/export/IExportExcelOperate.md

### IFilterModel
当你需要使用过滤模型时
-> api/entity/datamodel/IFilterModel.md

### IFormulaGrammarVerifier
当你需要使用语法验证接口时
-> api/formula/platform/api/IFormulaGrammarVerifier.md

### IFormulaVarInfos
当你需要使用解析公式代码中的变量定义时
-> api/formula/platform/api/IFormulaVarInfos.md

### IFrameMessage
当你需要使用IFrame信息对象时
-> api/entity/IFrameMessage.md

### IFuncParamInputFormPlugin
当你需要使用自定义函数参数编辑页面时
-> api/formula/platform/api/funcpara/IFuncParamInputFormPlugin.md

### IMessageCenterService
当你需要使用消息中心对外开放接口时
-> api/workflow/message/api/IMessageCenterService.md

### IMessageService
当你需要使用描述：消息服务接口时
-> api/message/api/IMessageService.md

### INoCodeWorkflowService
当你需要使用 INoCodeWorkflowService 相关功能时
-> api/workflow/api/INoCodeWorkflowService.md

### IOpBizRuleParameterEdit
当你需要使用操作服务配置界面插件接口时
-> api/metadata/entity/operation/IOpBizRuleParameterEdit.md

### IParameterModel
当你需要使用单据参数时
-> api/entity/datamodel/IParameterModel.md

### IQuery
当你需要使用序时簿相关接口时
-> api/entity/list/IQuery.md

### IRefrencedataProvider
当你需要使用关联数据读取接口时
-> api/entity/datamodel/IRefrencedataProvider.md

### IRelationService
当你需要使用 IRelationService 相关功能时
-> api/workflow/api/IRelationService.md

### IReportListModel
当你需要使用报表数据模型接口时
-> api/entity/report/IReportListModel.md

### IReportQueryExtPlugin
当你需要使用报表查询通用扩展插件接口时
-> api/entity/report/IReportQueryExtPlugin.md

### IReportTreeModel
当你需要使用树形报表数据模型接口时
-> api/entity/report/IReportTreeModel.md

### IReportView
当你需要使用报表视图时
-> api/report/IReportView.md

### ISVInfo
当你需要使用开发商信息时
-> api/entity/ISVInfo.md

### ISVServiceHelper
当你需要使用 ISVServiceHelper 相关功能时
-> api/servicehelper/ISVServiceHelper.md

### ISpreadAction
当你需要使用Spread表格控件动作自定义执行接口时
-> api/form/spread/event/ISpreadAction.md

### ITaskPlugin
当你需要使用 ITaskPlugin 相关功能时
-> api/workflow/engine/extitf/ITaskPlugin.md

### IVarInfo
当你需要使用公式变量信息接口时
-> api/formula/platform/api/IVarInfo.md

### IWorkflowDesigner
当你需要使用由于设计器初始化时加载js文件异步的问题时
-> api/workflow/design/plugin/IWorkflowDesigner.md

### IWorkflowModelPlugin
当你需要使用工作流模型相关插件（流程、节点生命周期）时
-> api/workflow/engine/extitf/IWorkflowModelPlugin.md

### IWorkflowPlugin
当你需要使用 IWorkflowPlugin 相关功能时
-> api/workflow/engine/extitf/IWorkflowPlugin.md

### IWorkflowService
当你需要使用 IWorkflowService 相关功能时
-> api/workflow/api/IWorkflowService.md

### IconField
当你需要使用通用字段--图标字段时
-> api/metadata/entity/commonfield/IconField.md

### IconProp
当你需要使用图标属性时
-> api/entity/property/IconProp.md

### If
当你需要使用条件分支时
-> api/formula/functions/If.md

### Image
当你需要使用图片控件时
-> api/form/control/Image.md

### ImageAp
当你需要使用通用控件--图片控件时
-> api/metadata/form/control/ImageAp.md

### ImageDirectory
当你需要使用图形目录枚举类时
-> api/dataentity/resource/ImageDirectory.md

### ImageField
当你需要使用打印数据模型-图片类型字段时
-> api/print/core/data/field/ImageField.md

### ImageList
当你需要使用图片列表时
-> api/form/control/ImageList.md

### ImageServiceHelper
当你需要使用图片服务帮助类时
-> api/servicehelper/image/ImageServiceHelper.md

### ImportBillData
当你需要使用导入流程中线程间传递的数据载体对象时
-> api/form/plugin/impt/ImportBillData.md

### ImportContext
当你需要使用导入过程中解析与数据处理线程间通信使用时
-> api/form/plugin/impt/ImportContext.md

### ImportDataEventArgs
当你需要使用引入数据包填写完毕事件参数时
-> api/entity/datamodel/events/ImportDataEventArgs.md

### IndexModeSetEvent
当你需要使用是否打开F7索引分页模式事件参数时
-> api/list/events/IndexModeSetEvent.md

### IndustryVersionServiceHelper
当你需要使用行业版本服务帮助类时
-> api/servicehelper/dbversion/IndustryVersionServiceHelper.md

### InitImportDataEventArgs
当你需要使用初始化引入数据包事件参数时
-> api/entity/datamodel/events/InitImportDataEventArgs.md

### InitVariableEventArgs
当你需要使用初始化变量事件参数时
-> api/entity/botp/plugin/args/InitVariableEventArgs.md

### Input
当你需要使用创建dataset的一种输入源时
-> api/algo/Input.md

### Instance
当你需要使用Jvm运行实例 包含以下属性时
-> api/instance/Instance.md

### InteServiceHelper
当你需要使用`InteServiceHelper` 国际化服务帮助类时
-> api/servicehelper/inte/InteServiceHelper.md

### InteTimeZone
当你需要使用国际化时区类时
-> api/service/InteTimeZone.md

### IntegerColumnDesc
当你需要使用整数格式化处理类时
-> api/entity/list/column/IntegerColumnDesc.md

### IntegerDataGridColumn
当你需要使用整数列时
-> api/form/control/grid/column/IntegerDataGridColumn.md

### IntegerDataGridColumnAp
当你需要使用整数列时
-> api/metadata/form/control/grid/column/IntegerDataGridColumnAp.md

### IntegerField
当你需要使用打印数据模型-整型字段时
-> api/print/core/data/field/IntegerField.md

### IntegerMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/IntegerMobTableColumnAp.md

### IntegerType
当你需要使用Algo中的数据类型,对应Java类型为Integer时
-> api/algo/datatype/IntegerType.md

### IntegralType
当你需要使用Integer,Long等整数类型的抽象父类时
-> api/algo/datatype/IntegralType.md

### IntentLockInfo
当你需要使用意向锁信息对象时
-> api/mutex/impl/IntentLockInfo.md

### InteractionCallBackHandler
当你需要使用定制交互界面的回调处理插件时
-> api/form/operate/interaction/InteractionCallBackHandler.md

### InteractionConfirmResult
当你需要使用操作交互时
-> api/entity/operate/interaction/InteractionConfirmResult.md

### InteractionContext
当你需要使用交互请求上下文对象时
-> api/entity/operate/interaction/InteractionContext.md

### InvokeFunctionException
当你需要使用函数调用异常时
-> api/formula/platform/api/InvokeFunctionException.md

### ItemClassColumnDesc
当你需要使用多列表基础资料格式化处理类时
-> api/entity/list/column/ItemClassColumnDesc.md

### ItemClickEventArgs
当你需要使用子按钮点击事件参数时
-> api/schedule/form/event/ItemClickEventArgs.md

### ItemSelectEvent
当你需要使用行选择事件时
-> api/list/events/ItemSelectEvent.md

### ItemValue
当你需要使用数据值时
-> api/form/chart/ItemValue.md

### IterableInput
当你需要使用使用一个迭代器作为一个构建DataSet的输入源时
-> api/algo/input/IterableInput.md

### IteratorInput
当你需要使用使用一个迭代器作为一个构建DataSet的输入源时
-> api/algo/input/IteratorInput.md

---

## J

### JSONUtils
当你需要使用json处理工具类时
-> api/util/JSONUtils.md

### JobClient
当你需要使用任务发布工具类时
-> api/schedule/executor/JobClient.md

### JobDispatcher
当你需要使用异步job调度器时
-> api/schedule/api/JobDispatcher.md

### JobDispatcherProxy
当你需要使用job分发真实实现时
-> api/schedule/server/JobDispatcherProxy.md

### JobForm
当你需要使用后台大任务进度显示时
-> api/schedule/form/JobForm.md

### JobFormInfo
当你需要使用表单层时
-> api/schedule/form/JobFormInfo.md

### JobFromStatus
当你需要使用任务执行状态枚举时
-> api/schedule/form/JobFromStatus.md

### JobInfo
当你需要使用job info时
-> api/schedule/api/JobInfo.md

### JobSession
当你需要使用分布式任务会话接口时
-> api/algox/JobSession.md

### JobType
当你需要使用job type时
-> api/schedule/api/JobType.md

### JoinDataSetX
当你需要使用 JoinDataSetX 相关功能时
-> api/algox/JoinDataSetX.md

### JoinEntity
当你需要使用查询实体关联实体时
-> api/entity/list/JoinEntity.md

### JoinFunction
当你需要使用用于自定义join后返回的列时
-> api/algox/JoinFunction.md

### JoinHint
当你需要使用可以指定Join的方式时
-> api/algo/JoinHint.md

### JoinProperty
当你需要使用关联属性时
-> api/entity/list/JoinProperty.md

### JoinType
当你需要使用join类型:包括inner join,left join,right join,full join,cross joi时
-> api/algo/JoinType.md

### JsonSubEntryEntity
当你需要使用子分录时
-> api/metadata/entity/JsonSubEntryEntity.md

---

## K

### KDDateFormatUtils
当你需要使用时区格式化工具类时
-> api/service/KDDateFormatUtils.md

### KDDateUtils
当你需要使用带时区处理长日期的工具类时
-> api/service/KDDateUtils.md

### KDException
当你需要使用系统异常时
-> api/exception/KDException.md

### KDInteractionException
当你需要使用交互错误：插件通过抛出交互错误时
-> api/entity/operate/interaction/KDInteractionException.md

### KdtxBusinessHelper
当你需要使用分布式事务帮助类时
-> api/kdtx/sdk/api/KdtxBusinessHelper.md

### KdtxRequestContext
当你需要使用分布式事务上下文信息时
-> api/context/KdtxRequestContext.md

---

## L

### Label
当你需要使用图形上的文本标签时
-> api/form/chart/Label.md

### Lang
当你需要使用语言枚举 national language support时
-> api/lang/Lang.md

### LayoutFlexAp
当你需要使用布局容器时
-> api/metadata/form/container/LayoutFlexAp.md

### LicenseServiceHelper
当你需要使用许可服务帮助类时
-> api/servicehelper/license/LicenseServiceHelper.md

### LimiterIntConfigRegistry
当你需要使用限流配置注册中心时
-> api/dataentity/limiter/LimiterIntConfigRegistry.md

### LineSeries
当你需要使用折线图图形图表序列时
-> api/form/chart/LineSeries.md

### LinkEntityPolicy
当你需要使用关联主实体策略时
-> api/entity/botp/LinkEntityPolicy.md

### LinkEntryEntity
当你需要使用关联子实体：用于记录单据转换来源单据信息时
-> api/metadata/entity/LinkEntryEntity.md

### LinkEntryType
当你需要使用关联子实体时
-> api/entity/LinkEntryType.md

### LinkQueryPkIdCollection
当你需要使用联查内部处理类集合时
-> api/list/LinkQueryPkIdCollection.md

### LinkSetElement
当你需要使用单据关联配置：运行时元数据对象时
-> api/entity/LinkSetElement.md

### LinkSetItemElement
当你需要使用BOTP关联子实体定义(即LK实体)时
-> api/entity/LinkSetItemElement.md

### ListBeforeBindDataEvent
当你需要使用列表数据绑定前执行事件参数时
-> api/list/events/ListBeforeBindDataEvent.md

### ListCardView
当你需要使用列表卡片视图控件时
-> api/list/ListCardView.md

### ListCardViewAp
当你需要使用设计时时
-> api/metadata/list/ListCardViewAp.md

### ListCellStyleBuilder
当你需要使用列表单元格样式构造器时
-> api/form/builder/ListCellStyleBuilder.md

### ListColumn
当你需要使用列表字段控件时
-> api/list/ListColumn.md

### ListColumnAp
当你需要使用设计时时
-> api/metadata/list/ListColumnAp.md

### ListColumnComboItem
当你需要使用列表表头过滤下拉类型比较符时
-> api/list/column/ListColumnComboItem.md

### ListColumnCompare
当你需要使用过滤比较符定义时
-> api/list/column/ListColumnCompare.md

### ListColumnCompareType
当你需要使用列表表头字段自定义比较符过滤比较符类型时
-> api/list/ListColumnCompareType.md

### ListColumnCompareTypesSetEvent
当你需要使用列表表头过滤比较符设置事件参数时
-> api/form/events/ListColumnCompareTypesSetEvent.md

### ListColumnCompares
当你需要使用列表表头过滤筛选比较符集合类时
-> api/list/column/ListColumnCompares.md

### ListColumnFilter
当你需要使用列表表头过滤干预事件,主要是用于追加一些自定义的过滤时
-> api/list/events/ListColumnFilter.md

### ListColumnFilterCollection
当你需要使用表头过滤比较符集合时
-> api/list/events/ListColumnFilterCollection.md

### ListColumnGroup
当你需要使用列表分组字段时
-> api/list/ListColumnGroup.md

### ListColumnGroupAp
当你需要使用设计时时
-> api/metadata/list/ListColumnGroupAp.md

### ListColumnType
当你需要使用列表列类型时
-> api/list/ListColumnType.md

### ListDcxmlBinder
当你需要使用默认实现的DcxmlBinder实现时
-> api/dataentity/serialization/ListDcxmlBinder.md

### ListExpandEvent
当你需要使用列表折叠表单事件参数时
-> api/form/field/events/ListExpandEvent.md

### ListExpandListener
当你需要使用列表折叠表单事件接口时
-> api/form/field/events/ListExpandListener.md

### ListField
当你需要使用列表列字段时
-> api/entity/datamodel/ListField.md

### ListFieldMeta
当你需要使用动态文本列表字段字段模板时
-> api/list/ListFieldMeta.md

### ListGridView
当你需要使用列表表格视图时
-> api/list/ListGridView.md

### ListGridViewAp
当你需要使用设计时时
-> api/metadata/list/ListGridViewAp.md

### ListHyperLinkClickEvent
当你需要使用列表字段超链接点击事件时
-> api/list/events/ListHyperLinkClickEvent.md

### ListHyperLinkClickListener
当你需要使用列表列超链接点击事件监听时
-> api/list/events/ListHyperLinkClickListener.md

### ListOperationColumn
当你需要使用列表操作列时
-> api/list/ListOperationColumn.md

### ListOperationColumnAp
当你需要使用设计时时
-> api/metadata/list/ListOperationColumnAp.md

### ListOperationColumnDesc
当你需要使用列表操作列格式化处理类时
-> api/list/column/ListOperationColumnDesc.md

### ListRowClickEvent
当你需要使用列表行点击事件时
-> api/list/events/ListRowClickEvent.md

### ListRowDetailShowEvent
当你需要使用列表“单头”展开事件时
-> api/list/events/ListRowDetailShowEvent.md

### ListRowFilterEvent
当你需要使用表头过滤监听事件时
-> api/list/events/ListRowFilterEvent.md

### ListSelectedRow
当你需要使用列表数据选择行时
-> api/entity/datamodel/ListSelectedRow.md

### ListSelectedRowCollection
当你需要使用列表选择行数据集合时
-> api/entity/datamodel/ListSelectedRowCollection.md

### ListShowParameter
当你需要使用列表打开参数时
-> api/list/ListShowParameter.md

### ListUserConfig
当你需要使用列表用户选项参数时
-> api/mvc/list/ListUserConfig.md

### ListVisible
当你需要使用列表可见性设置枚举类时
-> api/form/ListVisible.md

### ListboxItem
当你需要使用listboxitem listbox类似菜单栏控件时
-> api/entity/ListboxItem.md

### Literal
当你需要使用 Literal 相关功能时
-> api/formula/excel/Literal.md

### LoadCustomControlMetasArgs
当你需要使用加载定制控件元数据事件参数时
-> api/form/events/LoadCustomControlMetasArgs.md

### LoadDataEventArgs
当你需要使用加载数据包事件参数时
-> api/entity/datamodel/events/LoadDataEventArgs.md

### LocalMemoryCache
当你需要使用会话无关本地内存缓存的操作接口时
-> api/cache/LocalMemoryCache.md

### LocaleDynamicObjectCollection
当你需要使用多语言分录特定的数据行集合时
-> api/dataentity/entity/LocaleDynamicObjectCollection.md

### LocaleString
当你需要使用多语言文本字段值对象时
-> api/dataentity/entity/LocaleString.md

### LocaleStringSerializationUtils
当你需要使用序列化的辅助工具类时
-> api/dataentity/serialization/LocaleStringSerializationUtils.md

### LocaleValue
当你需要使用多语言记录类时
-> api/dataentity/entity/LocaleValue.md

### LocaleValueItem
当你需要使用多语言值单项时
-> api/dataentity/entity/LocaleValueItem.md

### LocateEvent
当你需要使用移动端视图层插件事件参数时
-> api/bill/events/LocateEvent.md

### LockType
当你需要使用采用的互斥锁类型时
-> api/mutex/LockType.md

### LockVisibleInfoReader
当你需要使用适用于单据和基础资料时
-> api/metadata/lockvisible/LockVisibleInfoReader.md

### LogBillEntity
当你需要使用日志单据时
-> api/metadata/entity/LogBillEntity.md

### LogBillFormAp
当你需要使用日志类单据界面设计时元数据时
-> api/metadata/form/LogBillFormAp.md

### LogFactory
当你需要使用日志工厂类时
-> api/logging/LogFactory.md

### LogServiceHelper
当你需要使用上机操作日志服务时
-> api/servicehelper/log/LogServiceHelper.md

### LogicOperate
当你需要使用过滤条件时
-> api/entity/filter/LogicOperate.md

### LongField
当你需要使用打印数据模型-长整型字段时
-> api/print/core/data/field/LongField.md

### LongType
当你需要使用Algo中的数据类型,对应Java类型为Long时
-> api/algo/datatype/LongType.md

### LookUpDataArgs
当你需要使用F7手工录入模糊匹配查询处理参数时
-> api/form/spread/LookUpDataArgs.md

---

## M

### MBarItemAp
当你需要使用工具栏菜单项时
-> api/metadata/form/mcontrol/MBarItemAp.md

### MBlockMenuAp
当你需要使用移动块状菜单时
-> api/metadata/form/mcontrol/MBlockMenuAp.md

### MBlockMenuItemAp
当你需要使用移动菜单项时
-> api/metadata/form/mcontrol/MBlockMenuItemAp.md

### MCArchive
当你需要使用单据归档路由获取时
-> api/db/archive/MCArchive.md

### MQCreateFactory
当你需要使用 MQCreateFactory 相关功能时
-> api/mq/support/MQCreateFactory.md

### MQFactory
当你需要使用消息生产者工厂时
-> api/mq/MQFactory.md

### MTabBarAp
当你需要使用移动端底部导航栏时
-> api/metadata/form/mcontrol/MTabBarAp.md

### MTabBarFormAp
当你需要使用移动端底部导航栏-表单容器控件时
-> api/metadata/form/mcontrol/MTabBarFormAp.md

### MTabBarItemAp
当你需要使用移动端底部导航栏-控件容器控件时
-> api/metadata/form/mcontrol/MTabBarItemAp.md

### MToolbarAp
当你需要使用移动工具栏时
-> api/metadata/form/mcontrol/MToolbarAp.md

### MacroItem
当你需要使用宏的子项时
-> api/workflow/api/model/MacroItem.md

### MainDataSource
当你需要使用主数据源时
-> api/print/core/data/datasource/MainDataSource.md

### MainEntity
当你需要使用主实体的元数据对象时
-> api/metadata/entity/MainEntity.md

### MainEntityType
当你需要使用ORM实体描述时
-> api/entity/MainEntityType.md

### MapExecuteContext
当你需要使用 MapExecuteContext 相关功能时
-> api/formula/excel/MapExecuteContext.md

### MapFunction
当你需要使用用于处理映射的回调接口时
-> api/algox/MapFunction.md

### MarkdownLinkData
当你需要使用Markdown链接数据对象时
-> api/entity/MarkdownLinkData.md

### MatcherResult
当你需要使用模板匹配结果类时
-> api/print/matchtpl/MatcherResult.md

### MatcherTpl
当你需要使用打印模板信息类时
-> api/print/matchtpl/MatcherTpl.md

### Max
当你需要使用最大值时
-> api/formula/functions/Max.md

### MenuItem
当你需要使用菜单条目时
-> api/metadata/form/MenuItem.md

### MergeBlock
当你需要使用单元格合并时
-> api/print/core/model/designer/grid/MergeBlock.md

### MergeColumnRule
当你需要使用报表单元格合并规则时
-> api/report/events/MergeColumnRule.md

### MergeListColumn
当你需要使用合并列表字段时
-> api/list/MergeListColumn.md

### MergeListColumnAp
当你需要使用设计时时
-> api/metadata/list/MergeListColumnAp.md

### MessageAttachment
当你需要使用消息中邮件附件对象时
-> api/workflow/engine/msg/info/MessageAttachment.md

### MessageBoxClosedEvent
当你需要使用提示框关闭事件参数时
-> api/form/events/MessageBoxClosedEvent.md

### MessageBoxLink
当你需要使用消息内容支持超链接转换对象时
-> api/form/MessageBoxLink.md

### MessageBoxOptions
当你需要使用确认提示消息框类型时
-> api/form/MessageBoxOptions.md

### MessageBoxResult
当你需要使用确认消息选择结果时
-> api/form/MessageBoxResult.md

### MessageCenterParams
当你需要使用消息中心参数时
-> api/workflow/engine/task/MessageCenterParams.md

### MessageCenterServiceHelper
当你需要使用消息中心服务时
-> api/servicehelper/workflow/MessageCenterServiceHelper.md

### MessageContext
当你需要使用 MessageContext 相关功能时
-> api/workflow/engine/msg/ctx/MessageContext.md

### MessageHandler
当你需要使用消息处理接口时
-> api/schedule/api/MessageHandler.md

### MessageInfo
当你需要使用消息中心推送消息接口入参对象属性时
-> api/workflow/engine/msg/info/MessageInfo.md

### MessageRequestInfo
当你需要使用 MessageRequestInfo 相关功能时
-> api/workflow/api/MessageRequestInfo.md

### MessageServiceConfig
当你需要使用服务配置模型时
-> api/workflow/engine/msg/MessageServiceConfig.md

### MessageServiceHelper
当你需要使用消息服务帮助类时
-> api/servicehelper/message/MessageServiceHelper.md

### MessageTypes
当你需要使用提示消息类型枚举时
-> api/form/MessageTypes.md

### MetadataService
当你需要使用元数据微服务时
-> api/service/metadata/MetadataService.md

### MetadataServiceHelper
当你需要使用动态表单元数据服务时
-> api/servicehelper/MetadataServiceHelper.md

### Min
当你需要使用最小值时
-> api/formula/functions/Min.md

### MobAdvFilterPanelAp
当你需要使用移动端高级筛选面板控件时
-> api/metadata/form/mcontrol/MobAdvFilterPanelAp.md

### MobCommonBaseDataFilterColumn
当你需要使用移动端基础资料常用过滤列时
-> api/filter/mcontrol/MobCommonBaseDataFilterColumn.md

### MobCommonDateFilterColumn
当你需要使用移动端日期常用过滤列时
-> api/filter/mcontrol/MobCommonDateFilterColumn.md

### MobCommonDateFilterColumnAp
当你需要使用设计时时
-> api/metadata/form/mcontrol/MobCommonDateFilterColumnAp.md

### MobControlContext
当你需要使用移动端列表上下文时
-> api/list/MobControlContext.md

### MobF7SelectedList
当你需要使用移动端F7已选列表控件时
-> api/list/MobF7SelectedList.md

### MobF7SelectedListAp
当你需要使用F7选择时时
-> api/metadata/list/MobF7SelectedListAp.md

### MobFilterSort
当你需要使用移动端过滤排序时
-> api/filter/mcontrol/MobFilterSort.md

### MobFilterSortAp
当你需要使用设计时时
-> api/metadata/form/mcontrol/MobFilterSortAp.md

### MobFilterSortInitArgs
当你需要使用过滤容器初始化事件参数时
-> api/form/events/MobFilterSortInitArgs.md

### MobFilterSortInitEvent
当你需要使用过滤容器初始化事件参数时
-> api/form/control/events/MobFilterSortInitEvent.md

### MobFilterSortSearchClickArgs
当你需要使用移动过滤排序控件搜索事件参数时
-> api/form/events/MobFilterSortSearchClickArgs.md

### MobLocation
当你需要使用移动端定位时
-> api/entity/MobLocation.md

### MobSortColumn
当你需要使用移动端排序列时
-> api/filter/mcontrol/MobSortColumn.md

### MobSortColumnAp
当你需要使用设计时时
-> api/metadata/form/mcontrol/MobSortColumnAp.md

### MobSortPanelAp
当你需要使用设计时时
-> api/metadata/form/mcontrol/MobSortPanelAp.md

### MobTable
当你需要使用移动表格：可以视为移动端单据体(卡片分录)的表格视图时
-> api/form/mcontrol/mobtable/MobTable.md

### MobTableAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/MobTableAp.md

### MobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/MobTableColumnAp.md

### MobTableData
当你需要使用移动表格数据时
-> api/form/mcontrol/mobtable/MobTableData.md

### MobTableHandleResult
当你需要使用移动表格处理结果时
-> api/form/mcontrol/mobtable/events/MobTableHandleResult.md

### MobTablePackageDataHandler
当你需要使用移动表格数据打包处理类时
-> api/form/mcontrol/mobtable/MobTablePackageDataHandler.md

### MobTablePackageDataHandlerArgs
当你需要使用移动表格数据打包处理类事件参数时
-> api/form/mcontrol/mobtable/events/MobTablePackageDataHandlerArgs.md

### MobTablePackageDataHandlerEvent
当你需要使用移动表格数据打包处理类事件参数时
-> api/form/mcontrol/mobtable/events/MobTablePackageDataHandlerEvent.md

### MobTableRowBuilder
当你需要使用移动表格行构造器时
-> api/form/mcontrol/mobtable/MobTableRowBuilder.md

### MobTableRowData
当你需要使用移动表格行数据时
-> api/form/mcontrol/mobtable/MobTableRowData.md

### MobileBillFormAp
当你需要使用移动端单据界面设计时时
-> api/metadata/form/MobileBillFormAp.md

### MobileBillShowParameter
当你需要使用移动端单据界面显示参数时
-> api/bill/MobileBillShowParameter.md

### MobileFormAp
当你需要使用移动表单控件时
-> api/metadata/form/MobileFormAp.md

### MobileFormShowParameter
当你需要使用移动表单显示参数时
-> api/form/MobileFormShowParameter.md

### MobileListAp
当你需要使用设计时时
-> api/metadata/list/MobileListAp.md

### MobileListF7Config
当你需要使用移动端F7列表配置时
-> api/entity/param/MobileListF7Config.md

### MobileListFormAp
当你需要使用设计时时
-> api/metadata/list/MobileListFormAp.md

### MobileListShowParameter
当你需要使用移动列表参数控件时
-> api/list/MobileListShowParameter.md

### MobileSearch
当你需要使用移动搜索控件时
-> api/list/MobileSearch.md

### MobileSearchAp
当你需要使用设计时时
-> api/metadata/form/mcontrol/MobileSearchAp.md

### MobileSearchInitEvent
当你需要使用移动端搜索控件初始化事件参数时
-> api/form/control/events/MobileSearchInitEvent.md

### MobileTreeList
当你需要使用移动树形列表时
-> api/list/MobileTreeList.md

### ModelModifyLogInfo
当你需要使用 ModelModifyLogInfo 相关功能时
-> api/workflow/api/ModelModifyLogInfo.md

### ModelType
当你需要使用 ModelType 相关功能时
-> api/workflow/engine/impl/persistence/entity/design/ModelType.md

### ModifyFilterValuesControllerEvent
当你需要使用修改过滤值事件时
-> api/form/field/events/ModifyFilterValuesControllerEvent.md

### MsgTypeEnum
当你需要使用消息类型 目前只支持这四种类型时
-> api/workflow/message/api/MsgTypeEnum.md

### MulBaseDataColumnDesc
当你需要使用多选基础资料格式化处理类时
-> api/entity/list/column/MulBaseDataColumnDesc.md

### MulBasedataDynamicObjectCollection
当你需要使用多选基础资料的数据行集合时
-> api/dataentity/entity/MulBasedataDynamicObjectCollection.md

### MulBasedataReportColumn
当你需要使用报表列-多选基础资料类型列时
-> api/entity/report/MulBasedataReportColumn.md

### MulComboReportColumn
当你需要使用报表列-多选下拉列表类型列时
-> api/entity/report/MulComboReportColumn.md

### MuliLangTextColumnDesc
当你需要使用多语言文本格式化处理类时
-> api/entity/list/column/MuliLangTextColumnDesc.md

### MultiEntity
当你需要使用被mapping引用时
-> api/dts/multientity/MultiEntity.md

### MultiFieldsSortEvent
当你需要使用列表多字段排序事件参数类时
-> api/list/events/MultiFieldsSortEvent.md

### MultiLangField
当你需要使用 MultiLangField 相关功能时
-> api/print/core/data/field/MultiLangField.md

### MutexBaseInfo
当你需要使用互斥锁信息时
-> api/mutex/impl/MutexBaseInfo.md

### MutexFactory
当你需要使用工厂类时
-> api/mutex/MutexFactory.md

### MutexHelper
当你需要使用网络互斥帮助类时
-> api/form/operate/MutexHelper.md

### MutexLockDataInfo
当你需要使用互斥锁信息时
-> api/mutex/impl/MutexLockDataInfo.md

### MutexLockInfo
当你需要使用互斥锁申请信息时
-> api/mutex/impl/MutexLockInfo.md

---

## N

### NamedExpr
当你需要使用 NamedExpr 相关功能时
-> api/formula/excel/NamedExpr.md

### NegativeTypeEnum
当你需要使用负数类型时
-> api/print/core/plugin/event/bo/propenum/NegativeTypeEnum.md

### NetAddressUtils
当你需要使用IP地址工具类时
-> api/util/NetAddressUtils.md

### NextUserTaskNode
当你需要使用下一步节点信息时
-> api/workflow/taskcenter/plugin/validate/NextUserTaskNode.md

### NoCodeWorkflowServiceHelper
当你需要使用 NoCodeWorkflowServiceHelper 相关功能时
-> api/servicehelper/workflow/NoCodeWorkflowServiceHelper.md

### NodeData
当你需要使用活动实例信息时
-> api/workflow/engine/process/NodeData.md

### NodeMacro
当你需要使用节点宏时
-> api/workflow/api/model/NodeMacro.md

### NodeProperty
当你需要使用节点属性时
-> api/workflow/api/model/NodeProperty.md

### NodeTemplate
当你需要使用 NodeTemplate 相关功能时
-> api/workflow/api/NodeTemplate.md

### NotificationServiceHelper
当你需要使用全局通知提醒弹窗服务帮助类时
-> api/servicehelper/notification/NotificationServiceHelper.md

### NullField
当你需要使用打印数据模型-控制字段时
-> api/print/core/data/field/NullField.md

### NullType
当你需要使用Algo中的数据类型:空类型时
-> api/algo/datatype/NullType.md

### NumberColumnDesc
当你需要使用数字类型的格式化处理基类时
-> api/entity/list/column/NumberColumnDesc.md

### NumberField
当你需要使用打印数据模型-数值字段抽象类时
-> api/print/core/data/field/NumberField.md

### NumberFormatProvider
当你需要使用数值日期格式化工具时
-> api/entity/NumberFormatProvider.md

### NumberPrecision
当你需要使用数值格式化工具时
-> api/entity/datamodel/NumberPrecision.md

### NumericType
当你需要使用数值类型的父类时
-> api/algo/datatype/NumericType.md

---

## O

### ORMException
当你需要使用 ORMException 相关功能时
-> api/orm/query/ORMException.md

### ORMUtil
当你需要使用部分多语言国际化数据读取工具类时
-> api/entity/datamodel/ORMUtil.md

### ObjectConverter
当你需要使用类型转换器时
-> api/dataentity/entity/ObjectConverter.md

### ObjectUtils
当你需要使用Miscellaneous object utility methods.时
-> api/dataentity/utils/ObjectUtils.md

### OnCreateDynamicUIMetasArgs
当你需要使用创建动态UI元数据事件参数时
-> api/form/events/OnCreateDynamicUIMetasArgs.md

### OnGetControlArgs
当你需要使用获取插件控件事件参数时
-> api/form/events/OnGetControlArgs.md

### OpBizRule
当你需要使用操作服务运行时元数据对象时
-> api/entity/operate/bizrule/OpBizRule.md

### OpBizRuleElement
当你需要使用操作服务设计时元数据对象时
-> api/metadata/entity/operation/OpBizRuleElement.md

### OpBizRuleSetServiceHelper
当你需要使用 OpBizRuleSetServiceHelper 相关功能时
-> api/servicehelper/OpBizRuleSetServiceHelper.md

### OpFieldValueReader
当你需要使用操作执行时时
-> api/form/operate/OpFieldValueReader.md

### OpenApiResult
当你需要使用OpenApiResult时
-> api/openapi/common/result/OpenApiResult.md

### OpenApiSdkUtil
当你需要使用OpenAPI服务时
-> api/openapi/common/util/OpenApiSdkUtil.md

### OpenStyle
当你需要使用界面展示风格时
-> api/form/OpenStyle.md

### OperateErrorInfo
当你需要使用错误操作信息时
-> api/entity/operate/result/OperateErrorInfo.md

### OperateInfo
当你需要使用操作信息时
-> api/entity/operate/result/OperateInfo.md

### OperateOption
当你需要使用操作选项（自定义参数）时
-> api/dataentity/OperateOption.md

### OperateParameter
当你需要使用操作参数时
-> api/form/OperateParameter.md

### OperateResult
当你需要使用操作结果时
-> api/workflow/engine/task/OperateResult.md

### OperateResultInfo
当你需要使用操作结果信息时
-> api/entity/operate/result/OperateResultInfo.md

### Operation
当你需要使用实体操作元数据,用于描述一个操作时
-> api/metadata/entity/operation/Operation.md

### OperationArgs
当你需要使用单据操作插件事件参数基类时
-> api/entity/plugin/args/OperationArgs.md

### OperationColItem
当你需要使用操作列项时
-> api/form/operatecol/OperationColItem.md

### OperationContext
当你需要使用操作的上下文信息时
-> api/entity/operate/OperationContext.md

### OperationDataGridColumn
当你需要使用操作列时
-> api/form/control/grid/column/OperationDataGridColumn.md

### OperationDataGridColumnAp
当你需要使用操作列时
-> api/metadata/form/control/grid/column/OperationDataGridColumnAp.md

### OperationException
当你需要使用操作异常    根据异常可以定位错误的数据时
-> api/entity/operate/OperationException.md

### OperationParameter
当你需要使用操作参数元数据抽象类时
-> api/metadata/entity/operation/OperationParameter.md

### OperationResult
当你需要使用操作结果时
-> api/entity/operate/result/OperationResult.md

### OperationServiceHelper
当你需要使用实体操作服务类时
-> api/servicehelper/operation/OperationServiceHelper.md

### OperationStatus
当你需要使用动态表单界面状态时
-> api/bill/OperationStatus.md

### Operations
当你需要使用系统的操作时
-> api/entity/operate/Operations.md

### Operator
当你需要使用 Operator 相关功能时
-> api/formula/excel/Operator.md

### OptionPolicy
当你需要使用单据转换选项控制策略：包含各种可选参数时
-> api/entity/botp/OptionPolicy.md

### OqlInput
当你需要使用使用orm作为创建一个DataSet的输入源时
-> api/algo/input/OqlInput.md

### OrgEntryInfo
当你需要使用编码规则受控组织信息时
-> api/coderule/api/OrgEntryInfo.md

### OrgList
当你需要使用组织时
-> api/list/OrgList.md

### OrgListAp
当你需要使用设计时时
-> api/metadata/list/OrgListAp.md

### OrgRelationConfig
当你需要使用单据上组织字段之间的协作关系时
-> api/entity/property/org/OrgRelationConfig.md

### OrgRelationItem
当你需要使用组织字段上的委托关系属性时
-> api/entity/property/org/OrgRelationItem.md

### OrgRelationItemDirect
当你需要使用业务单元间协作方向时
-> api/entity/property/org/OrgRelationItemDirect.md

### OrgRelationItemOrg
当你需要使用业务单元间协作组织字段（委托组织字段、受托组织字段）时
-> api/entity/property/org/OrgRelationItemOrg.md

### OrgRelationItemType
当你需要使用业务单元间业务协作类型时
-> api/entity/property/org/OrgRelationItemType.md

### OrgUnitServiceHelper
当你需要使用组织单元服务帮助类 用于替换原来的 OrgServiceHelper, OrgV时
-> api/servicehelper/org/OrgUnitServiceHelper.md

### OrgViewSchemeProp
当你需要使用组织视图方案时
-> api/entity/property/org/OrgViewSchemeProp.md

### OrmException
当你需要使用ORM异常类基类时
-> api/dataentity/exception/OrmException.md

### OrmInput
当你需要使用使用orm作为创建一个DataSet的输入源时
-> api/algo/input/OrmInput.md

### OrmLocaleValue
当你需要使用Orm专用多语言文本字段值对象时
-> api/dataentity/entity/OrmLocaleValue.md

### OrmUtils
当你需要使用Orm数据对象处理工具时
-> api/dataentity/utils/OrmUtils.md

### Output
当你需要使用algox使用:在algox处理完输入的Input之后时
-> api/algo/Output.md

### OverallParam
当你需要使用列表参数时
-> api/entity/param/OverallParam.md

---

## P

### PFileStorageType
当你需要使用打印文件存贮方式时
-> api/print/core/execute/PFileStorageType.md

### PKColumnDesc
当你需要使用主键类型格式化处理时
-> api/entity/list/column/PKColumnDesc.md

### PWGridBo
当你需要使用表格时
-> api/print/core/plugin/event/bo/PWGridBo.md

### PWGridCellBo
当你需要使用表格控件单元格包装类时
-> api/print/core/plugin/event/bo/PWGridCellBo.md

### PWGridColumnBo
当你需要使用表格、网格列包装类时
-> api/print/core/plugin/event/bo/PWGridColumnBo.md

### PWGridRowBo
当你需要使用表格、网格行包装类时
-> api/print/core/plugin/event/bo/PWGridRowBo.md

### PWTextBo
当你需要使用文本控件包装类时
-> api/print/core/plugin/event/bo/PWTextBo.md

### PackageDataEvent
当你需要使用单据列表、报表、单据体数据包装事件参数时
-> api/entity/datamodel/events/PackageDataEvent.md

### PageMode
当你需要使用分页模式时
-> api/list/PageMode.md

### PagerClickEvent
当你需要使用页面点击事件参数时
-> api/form/events/PagerClickEvent.md

### ParamKey
当你需要使用参数标识时
-> api/entity/param/ParamKey.md

### ParamOperationResult
当你需要使用系统参数操作返回结果的实体类时
-> api/entity/param/ParamOperationResult.md

### ParamPublishObject
当你需要使用参数查询对象时
-> api/entity/param/ParamPublishObject.md

### ParamRow
当你需要使用参数行对象时
-> api/entity/param/ParamRow.md

### ParameterFormAp
当你需要使用参数界面设计时时
-> api/metadata/form/ParameterFormAp.md

### Paren
当你需要使用 Paren 相关功能时
-> api/formula/excel/Paren.md

### ParticipantInfo
当你需要使用任务参与人信息时
-> api/workflow/engine/msg/info/ParticipantInfo.md

### PermLogReq
当你需要使用 PermLogReq 相关功能时
-> api/permission/model/perm/req/PermLogReq.md

### PermRes
当你需要使用 PermRes 相关功能时
-> api/permission/model/PermRes.md

### PermResult
当你需要使用 PermResult 相关功能时
-> api/permission/model/PermResult.md

### PermissionControlType
当你需要使用权限控制类型时
-> api/entity/PermissionControlType.md

### PermissionServiceHelper
当你需要使用权限服务类时
-> api/servicehelper/permission/PermissionServiceHelper.md

### PersonQueryParam
当你需要使用 PersonQueryParam 相关功能时
-> api/permission/model/PersonQueryParam.md

### PersonQueryType
当你需要使用 PersonQueryType 相关功能时
-> api/permission/model/PersonQueryType.md

### PictureField
当你需要使用通用字段--图片字段时
-> api/metadata/entity/commonfield/PictureField.md

### PictureMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/PictureMobTableColumnAp.md

### PictureProp
当你需要使用图片属性时
-> api/entity/property/PictureProp.md

### PieChart
当你需要使用扇形图时
-> api/form/chart/PieChart.md

### PieChartAp
当你需要使用扇形图时
-> api/metadata/form/chart/PieChartAp.md

### PieSeries
当你需要使用扇形图图形序列时
-> api/form/chart/PieSeries.md

### PkSnapshot
当你需要使用单个表对象的快照对象时
-> api/dataentity/entity/PkSnapshot.md

### PlanInfo
当你需要使用 PlanInfo 相关功能时
-> api/schedule/api/PlanInfo.md

### PlugInPolicy
当你需要使用插件策略时
-> api/entity/botp/PlugInPolicy.md

### Plugin
当你需要使用操作运行时元数据类时
-> api/entity/plugin/Plugin.md

### PluginDataVisitorBo
当你需要使用数据访问器包装类时
-> api/print/core/plugin/event/bo/PluginDataVisitorBo.md

### PointLineChart
当你需要使用点线图？和折线图有什么区别？目前只有一个方法时
-> api/form/chart/PointLineChart.md

### PointLineChartAp
当你需要使用点线图时
-> api/metadata/form/chart/PointLineChartAp.md

### PolygonGraphicShape
当你需要使用多边形图表时
-> api/form/chart/PolygonGraphicShape.md

### PolygonGraphicStyle
当你需要使用多边形图表样式时
-> api/form/chart/PolygonGraphicStyle.md

### PolygonGraphicType
当你需要使用多边形图表类型时
-> api/form/chart/PolygonGraphicType.md

### PreCondition
当你需要使用用于描述规则中的前置条件时
-> api/metadata/entity/validation/PreCondition.md

### PreOpenFormEventArgs
当你需要使用打开表单之前事件参数时
-> api/form/events/PreOpenFormEventArgs.md

### PreparePropertysEventArgs
当你需要使用单据操作插件IOperationServicePlugIn - onPreparePropertys 事件参数时
-> api/entity/plugin/PreparePropertysEventArgs.md

### PrintFormAp
当你需要使用打印专用的表单控件时
-> api/metadata/form/PrintFormAp.md

### PrintMetadata
当你需要使用套打功能专用的元数据 用于描述套打设计器中模型的元素时
-> api/metadata/form/PrintMetadata.md

### PrintTask
当你需要使用打印任务时
-> api/print/api/PrintTask.md

### PrintTimeField
当你需要使用单据最后修改时间字段时
-> api/metadata/entity/businessfield/PrintTimeField.md

### PrintUserField
当你需要使用单据创建人字段时
-> api/metadata/entity/businessfield/PrintUserField.md

### PrintWork
当你需要使用打印工作时
-> api/print/api/PrintWork.md

### PrintWork.EXP_TYPE
当你需要使用打印输出类型枚举时
-> api/print/api/PrintWork.EXP_TYPE.md

### PrivacyCenterServiceHelper
当你需要使用隐私中心服务帮助类时
-> api/servicehelper/privacy/PrivacyCenterServiceHelper.md

### ProcPublishResult
当你需要使用流程发布结果时
-> api/workflow/api/model/ProcPublishResult.md

### ProcessApiResult
当你需要使用 ProcessApiResult 相关功能时
-> api/workflow/engine/process/ProcessApiResult.md

### ProcessDefinitionInfo
当你需要使用流程定义信息时
-> api/workflow/api/model/ProcessDefinitionInfo.md

### ProcessInitiator
当你需要使用流程发起人时
-> api/workflow/api/model/ProcessInitiator.md

### ProcessInstData
当你需要使用流程实例信息时
-> api/workflow/engine/process/ProcessInstData.md

### ProcessInstanceMainOrgView
当你需要使用 ProcessInstanceMainOrgView 相关功能时
-> api/workflow/api/ProcessInstanceMainOrgView.md

### ProcessModel
当你需要使用流程模型时
-> api/workflow/api/model/ProcessModel.md

### ProcessNode
当你需要使用流程节点时
-> api/workflow/api/model/ProcessNode.md

### ProcessTemplate
当你需要使用节点模板时
-> api/workflow/api/model/ProcessTemplate.md

### ProcessVariableData
当你需要使用变量信息时
-> api/workflow/engine/process/ProcessVariableData.md

### ProductSettingServiceHelper
当你需要使用产品设置服务帮助类时
-> api/servicehelper/productsetting/ProductSettingServiceHelper.md

### PropertyChangedArgs
当你需要使用字段值更新事件参数时
-> api/entity/datamodel/events/PropertyChangedArgs.md

### PrtAttach
当你需要使用打印结果时
-> api/print/core/service/PrtAttach.md

### PrtAttach.AttachDetail
当你需要使用附件详情时
-> api/print/core/service/PrtAttach.AttachDetail.md

### PrtDataSource
当你需要使用打印数据源基类时
-> api/print/core/data/datasource/PrtDataSource.md

### PushArgs
当你需要使用下推微服务参数时
-> api/entity/botp/runtime/PushArgs.md

### PushMessage
当你需要使用前端推送的消息类时
-> api/dataentity/message/PushMessage.md

### PushMessageBuilder
当你需要使用推送消息构造帮助类时
-> api/dataentity/message/PushMessageBuilder.md

### PushServiceHelper
当你需要使用消息推送服务类时
-> api/servicehelper/pushMessage/PushServiceHelper.md

---

## Q

### QFilter
当你需要使用ORM查询的条件。支持普通的运算操作时
-> api/orm/query/QFilter.md

### QFilter.QFilterNest
当你需要使用QFilter 子链时
-> api/orm/query/QFilter.QFilterNest.md

### QRCodeEvent
当你需要使用二维码控件 kd.bos.form.control.QRCode 更新事件参数时
-> api/form/control/qrcode/QRCodeEvent.md

### QRCodeOption
当你需要使用二维码状态参数时
-> api/form/control/qrcode/QRCodeOption.md

### QRCodeStatus
当你需要使用二维码控件状态时
-> api/form/control/qrcode/QRCodeStatus.md

### QingAnalysis
当你需要使用 QingAnalysis 相关功能时
-> api/form/control/QingAnalysis.md

### QingViewAp
当你需要使用设计时时
-> api/metadata/list/QingViewAp.md

### QueryBillDataCountEvent
当你需要使用列表查询单据数量事件时
-> api/list/events/QueryBillDataCountEvent.md

### QueryBuilder
当你需要使用IdQuery时
-> api/entity/list/QueryBuilder.md

### QueryEntityType
当你需要使用查询实体类型时
-> api/entity/QueryEntityType.md

### QueryEvent
当你需要使用报表：方案查询事件时
-> api/report/events/QueryEvent.md

### QueryExceedMaxCountEvent
当你需要使用获取查询是否超过最大条数时
-> api/list/events/QueryExceedMaxCountEvent.md

### QueryImportBasedataEventArgs
当你需要使用单据引入时
-> api/entity/datamodel/events/QueryImportBasedataEventArgs.md

### QueryListEvent
当你需要使用搜索事件时
-> api/list/events/QueryListEvent.md

### QueryLookUpdataParameter
当你需要使用模糊查询参数实体时
-> api/filter/helper/QueryLookUpdataParameter.md

### QueryRealCountEvent
当你需要使用列表查询真实条数事件接口时
-> api/list/events/QueryRealCountEvent.md

### QueryResult
当你需要使用列表查询结果时
-> api/entity/list/QueryResult.md

### QueryServiceHelper
当你需要使用查询服务类，提供一些查询的方法时
-> api/servicehelper/QueryServiceHelper.md

---

## R

### RadarAxis
当你需要使用雷达图坐标系时
-> api/form/chart/radar/RadarAxis.md

### RadarChart
当你需要使用雷达图时
-> api/form/chart/radar/RadarChart.md

### RadarChartAp
当你需要使用雷达图时
-> api/metadata/form/chart/RadarChartAp.md

### RadarChartData
当你需要使用雷达图表数据时
-> api/form/chart/radar/RadarChartData.md

### RadarData
当你需要使用雷达图数据时
-> api/form/chart/radar/RadarData.md

### RadarIndicator
当你需要使用雷达图的指示器时
-> api/form/chart/radar/RadarIndicator.md

### RadarSeries
当你需要使用雷达图图表序列时
-> api/form/chart/radar/RadarSeries.md

### ReadonlyDynamicObject
当你需要使用只读的数据包时
-> api/dataentity/entity/ReadonlyDynamicObject.md

### ReduceGroupFunction
当你需要使用对DataSet进行reduce处理时
-> api/algo/ReduceGroupFunction.md

### ReduceGroupFunctionWithCollector
当你需要使用对分组后的结果集进行reduce处理时
-> api/algo/ReduceGroupFunctionWithCollector.md

### RefBillColumnDesc
当你需要使用引用单据格式化字段时
-> api/entity/list/column/RefBillColumnDesc.md

### RefEntityType
当你需要使用引用实体时
-> api/entity/RefEntityType.md

### RefObject
当你需要使用引用对象包装器时
-> api/dataentity/RefObject.md

### RefPropType
当你需要使用引用属性时
-> api/entity/RefPropType.md

### ReportBatchQueryInfo
当你需要使用批量查询信息-分批加载数据时
-> api/entity/report/ReportBatchQueryInfo.md

### ReportColumn
当你需要使用报表列表列信息时
-> api/entity/report/ReportColumn.md

### ReportColumnFactory
当你需要使用报表列构造工厂时
-> api/metadata/entity/report/ReportColumnFactory.md

### ReportColumnGroup
当你需要使用报表列分组信息时
-> api/entity/report/ReportColumnGroup.md

### ReportCommFilterPanelAp
当你需要使用报表过滤面板-常用过滤时
-> api/metadata/report/ReportCommFilterPanelAp.md

### ReportExportInitializeEvent
当你需要使用报表导出初始化事件时
-> api/report/events/ReportExportInitializeEvent.md

### ReportFilter
当你需要使用报表过滤控件时
-> api/report/filter/ReportFilter.md

### ReportFilterAp
当你需要使用报表过滤面板时
-> api/metadata/report/ReportFilterAp.md

### ReportFilterDefaultField
当你需要使用报表过滤初始字段定义时
-> api/entity/report/ReportFilterDefaultField.md

### ReportFilterField
当你需要使用报表过滤字段定义时
-> api/entity/report/queryds/ReportFilterField.md

### ReportFilterShowParameter
当你需要使用请求加载报表过滤时需要设置的参数； 利用对象化参数的形式时
-> api/report/filter/ReportFilterShowParameter.md

### ReportForm
当你需要使用报表控件时
-> api/report/ReportForm.md

### ReportFormAp
当你需要使用报表界面设计时时
-> api/metadata/report/ReportFormAp.md

### ReportList
当你需要使用报表列表控件时
-> api/report/ReportList.md

### ReportListAp
当你需要使用报表列表控件时
-> api/metadata/report/ReportListAp.md

### ReportListModel
当你需要使用报表数据模型时
-> api/mvc/report/ReportListModel.md

### ReportMoreFilterPanelAp
当你需要使用报表过滤面板-更多过滤时
-> api/metadata/report/ReportMoreFilterPanelAp.md

### ReportOperationColumn
当你需要使用报表列-操作列时
-> api/report/ReportOperationColumn.md

### ReportPropUtil
当你需要使用报表工具类时
-> api/mvc/report/ReportPropUtil.md

### ReportQueryExtEvent
当你需要使用报表查询扩展事件类时
-> api/event/ReportQueryExtEvent.md

### ReportQueryParam
当你需要使用报表查询参数类时
-> api/entity/report/ReportQueryParam.md

### ReportSelectedRow
当你需要使用报表选中行数据时
-> api/report/ReportSelectedRow.md

### ReportServiceHelper
当你需要使用 ReportServiceHelper 相关功能时
-> api/servicehelper/report/ReportServiceHelper.md

### ReportShowParameter
当你需要使用报表显示参数时
-> api/report/ReportShowParameter.md

### ReportTaskParam
当你需要使用报表任务参数类时
-> api/entity/report/ReportTaskParam.md

### ReportTree
当你需要使用报表树（控件）时
-> api/report/ReportTree.md

### ReportTreeAp
当你需要使用报表-左树控件时
-> api/metadata/report/ReportTreeAp.md

### ReportView
当你需要使用报表视图时
-> api/mvc/report/ReportView.md

### RequestContext
当你需要使用Request Context时
-> api/context/RequestContext.md

### RequestContextCreator
当你需要使用Web端创建RequestContext的统一入口时
-> api/context/RequestContextCreator.md

### RequestSecurityDto
当你需要使用签名认证请求模型时
-> api/openapi/security/model/RequestSecurityDto.md

### RequiredValidator
当你需要使用必录校验器时
-> api/entity/validate/RequiredValidator.md

### ResManager
当你需要使用获取多语言资源工具时
-> api/dataentity/resource/ResManager.md

### ResetDateFilterEvent
当你需要使用日期事件参数时
-> api/form/field/events/ResetDateFilterEvent.md

### Resources
当你需要使用 Resources 相关功能时
-> api/util/resource/Resources.md

### ResponseSecurityDto
当你需要使用签名认证响应模型时
-> api/openapi/security/model/ResponseSecurityDto.md

### ResultAwarable
当你需要使用元数据获取接口时
-> api/algox/ResultAwarable.md

### ReturnOperationArgs
当你需要使用操作微服务执行结束时
-> api/entity/plugin/args/ReturnOperationArgs.md

### RevProxyUtil
当你需要使用反向代理(例如Nginx)配置的变量名称与相关处理时
-> api/util/RevProxyUtil.md

### RoleAssignUserDimReq
当你需要使用 RoleAssignUserDimReq 相关功能时
-> api/permission/model/perm/req/RoleAssignUserDimReq.md

### RollbackOperationArgs
当你需要使用操作处理失败时
-> api/entity/plugin/args/RollbackOperationArgs.md

### RouteInfo
当你需要使用路由信息时
-> api/db/archive/RouteInfo.md

### Row
当你需要使用DataSet中对应的行数据时
-> api/algo/Row.md

### RowDataEntity
当你需要使用触发字段值改变事件的数据行时
-> api/entity/datamodel/RowDataEntity.md

### RowDataModel
当你需要使用行数据模型时
-> api/entity/formula/RowDataModel.md

### RowFactory
当你需要使用 RowFactory 相关功能时
-> api/algo/dataset/RowFactory.md

### RowFeature
当你需要使用Row顶层接口时
-> api/algo/RowFeature.md

### RowMapper
当你需要使用记录源数据行(Map)时
-> api/form/operate/imptapi/RowMapper.md

### RowMeta
当你需要使用元素据信息：主要包含当前DataSet的列名称时
-> api/algo/RowMeta.md

### RowMetaFactory
当你需要使用创建元素据的工厂时
-> api/algo/RowMetaFactory.md

### RowOperateType
当你需要使用行操作类型时
-> api/dataentity/metadata/RowOperateType.md

### RowUtil
当你需要使用DataSet行(Row)处理的工具类时
-> api/algo/RowUtil.md

### RowX
当你需要使用DataSetX中的一行数据时
-> api/algox/RowX.md

### RunModeServiceHelper
当你需要使用运行模式服务帮助类时
-> api/servicehelper/runmode/RunModeServiceHelper.md

---

## S

### SMSSender
当你需要使用登录页面时
-> api/login/utils/sms/SMSSender.md

### SaveServiceHelper
当你需要使用实体保存服务时
-> api/servicehelper/operation/SaveServiceHelper.md

### ScheduleMsgInfo
当你需要使用调度计划消息通知时
-> api/schedule/api/ScheduleMsgInfo.md

### ScheduleServiceHelper
当你需要使用调度服务帮助类时
-> api/servicehelper/schedule/ScheduleServiceHelper.md

### SchemeBaseDataFilterColumn
当你需要使用方案基础资料过滤字段时
-> api/filter/SchemeBaseDataFilterColumn.md

### SchemeBaseDataFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/SchemeBaseDataFilterColumnAp.md

### SchemeFilterColumn
当你需要使用方案过滤字段时
-> api/filter/SchemeFilterColumn.md

### SchemeFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/SchemeFilterColumnAp.md

### SchemeFilterView
当你需要使用方案过滤视图时
-> api/filter/SchemeFilterView.md

### SchemeFilterViewAp
当你需要使用设计时时
-> api/metadata/filter/SchemeFilterViewAp.md

### SchemeVoucherFilterColumnAp
当你需要使用设计时时
-> api/metadata/filter/SchemeVoucherFilterColumnAp.md

### ScriptExtensionManager
当你需要使用脚本扩展点创建器时
-> api/extplugin/ScriptExtensionManager.md

### SearchAp
当你需要使用搜索框时
-> api/metadata/form/mcontrol/SearchAp.md

### SearchEvent
当你需要使用报表查询事件时
-> api/report/events/SearchEvent.md

### SearchListener
当你需要使用报表查询事件时
-> api/report/filter/SearchListener.md

### SelectEvent
当你需要使用选择事件时
-> api/list/events/SelectEvent.md

### SelectedDisplayField
当你需要使用已选显示字段时
-> api/entity/SelectedDisplayField.md

### SensitiveArgs
当你需要使用敏感事件参数时
-> api/entity/plugin/args/SensitiveArgs.md

### SeqColumnType
当你需要使用列表字段seq类型枚举类时
-> api/list/SeqColumnType.md

### SerializationException
当你需要使用在序列化时发生的异常时
-> api/dataentity/exception/SerializationException.md

### SerializationUtils
当你需要使用序列化的辅助工具类时
-> api/dataentity/serialization/SerializationUtils.md

### Series
当你需要使用图表序列集合（即图表数据对象集合）时
-> api/form/chart/Series.md

### Service
当你需要使用用于用户实现微服务接口时
-> api/framework/lifecycle/Service.md

### ServiceFactory
当你需要使用微服务调用反射工厂时
-> api/service/ServiceFactory.md

### SetCellFieldValueArgs
当你需要使用表格控件设置单元格事件监听参数时
-> api/list/events/SetCellFieldValueArgs.md

### SetCellFieldValueEvent
当你需要使用表格控件设置单元格事件时
-> api/list/events/SetCellFieldValueEvent.md

### SetFilterContainerBaseDataSearchClosedEvent
当你需要使用是否关闭常用过滤视图基础资料模糊查询功能事件参数时
-> api/filter/events/SetFilterContainerBaseDataSearchClosedEvent.md

### SetFilterEvent
当你需要使用设置过滤条件事件参数时
-> api/form/events/SetFilterEvent.md

### SetShowFormCustomParamControllerEvent
当你需要使用设置表单自定义参数事件时
-> api/form/field/events/SetShowFormCustomParamControllerEvent.md

### ShardingHintContext
当你需要使用分片提示上下文：对范围内的sql有效时
-> api/xdb/hint/ShardingHintContext.md

### ShardingMetadataService
当你需要使用水平分表元数据接口时
-> api/xdb/mservice/ShardingMetadataService.md

### ShardingParam
当你需要使用调度任务分片参数时
-> api/schedule/api/ShardingParam.md

### ShareLock
当你需要使用共享、独占锁时
-> api/mutex/ShareLock.md

### SheetHandler
当你需要使用Excel平台解析类时
-> api/impt/SheetHandler.md

### SheetHandler.ParsedRow
当你需要使用导入解析Excel的行数据承载对象时
-> api/impt/SheetHandler.ParsedRow.md

### ShortMessageInfo
当你需要使用描述：短信信息对象时
-> api/message/api/ShortMessageInfo.md

### ShowColumn
当你需要使用基础资料模糊查询列头对象时
-> api/entity/param/ShowColumn.md

### ShowFlexEditEvent
当你需要使用显示弹性域编辑控件事件参数时
-> api/form/field/events/ShowFlexEditEvent.md

### ShowFlexEditListener
当你需要使用显示弹性域编辑控件事件接口时
-> api/form/field/events/ShowFlexEditListener.md

### ShowFormHelper
当你需要使用工具类时
-> api/form/ShowFormHelper.md

### ShowType
当你需要使用展示风格时
-> api/form/ShowType.md

### SidePanelAp
当你需要使用 SidePanelAp 相关功能时
-> api/metadata/form/container/SidePanelAp.md

### SignCommandParam
当你需要使用签名指令参数时
-> api/servicehelper/ca/SignCommandParam.md

### SignCommandResult
当你需要使用签名指令发送结果时
-> api/servicehelper/ca/SignCommandResult.md

### SignInfoDto
当你需要使用签名信息时
-> api/openapi/security/model/SignInfoDto.md

### SignScheme
当你需要使用签名配置方案时
-> api/entity/ca/SignScheme.md

### SignServiceHelper
当你需要使用签名服务类时
-> api/servicehelper/ca/SignServiceHelper.md

### SimpleFilterRow
当你需要使用过滤行数据时
-> api/entity/filter/SimpleFilterRow.md

### SimpleProperty
当你需要使用简单属性基础实现时
-> api/dataentity/metadata/clr/SimpleProperty.md

### SimplePropertyAttribute
当你需要使用标注实体类的简单属性时
-> api/dataentity/entity/SimplePropertyAttribute.md

### SingleOrgContextHelper
当你需要使用 SingleOrgContextHelper 相关功能时
-> api/form/SingleOrgContextHelper.md

### SmsUsingQuantities
当你需要使用消息中心短信使用数量时
-> api/workflow/message/api/SmsUsingQuantities.md

### SortAndFilterEvent
当你需要使用过滤排序事件参数时
-> api/report/events/SortAndFilterEvent.md

### SortField
当你需要使用数据表格排序字段时
-> api/print/core/data/datasource/prop/SortField.md

### SourceBillReport
当你需要使用源单转换报告时
-> api/entity/botp/runtime/SourceBillReport.md

### SourceRowReport
当你需要使用源单行转换报告时
-> api/entity/botp/runtime/SourceRowReport.md

### SplitContainerAp
当你需要使用分割容器时
-> api/metadata/form/container/SplitContainerAp.md

### SplitPanelAp
当你需要使用分割容器面板时
-> api/metadata/form/container/SplitPanelAp.md

### Spread
当你需要使用通用控件 - Spread表格时
-> api/form/spread/Spread.md

### SpreadActionAdapter
当你需要使用Spread表格控件自定义动作执行基类时
-> api/form/spread/SpreadActionAdapter.md

### SpreadAp
当你需要使用Spread表格时
-> api/metadata/form/spread/SpreadAp.md

### SpreadEvent
当你需要使用Spread表格控件动作执行参数时
-> api/form/spread/event/SpreadEvent.md

### SpreadPostDataInfo
当你需要使用Spread控件前端发送到服务端的数据时
-> api/form/spread/SpreadPostDataInfo.md

### SqlHint
当你需要使用用来注册自定义函数,在DataSet执行sql语句时时
-> api/algo/SqlHint.md

### SqlParameter
当你需要使用SQL参数时
-> api/dataentity/SqlParameter.md

### StandardTreeListPlugin
当你需要使用标准树列表插件时
-> api/list/plugin/StandardTreeListPlugin.md

### StatusItem
当你需要使用单据状态字段时
-> api/metadata/entity/businessfield/billstatusfield/StatusItem.md

### StdExtPluginProxy
当你需要使用通用的二次扩展接口 StdExtPlugin 代理对象时
-> api/extplugin/StdExtPluginProxy.md

### StringType
当你需要使用Algo中的数据类型,对应Java类型为String时
-> api/algo/datatype/StringType.md

### StringUtils
当你需要使用String工具类时
-> api/util/StringUtils.md

### Style
当你需要使用样式属性时
-> api/metadata/form/Style.md

### StyleCss
当你需要使用窗体风格层叠样式(HTML Only)时
-> api/form/StyleCss.md

### StyleKey
当你需要使用控件样式时
-> api/print/core/model/widget/StyleKey.md

### SubCardEntryAp
当你需要使用子卡片分录时
-> api/metadata/form/cardentry/SubCardEntryAp.md

### SubEntryEntity
当你需要使用 SubEntryEntity 相关功能时
-> api/metadata/entity/SubEntryEntity.md

### SubSysTreeBuilder
当你需要使用构建子系统树工具类时
-> api/devportal/common/util/SubSysTreeBuilder.md

### Sum
当你需要使用合计时
-> api/formula/functions/Sum.md

### SumDataLoadOnFirstSetEvent
当你需要使用页面加载同时“计算合计”事件开关参数时
-> api/form/events/SumDataLoadOnFirstSetEvent.md

### SummaryEvent
当你需要使用报表合计事件参数时
-> api/report/events/SummaryEvent.md

### SummaryResult
当你需要使用汇总集合对象时
-> api/entity/list/SummaryResult.md

### SummaryToField
当你需要使用汇总至字段映射对象时
-> api/entity/SummaryToField.md

### SystemParamServiceHelper
当你需要使用系统参数服务时
-> api/servicehelper/parameter/SystemParamServiceHelper.md

---

## T

### TCCAdapterService
当你需要使用TCC服务适配器:时
-> api/kdtx/sdk/api/TCCAdapterService.md

### TCCGlobalSession
当你需要使用TCC全局控制类:主要在插件流程里使用TCC时
-> api/kdtx/sdk/session/tcc/TCCGlobalSession.md

### TCCSession
当你需要使用分布式事务TCC模式Seesion时
-> api/kdtx/sdk/session/tcc/TCCSession.md

### TX
当你需要使用标准用法：时
-> api/db/tx/TX.md

### TXHandle
当你需要使用事务句柄时
-> api/db/tx/TXHandle.md

### Tab
当你需要使用页签时
-> api/form/container/Tab.md

### TabAp
当你需要使用页签时
-> api/metadata/form/container/TabAp.md

### TabIcon
当你需要使用页签控件支持配置图标在最右侧时
-> api/form/container/TabIcon.md

### TabPage
当你需要使用子页签控件时
-> api/form/container/TabPage.md

### TabPageAp
当你需要使用子页签时
-> api/metadata/form/container/TabPageAp.md

### TableDefine
当你需要使用单据实体表格定义时
-> api/entity/botp/runtime/TableDefine.md

### TableValueSetter
当你需要使用表值设置对象时
-> api/entity/datamodel/TableValueSetter.md

### Task
当你需要使用定时任务实现接口时
-> api/schedule/api/Task.md

### TaskAndParticipantBatchUpdateParams
当你需要使用批量更新任务参数时
-> api/workflow/engine/task/TaskAndParticipantBatchUpdateParams.md

### TaskAndParticipantBatchUpdateResult
当你需要使用批量更新任务信息以及参与人返回结果时
-> api/workflow/engine/task/TaskAndParticipantBatchUpdateResult.md

### TaskCenterNavigationEntity
当你需要使用 TaskCenterNavigationEntity 相关功能时
-> api/workflow/engine/impl/persistence/entity/task/TaskCenterNavigationEntity.md

### TaskClick
当你需要使用用户点击前端任务面板上的任务时时
-> api/schedule/form/TaskClick.md

### TaskClientProxy
当你需要使用前端的任务提醒面板内容管理对象：提供方法时
-> api/schedule/form/TaskClientProxy.md

### TaskEntityInfo
当你需要使用任务实体信息时
-> api/workflow/engine/msg/info/TaskEntityInfo.md

### TaskInfo
当你需要使用任务结构时
-> api/schedule/api/TaskInfo.md

### TaskOperationParam
当你需要使用任务操作参数时
-> api/workflow/engine/task/operation/TaskOperationParam.md

### TaskStatusConstant
当你需要使用任务状态常量时
-> api/schedule/api/TaskStatusConstant.md

### TelephoneParseResult
当你需要使用`TelephoneParseResult` 手机号码解析结果时
-> api/i18n/api/model/TelephoneParseResult.md

### TelephoneVerifyResult
当你需要使用`TelephoneVerifyResult` 手机号码格式检验结果时
-> api/i18n/api/model/TelephoneVerifyResult.md

### TempFileCacheDownloadable
当你需要使用 TempFileCacheDownloadable 相关功能时
-> api/cache/tempfile/TempFileCacheDownloadable.md

### TemplateTextItem
当你需要使用模式文本操作项时
-> api/list/column/TemplateTextItem.md

### TemplateTextListColumn
当你需要使用模式文本列表字段时
-> api/list/TemplateTextListColumn.md

### TextColumnDesc
当你需要使用文本格式化处理时
-> api/entity/list/column/TextColumnDesc.md

### TextField
当你需要使用打印数据模型-文本字段时
-> api/print/core/data/field/TextField.md

### TextFormatEnum
当你需要使用文本格式类型时
-> api/print/core/plugin/event/bo/propenum/TextFormatEnum.md

### TextGraphicStyle
当你需要使用图形-文本块样式时
-> api/form/chart/TextGraphicStyle.md

### TextGraphicType
当你需要使用图形-文本块时
-> api/form/chart/TextGraphicType.md

### TextMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/TextMobTableColumnAp.md

### TextReportColumn
当你需要使用报表列-文本类型列时
-> api/entity/report/TextReportColumn.md

### ThirdAppAuthtication
当你需要使用第三方系统免登星瀚的场景时
-> api/login/thirdauth/app/ThirdAppAuthtication.md

### ThirdCommentInfo
当你需要使用第三方审批信息时
-> api/workflow/engine/task/ThirdCommentInfo.md

### ThreadLocals
当你需要使用线程局部变量工具类时
-> api/util/ThreadLocals.md

### ThreadPools
当你需要使用后台线程池时
-> api/threads/ThreadPools.md

### TileItem
当你需要使用平铺项时
-> api/entity/TileItem.md

### TimeColumnDesc
当你需要使用时间格式化处理时
-> api/entity/list/column/TimeColumnDesc.md

### TimeDataGridColumn
当你需要使用时间列时
-> api/form/control/grid/column/TimeDataGridColumn.md

### TimeDataGridColumnAp
当你需要使用时间列时
-> api/metadata/form/control/grid/column/TimeDataGridColumnAp.md

### TimeField
当你需要使用打印数据模型-时间字段时
-> api/print/core/data/field/TimeField.md

### TimeListColumn
当你需要使用时间列表字段时
-> api/list/TimeListColumn.md

### TimeListColumnAp
当你需要使用设计时时
-> api/metadata/list/TimeListColumnAp.md

### TimeMobTableColumnAp
当你需要使用移动端表格时
-> api/metadata/form/mcontrol/mobtable/tablecolumn/TimeMobTableColumnAp.md

### TimeReportColumn
当你需要使用报表列-时间类型列时
-> api/entity/report/TimeReportColumn.md

### TimeService
当你需要使用时间服务接口默认实现时
-> api/service/TimeService.md

### TimeServiceHelper
当你需要使用时间服务时
-> api/servicehelper/TimeServiceHelper.md

### TimeZoneLocationEvent
当你需要使用移动端时区设置事件参数时
-> api/form/events/TimeZoneLocationEvent.md

### TimestampType
当你需要使用Algo中的数据类型,对应Java类型为TimeStamp时
-> api/algo/datatype/TimestampType.md

### Tips
当你需要使用设计器tips属性配置时
-> api/entity/Tips.md

### TipsLink
当你需要使用tips链接对象时
-> api/entity/TipsLink.md

### TipsSupport
当你需要使用控件、容器、标签、附件面板等支持帮助提示控件的父类时
-> api/form/TipsSupport.md

### TplInfo
当你需要使用打印模板信息时
-> api/print/core/plugin/tpl/TplInfo.md

### TplMatcherParam
当你需要使用模板匹配参数时
-> api/print/matchtpl/TplMatcherParam.md

### TplMatcherUtil
当你需要使用模板匹配工具类时
-> api/print/matchtpl/TplMatcherUtil.md

### TransferNode
当你需要使用穿梭框节点对象时
-> api/form/transfer/TransferNode.md

### TransferOperationParam
当你需要使用转交操作参数时
-> api/workflow/engine/task/operation/TransferOperationParam.md

### TransferTreeNode
当你需要使用穿梭框节点对象时
-> api/form/transfer/TransferTreeNode.md

### TreeEntryEntity
当你需要使用 TreeEntryEntity 相关功能时
-> api/metadata/entity/TreeEntryEntity.md

### TreeEntryType
当你需要使用树形单据体实体类型时
-> api/entity/TreeEntryType.md

### TreeFilterParameter
当你需要使用树形模板上树形数据的过滤条件参数对象时
-> api/tree/TreeFilterParameter.md

### TreeInitializeInfo
当你需要使用树节点初始化事件, 用于树形列表初始化时时
-> api/entity/tree/TreeInitializeInfo.md

### TreeLeafType
当你需要使用子系统数据节点类型枚举时
-> api/devportal/common/util/TreeLeafType.md

### TreeMenuNode
当你需要使用树形菜单控件的子节点（菜单项）时
-> api/entity/tree/TreeMenuNode.md

### TreeNode
当你需要使用树形控件节点时
-> api/entity/tree/TreeNode.md

### TreeNodePartialVariables
当你需要使用用于客户端局部更新节点属性（节点名称、是否锁定、是否展开、标签信息、图标信息）时
-> api/entity/tree/TreeNodePartialVariables.md

### TreeReportListEvent
当你需要使用折叠树形报表事件参数时
-> api/report/events/TreeReportListEvent.md

### TreeSubEntryEntity
当你需要使用 TreeSubEntryEntity 相关功能时
-> api/metadata/entity/TreeSubEntryEntity.md

### Tuple
当你需要使用变量值包装器：可含2个有顺序的值对象时
-> api/dataentity/Tuple.md

### TxCheckUtil
当你需要使用分布式事务工具类时
-> api/kdtx/sdk/check/TxCheckUtil.md

### TxLogInfo
当你需要使用分布式事务操作日志信息时
-> api/kdtx/common/entity/TxLogInfo.md

### TypesContainer
当你需要使用类实例反射构造工具时
-> api/dataentity/TypesContainer.md

---

## U

### UDFunction
当你需要使用自定义函数运行接口时
-> api/formula/excel/UDFunction.md

### UnitConvertHelper
当你需要使用根据目标单位进行数量换算时
-> api/servicehelper/UnitConvertHelper.md

### UpdateParticipantParam
当你需要使用更新参与人参数时
-> api/workflow/engine/task/operation/UpdateParticipantParam.md

### UpgradeResult
当你需要使用升级返回结果时
-> api/form/upgrade/UpgradeResult.md

### UploadOption
当你需要使用文件上传选项时
-> api/upload/UploadOption.md

### UploadResultEvent
当你需要使用附件上传结果事件参数时
-> api/form/control/events/UploadResultEvent.md

### UppercaseType
当你需要使用金额中文大写枚举类时
-> api/print/core/model/UppercaseType.md

### UserAssignDimRoleReq
当你需要使用 UserAssignDimRoleReq 相关功能时
-> api/permission/model/perm/req/UserAssignDimRoleReq.md

### UserAssignUserGroupReq
当你需要使用 UserAssignUserGroupReq 相关功能时
-> api/permission/model/perm/req/UserAssignUserGroupReq.md

### UserConfig
当你需要使用用户自定义数据配置表映射类时
-> api/entity/userconfig/UserConfig.md

### UserConfigServiceHelper
当你需要使用人员配置服务类时
-> api/servicehelper/user/UserConfigServiceHelper.md

### UserDimReq
当你需要使用 UserDimReq 相关功能时
-> api/permission/model/perm/req/UserDimReq.md

### UserDirectAssignPermReq
当你需要使用 UserDirectAssignPermReq 相关功能时
-> api/permission/model/perm/req/user/UserDirectAssignPermReq.md

### UserDirectAssignReq
当你需要使用 UserDirectAssignReq 相关功能时
-> api/permission/model/perm/req/user/UserDirectAssignReq.md

### UserGroupAssignUserReq
当你需要使用 UserGroupAssignUserReq 相关功能时
-> api/permission/model/perm/req/UserGroupAssignUserReq.md

### UserList
当你需要使用用户列表时
-> api/list/UserList.md

### UserListAp
当你需要使用设计时时
-> api/metadata/list/UserListAp.md

### UserParamterServiceHelper
当你需要使用用户选项服务时
-> api/servicehelper/parameter/UserParamterServiceHelper.md

### UserService
当你需要使用 UserService 相关功能时
-> api/servicehelper/user/UserService.md

### UserServiceHelper
当你需要使用公共资料服务类：人员时
-> api/servicehelper/user/UserServiceHelper.md

### Uuid16
当你需要使用字符类型ID生成工具时
-> api/dataentity/utils/Uuid16.md

### Uuid8
当你需要使用UUID8生成工具时
-> api/dataentity/utils/Uuid8.md

---

## V

### Validate
当你需要使用This class assists in validating arguments. The validation m时
-> api/dataentity/utils/Validate.md

### ValidateContext
当你需要使用校验上下文相关信息时
-> api/entity/validate/ValidateContext.md

### ValidatePrefixArgs
当你需要使用执行操作校验前事件参数时
-> api/entity/plugin/args/ValidatePrefixArgs.md

### ValidatePriority
当你需要使用校验器执行优先级：枚举值越低的时
-> api/entity/validate/ValidatePriority.md

### ValidateResult
当你需要使用校验结果时
-> api/entity/validate/ValidateResult.md

### ValidateResultCollection
当你需要使用校验结果集合 输出所以的校验器校验的结果时
-> api/entity/validate/ValidateResultCollection.md

### ValidateResultItem
当你需要使用流程校验结果项时
-> api/workflow/api/model/ValidateResultItem.md

### Validation
当你需要使用校验器的元数据定义时
-> api/metadata/entity/validation/Validation.md

### ValidationErrorInfo
当你需要使用校验错误信息时
-> api/entity/validate/ValidationErrorInfo.md

### ValidationType
当你需要使用校验器定义时
-> api/metadata/entity/validation/ValidationType.md

### ValidationTypes
当你需要使用校验器定义的集合时
-> api/metadata/entity/validation/ValidationTypes.md

### ValueMapItem
当你需要使用列表显示下拉列表字段格式化时用时
-> api/entity/ValueMapItem.md

### ValueTextItem
当你需要使用已选数据项时
-> api/entity/ValueTextItem.md

### VarInfo
当你需要使用公式变量信息类时
-> api/formula/platform/api/VarInfo.md

### Variable
当你需要使用 Variable 相关功能时
-> api/workflow/bpmn/model/Variable.md

### VerifySignInfo
当你需要使用验签信息类时
-> api/entity/ca/VerifySignInfo.md

### VerifySignResult
当你需要使用验签结果类时
-> api/ca/bean/VerifySignResult.md

### VerifyVisitor
当你需要使用 VerifyVisitor 相关功能时
-> api/formula/excel/VerifyVisitor.md

### ViewCommonUtil
当你需要使用列表视图和卡片视图字段通用处理类时
-> api/list/ViewCommonUtil.md

### Visitor
当你需要使用表达式执行单元遍历接口时
-> api/formula/excel/Visitor.md

### VoucherNoListColumn
当你需要使用凭证列表字段时
-> api/list/VoucherNoListColumn.md

### VoucherNoListColumnAp
当你需要使用设计时时
-> api/metadata/list/VoucherNoListColumnAp.md

### VoucherNoListField
当你需要使用列表列字段 - 凭证号列时
-> api/entity/datamodel/VoucherNoListField.md

---

## W

### WFAuditResultTypeEnum
当你需要使用 WFAuditResultTypeEnum 相关功能时
-> api/workflow/api/constants/WFAuditResultTypeEnum.md

### WFAuditTask
当你需要使用 WFAuditTask 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFAuditTask.md

### WFAutoTask
当你需要使用 WFAutoTask 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFAutoTask.md

### WFAutoTaskExtItf
当你需要使用 WFAutoTaskExtItf 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFAutoTaskExtItf.md

### WFBillSetting
当你需要使用 WFBillSetting 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFBillSetting.md

### WFCallActivityMultiInstDimensionItem
当你需要使用 WFCallActivityMultiInstDimensionItem 相关功能时
-> api/workflow/engine/extitf/WFCallActivityMultiInstDimensionItem.md

### WFCustomParam
当你需要使用自定义参数时
-> api/workflow/engine/dynprocess/freeflow/WFCustomParam.md

### WFDecisionOption
当你需要使用 WFDecisionOption 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFDecisionOption.md

### WFFlowElement
当你需要使用 WFFlowElement 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFFlowElement.md

### WFFlowNode
当你需要使用 WFFlowNode 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFFlowNode.md

### WFJointAuditTask
当你需要使用 WFJointAuditTask 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFJointAuditTask.md

### WFParticipantEntity
当你需要使用 WFParticipantEntity 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFParticipantEntity.md

### WFParticipantModel
当你需要使用 WFParticipantModel 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFParticipantModel.md

### WFProcess
当你需要使用 WFProcess 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFProcess.md

### WFRejectNodesModel
当你需要使用 WFRejectNodesModel 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFRejectNodesModel.md

### WFTaskResultEnum
当你需要使用 WFTaskResultEnum 相关功能时
-> api/workflow/api/constants/WFTaskResultEnum.md

### WFUserTask
当你需要使用 WFUserTask 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFUserTask.md

### WFValidationError
当你需要使用 WFValidationError 相关功能时
-> api/workflow/engine/dynprocess/freeflow/WFValidationError.md

### WarnMessageReceiver
当你需要使用消息接收人时
-> api/entity/earlywarn/warnschedule/messageconfig/WarnMessageReceiver.md

### WarnSchedule
当你需要使用预警监控方案运行时时
-> api/entity/earlywarn/warnschedule/WarnSchedule.md

### WarnScheduleMetaServiceHelper
当你需要使用监控方案元数据帮助类时
-> api/servicehelper/earlywarn/WarnScheduleMetaServiceHelper.md

### WebOfficeBrowserHelper
当你需要使用weboffice浏览器帮助类时
-> api/mvc/form/helper/WebOfficeBrowserHelper.md

### WebOfficeBrowserParam
当你需要使用weboffice 内建浏览器打开方式时
-> api/mvc/form/helper/WebOfficeBrowserParam.md

### WeixinqyMessageInfo
当你需要使用 WeixinqyMessageInfo 相关功能时
-> api/message/api/WeixinqyMessageInfo.md

### Widget
当你需要使用卡片时
-> api/form/widget/Widget.md

### WidgetAp
当你需要使用小部件(卡片)时
-> api/metadata/form/widget/WidgetAp.md

### WidgetChangedEvent
当你需要使用卡片改变事件参数时
-> api/form/widget/events/WidgetChangedEvent.md

### WidgetContainer
当你需要使用卡片容器时
-> api/form/widget/WidgetContainer.md

### WidgetContainerAp
当你需要使用小部件(卡片)容器时
-> api/metadata/form/widget/WidgetContainerAp.md

### WidgetFormAp
当你需要使用小部件界面设计时时
-> api/metadata/form/WidgetFormAp.md

### WidgetGroupPanelAp
当你需要使用小部件(卡片)分组容器时
-> api/metadata/form/widget/WidgetGroupPanelAp.md

### WithEntityEntryDistinctable
当你需要使用根据分录判断 distinct 实现时
-> api/orm/query/WithEntityEntryDistinctable.md

### Wizard
当你需要使用向导控件时
-> api/form/container/Wizard.md

### WizardAp
当你需要使用向导时
-> api/metadata/form/container/WizardAp.md

### WizardPageAp
当你需要使用向导页签时
-> api/metadata/form/container/WizardPageAp.md

### WorkFlowFormServiceHelper
当你需要使用工作流表单服务帮助类,用于快速打开流程中的表单界面时
-> api/workflow/service/WorkFlowFormServiceHelper.md

### WorkflowDataSource
当你需要使用工作流数据源时
-> api/print/core/data/datasource/WorkflowDataSource.md

### WorkflowDesigner
当你需要使用 WorkflowDesigner 相关功能时
-> api/workflow/component/WorkflowDesigner.md

### WorkflowPlugin
当你需要使用 WorkflowPlugin 相关功能时
-> api/workflow/engine/extitf/WorkflowPlugin.md

### WorkflowServiceHelper
当你需要使用工作流服务时
-> api/servicehelper/workflow/WorkflowServiceHelper.md

### WriteBackBizRule
当你需要使用反写规则 - 业务规则时
-> api/entity/botp/WriteBackBizRule.md

### WriteBackFormula
当你需要使用反写公式时
-> api/entity/botp/WriteBackFormula.md

### WriteBackRuleElement
当你需要使用运行时反写规则时
-> api/entity/botp/WriteBackRuleElement.md

### WriteBackRuleReader
当你需要使用反写规则时
-> api/metadata/botp/WriteBackRuleReader.md

---

## Y

### YzjMessageInfo
当你需要使用描述：云之家公共号消息信息对象时
-> api/message/api/YzjMessageInfo.md

---

## Z

### ZipFile
当你需要使用处理zip文件的基类时
-> api/zip/ZipFile.md

### ZipOutputStream
当你需要使用 ZipOutputStream 相关功能时
-> api/zip/io/outputstream/ZipOutputStream.md

### ZipParameters
当你需要使用封装控制 Zip4J 如何编码数据的参数时
-> api/zip/model/ZipParameters.md

---
