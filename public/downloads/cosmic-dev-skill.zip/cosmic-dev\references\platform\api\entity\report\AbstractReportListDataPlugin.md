---
framework_version: "8.0.1"
api_class: "AbstractReportListDataPlugin"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表查询取数插件时"
---

# AbstractReportListDataPlugin API 说明

## 概述
报表查询取数插件。实现 IReportListDataPlugin。
主要功能：读取属性、查询数据、设置属性。

## Import 路径
```java
import kd.bos.entity.report.AbstractReportListDataPlugin;
```

---

## 方法列表

### export

导出查询全量数据

**方法签名：**
```java
public DataSet export(ReportQueryParam queryParam, Object selectedObj)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数
- `selectedObj`: `Object` — 左树（表）右表是选中左树（表）对象，左树时为节点ID，左表时为选中行数据

**返回值：**
- `DataSet`: 返回报表数据

---

### exportWithSheet

分sheet页导出数据

**方法签名：**
```java
public List<kd.ReportExportDataResult> exportWithSheet(ReportQueryParam queryParam, Object selectedObj)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数
- `selectedObj`: `Object` — 左树（表）右表是选中左树（表）对象，左树时为节点ID，左表时为选中行数据

**返回值：**
- `List<kd.ReportExportDataResult>`: 一个sheet页对一个一个数据 ReportExportDataResult

---

### getColumns

改变列信息

**方法签名：**
```java
public List<AbstractReportColumn> getColumns(List<AbstractReportColumn> columns)
```

**参数说明：**
- `columns`: `List<AbstractReportColumn>` — 报表设计列

**返回值：**
- `List<AbstractReportColumn>`: 页面显示列

---

### getDynamicColumns

获取插件动态添加的字段，用于配置字段权限、打印等

**方法签名：**
```java
public void getDynamicColumns(DynamicReportColumnEvent event)
```

**参数说明：**
- `event`: `DynamicReportColumnEvent`

---

### getQueryParam

获取查询条件

**方法签名：**
```java
public ReportQueryParam getQueryParam()
```

**返回值：**
- `ReportQueryParam`

---

### getSelectedObj

获取左表、左树选择行或节点

**方法签名：**
```java
public Object getSelectedObj()
```

**返回值：**
- `Object`

---

### query

查询数据

**方法签名：**
```java
public abstract DataSet query(ReportQueryParam queryParam, Object selectedObj)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数
- `selectedObj`: `Object` — 左树（表）右表是选中左树（表）对象，左树时为节点ID，左表时为选中行数据

**返回值：**
- `DataSet`: 返回报表数据

---

### queryBatchBy

返回用于分批取数的依据数据
 
 eg：以物料为分批依据，些接口返回涉及的所有物料，
 然后query接口中通queryParam.getCurrentBatch获取当前分批，
 并可基于该分批过滤取数

**方法签名：**
```java
public DataSet queryBatchBy(ReportQueryParam queryParam)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数

**返回值：**
- `DataSet`: 返回报表数据

---

### setProgress

设置进度

**方法签名：**
```java
public void setProgress(int percent)
```

**参数说明：**
- `percent`: `int`

---
