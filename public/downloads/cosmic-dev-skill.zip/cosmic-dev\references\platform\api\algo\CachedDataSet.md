---
framework_version: "8.0.1"
api_class: "CachedDataSet"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用Cached dataset时"
---

# CachedDataSet API 说明

## 概述
Cached dataset，缓存的结果集，可以跨请求访问，用于实现分页报表，序时簿等。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.CachedDataSet;
```

---

## 方法列表

### close

关闭CacheDataSet

**方法签名：**
```java
public void close()
```

---

### getCacheId

获取cacheId

**方法签名：**
```java
public String getCacheId()
```

**返回值：**
- `String`: cacheId 缓存id

---

### getRowMeta

获取元素据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元素据 kd.bos.algo.RowMeta

---
