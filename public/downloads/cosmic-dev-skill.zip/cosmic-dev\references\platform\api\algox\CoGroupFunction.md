---
framework_version: "8.0.1"
api_class: "CoGroupFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分组协作函数时"
---

# CoGroupFunction API 说明

## 概述
分组协作函数。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：分组协作回调函数。

## Import 路径
```java
import kd.bos.algox.CoGroupFunction;
```

---

## 方法列表

### coGroup

分组协作回调函数

**方法签名：**
```java
public abstract void coGroup(Iterable<kd.RowX> iter1, Iterable<kd.RowX> iter2, Collector collector)
```

**参数说明：**
- `iter1`: `Iterable<kd.RowX>` — 左分组数据集，已经按照on中的字段分组好，且iter1和iter2中的分组key一致
- `iter2`: `Iterable<kd.RowX>` — 右分组数据集
- `collector`: `Collector` — collector

---
