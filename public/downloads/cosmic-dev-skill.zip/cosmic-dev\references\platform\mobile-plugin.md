---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "approved"
---

# 移动表单插件开发参考

> 覆盖：移动端表单插件（苍穹移动端 App）
> 注意：移动端插件与 PC 端大部分 API 通用，核心差异见下

## 基础结构

```java
package {isv}.{module}.formplugin;

import java.util.EventObject;
import kd.bos.bill.AbstractMobBillPlugIn;  // 移动端可复用 AbstractMobBillPlugIn
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

// 移动端表单插件通常也继承 AbstractMobBillPlugIn
// 差异在于：控件类型、事件行为、界面参数有所不同
public class XxxMobilePlugin extends AbstractMobBillPlugIn {
    private static final Log logger = LogFactory.getLog(XxxMobilePlugin.class);

    @Override
    public void afterBindData(EventObject e) {
        super.afterBindData(e);
        // 移动端界面初始化
    }
}
```

## PC vs 移动端主要差异

| 方面 | PC 端 | 移动端 |
|------|-------|-------|
| 页面打开方式 | `FormShowParamter` | `MobileFormShowParameter` |
| 控件标识 | 同设计器控件 key | 同，但移动端控件种类不同 |
| 界面刷新 | `updateView(fieldKey)` | 同 |
| 事件 | 完整事件生命周期 | 继承PC端事件，并额外增加移动端特有事件，如locate, uploadFile, afterMobilePageClose 等 |

## 打开移动端子页面

```java
import kd.bos.form.MobileFormShowParameter;
import kd.bos.form.openStyle.ShowType;

private void openMobileForm() {
    MobileFormShowParameter p = new MobileFormShowParameter();
    p.setFormId("mobile_form_id");
    p.setCaption("移动端子页面");
    p.getCustomParams().put("param1", "value1");
    getView().showForm(p);
}
```

## 移动端注意事项

1. 移动端不支持复杂弹窗控件（如 FilterGrid）
2. 移动端分录行操作 API 与 PC 相同
3. 移动端 `showMessage` 在 App 中显示为 Toast
4. 建议移动端插件逻辑尽量简单，复杂业务放操作插件（服务端）

> 完整移动端 API 参考：sync 后查阅 `references/platform/api/form/IMobileView.md`
