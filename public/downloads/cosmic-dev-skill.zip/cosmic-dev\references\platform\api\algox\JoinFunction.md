---
framework_version: "8.0.1"
api_class: "JoinFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用用于自定义join后返回的列时"
---

# JoinFunction API 说明

## 概述
用于自定义join后返回的列。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：处理join结果。

## Import 路径
```java
import kd.bos.algox.JoinFunction;
```

---

## 方法列表

### join

处理join结果

**方法签名：**
```java
public abstract RowX join(RowX row1, RowX row2)
```

**参数说明：**
- `row1`: `RowX` — 左边的row
- `row2`: `RowX` — 右边的row

**返回值：**
- `RowX`: RowX

---
