---
framework_version: "8.0.1"
api_class: "SimplePropertyAttribute"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用标注实体类的简单属性时"
---

# SimplePropertyAttribute API 说明

## 概述
标注实体类的简单属性，此属性参与ORM的处理。实现 Annotation。
主要功能：状态判断、界面显示。

## Import 路径
```java
import kd.bos.dataentity.entity.SimplePropertyAttribute;
```

---

## 方法列表

### alias

返回/设置字段名

**方法签名：**
```java
public String alias()
```

**返回值：**
- `String`

---

### autoSync

返回/设置AutoSync的枚举值

**方法签名：**
```java
public AutoSync autoSync()
```

**返回值：**
- `AutoSync`

---

### dbType

返回/设置对应的数据库类型

**方法签名：**
```java
public int dbType()
```

**返回值：**
- `int`

---

### displayName

返回/设置元数据的显示名称，例如列的中文名称

**方法签名：**
```java
public String displayName()
```

**返回值：**
- `String`

---

### isDbIgnore

是否关联数据库物理表，与数据库字段对应。false:关联，true：不关联

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---

### isEnableNull

返回/设置是否允许为空

**方法签名：**
```java
public boolean isEnableNull()
```

**返回值：**
- `boolean`

---

### isEncrypt

返回/设置字段是否需要加密

**方法签名：**
```java
public boolean isEncrypt()
```

**返回值：**
- `boolean`

---

### isPrimaryKey

返回/设置是否是主键

**方法签名：**
```java
public boolean isPrimaryKey()
```

**返回值：**
- `boolean`

---

### name

返回/设置屬性名称

**方法签名：**
```java
public String name()
```

**返回值：**
- `String`

---

### scale

返回/设置字段小数部分的长度

**方法签名：**
```java
public byte scale()
```

**返回值：**
- `byte`

---

### size

返回/设置字段的大小

**方法签名：**
```java
public int size()
```

**返回值：**
- `int`

---

### tableGroup

返回/设置此字段存储的扩展表后缀

**方法签名：**
```java
public String tableGroup()
```

**返回值：**
- `String`

---
