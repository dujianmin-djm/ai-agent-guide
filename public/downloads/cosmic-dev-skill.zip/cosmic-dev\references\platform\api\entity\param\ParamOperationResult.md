---
framework_version: "8.0.1"
api_class: "ParamOperationResult"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用系统参数操作返回结果的实体类时"
---

# ParamOperationResult API 说明

## 概述
系统参数操作返回结果的实体类。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.param.ParamOperationResult;
```

---

## 方法列表

### getMesseage

获取提示信息

**方法签名：**
```java
public String getMesseage()
```

**返回值：**
- `String`: 提示信息

---

### isSuccess

获取操作结果

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`: 操作结果

---

### setMesseage

设置提示信息

**方法签名：**
```java
public void setMesseage(String messeage)
```

**参数说明：**
- `messeage`: `String` — 提示信息

---

### setSuccess

设置操作结果

**方法签名：**
```java
public void setSuccess(boolean success)
```

**参数说明：**
- `success`: `boolean` — 操作结果

---
