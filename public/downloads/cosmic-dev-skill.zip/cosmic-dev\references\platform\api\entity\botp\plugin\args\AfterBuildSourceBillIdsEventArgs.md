---
framework_version: "8.0.1"
api_class: "AfterBuildSourceBillIdsEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用建立源单单据内码和分录内码之后, 触发此事件: 用于添加需要加载的源单单据与单据分录行时"
---

# AfterBuildSourceBillIdsEventArgs API 说明

## 概述
建立源单单据内码和分录内码之后, 触发此事件: 用于添加需要加载的源单单据与单据分录行。继承自 WriteBackEventArgs。
主要功能：读取属性、添加元素。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterBuildSourceBillIdsEventArgs;
```

---

## 方法列表

### addEntryInfo

增加分录信息

**方法签名：**
```java
public void addEntryInfo(AfterBuildSourceBillIdsEventArgs.EntryInfo e)
```

**参数说明：**
- `e`: `AfterBuildSourceBillIdsEventArgs.EntryInfo`

---

### getBillIds

获取单据id集合

**方法签名：**
```java
public Set<Long> getBillIds()
```

**返回值：**
- `Set<Long>`

---

### getEntryInfos

获取分录信息

**方法签名：**
```java
public List<kd.AfterBuildSourceBillIdsEventArgs.EntryInfo> getEntryInfos()
```

**返回值：**
- `List<kd.AfterBuildSourceBillIdsEventArgs.EntryInfo>`

---

### getRuleElements

获取转换规则

**方法签名：**
```java
public List<kd.WriteBackRuleElement> getRuleElements()
```

**返回值：**
- `List<kd.WriteBackRuleElement>`

---

### getSrcMainType

上游源单主实体，包含了完整字段

**方法签名：**
```java
public BillEntityType getSrcMainType()
```

**返回值：**
- `BillEntityType`

---
