---
framework_version: "8.0.1"
api_class: "InitVariableEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用初始化变量事件参数时"
---

# InitVariableEventArgs API 说明

## 概述
初始化变量事件参数。继承自 ConvertPluginEventArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.InitVariableEventArgs;
```

---

## 方法列表

### getConvertArgs

单据转换参数

**方法签名：**
```java
public AbstractConvertServiceArgs getConvertArgs()
```

**返回值：**
- `AbstractConvertServiceArgs`

---
