---
framework_version: "8.0.1"
api_class: "AbstractColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用列表字段格式化抽象类时"
---

# AbstractColumnDesc API 说明

## 概述
列表字段格式化抽象类。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.AbstractColumnDesc;
```

---

## 方法列表

### getColumnServiceName

获取列上对应的服务名

**方法签名：**
```java
public String getColumnServiceName()
```

**返回值：**
- `String`

---

### getDesensitizeValue

根据明文取脱敏取值

**方法签名：**
```java
public Object getDesensitizeValue(String localeid, DynamicObject dynamicObject, Object value)
```

**参数说明：**
- `localeid`: `String` — 多语言标识
- `dynamicObject`: `DynamicObject`
- `value`: `Object` — 明文值

**返回值：**
- `Object`: 脱敏值

---

### getFieldKey

获取对应字段Key

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### getFormaType

获取格式化类型，0：列表 1：轻分析 2：引出

**方法签名：**
```java
public int getFormaType()
```

**返回值：**
- `int`

---

### getFormatParams

获取格式化参数配置

**方法签名：**
```java
public Map<String,Object> getFormatParams()
```

**返回值：**
- `Map<String,Object>`

---

### getKey

获取需要格式化控件Key

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getMainOrgKey

获取主业务组织字段key

**方法签名：**
```java
public String getMainOrgKey()
```

**返回值：**
- `String`

---

### getUserFormatObject

获取用户格式化对象

**方法签名：**
```java
public FormatObject getUserFormatObject()
```

**返回值：**
- `FormatObject`

---

### getValue

根据字段取值

**方法签名：**
```java
public abstract Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject` — 数据来源

**返回值：**
- `Object`: 字段值

---

### setFormaType

设置格式化类型

**方法签名：**
```java
public void setFormaType(int formaType)
```

**参数说明：**
- `formaType`: `int`

---

### setKey

设置需要格式化控件Key

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String` — 格式化控件Key

---

### setListUserOption

设置列表用户选项

**方法签名：**
```java
public void setListUserOption(ListUserOption listUserOption)
```

**参数说明：**
- `listUserOption`: `ListUserOption`

---

### setMainOrgKey

设置主业务组织字段key

**方法签名：**
```java
public void setMainOrgKey(String mainOrgKey)
```

**参数说明：**
- `mainOrgKey`: `String`

---

### setUserFormat

设置用户格式化对象

**方法签名：**
```java
public void setUserFormat(FormatObject userFormatObject)
```

**参数说明：**
- `userFormatObject`: `FormatObject`

---
