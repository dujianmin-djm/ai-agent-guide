---
framework_version: "8.0.1"
api_class: "IReportListModel"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表数据模型接口时"
---

# IReportListModel API 说明

## 概述
报表数据模型接口。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.report.IReportListModel;
```

---

## 方法列表

### getColumns

获取列表列信息

**方法签名：**
```java
public List<kd.AbstractReportColumn> getColumns()
```

**返回值：**
- `List<kd.AbstractReportColumn>`

---

### getOtherQueryParam

获取关联查询参数

**方法签名：**
```java
public Object getOtherQueryParam()
```

**返回值：**
- `Object`

---

### getProgress

当前进度信息

**方法签名：**
```java
public int getProgress()
```

**返回值：**
- `int`

---

### getReportQueryParam

获取查询参数

**方法签名：**
```java
public ReportQueryParam getReportQueryParam()
```

**返回值：**
- `ReportQueryParam`

---

### getRowCount

记录总行数

**方法签名：**
```java
public int getRowCount()
```

**返回值：**
- `int`

---

### getRowData

获取行数据

**方法签名：**
```java
public DynamicObject getRowData(int rowIndex)
```

**参数说明：**
- `rowIndex`: `int` — 行索引

**返回值：**
- `DynamicObject`

---

### getValue

获取单元格的值

**方法签名：**
```java
public Object getValue(int rowIndex, String columnKey)
```

**参数说明：**
- `rowIndex`: `int` — 行索引
- `columnKey`: `String` — 报表列标识

**返回值：**
- `Object`

---
