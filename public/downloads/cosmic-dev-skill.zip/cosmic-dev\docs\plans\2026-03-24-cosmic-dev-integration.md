# cosmic-dev 技能包整合实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 cosmic-dev 技能包中三份重复 config 合并为一份 `skills/config.json`，废弃 `skill_env.json`/`setup.py`，改用 SKILL_DIR 路径推算，统一 Pre-flight Gate，更新技能路由规则。

**Architecture:** 所有 Python 脚本通过 `__file__` 推算路径，直接读写 `skills/config.json`（统一真源）；SKILL.md 文件中路径引用改为 SKILL_DIR 相对方式；Pre-flight Gate 分两层（轻量启动门 + 按需元数据门），均读同一 config；路由规则覆盖全部场景含 cosmic-gen 和需求文档歧义消解。

**Tech Stack:** Python 3.12+、JSON、Markdown

**工作目录（基准路径）：**
```
DEPLOY_DIR = c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-dev
SOURCE_DIR = c:\Users\HP\workspace\cosmic\cosmic-dev
```

> 所有变更在 DEPLOY_DIR 中执行，完成后同步到 SOURCE_DIR 并提交 git。

**设计文档：** `cosmic-dev/docs/specs/2026-03-24-cosmic-dev-integration-design.md`

---

## 文件变更地图

| 文件（相对 DEPLOY_DIR） | 操作 |
|------------------------|------|
| `skills/config.json` | 修改：合并三份 config |
| `skills/config.example.json` | 修改：与新结构对齐 |
| `skills/cosmic-meta-api/scripts/cosmic_api.py` | 修改：路径常量 + config 读写 + 删除废弃函数 |
| `skills/cosmic-meta-api/scripts/artifact_manager.py` | 修改：删除 `_resolve_artifacts_dir()`，改为常量 |
| `skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py` | 修改：config 路径 + load_config 逻辑 |
| `skills/cosmic-meta-api/scripts/pdm-automation/pdm_client.py` | 修改：删除双 config 机制，新增 `resolve_credentials()` |
| `skills/cosmic-meta-api/SKILL.md` | 修改：资源表 + 目录结构 |
| `skills/cosmic-meta-api/modules/init/SKILL.md` | 修改：SKILL_DIR 路径 + 字段名 + _initialized 位置 |
| `skills/cosmic-meta-api/modules/usage/SKILL.md` | 修改：移除 skill_env 字段说明 |
| `skills/cosmic-meta-api/modules/reset/SKILL.md` | 修改：_initialized 说明 |
| `skills/cosmic-meta-modeling/SKILL.md` | 修改：Step 0 路径引用 |
| `skills/cosmic-meta-modifier/SKILL.md` | 修改：Step 0 路径引用 |
| `SKILL.md`（根，cosmic-dev 入口） | 修改：启动门 + config 字段说明 |
| `.cursor/rules/cosmic-skill-routing.md` | 重写：全量更新 |
| `skills/cosmic-meta-api/scripts/config.json` | 删除 |
| `skills/cosmic-meta-api/scripts/pdm-automation/config.json` | 删除 |
| `skills/cosmic-meta-api/skill_env.json` | 删除 |
| `skills/cosmic-meta-api/setup.py` | 删除 |

---

## Task 1：合并 Config 文件

**Files:**
- Modify: `skills/config.json`
- Modify: `skills/config.example.json`

- [ ] **Step 1.1：读取当前 `skills/config.json` 内容**

读取 `DEPLOY_DIR/skills/config.json`，记录现有字段。

- [ ] **Step 1.2：读取 `skills/cosmic-meta-api/scripts/config.json`**

读取，记录待合并字段：`base_url`、`tenant_id`、`account_id`、`app_id`、`app_secret`、`login_user`、`isv`、`app_number`、`bizCloudName`。

- [ ] **Step 1.3：读取 `skills/cosmic-meta-api/scripts/pdm-automation/config.json`**

读取，记录待合并字段：`datamodel.*`。

- [ ] **Step 1.4：写入合并后的 `skills/config.json`**

结构如下（`_initialized` 从 skill_env.json 迁移，其余字段用用户当前实际值填充）：

```json
{
  "_initialized": false,
  "_comment": "统一配置文件。_initialized 由初始化向导自动管理，请勿手动修改。",
  "architecture": "plugin",
  "isv": "<保留原 cosmic-dev config 的 isv 值>",
  "javaHome": "<保留原值>",
  "buildTool": "gradle",
  "enableCompile": false,
  "mavenHome": "<保留原值>",
  "maven": {
    "settingsPath": "<保留原值>"
  },
  "server": {
    "baseUrl": "<来自 cosmic-meta-api config 的 base_url>",
    "tenantId": "<来自 tenant_id，默认 ierp>",
    "user": "<来自 login_user>",
    "appId": "<来自 app_id>",
    "appSecret": "<来自 app_secret>",
    "accountId": "<来自 account_id>",
    "appNumber": "<来自 app_number>",
    "bizCloudName": "<来自 bizCloudName>"
  },
  "pdm": {
    "baseUrl": "<来自 datamodel.baseUrl>",
    "user": "<来自 datamodel.user>",
    "appId": "<来自 datamodel.appId>",
    "appSecret": "<来自 datamodel.appSecret>",
    "accountId": "<来自 datamodel.accountId>",
    "outputDir": "<来自 datamodel.output，默认 datamodel>"
  }
}
```

> 注意：若两份 config 中 `isv` 值相同，只保留一份；`server.*` 字段凭据从 cosmic-meta-api config 迁移（那里有实际值）。

- [ ] **Step 1.5：更新 `skills/config.example.json`**

与新 config 结构完全一致，所有值改为占位说明：

```json
{
  "_initialized": false,
  "_comment": "统一配置文件。_initialized 由初始化向导自动管理，请勿手动修改。",
  "architecture": "plugin",
  "isv": "ISV开发商标识（如 uhyl），标准产品开发留空",
  "javaHome": "JDK 安装路径（如 C:/jdk17）",
  "buildTool": "gradle",
  "enableCompile": false,
  "mavenHome": "Maven 安装路径（isv 为空时编译使用）",
  "maven": {
    "settingsPath": "Maven settings.xml 路径"
  },
  "server": {
    "baseUrl": "苍穹服务地址（如 http://127.0.0.1:8080）",
    "tenantId": "租户ID（默认 ierp）",
    "user": "登录手机号",
    "appId": "OpenAPI 应用 ID",
    "appSecret": "OpenAPI 应用密钥",
    "accountId": "数据中心 ID",
    "appNumber": "苍穹应用编码（由 setConfig 自动写入）",
    "bizCloudName": "业务云名称（由 setConfig 自动写入）"
  },
  "pdm": {
    "baseUrl": "PDM 工具服务地址（可与 server.baseUrl 相同）",
    "user": "PDM 登录用户名",
    "appId": "PDM OpenAPI 应用 ID",
    "appSecret": "PDM OpenAPI 应用密钥",
    "accountId": "PDM 数据中心 ID",
    "outputDir": "datamodel"
  }
}
```

- [ ] **Step 1.6：提交**

```bash
git add skills/config.json skills/config.example.json
git commit -m "feat: 合并三份 config 为统一 skills/config.json"
```

---

## Task 2：重写 `cosmic_api.py` — 路径常量与 Config 读写

**Files:**
- Modify: `skills/cosmic-meta-api/scripts/cosmic_api.py`

- [ ] **Step 2.1：替换路径常量块（第 53–69 行）**

将当前：
```python
SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT   = os.path.dirname(SCRIPT_DIR)
RUNTIME_DIR  = os.path.join(SKILL_ROOT, "runtime")
CONFIG_FILE  = os.path.join(SCRIPT_DIR, "config.json")
TOKEN_CACHE  = os.path.join(RUNTIME_DIR, ".token_cache.json")
BIZ_CACHE    = os.path.join(RUNTIME_DIR, "biz_cache.json")
CONTEXT_MD   = os.path.join(RUNTIME_DIR, "context.md")
CONFIG_MD    = os.path.join(RUNTIME_DIR, "config.md")
ARTIFACTS_DIR = os.path.join(RUNTIME_DIR, "artifacts")
BATCH_MANIFESTS_DIR = os.path.join(RUNTIME_DIR, "batch_manifests")
PDM_CONFIG_FILE = os.path.join(SCRIPT_DIR, "pdm-automation", "config.json")
SKILL_ENV_FILE  = os.path.join(SKILL_ROOT, "skill_env.json")
```

替换为：
```python
from pathlib import Path

SCRIPT_DIR          = Path(__file__).parent
SKILL_ROOT          = SCRIPT_DIR.parent                          # cosmic-meta-api/
CONFIG_PATH         = SCRIPT_DIR.parent.parent / "config.json"  # skills/config.json
RUNTIME_DIR         = SKILL_ROOT / "runtime"
TOKEN_CACHE         = RUNTIME_DIR / ".token_cache.json"
BIZ_CACHE           = RUNTIME_DIR / "biz_cache.json"
CONTEXT_MD          = RUNTIME_DIR / "context.md"
CONFIG_MD           = RUNTIME_DIR / "config.md"
ARTIFACTS_DIR       = RUNTIME_DIR / "artifacts"
BATCH_MANIFESTS_DIR = RUNTIME_DIR / "batch_manifests"

# 兼容 os.path 调用（历史代码使用 os.path.join 的地方不受影响）
SCRIPT_DIR   = str(SCRIPT_DIR)
SKILL_ROOT   = str(SKILL_ROOT)
RUNTIME_DIR  = str(RUNTIME_DIR)
TOKEN_CACHE  = str(TOKEN_CACHE)
BIZ_CACHE    = str(BIZ_CACHE)
CONTEXT_MD   = str(CONTEXT_MD)
CONFIG_MD    = str(CONFIG_MD)
ARTIFACTS_DIR      = str(ARTIFACTS_DIR)
BATCH_MANIFESTS_DIR = str(BATCH_MANIFESTS_DIR)
```

> 注：`CONFIG_PATH` 保持 `Path` 对象供后续 open() 使用；SCRIPT_DIR 等转 str 保持历史兼容。删除 `PDM_CONFIG_FILE`、`SKILL_ENV_FILE`、`TEMP_ARTIFACT` 行（TEMP_ARTIFACT 若在 run 命令用到，改为 `os.path.join(SCRIPT_DIR, "artifact.json")`）。

- [ ] **Step 2.2：更新 `load_config()` 函数**

将：
```python
def load_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)
```

改为：
```python
def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg_raw = json.load(f)
    # 将新嵌套结构映射为脚本内部变量名（保持内部逻辑不变）
    server = cfg_raw.get("server", {})
    cfg = {
        "base_url":     server.get("baseUrl", ""),
        "tenant_id":    server.get("tenantId", "ierp"),
        "account_id":   server.get("accountId", ""),
        "app_id":       server.get("appId", ""),
        "app_secret":   server.get("appSecret", ""),
        "login_user":   server.get("user", ""),
        "isv":          cfg_raw.get("isv", ""),
        "app_number":   server.get("appNumber", ""),
        "bizCloudName": server.get("bizCloudName", ""),
        # 硬编码，不再从文件读取
        "api_base_path": "/ierp/kapi/v2/devportal/ai-meta",
        "user_type":     "Mobile",
        "language":      "zh_CN",
        # 透传原始结构供写回时使用
        "_raw": cfg_raw,
    }
    return cfg
```

- [ ] **Step 2.3：更新 `_api_url()` 函数**

删除对 `api_base_path` 空值的检查（现为硬编码，不会为空），简化为：
```python
def _api_url(cfg, endpoint):
    api_base = cfg.get("api_base_path", "").rstrip("/")
    return f"{cfg['base_url']}{api_base}/{endpoint}"
```

- [ ] **Step 2.4：重写 `_update_config_json()` 函数**

原函数写平铺字段到 `scripts/config.json`，改为写嵌套字段到 `skills/config.json`：

```python
def _update_config_json(updates: dict):
    """将 updates 中的字段合并写入 skills/config.json（嵌套 server.* 结构）。
    updates 的 key 使用旧内部名（如 base_url、login_user），自动映射到新结构。
    """
    _OLD_TO_NEW = {
        "base_url":     ("server", "baseUrl"),
        "tenant_id":    ("server", "tenantId"),
        "account_id":   ("server", "accountId"),
        "app_id":       ("server", "appId"),
        "app_secret":   ("server", "appSecret"),
        "login_user":   ("server", "user"),
        "app_number":   ("server", "appNumber"),
        "bizCloudName": ("server", "bizCloudName"),
        "isv":          (None,    "isv"),           # 顶层字段
    }
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg_raw = json.load(f)
    for old_key, value in updates.items():
        if value is None:
            continue
        if old_key in _OLD_TO_NEW:
            section, new_key = _OLD_TO_NEW[old_key]
            if section:
                cfg_raw.setdefault(section, {})[new_key] = value
            else:
                cfg_raw[new_key] = value
        else:
            cfg_raw[old_key] = value   # 未映射字段直接写顶层
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg_raw, f, ensure_ascii=False, indent=2)
    updated = ", ".join(f"{k}={repr(v)}" for k, v in updates.items() if v is not None)
    print(f"[config] 已更新: {updated}", flush=True)
```

- [ ] **Step 2.5：重写 `_set_initialized()` 函数**

原读写 `skill_env.json`，改为读写 `skills/config.json`：

```python
def _set_initialized(value: bool):
    """将 _initialized 写入 skills/config.json。"""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg_raw = json.load(f)
        cfg_raw["_initialized"] = value
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg_raw, f, ensure_ascii=False, indent=2)
        print(f"[config] _initialized = {value}", flush=True)
        return True
    except Exception as e:
        print(f"[config] 写入 _initialized 失败: {e}", flush=True)
        return False
```

- [ ] **Step 2.6：重写 `_clear_main_config_credentials()` 函数**

原清空平铺字段，改为清空嵌套 `server.*`：

```python
def _clear_main_config_credentials():
    """清空 skills/config.json 中的鉴权凭据字段（保留 isv/appNumber/bizCloudName）。"""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg_raw = json.load(f)
    server = cfg_raw.setdefault("server", {})
    CLEAR_FIELDS = ["baseUrl", "tenantId", "user", "appId", "appSecret", "accountId"]
    for field in CLEAR_FIELDS:
        server[field] = ""
    server["tenantId"] = "ierp"   # 默认值保留
    cfg_raw["_initialized"] = False
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg_raw, f, ensure_ascii=False, indent=2)
    print("[config] 凭据字段已清空", flush=True)
```

- [ ] **Step 2.7：重写 `_clear_pdm_config_credentials()` 函数**

原清空 `pdm-automation/config.json`，改为清空 `skills/config.json` 中的 `pdm.*`：

```python
def _clear_pdm_config_credentials():
    """清空 skills/config.json 中的 pdm.* 凭据字段（保留 outputDir）。"""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg_raw = json.load(f)
    pdm = cfg_raw.setdefault("pdm", {})
    for field in ["baseUrl", "user", "appId", "appSecret", "accountId"]:
        pdm[field] = ""
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg_raw, f, ensure_ascii=False, indent=2)
    print("[config] pdm 凭据字段已清空", flush=True)
```

- [ ] **Step 2.8：删除 `_regenerate_skill_env_json()` 函数及相关 CLI 参数**

找到并删除：
- `_regenerate_skill_env_json()` 函数定义
- `resetEnv` 子解析器中的 `--regenerate-skill-env` 参数定义
- `resetEnv` 命令处理中对应的 `elif getattr(args, "regenerate_skill_env", False):` 分支
- `resetEnv` 的 docstring 中对应的用法说明行

- [ ] **Step 2.9：更新 `_write_pdm_config()` 函数（原 `setPdmConfig` 写入逻辑）**

原函数写两个文件，改为只写 `skills/config.json`：

```python
def _write_pdm_config(base_url: str, user: str, app_id: str,
                      app_secret: str, account_id: str, output: str = "datamodel"):
    """将 PDM 连接配置写入 skills/config.json 的 pdm.* 节。"""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg_raw = json.load(f)
    pdm = cfg_raw.setdefault("pdm", {})
    if base_url:   pdm["baseUrl"]   = base_url
    if user:       pdm["user"]      = user
    if app_id:     pdm["appId"]     = app_id
    if app_secret: pdm["appSecret"] = app_secret
    if account_id: pdm["accountId"] = account_id
    if output:     pdm["outputDir"] = output
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg_raw, f, ensure_ascii=False, indent=2)
    print("[config] pdm.* 已更新", flush=True)
```

- [ ] **Step 2.10：提交**

```bash
git add skills/cosmic-meta-api/scripts/cosmic_api.py
git commit -m "feat: cosmic_api.py 迁移到统一 config，废弃 skill_env.json"
```

---

## Task 3：修改 `artifact_manager.py`

**Files:**
- Modify: `skills/cosmic-meta-api/scripts/artifact_manager.py`

- [ ] **Step 3.1：替换路径推算逻辑**

找到现有的 `_resolve_artifacts_dir()` 函数及其调用处，整体替换为：

```python
from pathlib import Path

SCRIPT_DIR      = Path(__file__).parent
ARTIFACTS_DIR   = str(SCRIPT_DIR.parent / "runtime" / "artifacts")
os.makedirs(ARTIFACTS_DIR, exist_ok=True)
```

删除：
- `_resolve_artifacts_dir()` 函数定义
- `ARTIFACTS_DIR = _resolve_artifacts_dir()` 这行调用

保留：`ARTIFACT_PREFIX`、`ARTIFACT_SUFFIX`、`HASH_LEN` 等常量不变。

- [ ] **Step 3.2：验证其余逻辑不依赖 skill_env.json**

快速扫描文件，确认除 `_resolve_artifacts_dir()` 外，无其他对 `skill_env.json` 的读取。

- [ ] **Step 3.3：提交**

```bash
git add skills/cosmic-meta-api/scripts/artifact_manager.py
git commit -m "feat: artifact_manager.py 改用 __file__ 推算路径，删除 skill_env.json 依赖"
```

---

## Task 4：重写 `pdm_client.py`

**Files:**
- Modify: `skills/cosmic-meta-api/scripts/pdm-automation/pdm_client.py`

- [ ] **Step 4.1：读取当前 `pdm_client.py` 全文**

找到以下函数，理解其逻辑：
- `cosmic_config_to_pdm_credentials()`：从旧 `scripts/config.json` 读平铺字段
- `datamodel_block_to_pdm_credentials()`：从 `pdm-automation/config.json` 的 `datamodel` 块读

- [ ] **Step 4.2：添加新的 `resolve_credentials()` 函数**

在文件顶部路径常量区，将 config 路径常量改为：

```python
from pathlib import Path
CONFIG_PATH = Path(__file__).parent.parent.parent.parent / "config.json"  # skills/config.json
```

新增统一凭据解析函数：

```python
def resolve_credentials(cfg_raw: dict, env: str) -> dict:
    """从统一 config 的 server.* 或 pdm.* 节解析凭据。
    
    Args:
        cfg_raw: skills/config.json 完整内容
        env: "server"（苍穹元数据环境）或 "datamodel"（PDM 工具环境）
    """
    if env == "server":
        s = cfg_raw.get("server", {})
        return {
            "baseUrl":   s.get("baseUrl", ""),
            "user":      s.get("user", ""),
            "appId":     s.get("appId", ""),
            "appSecret": s.get("appSecret", ""),
            "accountId": s.get("accountId", ""),
        }
    elif env == "datamodel":
        p = cfg_raw.get("pdm", {})
        return {
            "baseUrl":   p.get("baseUrl", ""),
            "user":      p.get("user", ""),
            "appId":     p.get("appId", ""),
            "appSecret": p.get("appSecret", ""),
            "accountId": p.get("accountId", ""),
            "outputDir": p.get("outputDir", "datamodel"),
        }
    else:
        raise ValueError(f"未知 env 类型: {env}，应为 'server' 或 'datamodel'")
```

- [ ] **Step 4.3：更新 `PDMClient` 的初始化和凭据使用**

找到 `PDMClient.__init__` 或调用 `cosmic_config_to_pdm_credentials` / `datamodel_block_to_pdm_credentials` 的地方，改为：

```python
import json
cfg_raw = json.load(open(CONFIG_PATH, encoding="utf-8"))
server_creds = resolve_credentials(cfg_raw, "server")
pdm_creds    = resolve_credentials(cfg_raw, "datamodel")
```

- [ ] **Step 4.4：删除废弃函数**

删除：
- `cosmic_config_to_pdm_credentials()` 函数
- `datamodel_block_to_pdm_credentials()` 函数
- 原来指向 `_cosmicConfig` 间接路径的引用代码

- [ ] **Step 4.5：提交**

```bash
git add skills/cosmic-meta-api/scripts/pdm-automation/pdm_client.py
git commit -m "feat: pdm_client.py 重写凭据解析，统一读 skills/config.json"
```

---

## Task 5：重写 `pdm_auto.py`

**Files:**
- Modify: `skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py`

- [ ] **Step 5.1：更新 config 默认路径（约第 23、274 行）**

找到 `config_path` 默认值（通常在 `argparse` 的 `--config` 参数或 `load_config` 调用处），将：

```python
default_config = os.path.join(script_dir, 'config.json')
# 或类似：
parser.add_argument('--config', default='config.json', ...)
```

改为：

```python
from pathlib import Path
DEFAULT_CONFIG = str(Path(__file__).parent.parent.parent.parent / "config.json")  # skills/config.json
# ...
parser.add_argument('--config', default=DEFAULT_CONFIG, ...)
```

- [ ] **Step 5.2：更新 `load_config()` / `resolve_output_dir()`**

`load_config()` 现在加载的是 `skills/config.json`（结构已变），需要从 `pdm.*` 节取 `outputDir`：

```python
def resolve_output_dir(config_path, config_data):
    """从 pdm.outputDir 解析输出目录（相对路径以 config 文件位置为基准）。"""
    pdm = config_data.get("pdm", {})
    output = pdm.get("outputDir", "datamodel")
    if os.path.isabs(output):
        return output
    # 相对路径以 config 文件目录（skills/）为基准
    return os.path.join(os.path.dirname(config_path), output)
```

- [ ] **Step 5.3：更新 PDMClient 的凭据传入方式**

`pdm_auto.py` 调用 `PDMClient` 时，传入凭据从新结构读取（借助 `pdm_client.resolve_credentials`）：

```python
from pdm_client import PDMClient, resolve_credentials
import json

cfg_raw = json.load(open(config_path, encoding="utf-8"))
server_creds = resolve_credentials(cfg_raw, "server")
pdm_creds    = resolve_credentials(cfg_raw, "datamodel")

client = PDMClient(server_creds=server_creds, pdm_creds=pdm_creds, ...)
```

- [ ] **Step 5.4：更新 docstring 中的用法说明**

将文件顶部 docstring 的 `--config config.json` 示例改为实际默认路径说明：

```
用法:
    python pdm_auto.py <entityNumber>
    python pdm_auto.py <entityNumber> --config /path/to/config.json  # 默认读 skills/config.json
```

- [ ] **Step 5.5：提交**

```bash
git add skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py
git commit -m "feat: pdm_auto.py 迁移到统一 config，更新凭据读取方式"
```

---

## Task 6：更新 `cosmic-meta-api` 的 SKILL.md 文件

**Files:**
- Modify: `skills/cosmic-meta-api/SKILL.md`
- Modify: `skills/cosmic-meta-api/modules/init/SKILL.md`
- Modify: `skills/cosmic-meta-api/modules/usage/SKILL.md`
- Modify: `skills/cosmic-meta-api/modules/reset/SKILL.md`

- [ ] **Step 6.1：更新 `skills/cosmic-meta-api/SKILL.md` 共用资源表**

将「共用资源」表中的相关行改为：

```markdown
| API 凭据配置 | `../config.json`（即 `skills/config.json`） | 唯一真源，`server.*` 节 |
| 核心脚本 | `scripts/cosmic_api.py` | 所有子命令入口 |
| 路径推算 | SKILL_DIR 相对方式（无需 skill_env.json） | |
| 运行时状态 | `runtime/` | context.md / biz_cache.json / token / artifacts |
```

目录结构图中删除 `skill_env.json` 和 `setup.py` 的条目，`scripts/` 下只保留：
```
├── scripts/
│   ├── cosmic_api.py
│   ├── artifact_manager.py
│   ├── ops_manager.py
│   ├── lookup_basedata.py
│   └── pdm-automation/
```

在文件开头或说明中加入路径推算注释：
```markdown
> **路径推算**：SKILL_DIR = 本文件所在目录。CONFIG = `SKILL_DIR/../config.json`（= skills/config.json）。
> python 命令按 OS：Windows 用 `python`，Linux/macOS 用 `python3`。
```

- [ ] **Step 6.2：更新 `modules/init/SKILL.md`（Pre-flight Gate）**

此文件在 `modules/init/` 下，其 SKILL_DIR 到 `skills/config.json` 需 3 级：`SKILL_DIR/../../../config.json`。

关键修改点：

1. 文件开头加路径注释：
```markdown
> **路径推算**：SKILL_DIR = 本文件所在目录（`cosmic-meta-api/modules/init/`）。
> CONFIG = `SKILL_DIR/../../../config.json`（= skills/config.json）。
> cosmic_api = `SKILL_DIR/../../scripts/cosmic_api.py`。
```

2. G1 检查逻辑改为读 `server.*` 字段，并新增第三分支：
```
Step G1：检查 server.appId / appSecret / accountId / user 是否全部非空
  → 全部非空 且 _initialized=true  → 静默通过
  → 有空字段 且 _initialized=false → 进入引导（G2~G6）
  → 有空字段 且 _initialized=true  → 警告"config.json server.* 存在空值"，提示 RST ENV 或手动补填，停止
```

3. G2 引导填写字段说明改为新字段名（`server.baseUrl`、`server.tenantId` 等）

4. G6 写入 `_initialized=true` 的命令保持不变（`cosmic_api.py setInitialized --value true`），但说明改为"写入 skills/config.json"

5. 所有脚本路径引用改为从 SKILL_DIR 相对推算，删除 `skill_env.json` 字段引用

- [ ] **Step 6.3：更新 `modules/usage/SKILL.md`**

删除「skill_env.json 字段说明」表格（`python`、`cosmic_api`、`artifact_manager`、`artifacts_dir` 等字段描述）。

改为：
```markdown
## 读取路径（每次开始时执行）

> 从 SKILL.md 所在路径推算：
> - SKILL_DIR = 本文件所在目录（`cosmic-meta-api/modules/usage/`）
> - CONFIG = `SKILL_DIR/../../../config.json`（= skills/config.json）
> - cosmic_api = `SKILL_DIR/../../scripts/cosmic_api.py`
> - python：Windows 用 `python`，Linux/macOS 用 `python3`
```

- [ ] **Step 6.4：更新 `modules/reset/SKILL.md`**

步骤 A 表格中，将 `runtime/artifacts/` 和 `runtime/batch_manifests/` 保持不变（路径正确），但说明中"本步不含：`scripts/config.json`"改为"本步不含：`skills/config.json` 中的 server/pdm 凭据字段"。

步骤 B 中：
- 将 "`scripts/config.json`" 改为 "`skills/config.json`"（描述的字段名改为 `server.baseUrl`、`server.tenantId` 等）
- 将 "`scripts/pdm-automation/config.json`：datamodel 内..." 改为 "`skills/config.json` 的 `pdm.*` 节"
- `resetEnv --credentials clear` 的说明：清空主 config 的 `server.*` 凭据（保留 `appNumber`/`bizCloudName`/`isv`），并清空 `pdm.*` 凭据

- [ ] **Step 6.5：提交**

```bash
git add skills/cosmic-meta-api/SKILL.md skills/cosmic-meta-api/modules/
git commit -m "docs: cosmic-meta-api SKILL.md 迁移到 SKILL_DIR 路径模式，移除 skill_env.json 引用"
```

---

## Task 7：更新 `cosmic-meta-modeling` 和 `cosmic-meta-modifier` 的 SKILL.md

**Files:**
- Modify: `skills/cosmic-meta-modeling/SKILL.md`
- Modify: `skills/cosmic-meta-modifier/SKILL.md`

- [ ] **Step 7.1：更新 `cosmic-meta-modeling/SKILL.md` 的 Step 0**

找到 Step 0（Pre-flight Gate 引用）：

```markdown
## Step 0：Pre-flight Gate（必须最先执行）

> 完整逻辑见 `../cosmic-meta-api/modules/init/SKILL.md`；本技能**不复制该逻辑，仅引用**。
>
> Gate 完成后，从 `../cosmic-meta-api/skill_env.json` 读取路径字段...
```

改为：

```markdown
## Step 0：Pre-flight Gate（必须最先执行）

> 完整逻辑见 `../cosmic-meta-api/modules/init/SKILL.md`；本技能**不复制该逻辑，仅引用**。
>
> Gate 完成后，路径推算方式：
> - SKILL_DIR = 本文件所在目录（`cosmic-meta-modeling/`）
> - CONFIG = `SKILL_DIR/../config.json`（= skills/config.json）
> - cosmic_api = `SKILL_DIR/../cosmic-meta-api/scripts/cosmic_api.py`
> - artifact_manager = `SKILL_DIR/../cosmic-meta-api/scripts/artifact_manager.py`
> - artifacts_dir = `SKILL_DIR/../cosmic-meta-api/runtime/artifacts/`
> - python：Windows 用 `python`，Linux/macOS 用 `python3`
> **禁止硬编码任何绝对路径。**
```

- [ ] **Step 7.2：更新 `cosmic-meta-modifier/SKILL.md` 的 Step 0**

同上，找到 Step 0 中引用 `skill_env.json` 的部分，改为 SKILL_DIR 相对路径推算：

```markdown
> Gate 完成后，路径推算方式：
> - SKILL_DIR = 本文件所在目录（`cosmic-meta-modifier/`）
> - CONFIG = `SKILL_DIR/../config.json`（= skills/config.json）
> - cosmic_api = `SKILL_DIR/../cosmic-meta-api/scripts/cosmic_api.py`
> - python：Windows 用 `python`，Linux/macOS 用 `python3`
```

- [ ] **Step 7.3：提交**

```bash
git add skills/cosmic-meta-modeling/SKILL.md skills/cosmic-meta-modifier/SKILL.md
git commit -m "docs: modeling/modifier SKILL.md Step 0 改为 SKILL_DIR 路径推算"
```

---

## Task 8：更新根 `SKILL.md`（cosmic-dev 入口）

**Files:**
- Modify: `SKILL.md`（DEPLOY_DIR 根目录）

- [ ] **Step 8.1：更新启动门逻辑**

找到当前配置检查部分（"若 config.json 不存在或缺少必填项（`javaHome`、`server.baseUrl`）"），改为：

```markdown
**本技能被激活时，执行轻量启动门：**

检查 `SKILL_DIR/skills/config.json` 是否存在：
- 不存在 → 提示复制 `SKILL_DIR/skills/config.example.json` 并填写必填项（`javaHome`、`server.baseUrl`），停止执行
- 存在 → 读取配置，静默通过

> 字段完整性校验由子技能按需触发（元数据操作触发 Pre-flight Gate，代码生成仅需 `javaHome`）。
```

- [ ] **Step 8.2：更新全局配置字段说明表**

将 `config.json` 字段说明表更新为新结构：

```markdown
| 配置项 | 必填 | 说明 |
|--------|------|------|
| `architecture` | 否 | `plugin`（默认）或 `frontend` |
| `isv` | 否 | 开发商标识，为空 = 标准产品（Maven），非空 = ISV（Gradle）；同时作为 API 路径前缀 |
| `javaHome` | 是 | JDK 路径 |
| `enableCompile` | 否 | 编译验证开关，默认关闭 |
| `server.baseUrl` | 是（元数据操作） | 苍穹服务地址 |
| `server.appId/appSecret/accountId/user` | 是（元数据操作） | OpenAPI 凭据 |
| `server.tenantId` | 否 | 租户 ID，默认 `ierp` |
| `server.appNumber/bizCloudName` | 否 | 由初始化向导自动写入 |
| `pdm.*` | 否 | PDM 工具专用连接，可与 server 不同 |
```

- [ ] **Step 8.3：配置文件路径引用更新**

将文档中所有 `SKILL_DIR/skills/config.json` 的引用方式与实际路径核对，确保用相对于 SKILL_DIR 的方式描述。

- [ ] **Step 8.4：提交**

```bash
git add SKILL.md
git commit -m "docs: cosmic-dev 根 SKILL.md 更新启动门和 config 字段说明"
```

---

## Task 9：重写技能路由规则

**Files:**
- Modify: `c:\Users\HP\workspace\cosmic\.cursor\rules\cosmic-skill-routing.md`

- [ ] **Step 9.1：重写路由规则文件**

完整替换为以下内容：

```markdown
---
description: 苍穹二开技能路由决策规则
alwaysApply: true
---

# 苍穹技能路由规则

收到用户指令时，**先判断场景，再决定读哪个 SKILL.md，读后按其步骤执行**。

## 决策树

```
用户说的是...
│
├─ 上传需求文档 / 直接描述需求（未明确场景）
│   ├─ 含 "建单据" / "建表单" / "创建元数据" / "建模" / "基础资料" / "主数据"
│   │   → 读取 cosmic-dev/skills/cosmic-meta-modeling/SKILL.md
│   │
│   ├─ 含 "插件" / "业务逻辑" / "联动" / "校验" / "提交" / "代码"
│   │   → 读取 cosmic-dev/SKILL.md（进入 cosmic-gen 流程）
│   │
│   └─ 无法判断
│       → 询问：「您是要建元数据（新建单据结构），还是开发插件逻辑（生成 Java 代码）？」
│
├─ "写插件" / "新建插件" / "开发业务逻辑" / "生成代码" / "生成插件"
│   → 读取 cosmic-dev/SKILL.md
│
├─ "建单据" / "需求建模" / "创建元数据" / "一键建模" / "建基础资料" / "主数据建模"
│   → 读取 cosmic-dev/skills/cosmic-meta-modeling/SKILL.md
│
├─ "改单据" / "加字段" / "删字段" / "改必填" / "改类型" / "改字段名" / "修改元数据"
│   → 读取 cosmic-dev/skills/cosmic-meta-modifier/SKILL.md
│   ⚠️ 禁止：用 buildMeta 代替 modifyMeta（会产生新 formId，破坏已有元数据）
│
├─ "生成PDM" / "同步数据模型" / "生成建表脚本" / "PDM同步"
│   → 从 runtime/context.md 获取 entityKey → 执行 pdm_auto.py
│   ⚠️ 也会在 buildMeta / modifyMeta 成功后自动询问是否生成 PDM
│
├─ "重置环境" / "RST ENV" / "rst env"（大小写不敏感）
│   → 读取 cosmic-dev/skills/cosmic-meta-api/modules/reset/SKILL.md
│   ⚠️ 必须两步确认后才执行 resetEnv --yes-cache；禁止未确认就执行
│
├─ "跑测试" / "验证元数据" / "测试建模" / "设计测试用例" / "查看测试结果"
│   → 读取 cosmic-meta-test/SKILL.md
│
└─ 其余场景 → 由 cosmic-dev/SKILL.md 的入口判断处理
```

## 高频混淆场景

| 用户说 | ❌ 错误做法 | ✅ 正确做法 |
|--------|-----------|-----------|
| "表头加个备注字段" | 修改 Artifact → buildMeta 重建 | `cosmic-meta-modifier` → `modifyMeta` |
| "把供应商改成必填" | 修改 Artifact → buildMeta 重建 | `cosmic-meta-modifier` → `modifyMeta` |
| "本轮刚 buildMeta，再加个字段" | 只改 artifact 或再跑 buildMeta | 读 `cosmic-meta-modifier/SKILL.md` → `modifyMeta` |
| 上传需求文档，说"帮我建" | — | 先判断意图：建元数据还是写插件，再路由 |
| "生成 PDM 脚本" | — | 从 context.md 获取 entityKey → pdm_auto.py |

## 上下文门控（强制）

满足任一条件时，"加/删/改字段"类需求必须走 `cosmic-meta-modifier`：
1. 本轮已成功执行过 buildMeta/run
2. 用户或 context.md 中出现明确 formId
3. 用户用语指向已有表单（"采购订单上加个字段"）

## 技能执行原则

一旦选定技能，**第一动作必须是：读取该技能的 SKILL.md**，再按步骤执行。不得凭记忆跳过读取。

| 原则 | 说明 |
|------|------|
| **先读再做** | 先 Read(技能/SKILL.md)，再按 Step 执行 |
| **不替技能造轮子** | 技能已定义的流程，按现有 API/工具完成，不另写脚本替代 |
| **例外允许** | 技能未覆盖、技能内明确允许、用户明确要求时，可偏离 |
```

- [ ] **Step 9.2：提交**

```bash
git add .cursor/rules/cosmic-skill-routing.md
git commit -m "feat: 重写技能路由规则，覆盖 cosmic-gen 和需求文档歧义消解"
```

---

## Task 10：删除废弃文件

**Files:**
- Delete: `skills/cosmic-meta-api/scripts/config.json`
- Delete: `skills/cosmic-meta-api/scripts/pdm-automation/config.json`
- Delete: `skills/cosmic-meta-api/skill_env.json`
- Delete: `skills/cosmic-meta-api/setup.py`

- [ ] **Step 10.1：执行删除**

```bash
# 在 DEPLOY_DIR 下执行
Remove-Item skills/cosmic-meta-api/scripts/config.json
Remove-Item skills/cosmic-meta-api/scripts/pdm-automation/config.json
Remove-Item skills/cosmic-meta-api/skill_env.json
Remove-Item skills/cosmic-meta-api/setup.py
```

同步到 SOURCE_DIR（`cosmic-dev/` 工作区）也删除对应文件。

- [ ] **Step 10.2：确认没有代码仍引用这些文件**

快速搜索以下字符串，确认已全部清理：
- `scripts/config.json`（除注释外）
- `pdm-automation/config.json`
- `skill_env.json`
- `setup.py`

- [ ] **Step 10.3：提交**

```bash
git add -A
git commit -m "chore: 删除废弃文件 config.json/pdm-automation-config/skill_env.json/setup.py"
```

---

## Task 11：同步到 SOURCE_DIR 并最终验证

- [ ] **Step 11.1：将 DEPLOY_DIR 变更同步到 SOURCE_DIR**

```bash
# SOURCE_DIR = c:\Users\HP\workspace\cosmic\cosmic-dev
# 将 DEPLOY_DIR 的 skills/ 目录变更手动同步，或使用 robocopy：
robocopy "c:\Users\HP\workspace\cosmic\.cursor\skills\cosmic-meta-api" `
         "c:\Users\HP\workspace\cosmic\cosmic-dev\skills\cosmic-meta-api" `
         /MIR /XD __pycache__ /XD runtime
```

- [ ] **Step 11.2：端到端冒烟验证**

```bash
# 1. 检查 config.json 加载
python skills/cosmic-meta-api/scripts/cosmic_api.py auth
# 期望：使用 skills/config.json 中的凭据尝试鉴权

# 2. 检查 artifact_manager 路径
python skills/cosmic-meta-api/scripts/artifact_manager.py list
# 期望：列出 runtime/artifacts/ 下的文件（或提示无缓存）

# 3. 检查 pdm_auto 默认路径
python skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py --help
# 期望：显示 --config 默认值为 skills/config.json 路径
```

- [ ] **Step 11.3：最终提交 SOURCE_DIR**

```bash
cd "c:\Users\HP\workspace\cosmic"
git add cosmic-dev/
git commit -m "feat: 整合完成——统一 config、废弃 skill_env.json、更新路由规则"
git push origin master
```
