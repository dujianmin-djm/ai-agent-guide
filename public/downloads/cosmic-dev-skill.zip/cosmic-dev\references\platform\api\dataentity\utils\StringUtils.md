---
framework_version: "8.0.1"
api_class: "StringUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Operations on java.lang.String that are时"
---

# StringUtils API 说明

## 概述
Operations on java.lang.String that are。
主要功能：状态判断、移除元素、读取属性。

## Import 路径
```java
import kd.bos.dataentity.utils.StringUtils;
```

---

## 方法列表

### abbreviate

**重载 1**

Abbreviates a String using ellipses. This will turn
 "Now is the time for all good men" into "Now is the time for..."

**方法签名：**
```java
public static String abbreviate(String str, int maxWidth)
```

**参数说明：**
- `str`: `String` — the String to check, may be null
- `maxWidth`: `int` — maximum length of result String, must be at least 4

**返回值：**
- `String`: abbreviated String, ` null` if null String input

---

**重载 2**

Abbreviates a String using ellipses. This will turn
 "Now is the time for all good men" into "...is the time for..."

**方法签名：**
```java
public static String abbreviate(String str, int offset, int maxWidth)
```

**参数说明：**
- `str`: `String` — the String to check, may be null
- `offset`: `int` — left edge of source String
- `maxWidth`: `int` — maximum length of result String, must be at least 4

**返回值：**
- `String`: abbreviated String, ` null` if null String input

---

### abbreviateMiddle

Abbreviates a String to the length passed, replacing the middle characters with the supplied
 replacement String.

**方法签名：**
```java
public static String abbreviateMiddle(String str, String middle, int length)
```

**参数说明：**
- `str`: `String` — the String to abbreviate, may be null
- `middle`: `String` — the String to replace the middle characters with, may be null
- `length`: `int` — the length to abbreviate ` str` to.

**返回值：**
- `String`: the abbreviated String if the above criteria is met, or the original String supplied for abbreviation.

---

### appendIfMissing

Appends the suffix to the end of the string if the string does not
 already end with any the suffixes.

**方法签名：**
```java
public static String appendIfMissing(String str, CharSequence suffix, CharSequence[] suffixes)
```

**参数说明：**
- `str`: `String` — The string.
- `suffix`: `CharSequence` — The suffix to append to the end of the string.
- `suffixes`: `CharSequence[]` — Additional suffixes that are valid terminators.

**返回值：**
- `String`: A new String if suffix was appened, the same string otherwise.

---

### appendIfMissingIgnoreCase

Appends the suffix to the end of the string if the string does not
 already end, case insensitive, with any of the suffixes.

**方法签名：**
```java
public static String appendIfMissingIgnoreCase(String str, CharSequence suffix, CharSequence[] suffixes)
```

**参数说明：**
- `str`: `String` — The string.
- `suffix`: `CharSequence` — The suffix to append to the end of the string.
- `suffixes`: `CharSequence[]` — Additional suffixes that are valid terminators.

**返回值：**
- `String`: A new String if suffix was appened, the same string otherwise.

---

### capitalize

Capitalizes a String changing the first letter to title case as
 per Character#toTitleCase(char). No other letters are changed.

**方法签名：**
```java
public static String capitalize(String str)
```

**参数说明：**
- `str`: `String` — the String to capitalize, may be null

**返回值：**
- `String`: the capitalized String, ` null` if null String input

---

### center

**重载 1**

Centers a String in a larger String of size ` size`
 using the space character (' ').

**方法签名：**
```java
public static String center(String str, int size)
```

**参数说明：**
- `str`: `String` — the String to center, may be null
- `size`: `int` — the int size of new String, negative treated as zero

**返回值：**
- `String`: centered String, ` null` if null String input

---

**重载 2**

Centers a String in a larger String of size ` size`.
 Uses a supplied character as the value to pad the String with.

**方法签名：**
```java
public static String center(String str, int size, char padChar)
```

**参数说明：**
- `str`: `String` — the String to center, may be null
- `size`: `int` — the int size of new String, negative treated as zero
- `padChar`: `char` — the character to pad the new String with

**返回值：**
- `String`: centered String, ` null` if null String input

---

**重载 3**

Centers a String in a larger String of size ` size`.
 Uses a supplied String as the value to pad the String with.

**方法签名：**
```java
public static String center(String str, int size, String padStr)
```

**参数说明：**
- `str`: `String` — the String to center, may be null
- `size`: `int` — the int size of new String, negative treated as zero
- `padStr`: `String` — the String to pad the new String with, must not be null or empty

**返回值：**
- `String`: centered String, ` null` if null String input

---

### chomp

Removes ` separator` from the end of
 ` str` if it's there, otherwise leave it alone.

**方法签名：**
```java
public static String chomp(String str, String separator)
```

**参数说明：**
- `str`: `String` — the String to chomp from, may be null
- `separator`: `String` — separator String, may be null

**返回值：**
- `String`: String without trailing separator, ` null` if null String input

---

### cleanChar

过滤不合法字符

**方法签名：**
```java
public static char cleanChar(char c)
```

**参数说明：**
- `c`: `char` — 原字符

**返回值：**
- `char`

---

### cleanString

对输入文件路劲参数进行过滤

**方法签名：**
```java
public static String cleanString(String str)
```

**参数说明：**
- `str`: `String`

**返回值：**
- `String`: cleanString

---

### contains

**重载 1**

Checks if CharSequence contains a search character, handling ` null`.
 This method uses String#indexOf(int) if possible.

**方法签名：**
```java
public static boolean contains(CharSequence seq, int searchChar)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChar`: `int` — the character to find

**返回值：**
- `boolean`: true if the CharSequence contains the search character,
  false if not or ` null` string input

---

**重载 2**

Checks if CharSequence contains a search CharSequence, handling ` null`.
 This method uses String#indexOf(String) if possible.

**方法签名：**
```java
public static boolean contains(CharSequence seq, CharSequence searchSeq)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchSeq`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `boolean`: true if the CharSequence contains the search CharSequence,
  false if not or ` null` string input

---

### containsIgnoreCase

Checks if CharSequence contains a search CharSequence irrespective of case,
 handling ` null`. Case-insensitivity is defined as by
 String#equalsIgnoreCase(String).

**方法签名：**
```java
public static boolean containsIgnoreCase(CharSequence str, CharSequence searchStr)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `boolean`: true if the CharSequence contains the search CharSequence irrespective of
 case or false if not or ` null` string input

---

### containsNone

**重载 1**

Checks that the CharSequence does not contain certain characters.

**方法签名：**
```java
public static boolean containsNone(CharSequence cs, char[] searchChars)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null
- `searchChars`: `char[]` — an array of invalid chars, may be null

**返回值：**
- `boolean`: true if it contains none of the invalid chars, or is null

---

**重载 2**

Checks that the CharSequence does not contain certain characters.

**方法签名：**
```java
public static boolean containsNone(CharSequence cs, String invalidChars)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null
- `invalidChars`: `String` — a String of invalid chars, may be null

**返回值：**
- `boolean`: true if it contains none of the invalid chars, or is null

---

### containsWhitespace

Check whether the given CharSequence contains any whitespace characters.

**方法签名：**
```java
public static boolean containsWhitespace(CharSequence seq)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check (may be ` null`)

**返回值：**
- `boolean`: ` true` if the CharSequence is not empty and
 contains at least 1 whitespace character

---

### countMatches

**重载 1**

Counts how many times the substring appears in the larger string.

**方法签名：**
```java
public static int countMatches(CharSequence str, CharSequence sub)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `sub`: `CharSequence` — the substring to count, may be null

**返回值：**
- `int`: the number of occurrences, 0 if either CharSequence is ` null`

---

**重载 2**

Counts how many times the char appears in the given string.

**方法签名：**
```java
public static int countMatches(CharSequence str, char ch)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `ch`: `char` — the char to count

**返回值：**
- `int`: the number of occurrences, 0 if the CharSequence is ` null`

---

### defaultIfBlank

Returns either the passed in CharSequence, or if the CharSequence is
 whitespace, empty ("") or ` null`, the value of ` defaultStr`.

**方法签名：**
```java
public static CharSequence defaultIfBlank(T str, T defaultStr)
```

**参数说明：**
- `str`: `T` — the CharSequence to check, may be null
- `defaultStr`: `T` — the default CharSequence to return
  if the input is whitespace, empty ("") or ` null`, may be null

**返回值：**
- `CharSequence`: the passed in CharSequence, or the default

---

### defaultIfEmpty

Returns either the passed in CharSequence, or if the CharSequence is
 empty or ` null`, the value of ` defaultStr`.

**方法签名：**
```java
public static CharSequence defaultIfEmpty(T str, T defaultStr)
```

**参数说明：**
- `str`: `T` — the CharSequence to check, may be null
- `defaultStr`: `T` — the default CharSequence to return
  if the input is empty ("") or ` null`, may be null

**返回值：**
- `CharSequence`: the passed in CharSequence, or the default

---

### defaultString

**重载 1**

Returns either the passed in String,
 or if the String is ` null`, an empty String ("").

**方法签名：**
```java
public static String defaultString(String str)
```

**参数说明：**
- `str`: `String` — the String to check, may be null

**返回值：**
- `String`: the passed in String, or the empty String if it
  was ` null`

---

**重载 2**

Returns either the passed in String, or if the String is
 ` null`, the value of ` defaultStr`.

**方法签名：**
```java
public static String defaultString(String str, String defaultStr)
```

**参数说明：**
- `str`: `String` — the String to check, may be null
- `defaultStr`: `String` — the default String to return
  if the input is ` null`, may be null

**返回值：**
- `String`: the passed in String, or the default if it was ` null`

---

### deleteWhitespace

Deletes all whitespaces from a String as defined by
 Character#isWhitespace(char).

**方法签名：**
```java
public static String deleteWhitespace(String str)
```

**参数说明：**
- `str`: `String` — the String to delete whitespace from, may be null

**返回值：**
- `String`: the String without whitespaces, ` null` if null String input

---

### difference

Compares two Strings, and returns the portion where they differ.
 More precisely, return the remainder of the second String,
 starting from where it's different from the first. This means that
 the difference between "abc" and "ab" is the empty String and not "c". 

**方法签名：**
```java
public static String difference(String str1, String str2)
```

**参数说明：**
- `str1`: `String` — the first String, may be null
- `str2`: `String` — the second String, may be null

**返回值：**
- `String`: the portion of str2 where it differs from str1; returns the
 empty String if they are equal

---

### endsWith

Check if a CharSequence ends with a specified suffix.

**方法签名：**
```java
public static boolean endsWith(CharSequence str, CharSequence suffix)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `suffix`: `CharSequence` — the suffix to find, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence ends with the suffix, case sensitive, or
  both ` null`

---

### endsWithAny

Check if a CharSequence ends with any of an array of specified strings.

**方法签名：**
```java
public static boolean endsWithAny(CharSequence string, CharSequence[] searchStrings)
```

**参数说明：**
- `string`: `CharSequence` — the CharSequence to check, may be null
- `searchStrings`: `CharSequence[]` — the CharSequences to find, may be null or empty

**返回值：**
- `boolean`: ` true` if the CharSequence ends with any of the the prefixes, case insensitive, or
  both ` null`

---

### endsWithIgnoreCase

Case insensitive check if a CharSequence ends with a specified suffix.

**方法签名：**
```java
public static boolean endsWithIgnoreCase(CharSequence str, CharSequence suffix)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `suffix`: `CharSequence` — the suffix to find, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence ends with the suffix, case insensitive, or
  both ` null`

---

### equals

Compares two CharSequences, returning ` true` if they represent
 equal sequences of characters.

**方法签名：**
```java
public static boolean equals(CharSequence cs1, CharSequence cs2)
```

**参数说明：**
- `cs1`: `CharSequence` — the first CharSequence, may be ` null`
- `cs2`: `CharSequence` — the second CharSequence, may be ` null`

**返回值：**
- `boolean`: ` true` if the CharSequences are equal (case-sensitive), or both ` null`

---

### equalsIgnoreCase

Compares two CharSequences, returning ` true` if they represent
 equal sequences of characters, ignoring case.

**方法签名：**
```java
public static boolean equalsIgnoreCase(CharSequence str1, CharSequence str2)
```

**参数说明：**
- `str1`: `CharSequence` — the first CharSequence, may be null
- `str2`: `CharSequence` — the second CharSequence, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence are equal, case insensitive, or
  both ` null`

---

### getCommonPrefix

Compares all Strings in an array and returns the initial sequence of
 characters that is common to all of them.

**方法签名：**
```java
public static String getCommonPrefix(String[] strs)
```

**参数说明：**
- `strs`: `String[]` — array of String objects, entries may be null

**返回值：**
- `String`: the initial sequence of characters that are common to all Strings
 in the array; empty String if the array is null, the elements are all null
 or if there is no common prefix.

---

### getFuzzyDistance

Find the Fuzzy Distance which indicates the similarity score between two Strings.

**方法签名：**
```java
public static int getFuzzyDistance(CharSequence term, CharSequence query, Locale locale)
```

**参数说明：**
- `term`: `CharSequence` — a full term that should be matched against, must not be null
- `query`: `CharSequence` — the query that will be matched against a term, must not be null
- `locale`: `Locale` — This string matching logic is case insensitive. A locale is necessary to normalize
  both Strings to lower case.

**返回值：**
- `int`: result score

---

### getJaroWinklerDistance

Find the Jaro Winkler Distance which indicates the similarity score between two Strings.

**方法签名：**
```java
public static double getJaroWinklerDistance(CharSequence first, CharSequence second)
```

**参数说明：**
- `first`: `CharSequence` — the first String, must not be null
- `second`: `CharSequence` — the second String, must not be null

**返回值：**
- `double`: result distance

---

### getLevenshteinDistance

**重载 1**

Find the Levenshtein distance between two Strings.

**方法签名：**
```java
public static int getLevenshteinDistance(CharSequence s, CharSequence t)
```

**参数说明：**
- `s`: `CharSequence` — the first String, must not be null
- `t`: `CharSequence` — the second String, must not be null

**返回值：**
- `int`: result distance

---

**重载 2**

Find the Levenshtein distance between two Strings if it's less than or equal to a given
 threshold.

**方法签名：**
```java
public static int getLevenshteinDistance(CharSequence s, CharSequence t, int threshold)
```

**参数说明：**
- `s`: `CharSequence` — the first String, must not be null
- `t`: `CharSequence` — the second String, must not be null
- `threshold`: `int` — the target threshold, must not be negative

**返回值：**
- `int`: result distance, or ` -1` if the distance would be greater than the threshold

---

### indexOf

**重载 1**

Finds the first index within a CharSequence, handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int indexOf(CharSequence seq, int searchChar)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChar`: `int` — the character to find

**返回值：**
- `int`: the first index of the search character,
  -1 if no match or ` null` string input

---

**重载 2**

Finds the first index within a CharSequence from a start position,
 handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int indexOf(CharSequence seq, int searchChar, int startPos)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChar`: `int` — the character to find
- `startPos`: `int` — the start position, negative treated as zero

**返回值：**
- `int`: the first index of the search character (always ≥ startPos),
  -1 if no match or ` null` string input

---

**重载 3**

Finds the first index within a CharSequence, handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int indexOf(CharSequence seq, CharSequence searchSeq)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchSeq`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `int`: the first index of the search CharSequence,
  -1 if no match or ` null` string input

---

**重载 4**

Finds the first index within a CharSequence, handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int indexOf(CharSequence seq, CharSequence searchSeq, int startPos)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchSeq`: `CharSequence` — the CharSequence to find, may be null
- `startPos`: `int` — the start position, negative treated as zero

**返回值：**
- `int`: the first index of the search CharSequence (always ≥ startPos),
  -1 if no match or ` null` string input

---

### indexOfAny

Find the first index of any of a set of potential substrings.

**方法签名：**
```java
public static int indexOfAny(CharSequence str, CharSequence[] searchStrs)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStrs`: `CharSequence[]` — the CharSequences to search for, may be null

**返回值：**
- `int`: the first index of any of the searchStrs in str, -1 if no match

---

### indexOfAnyBut

Search a CharSequence to find the first index of any
 character not in the given set of characters.

**方法签名：**
```java
public static int indexOfAnyBut(CharSequence seq, CharSequence searchChars)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChars`: `CharSequence` — the chars to search for, may be null

**返回值：**
- `int`: the index of any of the chars, -1 if no match or null input

---

### indexOfDifference

**重载 1**

Compares two CharSequences, and returns the index at which the
 CharSequences begin to differ.

**方法签名：**
```java
public static int indexOfDifference(CharSequence cs1, CharSequence cs2)
```

**参数说明：**
- `cs1`: `CharSequence` — the first CharSequence, may be null
- `cs2`: `CharSequence` — the second CharSequence, may be null

**返回值：**
- `int`: the index where cs1 and cs2 begin to differ; -1 if they are equal

---

**重载 2**

Compares all CharSequences in an array and returns the index at which the
 CharSequences begin to differ.

**方法签名：**
```java
public static int indexOfDifference(CharSequence[] css)
```

**参数说明：**
- `css`: `CharSequence[]` — array of CharSequences, entries may be null

**返回值：**
- `int`: the index where the strings begin to differ; -1 if they are all equal

---

### indexOfIgnoreCase

**重载 1**

Case in-sensitive find of the first index within a CharSequence.

**方法签名：**
```java
public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `int`: the first index of the search CharSequence,
  -1 if no match or ` null` string input

---

**重载 2**

Case in-sensitive find of the first index within a CharSequence
 from the specified position.

**方法签名：**
```java
public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null
- `startPos`: `int` — the start position, negative treated as zero

**返回值：**
- `int`: the first index of the search CharSequence (always ≥ startPos),
  -1 if no match or ` null` string input

---

### isAllLowerCase

Checks if the CharSequence contains only lowercase characters.

**方法签名：**
```java
public static boolean isAllLowerCase(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains lowercase characters, and is non-null

---

### isAllUpperCase

Checks if the CharSequence contains only uppercase characters.

**方法签名：**
```java
public static boolean isAllUpperCase(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains uppercase characters, and is non-null

---

### isAlpha

Checks if the CharSequence contains only Unicode letters.

**方法签名：**
```java
public static boolean isAlpha(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains letters, and is non-null

---

### isAlphaSpace

Checks if the CharSequence contains only Unicode letters and
 space (' ').

**方法签名：**
```java
public static boolean isAlphaSpace(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains letters and space,
  and is non-null

---

### isAlphanumeric

Checks if the CharSequence contains only Unicode letters or digits.

**方法签名：**
```java
public static boolean isAlphanumeric(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains letters or digits,
  and is non-null

---

### isAlphanumericSpace

Checks if the CharSequence contains only Unicode letters, digits
 or space (` ' '`).

**方法签名：**
```java
public static boolean isAlphanumericSpace(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains letters, digits or space,
  and is non-null

---

### isAsciiPrintable

Checks if the CharSequence contains only ASCII printable characters.

**方法签名：**
```java
public static boolean isAsciiPrintable(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if every character is in the range
  32 thru 126

---

### isBlank

**重载 1**

Checks if a CharSequence is whitespace, empty ("") or null.

**方法签名：**
```java
public static boolean isBlank(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence is null, empty or whitespace

---

**重载 2**

检查目标对象是否为空字符串或null
 Iterable/Map 对象返回false
 check object==null or isBlack(object.toString())

**方法签名：**
```java
public static boolean isBlank(Object cs)
```

**参数说明：**
- `cs`: `Object`

**返回值：**
- `boolean`

---

### isEmail

判断邮箱格式是否正确

**方法签名：**
```java
public static boolean isEmail(String email)
```

**参数说明：**
- `email`: `String`

**返回值：**
- `boolean`

---

### isEmpty

Checks if a CharSequence is empty ("") or null.

**方法签名：**
```java
public static boolean isEmpty(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence is empty or null

---

### isJavaIdentifier

判断字符串是否作为java标识符（字符串中每一个字符都必须是java标识符的一部分）
 空值返回false

**方法签名：**
```java
public static boolean isJavaIdentifier(String s)
```

**参数说明：**
- `s`: `String`

**返回值：**
- `boolean`

---

### isNotBlank

**重载 1**

Checks if a CharSequence is not empty (""), not null and not whitespace only.

**方法签名：**
```java
public static boolean isNotBlank(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence is
  not empty and not null and not whitespace

---

**重载 2**

检查目标对象不为空 （等效 !isBlank(Object cs)）
 Iterable/Map 对象返回 true

**方法签名：**
```java
public static boolean isNotBlank(Object cs)
```

**参数说明：**
- `cs`: `Object`

**返回值：**
- `boolean`

---

### isNotEmpty

Checks if a CharSequence is not empty ("") and not null.

**方法签名：**
```java
public static boolean isNotEmpty(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence is not empty and not null

---

### isNumeric

Checks if the CharSequence contains only Unicode digits.
 A decimal point is not a Unicode digit and returns false.

**方法签名：**
```java
public static boolean isNumeric(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains digits, and is non-null

---

### isNumericSpace

Checks if the CharSequence contains only Unicode digits or space
 (` ' '`).
 A decimal point is not a Unicode digit and returns false.

**方法签名：**
```java
public static boolean isNumericSpace(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains digits or space,
  and is non-null

---

### isPhoneNumberValid

判断电话号码格式是否正确

**方法签名：**
```java
public static boolean isPhoneNumberValid(String phoneNumber)
```

**参数说明：**
- `phoneNumber`: `String`

**返回值：**
- `boolean`

---

### isWhitespace

Checks if the CharSequence contains only whitespace.

**方法签名：**
```java
public static boolean isWhitespace(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence` — the CharSequence to check, may be null

**返回值：**
- `boolean`: ` true` if only contains whitespace, and is non-null

---

### join

**重载 1**

Joins the elements of the provided array into a single String
 containing the provided list of elements.

**方法签名：**
```java
public static String join(T[] elements)
```

**参数说明：**
- `elements`: `T[]` — the values to join together, may be null

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 2**

Joins the elements of the provided array into a single String
 containing the provided list of elements.

**方法签名：**
```java
public static String join(Object[] array, char separator)
```

**参数说明：**
- `array`: `Object[]` — the array of values to join together, may be null
- `separator`: `char` — the separator character to use

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 3**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(long[] array, char separator)
```

**参数说明：**
- `array`: `long[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 4**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(int[] array, char separator)
```

**参数说明：**
- `array`: `int[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 5**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(short[] array, char separator)
```

**参数说明：**
- `array`: `short[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 6**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(byte[] array, char separator)
```

**参数说明：**
- `array`: `byte[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 7**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(char[] array, char separator)
```

**参数说明：**
- `array`: `char[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 8**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(float[] array, char separator)
```

**参数说明：**
- `array`: `float[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 9**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(double[] array, char separator)
```

**参数说明：**
- `array`: `double[]`
- `separator`: `char`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 10**

Joins the elements of the provided array into a single String
 containing the provided list of elements.

**方法签名：**
```java
public static String join(Object[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `Object[]` — the array of values to join together, may be null
- `separator`: `char` — the separator character to use
- `startIndex`: `int` — the first index to start joining from.  It is
 an error to pass in an end index past the end of the array
- `endIndex`: `int` — the index to stop joining from (exclusive). It is
 an error to pass in an end index past the end of the array

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 11**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(long[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `long[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 12**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(int[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `int[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 13**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(byte[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `byte[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 14**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(short[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `short[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 15**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(char[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `char[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 16**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(double[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `double[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 17**

Joins the elements of the provided array into a single String containing the provided list of elements.
 

**方法签名：**
```java
public static String join(float[] array, char separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `float[]`
- `separator`: `char`
- `startIndex`: `int`
- `endIndex`: `int`

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 18**

Joins the elements of the provided array into a single String
 containing the provided list of elements.

**方法签名：**
```java
public static String join(Object[] array, String separator)
```

**参数说明：**
- `array`: `Object[]` — the array of values to join together, may be null
- `separator`: `String` — the separator character to use, null treated as ""

**返回值：**
- `String`: the joined String, ` null` if null array input

---

**重载 19**

Joins the elements of the provided array into a single String
 containing the provided list of elements.

**方法签名：**
```java
public static String join(Object[] array, String separator, int startIndex, int endIndex)
```

**参数说明：**
- `array`: `Object[]` — the array of values to join together, may be null
- `separator`: `String` — the separator character to use, null treated as ""
- `startIndex`: `int` — the first index to start joining from.
- `endIndex`: `int` — the index to stop joining from (exclusive).

**返回值：**
- `String`: the joined String, ` null` if null array input; or the empty string
 if ` endIndex - startIndex <= 0`. The number of joined entries is given by
 ` endIndex - startIndex`

---

**重载 20**

Joins the elements of the provided ` Iterable` into
 a single String containing the provided elements.

**方法签名：**
```java
public static String join(Iterable<?> iterable, char separator)
```

**参数说明：**
- `iterable`: `Iterable<?>` — the ` Iterable` providing the values to join together, may be null
- `separator`: `char` — the separator character to use

**返回值：**
- `String`: the joined String, ` null` if null iterator input

---

**重载 21**

Joins the elements of the provided ` Iterable` into
 a single String containing the provided elements.

**方法签名：**
```java
public static String join(Iterable<?> iterable, String separator)
```

**参数说明：**
- `iterable`: `Iterable<?>` — the ` Iterable` providing the values to join together, may be null
- `separator`: `String` — the separator character to use, null treated as ""

**返回值：**
- `String`: the joined String, ` null` if null iterator input

---

### lastIndexOf

**重载 1**

Finds the last index within a CharSequence, handling ` null`.
 This method uses String#lastIndexOf(int) if possible.

**方法签名：**
```java
public static int lastIndexOf(CharSequence seq, int searchChar)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChar`: `int` — the character to find

**返回值：**
- `int`: the last index of the search character,
  -1 if no match or ` null` string input

---

**重载 2**

Finds the last index within a CharSequence from a start position,
 handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int lastIndexOf(CharSequence seq, int searchChar, int startPos)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchChar`: `int` — the character to find
- `startPos`: `int` — the start position

**返回值：**
- `int`: the last index of the search character (always ≤ startPos),
  -1 if no match or ` null` string input

---

**重载 3**

Finds the last index within a CharSequence, handling ` null`.
 This method uses String#lastIndexOf(String) if possible.

**方法签名：**
```java
public static int lastIndexOf(CharSequence seq, CharSequence searchSeq)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchSeq`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `int`: the last index of the search String,
  -1 if no match or ` null` string input

---

**重载 4**

Finds the last index within a CharSequence, handling ` null`.
 This method uses int) if possible.

**方法签名：**
```java
public static int lastIndexOf(CharSequence seq, CharSequence searchSeq, int startPos)
```

**参数说明：**
- `seq`: `CharSequence` — the CharSequence to check, may be null
- `searchSeq`: `CharSequence` — the CharSequence to find, may be null
- `startPos`: `int` — the start position, negative treated as zero

**返回值：**
- `int`: the last index of the search CharSequence (always ≤ startPos),
  -1 if no match or ` null` string input

---

### lastIndexOfAny

Find the latest index of any of a set of potential substrings.

**方法签名：**
```java
public static int lastIndexOfAny(CharSequence str, CharSequence[] searchStrs)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStrs`: `CharSequence[]` — the CharSequences to search for, may be null

**返回值：**
- `int`: the last index of any of the CharSequences, -1 if no match

---

### lastIndexOfIgnoreCase

**重载 1**

Case in-sensitive find of the last index within a CharSequence.

**方法签名：**
```java
public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null

**返回值：**
- `int`: the first index of the search CharSequence,
  -1 if no match or ` null` string input

---

**重载 2**

Case in-sensitive find of the last index within a CharSequence
 from the specified position.

**方法签名：**
```java
public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null
- `startPos`: `int` — the start position

**返回值：**
- `int`: the last index of the search CharSequence (always ≤ startPos),
  -1 if no match or ` null` input

---

### lastOrdinalIndexOf

Finds the n-th last index within a String, handling ` null`.
 This method uses String#lastIndexOf(String).

**方法签名：**
```java
public static int lastOrdinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null
- `ordinal`: `int` — the n-th last ` searchStr` to find

**返回值：**
- `int`: the n-th last index of the search CharSequence,
  ` -1` (` INDEX_NOT_FOUND`) if no match or ` null` string input

---

### left

Gets the leftmost ` len` characters of a String.

**方法签名：**
```java
public static String left(String str, int len)
```

**参数说明：**
- `str`: `String` — the String to get the leftmost characters from, may be null
- `len`: `int` — the length of the required String

**返回值：**
- `String`: the leftmost characters, ` null` if null String input

---

### leftPad

**重载 1**

Left pad a String with spaces (' ').

**方法签名：**
```java
public static String leftPad(String str, int size)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to

**返回值：**
- `String`: left padded String or original String if no padding is necessary,
  ` null` if null String input

---

**重载 2**

Left pad a String with a specified character.

**方法签名：**
```java
public static String leftPad(String str, int size, char padChar)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to
- `padChar`: `char` — the character to pad with

**返回值：**
- `String`: left padded String or original String if no padding is necessary,
  ` null` if null String input

---

**重载 3**

Left pad a String with a specified String.

**方法签名：**
```java
public static String leftPad(String str, int size, String padStr)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to
- `padStr`: `String` — the String to pad with, null or empty treated as single space

**返回值：**
- `String`: left padded String or original String if no padding is necessary,
  ` null` if null String input

---

### length

Gets a CharSequence length or ` 0` if the CharSequence is
 ` null`.

**方法签名：**
```java
public static int length(CharSequence cs)
```

**参数说明：**
- `cs`: `CharSequence`

**返回值：**
- `int`: CharSequence length or ` 0` if the CharSequence is
         ` null`.

---

### lowerCase

**重载 1**

Converts a String to lower case as per String#toLowerCase().

**方法签名：**
```java
public static String lowerCase(String str)
```

**参数说明：**
- `str`: `String` — the String to lower case, may be null

**返回值：**
- `String`: the lower cased String, ` null` if null String input

---

**重载 2**

Converts a String to lower case as per String#toLowerCase(Locale).

**方法签名：**
```java
public static String lowerCase(String str, Locale locale)
```

**参数说明：**
- `str`: `String` — the String to lower case, may be null
- `locale`: `Locale` — the locale that defines the case transformation rules, must not be null

**返回值：**
- `String`: the lower cased String, ` null` if null String input

---

### mid

Gets ` len` characters from the middle of a String.

**方法签名：**
```java
public static String mid(String str, int pos, int len)
```

**参数说明：**
- `str`: `String` — the String to get the characters from, may be null
- `pos`: `int` — the position to start from, negative treated as zero
- `len`: `int` — the length of the required String

**返回值：**
- `String`: the middle characters, ` null` if null String input

---

### normalizeSpace

Similar to http://www.w3.org/TR/xpath/#function-normalize
 -space
 
 
 The function returns the argument string with whitespace normalized by using
 `#trim(String)` to remove leading and trailing whitespace
 and then replacing sequences of whitespace characters by a single space.
 
 In XML Whitespace characters are the same as those allowed by the S production, which is S ::= (#x20 | #x9 | #xD | #xA)+
 
 Java's regexp pattern \s defines whitespace as [ \t\n\x0B\f\r]

**方法签名：**
```java
public static String normalizeSpace(String str)
```

**参数说明：**
- `str`: `String` — the source String to normalize whitespaces from, may be null

**返回值：**
- `String`: the modified string with whitespace normalized, ` null` if null String input

---

### ordinalIndexOf

Finds the n-th index within a CharSequence, handling ` null`.
 This method uses String#indexOf(String) if possible.

**方法签名：**
```java
public static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `searchStr`: `CharSequence` — the CharSequence to find, may be null
- `ordinal`: `int` — the n-th ` searchStr` to find

**返回值：**
- `int`: the n-th index of the search CharSequence,
  ` -1` (` INDEX_NOT_FOUND`) if no match or ` null` string input

---

### overlay

Overlays part of a String with another String.

**方法签名：**
```java
public static String overlay(String str, String overlay, int start, int end)
```

**参数说明：**
- `str`: `String` — the String to do overlaying in, may be null
- `overlay`: `String` — the String to overlay, may be null
- `start`: `int` — the position to start overlaying at
- `end`: `int` — the position to stop overlaying before

**返回值：**
- `String`: overlayed String, ` null` if null String input

---

### prependIfMissing

Prepends the prefix to the start of the string if the string does not
 already start with any of the prefixes.

**方法签名：**
```java
public static String prependIfMissing(String str, CharSequence prefix, CharSequence[] prefixes)
```

**参数说明：**
- `str`: `String` — The string.
- `prefix`: `CharSequence` — The prefix to prepend to the start of the string.
- `prefixes`: `CharSequence[]` — Additional prefixes that are valid.

**返回值：**
- `String`: A new String if prefix was prepended, the same string otherwise.

---

### prependIfMissingIgnoreCase

Prepends the prefix to the start of the string if the string does not
 already start, case insensitive, with any of the prefixes.

**方法签名：**
```java
public static String prependIfMissingIgnoreCase(String str, CharSequence prefix, CharSequence[] prefixes)
```

**参数说明：**
- `str`: `String` — The string.
- `prefix`: `CharSequence` — The prefix to prepend to the start of the string.
- `prefixes`: `CharSequence[]` — Additional prefixes that are valid (optional).

**返回值：**
- `String`: A new String if prefix was prepended, the same string otherwise.

---

### remove

**重载 1**

Removes all occurrences of a substring from within the source string.

**方法签名：**
```java
public static String remove(String str, String remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `String` — the String to search for and remove, may be null

**返回值：**
- `String`: the substring with the string removed if found,
  ` null` if null String input

---

**重载 2**

Removes all occurrences of a character from within the source string.

**方法签名：**
```java
public static String remove(String str, char remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `char` — the char to search for and remove, may be null

**返回值：**
- `String`: the substring with the char removed if found,
  ` null` if null String input

---

### removeEnd

Removes a substring only if it is at the end of a source string,
 otherwise returns the source string.

**方法签名：**
```java
public static String removeEnd(String str, String remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `String` — the String to search for and remove, may be null

**返回值：**
- `String`: the substring with the string removed if found,
  ` null` if null String input

---

### removeEndIgnoreCase

Case insensitive removal of a substring if it is at the end of a source string,
 otherwise returns the source string.

**方法签名：**
```java
public static String removeEndIgnoreCase(String str, String remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `String` — the String to search for (case insensitive) and remove, may be null

**返回值：**
- `String`: the substring with the string removed if found,
  ` null` if null String input

---

### removePattern

Removes each substring of the source String that matches the given regular expression using the DOTALL option.

**方法签名：**
```java
public static String removePattern(String source, String regex)
```

**参数说明：**
- `source`: `String`
- `regex`: `String`

**返回值：**
- `String`: The resulting ` String`

---

### removeStart

Removes a substring only if it is at the beginning of a source string,
 otherwise returns the source string.

**方法签名：**
```java
public static String removeStart(String str, String remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `String` — the String to search for and remove, may be null

**返回值：**
- `String`: the substring with the string removed if found,
  ` null` if null String input

---

### removeStartIgnoreCase

Case insensitive removal of a substring if it is at the beginning of a source string,
 otherwise returns the source string.

**方法签名：**
```java
public static String removeStartIgnoreCase(String str, String remove)
```

**参数说明：**
- `str`: `String` — the source String to search, may be null
- `remove`: `String` — the String to search for (case insensitive) and remove, may be null

**返回值：**
- `String`: the substring with the string removed if found,
  ` null` if null String input

---

### repeat

**重载 1**

Repeat a String ` repeat` times to form a
 new String.

**方法签名：**
```java
public static String repeat(String str, int repeat)
```

**参数说明：**
- `str`: `String` — the String to repeat, may be null
- `repeat`: `int` — number of times to repeat str, negative treated as zero

**返回值：**
- `String`: a new String consisting of the original String repeated,
  ` null` if null String input

---

**重载 2**

Repeat a String ` repeat` times to form a
 new String, with a String separator injected each time. 

**方法签名：**
```java
public static String repeat(String str, String separator, int repeat)
```

**参数说明：**
- `str`: `String` — the String to repeat, may be null
- `separator`: `String` — the String to inject, may be null
- `repeat`: `int` — number of times to repeat str, negative treated as zero

**返回值：**
- `String`: a new String consisting of the original String repeated,
  ` null` if null String input

---

**重载 3**

Returns padding using the specified delimiter repeated
 to a given length.

**方法签名：**
```java
public static String repeat(char ch, int repeat)
```

**参数说明：**
- `ch`: `char` — character to repeat
- `repeat`: `int` — number of times to repeat char, negative treated as zero

**返回值：**
- `String`: String with repeated character

---

### replace

**重载 1**

Replaces all occurrences of a String within another String.

**方法签名：**
```java
public static String replace(String text, String searchString, String replacement)
```

**参数说明：**
- `text`: `String` — text to search and replace in, may be null
- `searchString`: `String` — the String to search for, may be null
- `replacement`: `String` — the String to replace it with, may be null

**返回值：**
- `String`: the text with any replacements processed,
  ` null` if null String input

---

**重载 2**

Replaces a String with another String inside a larger String,
 for the first ` max` values of the search String.

**方法签名：**
```java
public static String replace(String text, String searchString, String replacement, int max)
```

**参数说明：**
- `text`: `String` — text to search and replace in, may be null
- `searchString`: `String` — the String to search for, may be null
- `replacement`: `String` — the String to replace it with, may be null
- `max`: `int` — maximum number of values to replace, or ` -1` if no maximum

**返回值：**
- `String`: the text with any replacements processed,
  ` null` if null String input

---

### replaceChars

**重载 1**

Replaces all occurrences of a character in a String with another.
 This is a null-safe version of char).

**方法签名：**
```java
public static String replaceChars(String str, char searchChar, char replaceChar)
```

**参数说明：**
- `str`: `String` — String to replace characters in, may be null
- `searchChar`: `char` — the character to search for, may be null
- `replaceChar`: `char` — the character to replace, may be null

**返回值：**
- `String`: modified String, ` null` if null string input

---

**重载 2**

Replaces multiple characters in a String in one go.
 This method can also be used to delete characters.

**方法签名：**
```java
public static String replaceChars(String str, String searchChars, String replaceChars)
```

**参数说明：**
- `str`: `String` — String to replace characters in, may be null
- `searchChars`: `String` — a set of characters to search for, may be null
- `replaceChars`: `String` — a set of characters to replace, may be null

**返回值：**
- `String`: modified String, ` null` if null string input

---

### replaceEach

Replaces all occurrences of Strings within another String.
 

**方法签名：**
```java
public static String replaceEach(String text, String[] searchList, String[] replacementList)
```

**参数说明：**
- `text`: `String`
- `searchList`: `String[]`
- `replacementList`: `String[]`

**返回值：**
- `String`: the text with any replacements processed, ` null` if
         null String input

---

### replaceEachRepeatedly

Replaces all occurrences of Strings within another String.
 

**方法签名：**
```java
public static String replaceEachRepeatedly(String text, String[] searchList, String[] replacementList)
```

**参数说明：**
- `text`: `String`
- `searchList`: `String[]`
- `replacementList`: `String[]`

**返回值：**
- `String`: the text with any replacements processed, ` null` if
         null String input

---

### replaceOnce

Replaces a String with another String inside a larger String, once.

**方法签名：**
```java
public static String replaceOnce(String text, String searchString, String replacement)
```

**参数说明：**
- `text`: `String` — text to search and replace in, may be null
- `searchString`: `String` — the String to search for, may be null
- `replacement`: `String` — the String to replace with, may be null

**返回值：**
- `String`: the text with any replacements processed,
  ` null` if null String input

---

### replacePattern

Replaces each substring of the source String that matches the given regular expression with the given
 replacement using the Pattern#DOTALL option. DOTALL is also know as single-line mode in Perl. This call
 is also equivalent to:
 
 ` source.replaceAll("(?s)" + regex, replacement)`
 ` Pattern.compile(regex, Pattern.DOTALL).matcher(source).replaceAll(replacement)`

**方法签名：**
```java
public static String replacePattern(String source, String regex, String replacement)
```

**参数说明：**
- `source`: `String`
- `regex`: `String`
- `replacement`: `String`

**返回值：**
- `String`: The resulting ` String`

---

### reverse

Reverses a String as per StringBuilder#reverse().

**方法签名：**
```java
public static String reverse(String str)
```

**参数说明：**
- `str`: `String` — the String to reverse, may be null

**返回值：**
- `String`: the reversed String, ` null` if null String input

---

### right

Gets the rightmost ` len` characters of a String.

**方法签名：**
```java
public static String right(String str, int len)
```

**参数说明：**
- `str`: `String` — the String to get the rightmost characters from, may be null
- `len`: `int` — the length of the required String

**返回值：**
- `String`: the rightmost characters, ` null` if null String input

---

### rightPad

**重载 1**

Right pad a String with spaces (' ').

**方法签名：**
```java
public static String rightPad(String str, int size)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to

**返回值：**
- `String`: right padded String or original String if no padding is necessary,
  ` null` if null String input

---

**重载 2**

Right pad a String with a specified character.

**方法签名：**
```java
public static String rightPad(String str, int size, char padChar)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to
- `padChar`: `char` — the character to pad with

**返回值：**
- `String`: right padded String or original String if no padding is necessary,
  ` null` if null String input

---

**重载 3**

Right pad a String with a specified String.

**方法签名：**
```java
public static String rightPad(String str, int size, String padStr)
```

**参数说明：**
- `str`: `String` — the String to pad out, may be null
- `size`: `int` — the size to pad to
- `padStr`: `String` — the String to pad with, null or empty treated as single space

**返回值：**
- `String`: right padded String or original String if no padding is necessary,
  ` null` if null String input

---

### split

**重载 1**

Splits the provided text into an array, using whitespace as the
 separator.
 Whitespace is defined by Character#isWhitespace(char).

**方法签名：**
```java
public static String[] split(String str)
```

**参数说明：**
- `str`: `String` — the String to parse, may be null

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

**重载 2**

Splits the provided text into an array, separators specified.
 This is an alternative to using StringTokenizer.

**方法签名：**
```java
public static String[] split(String str, String separatorChars)
```

**参数说明：**
- `str`: `String` — the String to parse, may be null
- `separatorChars`: `String` — the characters used as the delimiters,
  ` null` splits on whitespace

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

**重载 3**

Splits the provided text into an array with a maximum length,
 separators specified.

**方法签名：**
```java
public static String[] split(String str, String separatorChars, int max)
```

**参数说明：**
- `str`: `String` — the String to parse, may be null
- `separatorChars`: `String` — the characters used as the delimiters,
  ` null` splits on whitespace
- `max`: `int` — the maximum number of elements to include in the
  array. A zero or negative value implies no limit

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

### splitByCharacterType

Splits a String by Character type as returned by
 ` java.lang.Character.getType(char)`. Groups of contiguous
 characters of the same type are returned as complete tokens.
 
 StringUtils.splitByCharacterType(null)         = null
 StringUtils.splitByCharacterType("")           = []
 StringUtils.splitByCharacterType("ab de fg")   = ["ab", " ", "de", " ", "fg"]
 StringUtils.splitByCharacterType("ab   de fg") = ["ab", "   ", "de", " ", "fg"]
 StringUtils.splitByCharacterType("ab:cd:ef")   = ["ab", ":", "cd", ":", "ef"]
 StringUtils.splitByCharacterType("number5")    = ["number", "5"]
 StringUtils.splitByCharacterType("fooBar")     = ["foo", "B", "ar"]
 StringUtils.splitByCharacterType("foo200Bar")  = ["foo", "200", "B", "ar"]
 StringUtils.splitByCharacterType("ASFRules")   = ["ASFR", "ules"]

**方法签名：**
```java
public static String[] splitByCharacterType(String str)
```

**参数说明：**
- `str`: `String` — the String to split, may be ` null`

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

### splitByCharacterTypeCamelCase

Splits a String by Character type as returned by
 ` java.lang.Character.getType(char)`. Groups of contiguous
 characters of the same type are returned as complete tokens, with the
 following exception: the character of type
 ` Character.UPPERCASE_LETTER`, if any, immediately
 preceding a token of type ` Character.LOWERCASE_LETTER`
 will belong to the following token rather than to the preceding, if any,
 ` Character.UPPERCASE_LETTER` token.
 
 StringUtils.splitByCharacterTypeCamelCase(null)         = null
 StringUtils.splitByCharacterTypeCamelCase("")           = []
 StringUtils.splitByCharacterTypeCamelCase("ab de fg")   = ["ab", " ", "de", " ", "fg"]
 StringUtils.splitByCharacterTypeCamelCase("ab   de fg") = ["ab", "   ", "de", " ", "fg"]
 StringUtils.splitByCharacterTypeCamelCase("ab:cd:ef")   = ["ab", ":", "cd", ":", "ef"]
 StringUtils.splitByCharacterTypeCamelCase("number5")    = ["number", "5"]
 StringUtils.splitByCharacterTypeCamelCase("fooBar")     = ["foo", "Bar"]
 StringUtils.splitByCharacterTypeCamelCase("foo200Bar")  = ["foo", "200", "Bar"]
 StringUtils.splitByCharacterTypeCamelCase("ASFRules")   = ["ASF", "Rules"]

**方法签名：**
```java
public static String[] splitByCharacterTypeCamelCase(String str)
```

**参数说明：**
- `str`: `String` — the String to split, may be ` null`

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

### splitPreserveAllTokens

**重载 1**

Splits the provided text into an array, using whitespace as the
 separator, preserving all tokens, including empty tokens created by
 adjacent separators. This is an alternative to using StringTokenizer.
 Whitespace is defined by Character#isWhitespace(char).

**方法签名：**
```java
public static String[] splitPreserveAllTokens(String str)
```

**参数说明：**
- `str`: `String` — the String to parse, may be ` null`

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

**重载 2**

Splits the provided text into an array, separators specified,
 preserving all tokens, including empty tokens created by adjacent
 separators. This is an alternative to using StringTokenizer.

**方法签名：**
```java
public static String[] splitPreserveAllTokens(String str, String separatorChars)
```

**参数说明：**
- `str`: `String` — the String to parse, may be ` null`
- `separatorChars`: `String` — the characters used as the delimiters,
  ` null` splits on whitespace

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

**重载 3**

Splits the provided text into an array with a maximum length,
 separators specified, preserving all tokens, including empty tokens
 created by adjacent separators.

**方法签名：**
```java
public static String[] splitPreserveAllTokens(String str, String separatorChars, int max)
```

**参数说明：**
- `str`: `String` — the String to parse, may be ` null`
- `separatorChars`: `String` — the characters used as the delimiters,
  ` null` splits on whitespace
- `max`: `int` — the maximum number of elements to include in the
  array. A zero or negative value implies no limit

**返回值：**
- `String[]`: an array of parsed Strings, ` null` if null String input

---

### startsWith

Check if a CharSequence starts with a specified prefix.

**方法签名：**
```java
public static boolean startsWith(CharSequence str, CharSequence prefix)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `prefix`: `CharSequence` — the prefix to find, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence starts with the prefix, case sensitive, or
  both ` null`

---

### startsWithAny

Check if a CharSequence starts with any of an array of specified strings.

**方法签名：**
```java
public static boolean startsWithAny(CharSequence string, CharSequence[] searchStrings)
```

**参数说明：**
- `string`: `CharSequence` — the CharSequence to check, may be null
- `searchStrings`: `CharSequence[]` — the CharSequences to find, may be null or empty

**返回值：**
- `boolean`: ` true` if the CharSequence starts with any of the the prefixes, case insensitive, or
  both ` null`

---

### startsWithIgnoreCase

Case insensitive check if a CharSequence starts with a specified prefix.

**方法签名：**
```java
public static boolean startsWithIgnoreCase(CharSequence str, CharSequence prefix)
```

**参数说明：**
- `str`: `CharSequence` — the CharSequence to check, may be null
- `prefix`: `CharSequence` — the prefix to find, may be null

**返回值：**
- `boolean`: ` true` if the CharSequence starts with the prefix, case insensitive, or
  both ` null`

---

### strip

**重载 1**

Strips whitespace from the start and end of a String.

**方法签名：**
```java
public static String strip(String str)
```

**参数说明：**
- `str`: `String` — the String to remove whitespace from, may be null

**返回值：**
- `String`: the stripped String, ` null` if null String input

---

**重载 2**

Strips any of a set of characters from the start and end of a String.
 This is similar to String#trim() but allows the characters
 to be stripped to be controlled.

**方法签名：**
```java
public static String strip(String str, String stripChars)
```

**参数说明：**
- `str`: `String` — the String to remove characters from, may be null
- `stripChars`: `String` — the characters to remove, null treated as whitespace

**返回值：**
- `String`: the stripped String, ` null` if null String input

---

### stripAccents

Removes diacritics (~= accents) from a string. The case will not be altered.
 For instance, 'à' will be replaced by 'a'.
 Note that ligatures will be left as is.

**方法签名：**
```java
public static String stripAccents(String input)
```

**参数说明：**
- `input`: `String` — String to be stripped

**返回值：**
- `String`: input text with diacritics removed

---

### stripAll

**重载 1**

Strips whitespace from the start and end of every String in an array.
 Whitespace is defined by Character#isWhitespace(char).

**方法签名：**
```java
public static String[] stripAll(String[] strs)
```

**参数说明：**
- `strs`: `String[]` — the array to remove whitespace from, may be null

**返回值：**
- `String[]`: the stripped Strings, ` null` if null array input

---

**重载 2**

Strips any of a set of characters from the start and end of every
 String in an array.
 Whitespace is defined by Character#isWhitespace(char).

**方法签名：**
```java
public static String[] stripAll(String[] strs, String stripChars)
```

**参数说明：**
- `strs`: `String[]` — the array to remove characters from, may be null
- `stripChars`: `String` — the characters to remove, null treated as whitespace

**返回值：**
- `String[]`: the stripped Strings, ` null` if null array input

---

### stripEnd

Strips any of a set of characters from the end of a String.

**方法签名：**
```java
public static String stripEnd(String str, String stripChars)
```

**参数说明：**
- `str`: `String` — the String to remove characters from, may be null
- `stripChars`: `String` — the set of characters to remove, null treated as whitespace

**返回值：**
- `String`: the stripped String, ` null` if null String input

---

### stripStart

Strips any of a set of characters from the start of a String.

**方法签名：**
```java
public static String stripStart(String str, String stripChars)
```

**参数说明：**
- `str`: `String` — the String to remove characters from, may be null
- `stripChars`: `String` — the characters to remove, null treated as whitespace

**返回值：**
- `String`: the stripped String, ` null` if null String input

---

### stripToEmpty

Strips whitespace from the start and end of a String  returning
 an empty String if ` null` input.

**方法签名：**
```java
public static String stripToEmpty(String str)
```

**参数说明：**
- `str`: `String` — the String to be stripped, may be null

**返回值：**
- `String`: the trimmed String, or an empty String if ` null` input

---

### stripToNull

Strips whitespace from the start and end of a String  returning
 ` null` if the String is empty ("") after the strip.

**方法签名：**
```java
public static String stripToNull(String str)
```

**参数说明：**
- `str`: `String` — the String to be stripped, may be null

**返回值：**
- `String`: the stripped String,
  ` null` if whitespace, empty or null String input

---

### substring

**重载 1**

Gets a substring from the specified String avoiding exceptions.

**方法签名：**
```java
public static String substring(String str, int start)
```

**参数说明：**
- `str`: `String` — the String to get the substring from, may be null
- `start`: `int` — the position to start from, negative means
  count back from the end of the String by this many characters

**返回值：**
- `String`: substring from start position, ` null` if null String input

---

**重载 2**

Gets a substring from the specified String avoiding exceptions.

**方法签名：**
```java
public static String substring(String str, int start, int end)
```

**参数说明：**
- `str`: `String` — the String to get the substring from, may be null
- `start`: `int` — the position to start from, negative means
  count back from the end of the String by this many characters
- `end`: `int` — the position to end at (exclusive), negative means
  count back from the end of the String by this many characters

**返回值：**
- `String`: substring from start position to end position,
  ` null` if null String input

---

### substringAfter

Gets the substring after the first occurrence of a separator.
 The separator is not returned.

**方法签名：**
```java
public static String substringAfter(String str, String separator)
```

**参数说明：**
- `str`: `String` — the String to get a substring from, may be null
- `separator`: `String` — the String to search for, may be null

**返回值：**
- `String`: the substring after the first occurrence of the separator,
  ` null` if null String input

---

### substringAfterLast

Gets the substring after the last occurrence of a separator.
 The separator is not returned.

**方法签名：**
```java
public static String substringAfterLast(String str, String separator)
```

**参数说明：**
- `str`: `String` — the String to get a substring from, may be null
- `separator`: `String` — the String to search for, may be null

**返回值：**
- `String`: the substring after the last occurrence of the separator,
  ` null` if null String input

---

### substringBefore

Gets the substring before the first occurrence of a separator.
 The separator is not returned.

**方法签名：**
```java
public static String substringBefore(String str, String separator)
```

**参数说明：**
- `str`: `String` — the String to get a substring from, may be null
- `separator`: `String` — the String to search for, may be null

**返回值：**
- `String`: the substring before the first occurrence of the separator,
  ` null` if null String input

---

### substringBeforeLast

Gets the substring before the last occurrence of a separator.
 The separator is not returned.

**方法签名：**
```java
public static String substringBeforeLast(String str, String separator)
```

**参数说明：**
- `str`: `String` — the String to get a substring from, may be null
- `separator`: `String` — the String to search for, may be null

**返回值：**
- `String`: the substring before the last occurrence of the separator,
  ` null` if null String input

---

### substringBetween

**重载 1**

Gets the String that is nested in between two instances of the
 same String.

**方法签名：**
```java
public static String substringBetween(String str, String tag)
```

**参数说明：**
- `str`: `String` — the String containing the substring, may be null
- `tag`: `String` — the String before and after the substring, may be null

**返回值：**
- `String`: the substring, ` null` if no match

---

**重载 2**

Gets the String that is nested in between two Strings.
 Only the first match is returned.

**方法签名：**
```java
public static String substringBetween(String str, String open, String close)
```

**参数说明：**
- `str`: `String` — the String containing the substring, may be null
- `open`: `String` — the String before the substring, may be null
- `close`: `String` — the String after the substring, may be null

**返回值：**
- `String`: the substring, ` null` if no match

---

### swapCase

Swaps the case of a String changing upper and title case to
 lower case, and lower case to upper case.

**方法签名：**
```java
public static String swapCase(String str)
```

**参数说明：**
- `str`: `String` — the String to swap case, may be null

**返回值：**
- `String`: the changed String, ` null` if null String input

---

### toEncodedString

Converts a `byte[]` to a String using the specified character encoding.

**方法签名：**
```java
public static String toEncodedString(byte[] bytes, Charset charset)
```

**参数说明：**
- `bytes`: `byte[]`
- `charset`: `Charset`

**返回值：**
- `String`: a new String

---

### toString

Converts a `byte[]` to a String using the specified character encoding.

**方法签名：**
```java
public static String toString(byte[] bytes, String charsetName)
```

**参数说明：**
- `bytes`: `byte[]`
- `charsetName`: `String`

**返回值：**
- `String`: a new String

---

### trim

Removes control characters (char <= 32) from both
 ends of this String, handling ` null` by returning
 ` null`.

**方法签名：**
```java
public static String trim(String str)
```

**参数说明：**
- `str`: `String` — the String to be trimmed, may be null

**返回值：**
- `String`: the trimmed string, ` null` if null String input

---

### trimToEmpty

Removes control characters (char <= 32) from both
 ends of this String returning an empty String ("") if the String
 is empty ("") after the trim or if it is ` null`.

**方法签名：**
```java
public static String trimToEmpty(String str)
```

**参数说明：**
- `str`: `String` — the String to be trimmed, may be null

**返回值：**
- `String`: the trimmed String, or an empty String if ` null` input

---

### trimToNull

Removes control characters (char <= 32) from both
 ends of this String returning ` null` if the String is
 empty ("") after the trim or if it is ` null`.

**方法签名：**
```java
public static String trimToNull(String str)
```

**参数说明：**
- `str`: `String` — the String to be trimmed, may be null

**返回值：**
- `String`: the trimmed String,
  ` null` if only chars <= 32, empty or null String input

---

### uncapitalize

Uncapitalizes a String changing the first letter to title case as
 per Character#toLowerCase(char). No other letters are changed.

**方法签名：**
```java
public static String uncapitalize(String str)
```

**参数说明：**
- `str`: `String` — the String to uncapitalize, may be null

**返回值：**
- `String`: the uncapitalized String, ` null` if null String input

---

### upperCase

**重载 1**

Converts a String to upper case as per String#toUpperCase().

**方法签名：**
```java
public static String upperCase(String str)
```

**参数说明：**
- `str`: `String` — the String to upper case, may be null

**返回值：**
- `String`: the upper cased String, ` null` if null String input

---

**重载 2**

Converts a String to upper case as per String#toUpperCase(Locale).

**方法签名：**
```java
public static String upperCase(String str, Locale locale)
```

**参数说明：**
- `str`: `String` — the String to upper case, may be null
- `locale`: `Locale` — the locale that defines the case transformation rules, must not be null

**返回值：**
- `String`: the upper cased String, ` null` if null String input

---

### wrap

**重载 1**

Wraps a string with a char.
 
 
 
 StringUtils.wrap(null, *)        = null
 StringUtils.wrap("", *)          = ""
 StringUtils.wrap("ab", '\0')     = "ab"
 StringUtils.wrap("ab", 'x')      = "xabx"
 StringUtils.wrap("ab", '\'')     = "'ab'"
 StringUtils.wrap("\"ab\"", '\"') = "\"\"ab\"\""

**方法签名：**
```java
public static String wrap(String str, char wrapWith)
```

**参数说明：**
- `str`: `String`
- `wrapWith`: `char`

**返回值：**
- `String`: the wrapped string, or ` null` if ` str==null`

---

**重载 2**

Wraps a String with another String.
 
 
 
 A ` null` input String returns ` null`.
 
 
 
 StringUtils.wrap(null, *)         = null
 StringUtils.wrap("", *)           = ""
 StringUtils.wrap("ab", null)      = "ab"
 StringUtils.wrap("ab", "x")       = "xabx"
 StringUtils.wrap("ab", "\"")      = "\"ab\""
 StringUtils.wrap("\"ab\"", "\"")  = "\"\"ab\"\""
 StringUtils.wrap("ab", "'")       = "'ab'"
 StringUtils.wrap("'abcd'", "'")   = "''abcd''"
 StringUtils.wrap("\"abcd\"", "'") = "'\"abcd\"'"
 StringUtils.wrap("'abcd'", "\"")  = "\"'abcd'\""

**方法签名：**
```java
public static String wrap(String str, String wrapWith)
```

**参数说明：**
- `str`: `String`
- `wrapWith`: `String`

**返回值：**
- `String`: wrapped String, ` null` if null String input

---
