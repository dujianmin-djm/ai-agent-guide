---
framework_version: "8.0.1"
api_class: "DataSetCacheOutput"
api_package: "kd.bos.algo.output"
when_to_use: "当你需要使用将结果输出为Algo CacheDataSet时"
---

# DataSetCacheOutput API 说明

## 概述
将结果输出为Algo CacheDataSet，可以通过Algo#getCacheDataSet获取。。继承自 AbstractOutput。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.output.DataSetCacheOutput;
```

---

## 方法列表

### getCacheHint

获取缓存参数

**方法签名：**
```java
public CacheHint getCacheHint()
```

**返回值：**
- `CacheHint`: hint

---

### getId

获取缓存数据ID

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: id

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
