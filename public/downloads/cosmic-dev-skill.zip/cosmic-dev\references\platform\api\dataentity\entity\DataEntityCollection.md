---
framework_version: "8.0.1"
api_class: "DataEntityCollection"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用数据包集合基类时"
---

# DataEntityCollection API 说明

## 概述
数据包集合基类，DynamicObjectCollection的父类。继承自 ArrayList，实现 ISupportInitialize, Serializable, List, RandomAccess, Cloneable。
主要功能：添加元素、读取属性、状态判断、移除元素。

## Import 路径
```java
import kd.bos.dataentity.entity.DataEntityCollection;
```

---

## 方法列表

### add

**重载 1**

{待补充}

**方法签名：**
```java
public boolean add(T item)
```

**参数说明：**
- `item`: `T`

**返回值：**
- `boolean`

---

**重载 2**

把数据包对象插入到集合index的位置上

**方法签名：**
```java
public void add(int index, T item)
```

**参数说明：**
- `index`: `int` — 从零开始的索引，应在index位置插入item
- `item`: `T`

---

### addAll

**重载 1**

{待补充}

**方法签名：**
```java
public boolean addAll(Collection<? extends T> c)
```

**参数说明：**
- `c`: `Collection<? extends T>`

**返回值：**
- `boolean`

---

**重载 2**

{待补充}

**方法签名：**
```java
public boolean addAll(int index, Collection<? extends T> c)
```

**参数说明：**
- `index`: `int`
- `c`: `Collection<? extends T>`

**返回值：**
- `boolean`

---

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### clear

清除集合对象

**方法签名：**
```java
public void clear()
```

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### getParent

返回此集合所在的实体，即父对象

**方法签名：**
```java
public final Object getParent()
```

**返回值：**
- `Object`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### remove

从集合中移除序号为index索引的数据包对象

**方法签名：**
```java
public T remove(int index)
```

**参数说明：**
- `index`: `int` — 要移除的元素的从零开始的索引

**返回值：**
- `T`

---

### set

以当前数据包对象替换集合中index索引中的数据包对象

**方法签名：**
```java
public T set(int index, T item)
```

**参数说明：**
- `index`: `int` — 待替换元素的从零开始的索引
- `item`: `T` — 数据包

**返回值：**
- `T`

---
