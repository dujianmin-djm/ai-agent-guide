---
framework_version: "8.0.1"
api_class: "KdtxRequestContext"
api_package: "kd.bos.context"
when_to_use: "当你需要使用分布式事务上下文信息时"
---

# KdtxRequestContext API 说明

## 概述
分布式事务上下文信息。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.context.KdtxRequestContext;
```

---

## 方法列表

### get

获取当前线程的分布式事务上下文，若没有则创建一个空对象

**方法签名：**
```java
public static KdtxRequestContext get()
```

**返回值：**
- `KdtxRequestContext`: 分布式事务上下文

---

### getXid

获取分布式事务请求上下文的分布式事务id

**方法签名：**
```java
public String getXid()
```

**返回值：**
- `String`: 分布式事务id

---
