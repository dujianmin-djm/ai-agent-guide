---
framework_version: "8.0.1"
api_class: "CompareType"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤比较符描述类时"
---

# CompareType API 说明

## 概述
过滤比较符描述类。实现 Serializable, Cloneable。
主要功能：设置属性、读取属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.filter.CompareType;
```

---

## 方法列表

### createContant

根据属性创建比较符实例对象

**方法签名：**
```java
public static CompareType createContant(String id, LocaleString name, String contantClass, boolean isNeedInput, CompareInputType compareInputType)
```

**参数说明：**
- `id`: `String` — 比较符标识
- `name`: `LocaleString` — 名称
- `contantClass`: `String` — 解析类
- `isNeedInput`: `boolean` — 是否需要输入
- `compareInputType`: `CompareInputType` — 输入类型

**返回值：**
- `CompareType`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### getClassName

比较符解析类

**方法签名：**
```java
public String getClassName()
```

**返回值：**
- `String`

---

### getGroupId

获取比较符分组

**方法签名：**
```java
public int getGroupId()
```

**返回值：**
- `int`

---

### getId

获取比较符标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getInputCtlType

比较值录入控件类型，枚举值：-1 = 无需录入, 0 = 手工书写；其他类型已经废弃( 1 = 下拉选择, 2 = ?)

**方法签名：**
```java
public int getInputCtlType()
```

**返回值：**
- `int`

---

### getMarkedWord

获取提示词

**方法签名：**
```java
public LocaleString getMarkedWord()
```

**返回值：**
- `LocaleString`

---

### getName

获取比较符名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`

---

### getOperate

获取比较符操作

**方法签名：**
```java
public String getOperate()
```

**返回值：**
- `String`

---

### getValue

获取比较符值

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isAmongAt

是否是在...之中

**方法签名：**
```java
public boolean isAmongAt()
```

**返回值：**
- `boolean`

---

### isBetween

{待补充}

**方法签名：**
```java
public boolean isBetween()
```

**返回值：**
- `boolean`: 是不是介于比较符

---

### isFieldCompare

是不是字段比较符

**方法签名：**
```java
public boolean isFieldCompare()
```

**返回值：**
- `boolean`

---

### isMulti

是否支持多选

**方法签名：**
```java
public boolean isMulti()
```

**返回值：**
- `boolean`

---

### isNeedInput

是否需要输入

**方法签名：**
```java
public boolean isNeedInput()
```

**返回值：**
- `boolean`

---

### isNumber

是否为数字

**方法签名：**
```java
public boolean isNumber()
```

**返回值：**
- `boolean`

---

### isVisible

是否可见

**方法签名：**
```java
public boolean isVisible()
```

**返回值：**
- `boolean`

---

### setAmongAt

是否是在...之中，或者不在...之中

**方法签名：**
```java
public void setAmongAt(boolean amongAt)
```

**参数说明：**
- `amongAt`: `boolean`

---

### setBetween

设置是不是介于比较符

**方法签名：**
```java
public void setBetween(boolean isBetween)
```

**参数说明：**
- `isBetween`: `boolean` — 是否介于比较符

---

### setClassName

设置比较符解析类

**方法签名：**
```java
public void setClassName(String className)
```

**参数说明：**
- `className`: `String`

---

### setFieldCompare

设置字段比较符

**方法签名：**
```java
public void setFieldCompare(boolean isFieldCompare)
```

**参数说明：**
- `isFieldCompare`: `boolean`

---

### setGroupId

设置比较符分组

**方法签名：**
```java
public void setGroupId(int groupId)
```

**参数说明：**
- `groupId`: `int`

---

### setId

设置比较符标识

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setInputCtlType

设置比较值录入控件类型

**方法签名：**
```java
public void setInputCtlType(int inputCtlType)
```

**参数说明：**
- `inputCtlType`: `int`

---

### setMarkedWord

设置提示词

**方法签名：**
```java
public void setMarkedWord(LocaleString markedWord)
```

**参数说明：**
- `markedWord`: `LocaleString`

---

### setMulti

设置是否支持多选

**方法签名：**
```java
public void setMulti(boolean isMulti)
```

**参数说明：**
- `isMulti`: `boolean`

---

### setName

设置比较符名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setNeedInput

设置是否需要输入

**方法签名：**
```java
public void setNeedInput(boolean isNeedInput)
```

**参数说明：**
- `isNeedInput`: `boolean`

---

### setNumber

设置是否为数字

**方法签名：**
```java
public void setNumber(boolean isNumber)
```

**参数说明：**
- `isNumber`: `boolean`

---

### setOperate

设置比较符操作

**方法签名：**
```java
public void setOperate(String operate)
```

**参数说明：**
- `operate`: `String`

---

### setValue

设置比较符值

**方法签名：**
```java
public void setValue(String value)
```

**参数说明：**
- `value`: `String`

---

### setVisible

设置是否可见

**方法签名：**
```java
public void setVisible(boolean isVisible)
```

**参数说明：**
- `isVisible`: `boolean`

---
