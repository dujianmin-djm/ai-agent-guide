---
framework_version: "8.0.1"
api_class: "IBasedataController"
api_package: "kd.bos.base"
when_to_use: "当你需要使用基础资料个性化逻辑控制功能接口时"
---

# IBasedataController API 说明

## 概述
基础资料个性化逻辑控制功能接口。实现 Serializable。
主要功能：构建基础资料内置过滤条件;。

## Import 路径
```java
import kd.bos.base.IBasedataController;
```

---

## 方法列表

### buildBaseDataCoreFilter

构建基础资料内置过滤条件;

**方法签名：**
```java
public void buildBaseDataCoreFilter(BaseDataCustomControllerEvent event)
```

**参数说明：**
- `event`: `BaseDataCustomControllerEvent`

---
