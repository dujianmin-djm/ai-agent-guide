---
framework_version: "8.0.1"
api_class: "ParamRow"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用参数行对象时"
---

# ParamRow API 说明

## 概述
参数行对象，用于表示单个参数的键值对信息。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.param.ParamRow;
```

---

## 方法列表

### getKey

获取参数的键对象

**方法签名：**
```java
public ParamKey getKey()
```

**返回值：**
- `ParamKey`: 参数的键

---

### getValue

获取参数的值

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`: 参数的值

---

### isLock

获取是否锁定的标志

**方法签名：**
```java
public boolean isLock()
```

**返回值：**
- `boolean`: 是否锁定

---

### isSync

获取是否同步的标志

**方法签名：**
```java
public boolean isSync()
```

**返回值：**
- `boolean`: 是否同步

---

### setKey

设置参数的键对象

**方法签名：**
```java
public void setKey(ParamKey key)
```

**参数说明：**
- `key`: `ParamKey` — 参数的键

---

### setLock

设置是否锁定的标志

**方法签名：**
```java
public void setLock(boolean lock)
```

**参数说明：**
- `lock`: `boolean` — 是否锁定

---

### setSync

设置是否同步的标志

**方法签名：**
```java
public void setSync(boolean sync)
```

**参数说明：**
- `sync`: `boolean` — 是否同步

---

### setValue

设置参数的值

**方法签名：**
```java
public void setValue(Object value)
```

**参数说明：**
- `value`: `Object` — 参数的值

---
