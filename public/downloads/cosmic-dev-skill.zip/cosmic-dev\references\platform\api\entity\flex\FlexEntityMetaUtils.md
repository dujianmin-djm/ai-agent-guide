---
framework_version: "8.0.1"
api_class: "FlexEntityMetaUtils"
api_package: "kd.bos.entity.flex"
when_to_use: "当你需要使用弹性域实体元数据工具时"
---

# FlexEntityMetaUtils API 说明

## 概述
弹性域实体元数据工具。
主要功能：读取属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.flex.FlexEntityMetaUtils;
```

---

## 方法列表

### clearFlexEntityMeta

暂未实现

**方法签名：**
```java
public static void clearFlexEntityMeta()
```

---

### createProperty

构造弹性域维度

**方法签名：**
```java
public static DynamicProperty createProperty(String flexFieldKey, FlexProperty flexProperty)
```

**参数说明：**
- `flexFieldKey`: `String`
- `flexProperty`: `FlexProperty`

**返回值：**
- `DynamicProperty`

---

### getBasedataPropFlexEntityType

**重载 1**

基础资料上弹性域实体类型

**方法签名：**
```java
public static FlexEntityType getBasedataPropFlexEntityType(String formNumber, String flexFieldKey, int flexTypeId, List<Long> propertyIds)
```

**参数说明：**
- `formNumber`: `String`
- `flexFieldKey`: `String`
- `flexTypeId`: `int`
- `propertyIds`: `List<Long>`

**返回值：**
- `FlexEntityType`

---

**重载 2**

基础资料上弹性域实体类型

**方法签名：**
```java
public static FlexEntityType getBasedataPropFlexEntityType(CreateFlexMetaArgs args)
```

**参数说明：**
- `args`: `CreateFlexMetaArgs`

**返回值：**
- `FlexEntityType`

---

### getFlexProperties

获取弹性域属性

**方法签名：**
```java
public static List<kd.FlexProperty> getFlexProperties(int flexTypeId)
```

**参数说明：**
- `flexTypeId`: `int`

**返回值：**
- `List<kd.FlexProperty>`

---

### getFlexProperty

**重载 1**

按弹性域属性内码取弹性域属性

**方法签名：**
```java
public static List<kd.FlexProperty> getFlexProperty(List<Long> propertyIds)
```

**参数说明：**
- `propertyIds`: `List<Long>`

**返回值：**
- `List<kd.FlexProperty>`

---

**重载 2**

根据flexField取flexproperty

**方法签名：**
```java
public static FlexProperty getFlexProperty(String flexField)
```

**参数说明：**
- `flexField`: `String`

**返回值：**
- `FlexProperty`

---

### getFlexType

获取弹性域实体

**方法签名：**
```java
public static FlexType getFlexType(int id)
```

**参数说明：**
- `id`: `int`

**返回值：**
- `FlexType`

---

### isFlexCacheRelease

弹性域缓存是否释放

**方法签名：**
```java
public static boolean isFlexCacheRelease()
```

**返回值：**
- `boolean`

---

### isFlexListBatchLoad

列表是否批量加载

**方法签名：**
```java
public static boolean isFlexListBatchLoad()
```

**返回值：**
- `boolean`

---

### isOutLog

是否开启输入日志

**方法签名：**
```java
public static boolean isOutLog()
```

**返回值：**
- `boolean`

---

### outLog

输出日志

**方法签名：**
```java
public static void outLog(String className, String method, String info)
```

**参数说明：**
- `className`: `String` — 类名
- `method`: `String` — 方法
- `info`: `String` — 日志信息

---
