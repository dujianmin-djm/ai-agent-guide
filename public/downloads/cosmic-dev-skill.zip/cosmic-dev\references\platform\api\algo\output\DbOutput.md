---
framework_version: "8.0.1"
api_class: "DbOutput"
api_package: "kd.bos.algo.output"
when_to_use: "当你需要使用将计算结果保存到数据库时"
---

# DbOutput API 说明

## 概述
将计算结果保存到数据库。继承自 AbstractOutput。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.algo.output.DbOutput;
```

---

## 方法列表

### getBatchInterval

获取分批参数

**方法签名：**
```java
public int getBatchInterval()
```

**返回值：**
- `int`: 分批参数

---

### getRequestContext

获取上下文

**方法签名：**
```java
public RequestContext getRequestContext()
```

**返回值：**
- `RequestContext`: rc 上下文

---

### getRouteKey

获取分库路由

**方法签名：**
```java
public String getRouteKey()
```

**返回值：**
- `String`: routeKey

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---

### getSql

获取执行保存的SQL

**方法签名：**
```java
public String getSql()
```

**返回值：**
- `String`: sql

---

### getSqlTypes

获取SqlTypes

**方法签名：**
```java
public int[] getSqlTypes()
```

**返回值：**
- `int[]`: sqlTypes

---

### isNeedTx

是否事务保存

**方法签名：**
```java
public boolean isNeedTx()
```

**返回值：**
- `boolean`: true=事务中保存，false不在事务中保存

---

### setBatchInterval

设置分批参数

**方法签名：**
```java
public void setBatchInterval(int batchInterval)
```

**参数说明：**
- `batchInterval`: `int` — 分批参数

---

### setNeedTx

是否需要事务保存

**方法签名：**
```java
public void setNeedTx(boolean needTx)
```

**参数说明：**
- `needTx`: `boolean` — true=需要，false=不需要

---

### setRequestContext

设置上下文

**方法签名：**
```java
public void setRequestContext(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext` — 上下文

---

### setRowMeta

设置元数据

**方法签名：**
```java
public void setRowMeta(RowMeta rowMeta)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据

---

### setSqlTypes

设置SQL数据类型

**方法签名：**
```java
public void setSqlTypes(int[] sqlTypes)
```

**参数说明：**
- `sqlTypes`: `int[]` — 数据库字段类型

---
