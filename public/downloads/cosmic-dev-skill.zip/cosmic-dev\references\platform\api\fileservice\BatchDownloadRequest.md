---
framework_version: "8.0.1"
api_class: "BatchDownloadRequest"
api_package: "kd.bos.fileservice"
when_to_use: "当你需要使用批量下载请求实体时"
---

# BatchDownloadRequest API 说明

## 概述
批量下载请求实体，支持层级化文件结构打包功能。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.fileservice.BatchDownloadRequest;
```

---

## 方法列表

### getDirs

getter方法，获得压缩包内根路径下，目录结构定义对象

**方法签名：**
```java
public BatchDownloadRequest.Dir[] getDirs()
```

**返回值：**
- `BatchDownloadRequest.Dir[]`

---

### getFileName

getter方法，获取目标压缩文件基名称

**方法签名：**
```java
public String getFileName()
```

**返回值：**
- `String`

---

### getFiles

getter方法，获取位于压缩包根目录的直接文件列表

**方法签名：**
```java
public BatchDownloadRequest.File[] getFiles()
```

**返回值：**
- `BatchDownloadRequest.File[]`

---

### getType

getter方法，获取压缩类型

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### setDirs

setter方法，设置压缩包内根路径下，目录结构定义对象

**方法签名：**
```java
public void setDirs(BatchDownloadRequest.Dir[] dirs)
```

**参数说明：**
- `dirs`: `BatchDownloadRequest.Dir[]`

---

### setFiles

setter方法，设置位于压缩包根目录的直接文件列表

**方法签名：**
```java
public void setFiles(BatchDownloadRequest.File[] files)
```

**参数说明：**
- `files`: `BatchDownloadRequest.File[]`

---
