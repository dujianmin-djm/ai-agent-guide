---
framework_version: "8.0.1"
api_class: "AtomicIncrement"
api_package: "kd.bos.atomicincr"
when_to_use: "当你需要使用 AtomicIncrement 相关功能时"
---

# AtomicIncrement API 说明

## 概述
AtomicIncrement 类。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.atomicincr.AtomicIncrement;
```

---

## 方法列表

### batchGet

批量获取key的值

**方法签名：**
```java
public Map<String,Long> batchGet(Set<String> keys)
```

**参数说明：**
- `keys`: `Set<String>` — key集合

**返回值：**
- `Map<String,Long>`: key-value map结果集

---

### compareAndSet

如果key的当前值小于入参value，则将当前key值设置为value

**方法签名：**
```java
public boolean compareAndSet(String key, long value)
```

**参数说明：**
- `key`: `String` — 自增key
- `value`: `long` — 设置key的结果

**返回值：**
- `boolean`: 是否设置成功

---

### decr

**重载 1**

自减，步长1

**方法签名：**
```java
public Long decr(String key)
```

**参数说明：**
- `key`: `String` — 自增key

**返回值：**
- `Long`: 自减后的值

---

**重载 2**

自减，指定步长

**方法签名：**
```java
public Long decr(String key, int step)
```

**参数说明：**
- `key`: `String` — 自增key
- `step`: `int` — 步长，大于0

**返回值：**
- `Long`: 自减后的值

---

### del

删除key，会从数据库中删除key，无法恢复。

**方法签名：**
```java
public void del(String key)
```

**参数说明：**
- `key`: `String` — 自增key

---

### exist

判断key是否存在

**方法签名：**
```java
public boolean exist(String key)
```

**参数说明：**
- `key`: `String` — 自增key

**返回值：**
- `boolean`: 若存在返回true，否则返回false

---

### get

获取自增key的当前值

**方法签名：**
```java
public Long get(String key)
```

**参数说明：**
- `key`: `String` — 自增key

**返回值：**
- `Long`: key的当前值

---

### getInstance

获取自增服务实例

**方法签名：**
```java
public static AtomicIncrement getInstance(String module)
```

**参数说明：**
- `module`: `String` — 模块

**返回值：**
- `AtomicIncrement`: 自增服务实例

---

### incr

**重载 1**

自增，步长1

**方法签名：**
```java
public Long incr(String key)
```

**参数说明：**
- `key`: `String` — 自增key

**返回值：**
- `Long`: 自增后的值

---

**重载 2**

自增，步长step

**方法签名：**
```java
public Long incr(String key, int step)
```

**参数说明：**
- `key`: `String` — 自增key
- `step`: `int` — 自增步长

**返回值：**
- `Long`: 自增后的值

---

### setnx

set if not exist

**方法签名：**
```java
public void setnx(String key, long initValue)
```

**参数说明：**
- `key`: `String` — 自增key
- `initValue`: `long` — 初始值

---
