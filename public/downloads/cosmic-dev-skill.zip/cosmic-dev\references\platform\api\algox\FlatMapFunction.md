---
framework_version: "8.0.1"
api_class: "FlatMapFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用展开RowX时"
---

# FlatMapFunction API 说明

## 概述
展开RowX，一行RowX生成多行RowX。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：展开RowX,对rowX生成多行数据后，。

## Import 路径
```java
import kd.bos.algox.FlatMapFunction;
```

---

## 方法列表

### flatMap

展开RowX,对rowX生成多行数据后，通过collector将数据输出到下个结算节点

**方法签名：**
```java
public abstract void flatMap(RowX rowX, Collector collector)
```

**参数说明：**
- `rowX`: `RowX` — 当前行
- `collector`: `Collector` — 收集器

---
