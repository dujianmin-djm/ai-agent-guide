---
framework_version: "8.0.1"
api_class: "AICommand"
api_package: "kd.bos.entity.api"
when_to_use: "当你需要使用WepApi请求时"
---

# AICommand API 说明

## 概述
WepApi请求，AI指令参数。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.api.AICommand;
```

---

## 方法列表

### getAppId

获取appId

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`

---

### getCommand

获取指令

**方法签名：**
```java
public String getCommand()
```

**返回值：**
- `String`

---

### getOpenId

获取openid

**方法签名：**
```java
public String getOpenId()
```

**返回值：**
- `String`

---

### getParameter

获取参数

**方法签名：**
```java
public Map<String,Object> getParameter()
```

**返回值：**
- `Map<String,Object>`

---

### getTaskId

获取任务id

**方法签名：**
```java
public String getTaskId()
```

**返回值：**
- `String`

---

### getToken

获取token

**方法签名：**
```java
public String getToken()
```

**返回值：**
- `String`

---

### setAppId

设置appId

**方法签名：**
```java
public void setAppId(String app)
```

**参数说明：**
- `app`: `String`

---

### setCommand

设置指令

**方法签名：**
```java
public void setCommand(String cmd)
```

**参数说明：**
- `cmd`: `String`

---

### setOpenId

设置openid

**方法签名：**
```java
public void setOpenId(String openid)
```

**参数说明：**
- `openid`: `String`

---

### setParameter

设置参数

**方法签名：**
```java
public void setParameter(Map<String,Object> param)
```

**参数说明：**
- `param`: `Map<String,Object>`

---

### setTaskId

设置任务id

**方法签名：**
```java
public void setTaskId(String taskId)
```

**参数说明：**
- `taskId`: `String`

---

### setToken

设置token

**方法签名：**
```java
public void setToken(String token)
```

**参数说明：**
- `token`: `String`

---
