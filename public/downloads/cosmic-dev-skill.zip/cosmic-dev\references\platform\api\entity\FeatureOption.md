---
framework_version: "8.0.1"
api_class: "FeatureOption"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用字段功能控制选项时"
---

# FeatureOption API 说明

## 概述
字段功能控制选项。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.FeatureOption;
```

---

## 方法列表

### getValue

获取当前功能选项的二进制位标志值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`: 当前选项的二进制位权值，用于构建功能组合标识

---
