---
framework_version: "8.0.1"
api_class: "OqlInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用使用orm作为创建一个DataSet的输入源时"
---

# OqlInput API 说明

## 概述
使用orm作为创建一个DataSet的输入源，只是这里使用的oql语句，而非参数形式。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.OqlInput;
```

---

## 方法列表

### getAlgoKey

获取algoKey

**方法签名：**
```java
public String getAlgoKey()
```

**返回值：**
- `String`: algoKey 用来标识DataSet

---

### getOql

获取oql语句

**方法签名：**
```java
public String getOql()
```

**返回值：**
- `String`: oql语句

---

### getParams

获取oql参数

**方法签名：**
```java
public Object[] getParams()
```

**返回值：**
- `Object[]`: oql参数

---

### getRequestContext

获取请求上下文信息

**方法签名：**
```java
public RequestContext getRequestContext()
```

**返回值：**
- `RequestContext`: 请求上下文信息

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
