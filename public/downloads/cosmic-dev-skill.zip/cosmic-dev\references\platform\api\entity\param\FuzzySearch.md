---
framework_version: "8.0.1"
api_class: "FuzzySearch"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用模糊查询对象时"
---

# FuzzySearch API 说明

## 概述
模糊查询对象。。
主要功能：设置属性、读取属性。

## Import 路径
```java
import kd.bos.entity.param.FuzzySearch;
```

---

## 方法列表

### getComboListFields

获取模糊查询列头字段

**方法签名：**
```java
public List<kd.ShowColumn> getComboListFields()
```

**返回值：**
- `List<kd.ShowColumn>`: 模糊查询列头字段

---

### getPageSize

获取分页大小

**方法签名：**
```java
public int getPageSize()
```

**返回值：**
- `int`: 分页大小

---

### getSearchFields

获取查询字段

**方法签名：**
```java
public List<String> getSearchFields()
```

**返回值：**
- `List<String>`: 查询字段

---

### getSortOrder

获取模糊查询排序方式

**方法签名：**
```java
public String getSortOrder()
```

**返回值：**
- `String`: 模糊查询排序方式

---

### setComboListFields

设置模糊查询列头字段

**方法签名：**
```java
public void setComboListFields(List<kd.ShowColumn> comboListFields)
```

**参数说明：**
- `comboListFields`: `List<kd.ShowColumn>` — 模糊查询列头字段

---

### setDefaultSort

设置默认排序标志位

**方法签名：**
```java
public void setDefaultSort(boolean defaultSort)
```

**参数说明：**
- `defaultSort`: `boolean` — 默认排序标志位

---

### setF7FullName

设置F7全名的标志位

**方法签名：**
```java
public void setF7FullName(boolean f7FullName)
```

**参数说明：**
- `f7FullName`: `boolean` — 一个布尔值，用于指示是否使用F7全名

---

### setPageSize

设置分页大小

**方法签名：**
```java
public void setPageSize(int pageSize)
```

**参数说明：**
- `pageSize`: `int` — 分页大小

---

### setSearchFields

设置查询字段

**方法签名：**
```java
public void setSearchFields(List<String> searchFields)
```

**参数说明：**
- `searchFields`: `List<String>` — 查询字段

---

### setSortOrder

设置模糊查询排序方式

**方法签名：**
```java
public void setSortOrder(String sortOrder)
```

**参数说明：**
- `sortOrder`: `String` — 模糊查询排序方式

---
