---
framework_version: "8.0.1"
api_class: "RowDataModel"
api_package: "kd.bos.entity.formula"
when_to_use: "当你需要使用行数据模型时"
---

# RowDataModel API 说明

## 概述
行数据模型。
主要功能：读取属性、设置属性、查询数据。

## Import 路径
```java
import kd.bos.entity.formula.RowDataModel;
```

---

## 方法列表

### compareEntityLevel

比较两个实体的等级，如果e1是父级，返回-1; 如果e1是子级，则返回1;

**方法签名：**
```java
public static int compareEntityLevel(EntityType e1, EntityType e2)
```

**参数说明：**
- `e1`: `EntityType` — 第一个实体
- `e2`: `EntityType` — 第二个实体

**返回值：**
- `int`: 实体等级比较的结果

---

### findProperty

从单据主实体中，寻找变量对应的字段返回：变量名，可能包含了单据体前缀，或者是基础资料的引用属性，本函数会对变量按"."进行分解，找出原始字段属性返回

**方法签名：**
```java
public static DynamicProperty findProperty(MainEntityType mainType, String var)
```

**参数说明：**
- `mainType`: `MainEntityType` — 主实体
- `var`: `String` — 变量

**返回值：**
- `DynamicProperty`: 变量在实体中对应的属性

---

### get

取字段值，已废弃

**方法签名：**
```java
public Object get(String var, int rowIndex)
```

**参数说明：**
- `var`: `String` — 字段
- `rowIndex`: `int` — 字段所在实体行

**返回值：**
- `Object`

---

### getActiveRow

焦点行

**方法签名：**
```java
public Object getActiveRow()
```

**返回值：**
- `Object`: 焦点行

---

### getEntityKey

焦点实体名

**方法签名：**
```java
public String getEntityKey()
```

**返回值：**
- `String`: 实体key

---

### getEntityType

焦点实体

**方法签名：**
```java
public EntityType getEntityType()
```

**返回值：**
- `EntityType`: 实体类型

---

### getMainEntityType

主实体

**方法签名：**
```java
public MainEntityType getMainEntityType()
```

**返回值：**
- `MainEntityType`: 主实体类型

---

### getModel

获取当前数据模型

**方法签名：**
```java
public IDataModel getModel()
```

**返回值：**
- `IDataModel`

---

### getSource

焦点实体

**方法签名：**
```java
public String getSource()
```

**返回值：**
- `String`: 实体key

---

### getSourceLevel

焦点实体级别：0 = 单据头，1 = 单据体，2 = 子单据体

**方法签名：**
```java
public int getSourceLevel()
```

**返回值：**
- `int`: 实体级别

---

### getValue

取变量值

**方法签名：**
```java
public Object getValue(String var)
```

**参数说明：**
- `var`: `String` — 变量，如"dept.number"、"entryentity1.id"

**返回值：**
- `Object`: 如果在当前实体上取字段值，返回单值；如果在子实体中取值，返回值集合

---

### setRowContext

**重载 1**

设置焦点实体的当前数据行

**方法签名：**
```java
public void setRowContext(DynamicObject activeRow)
```

**参数说明：**
- `activeRow`: `DynamicObject` — 焦点实体的当前数据行

---

**重载 2**

设置焦点实体的当前数据行

**方法签名：**
```java
public void setRowContext(Object activeRow, int rowIndex)
```

**参数说明：**
- `activeRow`: `Object` — 焦点实体的当前数据行
- `rowIndex`: `int` — 当前实体行序号

---

### setValue

填写变量值

**方法签名：**
```java
public void setValue(String var, Object value)
```

**参数说明：**
- `var`: `String` — 变量，如 "billnoResManager.loadKDString("等，不支持给嵌套的属性赋值（如", "602753689555305472", SubSystemType.SL)dept.number"）
- `value`: `Object` — 变量值

---

### tryGetValue

尝试取变量值

**方法签名：**
```java
public Boolean tryGetValue(String var, OutValue<Object> value)
```

**参数说明：**
- `var`: `String` — 变量名
- `value`: `OutValue<Object>` — 输出变量值

**返回值：**
- `Boolean`: 如果取值失败，返回false

---
