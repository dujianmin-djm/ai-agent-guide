---
framework_version: "8.0.1"
api_class: "TileItem"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用平铺项时"
---

# TileItem API 说明

## 概述
平铺项。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.TileItem;
```

---

## 方法列表

### getContent

获取内容

**方法签名：**
```java
public String getContent()
```

**返回值：**
- `String`

---

### getId

获取id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getItems

获取平铺子项

**方法签名：**
```java
public List<kd.TileItem> getItems()
```

**返回值：**
- `List<kd.TileItem>`

---

### isSelected

是否选中

**方法签名：**
```java
public boolean isSelected()
```

**返回值：**
- `boolean`

---

### setContent

设置内容

**方法签名：**
```java
public void setContent(String content)
```

**参数说明：**
- `content`: `String`

---

### setId

设置id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setItems

设置平铺子项

**方法签名：**
```java
public void setItems(List<kd.TileItem> items)
```

**参数说明：**
- `items`: `List<kd.TileItem>`

---

### setSelected

设置是否选中

**方法签名：**
```java
public void setSelected(boolean selected)
```

**参数说明：**
- `selected`: `boolean`

---
