---
framework_version: "8.0.1"
api_class: "CodeRuleInfo"
api_package: "kd.bos.coderule.api"
when_to_use: "当你需要使用编码规则配置信息类时"
---

# CodeRuleInfo API 说明

## 概述
编码规则配置信息类。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.coderule.api.CodeRuleInfo;
```

---

## 方法列表

### getCodeRuleNumber

获取编码规则编码

**方法签名：**
```java
public String getCodeRuleNumber()
```

**返回值：**
- `String`: 编码规则编码

---

### getEnableCondition

获取启动条件配置
 通用过滤控件序列化数据
 可通过此方式反序列化使用：`FilterCondition condition = SerializationUtils.fromJsonString(enableCondition, FilterCondition.class)`

**方法签名：**
```java
public String getEnableCondition()
```

**返回值：**
- `String`: 启动条件配置

---

### getEntityId

获取业务对象编码

**方法签名：**
```java
public String getEntityId()
```

**返回值：**
- `String`: 业务对象编码

---

### getId

获取编码规则id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 编码规则id

---

### getIsAddView

是否开启新增显示

**方法签名：**
```java
public Boolean getIsAddView()
```

**返回值：**
- `Boolean`: true：开启新增显示；false：关闭新增显示

---

### getIsModifiable

是否开启允许修改

**方法签名：**
```java
public Boolean getIsModifiable()
```

**返回值：**
- `Boolean`: true：开启允许修改；false：未开启允许修改

---

### getIsNonBreak

是否开启断号补偿

**方法签名：**
```java
public Boolean getIsNonBreak()
```

**返回值：**
- `Boolean`: true：开启断号补偿；false：关闭断号补偿

---

### getName

获取编码规则名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 编码规则名称

---

### getOrgEntry

获取受控组织配置信息

**方法签名：**
```java
public List<kd.OrgEntryInfo> getOrgEntry()
```

**返回值：**
- `List<kd.OrgEntryInfo>`: 受控组织配置信息

---

### getOrgId

获取使用组织id

**方法签名：**
```java
public long getOrgId()
```

**返回值：**
- `long`: 使用组织id

---

### getRuleEntry

获取编码规则的编码段信息

**方法签名：**
```java
public List<kd.CodeRuleEntryInfo> getRuleEntry()
```

**返回值：**
- `List<kd.CodeRuleEntryInfo>`: 编码段信息

---

### getSplitSign

获取分隔符

**方法签名：**
```java
public String getSplitSign()
```

**返回值：**
- `String`: 分隔符

---

### getUpdateMaxNumber

获取修改编码时更新最大号的场景，界面上是下拉选。包含导入、下推和修改三种场景

**方法签名：**
```java
public String getUpdateMaxNumber()
```

**返回值：**
- `String`: 修改编码时更新最大号的场景

---

### getUseInterruption

获取修改编码时使用断号的场景，界面上是下拉选。包含导入、下推和修改三种场景

**方法签名：**
```java
public String getUseInterruption()
```

**返回值：**
- `String`: 修改编码时使用断号的场景

---

### isAutoIncrLength

是否流水号自动升位

**方法签名：**
```java
public Boolean isAutoIncrLength()
```

**返回值：**
- `Boolean`: true：自动升位；false：限制固定长度

---

### isCheckNumber

是否校验编码格式

**方法签名：**
```java
public Boolean isCheckNumber()
```

**返回值：**
- `Boolean`: true：校验编码格式；false：不校验编码格式

---

### isFillWithZero

是否用0补位

**方法签名：**
```java
public Boolean isFillWithZero()
```

**返回值：**
- `Boolean`: true：用0补位；false：不用0补位

---

### isUpdateRecover

是否开启修改时重新编码

**方法签名：**
```java
public boolean isUpdateRecover()
```

**返回值：**
- `boolean`: true：开启修改时重新编码；false：关闭修改时重新编码

---
