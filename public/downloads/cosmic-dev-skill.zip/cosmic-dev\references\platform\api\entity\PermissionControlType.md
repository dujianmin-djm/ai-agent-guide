---
framework_version: "8.0.1"
api_class: "PermissionControlType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用权限控制类型时"
---

# PermissionControlType API 说明

## 概述
权限控制类型。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.PermissionControlType;
```

---

## 方法列表

### getDataAssistDimension

获取辅字段权限

**方法签名：**
```java
public String getDataAssistDimension()
```

**返回值：**
- `String`

---

### getDataAssistDimensionField

获取权限控制辅字段

**方法签名：**
```java
public String getDataAssistDimensionField()
```

**返回值：**
- `String`

---

### getDataDimension

获取主字段权限

**方法签名：**
```java
public String getDataDimension()
```

**返回值：**
- `String`

---

### getDataDimensionField

获取权限控制主字段

**方法签名：**
```java
public String getDataDimensionField()
```

**返回值：**
- `String`

---

### getDimension

获取权限类型

**方法签名：**
```java
public String getDimension()
```

**返回值：**
- `String`

---

### getPublishApps

获取权限发布应用

**方法签名：**
```java
public List<String> getPublishApps()
```

**返回值：**
- `List<String>`

---

### isAllowFrontAccess

是否允许前端访问

**方法签名：**
```java
public boolean isAllowFrontAccess()
```

**返回值：**
- `boolean`

---

### isAnonymousUserControl

是否是匿名用户

**方法签名：**
```java
public boolean isAnonymousUserControl()
```

**返回值：**
- `boolean`

---

### isControlFunction

是否控制功能权限

**方法签名：**
```java
public boolean isControlFunction()
```

**返回值：**
- `boolean`

---

### isEmptyObject

用于标记该权限对象是否是new出来的空对象

**方法签名：**
```java
public boolean isEmptyObject()
```

**返回值：**
- `boolean`

---

### isForbidDataPerm

是否停用数据权限

**方法签名：**
```java
public boolean isForbidDataPerm()
```

**返回值：**
- `boolean`

---

### setAllowFrontAccess

设置是否允许前端访问

**方法签名：**
```java
public void setAllowFrontAccess(boolean allowFrontAccess)
```

**参数说明：**
- `allowFrontAccess`: `boolean`

---

### setAnonymousUserControl

设置是否是匿名用户

**方法签名：**
```java
public void setAnonymousUserControl(boolean isAnonymousUserControl)
```

**参数说明：**
- `isAnonymousUserControl`: `boolean`

---

### setControlFunction

设置是否控制功能权限

**方法签名：**
```java
public void setControlFunction(boolean isControlFunction)
```

**参数说明：**
- `isControlFunction`: `boolean`

---

### setDataAssistDimension

设置辅字段权限

**方法签名：**
```java
public void setDataAssistDimension(String dataAssistDimension)
```

**参数说明：**
- `dataAssistDimension`: `String`

---

### setDataAssistDimensionField

设置权限控制辅字段

**方法签名：**
```java
public void setDataAssistDimensionField(String dataAssistDimensionField)
```

**参数说明：**
- `dataAssistDimensionField`: `String`

---

### setDataDimension

设置主字段权限

**方法签名：**
```java
public void setDataDimension(String dataDimension)
```

**参数说明：**
- `dataDimension`: `String`

---

### setDataDimensionField

设置权限控制主字段

**方法签名：**
```java
public void setDataDimensionField(String dataDimensionField)
```

**参数说明：**
- `dataDimensionField`: `String`

---

### setDimension

设置权限类型

**方法签名：**
```java
public void setDimension(String dimension)
```

**参数说明：**
- `dimension`: `String`

---

### setEmptyObject

设置该权限对象是否是new出来的空对象

**方法签名：**
```java
public void setEmptyObject(boolean isEmptyObject)
```

**参数说明：**
- `isEmptyObject`: `boolean`

---

### setForbidDataPerm

设置是否停用数据权限

**方法签名：**
```java
public void setForbidDataPerm(boolean isForbidDataPerm)
```

**参数说明：**
- `isForbidDataPerm`: `boolean`

---

### setPublishApps

设置权限发布应用

**方法签名：**
```java
public void setPublishApps(List<String> publishApps)
```

**参数说明：**
- `publishApps`: `List<String>`

---
