---
framework_version: "8.0.1"
api_class: "FilterBuilderParameter"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用 FilterBuilderParameter 相关功能时"
---

# FilterBuilderParameter API 说明

## 概述
FilterBuilderParameter 类。
主要功能：读取属性、设置属性、状态判断、添加元素。

## Import 路径
```java
import kd.bos.entity.filter.FilterBuilderParameter;
```

---

## 方法列表

### addFlexField

添加弹性域字段

**方法签名：**
```java
public FilterBuilderParameter addFlexField(String flexField)
```

**参数说明：**
- `flexField`: `String`

**返回值：**
- `FilterBuilderParameter`

---

### getDataType

实体类型

**方法签名：**
```java
public MainEntityType getDataType()
```

**返回值：**
- `MainEntityType`

---

### getFilterCondition

过滤条件元数据

**方法签名：**
```java
public FilterCondition getFilterCondition()
```

**返回值：**
- `FilterCondition`

---

### getFilterFields

过滤字段解析需要的工具类集合 FilterField

**方法签名：**
```java
public List<kd.FilterField> getFilterFields()
```

**返回值：**
- `List<kd.FilterField>`

---

### getFilterValueSetter

字段取值接口

**方法签名：**
```java
public IFilterValueSetter getFilterValueSetter()
```

**返回值：**
- `IFilterValueSetter`

---

### getFlexFields

获取弹性域字段

**方法签名：**
```java
public Set<String> getFlexFields()
```

**返回值：**
- `Set<String>`

---

### isCheckInput

是否进行输入校验，即进行真正的解析，如果是false，只会解析出过滤条件描述，不会生成QFilter

**方法签名：**
```java
public boolean isCheckInput()
```

**返回值：**
- `boolean`

---

### isNeedParse

是否需要解析

**方法签名：**
```java
public boolean isNeedParse()
```

**返回值：**
- `boolean`

---

### isNeedParseBaseDataIds

是否需要解析基础资料id

**方法签名：**
```java
public boolean isNeedParseBaseDataIds()
```

**返回值：**
- `boolean`

---

### setCheckInput

设置是否进行输入校验

**方法签名：**
```java
public FilterBuilderParameter setCheckInput(boolean checkInput)
```

**参数说明：**
- `checkInput`: `boolean`

**返回值：**
- `FilterBuilderParameter`

---

### setFilterFields

设置过滤字段

**方法签名：**
```java
public FilterBuilderParameter setFilterFields(List<kd.FilterField> filterFields)
```

**参数说明：**
- `filterFields`: `List<kd.FilterField>`

**返回值：**
- `FilterBuilderParameter`

---

### setFilterValueSetter

设置过滤条件值解析器

**方法签名：**
```java
public FilterBuilderParameter setFilterValueSetter(IFilterValueSetter filterValueSetter)
```

**参数说明：**
- `filterValueSetter`: `IFilterValueSetter`

**返回值：**
- `FilterBuilderParameter`

---

### setNeedParse

设置是否需要解析

**方法签名：**
```java
public FilterBuilderParameter setNeedParse(boolean needParse)
```

**参数说明：**
- `needParse`: `boolean`

**返回值：**
- `FilterBuilderParameter`

---

### setNeedParseBaseDataIds

设置是否需要解析基础资料id

**方法签名：**
```java
public FilterBuilderParameter setNeedParseBaseDataIds(boolean needParseBaseDataIds)
```

**参数说明：**
- `needParseBaseDataIds`: `boolean`

**返回值：**
- `FilterBuilderParameter`

---
