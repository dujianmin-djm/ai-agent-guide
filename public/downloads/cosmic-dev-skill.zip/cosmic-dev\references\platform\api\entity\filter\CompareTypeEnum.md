---
framework_version: "8.0.1"
api_class: "CompareTypeEnum"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤比较符枚举时"
---

# CompareTypeEnum API 说明

## 概述
过滤比较符枚举，供业务插件使用，用来设置常用过滤字段常量。实现 Comparable, Serializable。
主要功能：创建对象、读取属性。

## Import 路径
```java
import kd.bos.entity.filter.CompareTypeEnum;
```

---

## 方法列表

### createCompareTypeEnum

根据比较符id获取过滤比较符

**方法签名：**
```java
public static CompareTypeEnum createCompareTypeEnum(String id)
```

**参数说明：**
- `id`: `String` — 比较符id

**返回值：**
- `CompareTypeEnum`

---

### getId

获取比较符id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 比较符id

---
