---
framework_version: "8.0.1"
api_class: "HashTable"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用hash表接口时"
---

# HashTable API 说明

## 概述
hash表接口，可以用来与dataset进行互转。。
主要功能：关闭资源。

## Import 路径
```java
import kd.bos.algo.HashTable;
```

---

## 方法列表

### close

关闭资源

**方法签名：**
```java
public void close()
```

---
