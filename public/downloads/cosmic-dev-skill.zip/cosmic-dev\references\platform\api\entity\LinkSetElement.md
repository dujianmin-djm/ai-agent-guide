---
framework_version: "8.0.1"
api_class: "LinkSetElement"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用单据关联配置：运行时元数据对象时"
---

# LinkSetElement API 说明

## 概述
单据关联配置：运行时元数据对象。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.LinkSetElement;
```

---

## 方法列表

### getConvRulePlugIns

单据转换规则，界面配置控制插件

**方法签名：**
```java
public List<kd.CRPlugin> getConvRulePlugIns()
```

**返回值：**
- `List<kd.CRPlugin>`

---

### getItems

各实体关联配置集合

**方法签名：**
```java
public List<kd.LinkSetItemElement> getItems()
```

**返回值：**
- `List<kd.LinkSetItemElement>`

---

### getPlugIns

单据反写插件

**方法签名：**
```java
public List<kd.CRPlugin> getPlugIns()
```

**返回值：**
- `List<kd.CRPlugin>`

---

### getTrackerTable

业务流程跟踪表

**方法签名：**
```java
public String getTrackerTable()
```

**返回值：**
- `String`

---

### getWbSnapTable

反写快照表

**方法签名：**
```java
public String getWbSnapTable()
```

**返回值：**
- `String`

---

### setConvRulePlugIns

设置单据转换规则，界面配置控制插件

**方法签名：**
```java
public void setConvRulePlugIns(List<kd.CRPlugin> convRulePlugIns)
```

**参数说明：**
- `convRulePlugIns`: `List<kd.CRPlugin>`

---

### setItems

设置各实体关联配置集合

**方法签名：**
```java
public void setItems(List<kd.LinkSetItemElement> items)
```

**参数说明：**
- `items`: `List<kd.LinkSetItemElement>`

---

### setPlugIns

设置单据反写插件

**方法签名：**
```java
public void setPlugIns(List<kd.CRPlugin> plugIns)
```

**参数说明：**
- `plugIns`: `List<kd.CRPlugin>`

---

### setTrackerTable

设置业务流程跟踪表

**方法签名：**
```java
public void setTrackerTable(String trackerTable)
```

**参数说明：**
- `trackerTable`: `String`

---

### setWbSnapTable

设置反写快照表

**方法签名：**
```java
public void setWbSnapTable(String wbSnapTable)
```

**参数说明：**
- `wbSnapTable`: `String`

---
