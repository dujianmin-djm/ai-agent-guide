---
framework_version: "8.0.1"
api_class: "DataSetInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用使用另外一个DataSet作为构建DataSet的输入源时"
---

# DataSetInput API 说明

## 概述
使用另外一个DataSet作为构建DataSet的输入源。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.DataSetInput;
```

---

## 方法列表

### getDataSet

获取源DataSet

**方法签名：**
```java
public DataSet getDataSet()
```

**返回值：**
- `DataSet`: 源DataSet

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
