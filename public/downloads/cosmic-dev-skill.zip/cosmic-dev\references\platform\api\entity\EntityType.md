---
framework_version: "8.0.1"
api_class: "EntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用抽象实体模型时"
---

# EntityType API 说明

## 概述
抽象实体模型。继承自 DynamicObjectType。
主要功能：读取属性、状态判断、添加元素、创建对象。

## Import 路径
```java
import kd.bos.entity.EntityType;
```

---

## 方法列表

### addProperty

添加属性

**方法签名：**
```java
public void addProperty(DynamicProperty prop)
```

**参数说明：**
- `prop`: `DynamicProperty`

---

### beginInit

开始初始化

**方法签名：**
```java
public void beginInit()
```

---

### createPropIndexs

创建实体属性关系

**方法签名：**
```java
public void createPropIndexs()
```

---

### endInit

结束初始化

**方法签名：**
```java
public synchronized void endInit()
```

---

### findProperty

查找属性

**方法签名：**
```java
public IDataEntityProperty findProperty(String name)
```

**参数说明：**
- `name`: `String` — 属性名称

**返回值：**
- `IDataEntityProperty`: 实体属性

---

### getFields

获取本实体的字段清单

**方法签名：**
```java
public Map<String,IDataEntityProperty> getFields()
```

**返回值：**
- `Map<String,IDataEntityProperty>`: 实体属性列表

---

### getRuleCount

获取规则数量

**方法签名：**
```java
public int getRuleCount()
```

**返回值：**
- `int`: 规则数量

---

### getSubEntityType

根据实体属性构造一个新的属性

**方法签名：**
```java
public final EntityType getSubEntityType(Collection<String> properties)
```

**参数说明：**
- `properties`: `Collection<String>` — 属性列表

**返回值：**
- `EntityType`: 返回实体属性

---

### isDbIgnore

数据库字段

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---

### isInitialized

正在初始化

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### setRuleCount

设置规则数量

**方法签名：**
```java
public void setRuleCount(int ruleCount)
```

**参数说明：**
- `ruleCount`: `int` — 规则数量

---
