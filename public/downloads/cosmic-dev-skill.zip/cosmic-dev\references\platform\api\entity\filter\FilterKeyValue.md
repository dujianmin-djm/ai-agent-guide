---
framework_version: "8.0.1"
api_class: "FilterKeyValue"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤元数据字段名和值实例类时"
---

# FilterKeyValue API 说明

## 概述
过滤元数据字段名和值实例类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterKeyValue;
```

---

## 方法列表

### getId

获取PK,序列化使用

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: PK

---

### getKey

获取字段名

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`: 字段名

---

### getValue

获取值

**方法签名：**
```java
public List<Object> getValue()
```

**返回值：**
- `List<Object>`: 值

---
