---
framework_version: "8.0.1"
api_class: "CoGroupDataSetX"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分组协作数据集时"
---

# CoGroupDataSetX API 说明

## 概述
分组协作数据集。继承自 AbstractDataSetX，实现 DataSetX。
主要功能：事件处理。

## Import 路径
```java
import kd.bos.algox.CoGroupDataSetX;
```

---

## 方法列表

### on

指定分组协作字段，类似于SQL JOIN中的on

**方法签名：**
```java
public CoGroupDataSetX on(String leftField, String rightField)
```

**参数说明：**
- `leftField`: `String` — 左数据集中的字段名
- `rightField`: `String` — 右数据集中的字段名

**返回值：**
- `CoGroupDataSetX`: 数据集

---
