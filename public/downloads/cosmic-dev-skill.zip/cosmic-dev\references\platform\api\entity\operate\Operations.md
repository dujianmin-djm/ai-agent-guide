---
framework_version: "8.0.1"
api_class: "Operations"
api_package: "kd.bos.entity.operate"
when_to_use: "当你需要使用系统的操作时"
---

# Operations API 说明

## 概述
系统的操作，描述实体上系统操作对应的代码。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.Operations;
```

---

## 方法列表

### getAudit

获取审核操作代码

**方法签名：**
```java
public String getAudit()
```

**返回值：**
- `String`

---

### getDelete

获取删除操作代码

**方法签名：**
```java
public String getDelete()
```

**返回值：**
- `String`

---

### getSave

获取保存操作代码

**方法签名：**
```java
public String getSave()
```

**返回值：**
- `String`

---

### getStatusConvert

获取状态转换操作代码

**方法签名：**
```java
public String getStatusConvert()
```

**返回值：**
- `String`

---

### getSubmit

获取提交操作代码

**方法签名：**
```java
public String getSubmit()
```

**返回值：**
- `String`

---

### getUnAudit

获取反审核操作代码

**方法签名：**
```java
public String getUnAudit()
```

**返回值：**
- `String`

---

### getUnSubmit

获取撤销操作代码

**方法签名：**
```java
public String getUnSubmit()
```

**返回值：**
- `String`

---

### setAudit

设置审核操作代码

**方法签名：**
```java
public void setAudit(String audit)
```

**参数说明：**
- `audit`: `String`

---

### setDelete

设置删除操作代码

**方法签名：**
```java
public void setDelete(String delete)
```

**参数说明：**
- `delete`: `String`

---

### setSave

设置保存操作代码

**方法签名：**
```java
public void setSave(String save)
```

**参数说明：**
- `save`: `String`

---

### setStatusConvert

设置状态转换操作代码

**方法签名：**
```java
public void setStatusConvert(String statusConvert)
```

**参数说明：**
- `statusConvert`: `String`

---

### setSubmit

设置提交操作代码

**方法签名：**
```java
public void setSubmit(String submmit)
```

**参数说明：**
- `submmit`: `String`

---

### setUnAudit

设置反审核操作代码

**方法签名：**
```java
public void setUnAudit(String unaudit)
```

**参数说明：**
- `unaudit`: `String`

---

### setUnSubmit

设置撤销操作代码

**方法签名：**
```java
public void setUnSubmit(String unsubmit)
```

**参数说明：**
- `unsubmit`: `String`

---
