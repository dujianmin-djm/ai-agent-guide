---
framework_version: "8.0.1"
api_class: "ValueTextItem"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用已选数据项时"
---

# ValueTextItem API 说明

## 概述
已选数据项。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.ValueTextItem;
```

---

## 方法列表

### getText

获取文本

**方法签名：**
```java
public String getText()
```

**返回值：**
- `String`

---

### getValue

获取值域

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`

---

### setText

设置文本

**方法签名：**
```java
public void setText(String text)
```

**参数说明：**
- `text`: `String`

---

### setValue

设置值域

**方法签名：**
```java
public void setValue(String value)
```

**参数说明：**
- `value`: `String`

---
