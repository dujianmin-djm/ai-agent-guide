---
framework_version: "8.0.1"
api_class: "OverallParam"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用列表参数时"
---

# OverallParam API 说明

## 概述
列表参数。。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.param.OverallParam;
```

---

## 方法列表

### isEnableSignOrg

是否开启签名受控组织

**方法签名：**
```java
public boolean isEnableSignOrg()
```

**返回值：**
- `boolean`: 是否开启签名受控组织

---

### setEnableSignOrg

设置是否开启签名受控组织

**方法签名：**
```java
public void setEnableSignOrg(boolean isEnableSignOrg)
```

**参数说明：**
- `isEnableSignOrg`: `boolean` — 是否开启签名受控组织

---
