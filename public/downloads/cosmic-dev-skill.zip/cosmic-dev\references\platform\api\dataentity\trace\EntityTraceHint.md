---
framework_version: "8.0.1"
api_class: "EntityTraceHint"
api_package: "kd.bos.dataentity.trace"
when_to_use: "当你需要使用创建实体运行监控节点时的参数设置时"
---

# EntityTraceHint API 说明

## 概述
创建实体运行监控节点时的参数设置。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.trace.EntityTraceHint;
```

---

## 方法列表

### getHintDisLinkAPM

返回不链接到APM平台的参数配置
 
 使用共享的静态变量，避免调用者重复实例化参数对象

**方法签名：**
```java
public static EntityTraceHint getHintDisLinkAPM()
```

**返回值：**
- `EntityTraceHint`

---

### getHintLinkAPM

获取连接到APM平台的参数配置

**方法签名：**
```java
public static EntityTraceHint getHintLinkAPM()
```

**返回值：**
- `EntityTraceHint`: Trace参数配置

---

### isLinkToApm

返回：是否对接apm平台，即同时生成apm的调用链节点
 
 部分方法调用非常频繁，会对apm产生很大性能压力，没有必要对接

**方法签名：**
```java
public boolean isLinkToApm()
```

**返回值：**
- `boolean`: 返回false：不对接apm平台

---

### setLinkToApm

设置参数：是否和apm对接

**方法签名：**
```java
public void setLinkToApm(boolean linkToApm)
```

**参数说明：**
- `linkToApm`: `boolean` — 设置为true：对接apm平台，即同时生成apm调用链节点

---

### toString

把本对象转换为字符串，用于显示内容

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 返回本对象转换成的字符串

---
