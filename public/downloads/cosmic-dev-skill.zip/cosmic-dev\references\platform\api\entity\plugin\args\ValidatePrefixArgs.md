---
framework_version: "8.0.1"
api_class: "ValidatePrefixArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用执行操作校验前事件参数时"
---

# ValidatePrefixArgs API 说明

## 概述
执行操作校验前事件参数。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.ValidatePrefixArgs;
```

---

## 方法列表

### getPropName

返回校验提示内容前缀使用的字段标识

**方法签名：**
```java
public String getPropName()
```

**返回值：**
- `String`: 字段标识

---

### setPropName

设置校验提示前缀使用的字段标识：生成提示，使用此字段值作为提示前缀，默认用单据编号字段值做为提示前缀

**方法签名：**
```java
public void setPropName(String propName)
```

**参数说明：**
- `propName`: `String` — 字段标识

---
