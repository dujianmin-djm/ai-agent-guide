---
framework_version: "8.0.1"
api_class: "JoinProperty"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用关联属性时"
---

# JoinProperty API 说明

## 概述
关联属性。继承自 BasedataProp，实现 IValidatorHanlder, IBasedataField, ICompareTypeConfig, IFieldRuleHandle, IRegisterListField。
主要功能：读取属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.entity.list.JoinProperty;
```

---

## 方法列表

### createFilterFields

{待补充}

**方法签名：**
```java
public List<kd.FilterField> createFilterFields(MainEntityType mainType)
```

**参数说明：**
- `mainType`: `MainEntityType`

**返回值：**
- `List<kd.FilterField>`

---

### getFKProperty

获取所在实体外键标识

**方法签名：**
```java
public IDataEntityProperty getFKProperty()
```

**返回值：**
- `IDataEntityProperty`

---

### getJoinProperty

获取实体关联标识

**方法签名：**
```java
public IDataEntityProperty getJoinProperty()
```

**返回值：**
- `IDataEntityProperty`

---

### isExportable

允许引出

**方法签名：**
```java
public boolean isExportable()
```

**返回值：**
- `boolean`

---
