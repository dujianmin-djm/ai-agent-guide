---
framework_version: "8.0.1"
api_class: "ParamKey"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用参数标识时"
---

# ParamKey API 说明

## 概述
参数标识。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.param.ParamKey;
```

---

## 方法列表

### getOrgId

获取组织id

**方法签名：**
```java
public long getOrgId()
```

**返回值：**
- `long`: 组织id

---

### getParam

获取参数标识

**方法签名：**
```java
public String getParam()
```

**返回值：**
- `String`: 参数标识

---

### setOrgId

设置组织id

**方法签名：**
```java
public void setOrgId(long orgId)
```

**参数说明：**
- `orgId`: `long` — 组织id

---

### setParam

设置参数标识

**方法签名：**
```java
public void setParam(String param)
```

**参数说明：**
- `param`: `String` — 参数标识

---
