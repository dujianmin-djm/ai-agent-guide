---
framework_version: "8.0.1"
api_class: "BasedataHelper"
api_package: "kd.bos.base"
when_to_use: "当你需要使用 BasedataHelper 相关功能时"
---

# BasedataHelper API 说明

## 概述
BasedataHelper 类。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.base.BasedataHelper;
```

---

## 方法列表

### createPlugin

创建插件(基础资料个性化控制插件)

**方法签名：**
```java
public static List<kd.IBasedataController> createPlugin(List<Plugin> plugins)
```

**参数说明：**
- `plugins`: `List<Plugin>`

**返回值：**
- `List<kd.IBasedataController>`: 创建的插件列表

---
