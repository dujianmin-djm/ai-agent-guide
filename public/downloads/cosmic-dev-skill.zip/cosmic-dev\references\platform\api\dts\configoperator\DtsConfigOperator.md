---
framework_version: "8.0.1"
api_class: "DtsConfigOperator"
api_package: "kd.bos.dts.configoperator"
when_to_use: "当你需要使用dts配置信息操作api时"
---

# DtsConfigOperator API 说明

## 概述
dts配置信息操作api。
主要功能：移除元素、状态判断、保存更新。

## Import 路径
```java
import kd.bos.dts.configoperator.DtsConfigOperator;
```

---

## 方法列表

### deleteDtsConfig

**重载 1**

删除数据同步配置

**方法签名：**
```java
public default void deleteDtsConfig(String entityNumber, String businessType, String region, String mappingRule)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识

---

**重载 2**

删除同步同步配置

**方法签名：**
```java
public void deleteDtsConfig(String entityNumber, String businessType, String region, String mappingRule, String destType)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识
- `destType`: `String` — 目标类型

---

### disableDtsConfig

**重载 1**

禁用数据同步配置

**方法签名：**
```java
public default void disableDtsConfig(String entityNumber, String businessType, String region, String mappingRule)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识

---

**重载 2**

禁用数据同步配置

**方法签名：**
```java
public void disableDtsConfig(String entityNumber, String businessType, String region, String mappingRule, String destType)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识
- `destType`: `String` — 目标类型

---

### enableDtsConfig

**重载 1**

启动数据同步配置

**方法签名：**
```java
public default void enableDtsConfig(String entityNumber, String businessType, String region, String mappingRule)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识

---

**重载 2**

启用数据同步配置

**方法签名：**
```java
public void enableDtsConfig(String entityNumber, String businessType, String region, String mappingRule, String destType)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识
- `destType`: `String` — 目标类型

---

### existsSyncConfigSnapshot

**重载 1**

是否存在配置快照

**方法签名：**
```java
public default boolean existsSyncConfigSnapshot(String entityNumber, String businessType, String region, String mappingRule)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识

**返回值：**
- `boolean`

---

**重载 2**

是否存在配置快照

**方法签名：**
```java
public boolean existsSyncConfigSnapshot(String entityNumber, String businessType, String region, String mappingRule, String destType)
```

**参数说明：**
- `entityNumber`: `String` — 实体编码
- `businessType`: `String` — 业务类型
- `region`: `String` — 目标地址标识
- `mappingRule`: `String` — 映射规则标识
- `destType`: `String` — 目标类型

**返回值：**
- `boolean`

---

### isFullSync

是否正在全量同步/初始同步

**方法签名：**
```java
public boolean isFullSync(String entityNumber, String region, String destinationType, String mappingRule)
```

**参数说明：**
- `entityNumber`: `String`
- `region`: `String`
- `destinationType`: `String`
- `mappingRule`: `String`

**返回值：**
- `boolean`

---

### saveDtsConfig

保存数据同步配置

**方法签名：**
```java
public void saveDtsConfig(DtsConfigOperatorInfo dtsConfigOperatorInfo)
```

**参数说明：**
- `dtsConfigOperatorInfo`: `DtsConfigOperatorInfo` — 同步配置对象

---
