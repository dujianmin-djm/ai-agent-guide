---
framework_version: "8.0.1"
api_class: "DcSerializer"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用对象序列化基类时"
---

# DcSerializer API 说明

## 概述
对象序列化基类。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.serialization.DcSerializer;
```

---

## 方法列表

### getBinder

获取节点名称和实体类型的映射工具

**方法签名：**
```java
public final DcBinder getBinder()
```

**返回值：**
- `DcBinder`: DcBinder 类型的映射工具

---

### getSerializeComplexProperty

获取是否序列化复合属性

**方法签名：**
```java
public final boolean getSerializeComplexProperty()
```

**返回值：**
- `boolean`

---

### isCallUpdateFuncWhenCreated

获取当新建对象后是否再调用更新方法标记

**方法签名：**
```java
public boolean isCallUpdateFuncWhenCreated()
```

**返回值：**
- `boolean`

---

### isLocaleValueFull

获取否完整序列化LocaleValue开关,缺省为false

**方法签名：**
```java
public final boolean isLocaleValueFull()
```

**返回值：**
- `boolean`

---

### setBinder

设置节点名称和实体类型的映射工具

**方法签名：**
```java
public final void setBinder(DcBinder value)
```

**参数说明：**
- `value`: `DcBinder` — DcBinder 类型的映射工具

---

### setCallUpdateFuncWhenCreated

设置当新建对象后是否再调用更新方法标记

**方法签名：**
```java
public void setCallUpdateFuncWhenCreated(boolean callUpdateFuncWhenCreated)
```

**参数说明：**
- `callUpdateFuncWhenCreated`: `boolean`

---

### setIsLocaleValueFull

设置是否完整序列化LocaleValue，缺省为false

**方法签名：**
```java
public final void setIsLocaleValueFull(boolean value)
```

**参数说明：**
- `value`: `boolean` — 完整序列化LocaleValue

---

### setSerializeComplexProperty

设置是否序列化复合属性

**方法签名：**
```java
public final void setSerializeComplexProperty(boolean value)
```

**参数说明：**
- `value`: `boolean` — 序列化复合属性

---
