---
framework_version: "8.0.1"
api_class: "ValidateResult"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用校验结果时"
---

# ValidateResult API 说明

## 概述
校验结果。继承自 AbstractOperationResult，实现 Serializable, IOperationResult。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.validate.ValidateResult;
```

---

## 方法列表

### getFeedbackCusOpData

自定操作结果反馈信息， 在操作结果中返回 kd.bos.entity.operate.result.OperationResult#getCustomData()

**方法签名：**
```java
public Map<String,String> getFeedbackCusOpData()
```

**返回值：**
- `Map<String,String>`

---

### getValidatorKey

获取校验器标识

**方法签名：**
```java
public String getValidatorKey()
```

**返回值：**
- `String`: 校验器标识

---

### setFeedbackCusOpData

设置自定操作结果反馈信息， 在操作结果中返回 kd.bos.entity.operate.result.OperationResult#getCustomData()

**方法签名：**
```java
public void setFeedbackCusOpData(Map<String,String> feedbackCusOpData)
```

**参数说明：**
- `feedbackCusOpData`: `Map<String,String>`

---

### setValidatorKey

设置校验器标识

**方法签名：**
```java
public void setValidatorKey(String validatorKey)
```

**参数说明：**
- `validatorKey`: `String` — 校验器标识

---
