---
framework_version: "8.0.1"
api_class: "RowMetaFactory"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用创建元素据的工厂时"
---

# RowMetaFactory API 说明

## 概述
创建元素据的工厂。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.algo.RowMetaFactory;
```

---

## 方法列表

### createRowMeta

根据字段名称和类型创建元素据

**方法签名：**
```java
public static RowMeta createRowMeta(String[] fieldNames, DataType[] dataTypes)
```

**参数说明：**
- `fieldNames`: `String[]` — 属性名称
- `dataTypes`: `DataType[]` — 数据类型

**返回值：**
- `RowMeta`: 元数据

---
