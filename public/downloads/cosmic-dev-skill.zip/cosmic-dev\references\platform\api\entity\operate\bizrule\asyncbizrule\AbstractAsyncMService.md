---
framework_version: "8.0.1"
api_class: "AbstractAsyncMService"
api_package: "kd.bos.entity.operate.bizrule.asyncbizrule"
when_to_use: "当你需要使用抽象异步微服务时"
---

# AbstractAsyncMService API 说明

## 概述
抽象异步微服务。实现 IAsyncMService。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.bizrule.asyncbizrule.AbstractAsyncMService;
```

---

## 方法列表

### getBillID

获取单据内码

**方法签名：**
```java
public Object getBillID()
```

**返回值：**
- `Object`

---

### getCustomParamMap

获取服务自定义参数

**方法签名：**
```java
public Map<String,String> getCustomParamMap()
```

**返回值：**
- `Map<String,String>`

---

### getOperateOption

获取操作自定义参数

**方法签名：**
```java
public OperateOption getOperateOption()
```

**返回值：**
- `OperateOption`

---

### setBillID

设置单据内码

**方法签名：**
```java
public void setBillID(Object billID)
```

**参数说明：**
- `billID`: `Object`

---

### setCustomParamMap

设置服务自定义参数

**方法签名：**
```java
public void setCustomParamMap(Map<String,String> customParamMap)
```

**参数说明：**
- `customParamMap`: `Map<String,String>`

---

### setOperateOption

设置操作自定义参数

**方法签名：**
```java
public void setOperateOption(OperateOption operateOption)
```

**参数说明：**
- `operateOption`: `OperateOption`

---
