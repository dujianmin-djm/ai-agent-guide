---
framework_version: "8.0.1"
api_class: "EntryInfo"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用分录行状态信息时"
---

# EntryInfo API 说明

## 概述
分录行状态信息。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.dataentity.entity.EntryInfo;
```

---

## 方法列表

### getPageSize

获取分录的每页条数

**方法签名：**
```java
public int getPageSize()
```

**返回值：**
- `int`: 每页条数

---

### getRowCount

获取分录总行数。如果未设置，返回空(null)

**方法签名：**
```java
public Integer getRowCount()
```

**返回值：**
- `Integer`: 分录总行数

---

### getStartRowIndex

获取分录页起始行索引

**方法签名：**
```java
public int getStartRowIndex()
```

**返回值：**
- `int`: 起始行索引

---

### inCurrentPage

判断当前索引是否在当前分录页

**方法签名：**
```java
public boolean inCurrentPage(int index)
```

**参数说明：**
- `index`: `int` — 当前索引

**返回值：**
- `boolean`: 当前序号是否在当前分录页

---

### setPageSize

设置分录的每页条数

**方法签名：**
```java
public void setPageSize(int pageSize)
```

**参数说明：**
- `pageSize`: `int` — 每页条数

---

### setRowCount

设置分录总行数

**方法签名：**
```java
public void setRowCount(int rowCount)
```

**参数说明：**
- `rowCount`: `int` — 分录总行数

---

### setStartRowIndex

设置分录页起始行索引

**方法签名：**
```java
public void setStartRowIndex(int startRowIndex)
```

**参数说明：**
- `startRowIndex`: `int` — 起始行索引

---
