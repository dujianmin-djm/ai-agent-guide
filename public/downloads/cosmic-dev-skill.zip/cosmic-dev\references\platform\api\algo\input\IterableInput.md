---
framework_version: "8.0.1"
api_class: "IterableInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用使用一个迭代器作为一个构建DataSet的输入源时"
---

# IterableInput API 说明

## 概述
使用一个迭代器作为一个构建DataSet的输入源。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.IterableInput;
```

---

## 方法列表

### getIterable

获取迭代器

**方法签名：**
```java
public Iterable<Object[]> getIterable()
```

**返回值：**
- `Iterable<Object[]>`: 迭代器

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
