---
version: "1.0.0"
framework_version: "8.0.0"
last_updated: "2026-03-06"
confidence: "extracted"
status: "draft"
---

# 工作流插件开发参考

> 覆盖：IWorkflowPlugin / WorkflowPlugin / IEventServicePlugin / AbstractWorkflowPlugin
> 适用：参与人计算、节点回调、会审、流程事件处理、审批页面定制

## 插件类型

| 类型 | 基类/接口 | 包路径 | 适用场景 |
|------|----------|--------|---------|
| 流程节点插件 | `IWorkflowPlugin`（接口）/ `WorkflowPlugin`（基类） | `kd.bos.workflow.engine.extitf` | 参与人计算、节点通知、条件分支、会审 |
| 流程事件插件 | `IEventServicePlugin` | `kd.bos.bec.api` | 流程事件订阅（待办推送、传阅通知） |
| 审批页面插件 | `AbstractWorkflowPlugin` | `kd.bos.workflow.design.plugin` | 审批页面 UI 定制（继承自 AbstractFormPlugin） |

## 生命周期

### IWorkflowPlugin（流程节点执行流程）

```
notify（进入节点） → calcUserIds（计算参与人） → filterParticipant（过滤参与人）
→ 任务创建 → afterHandleTask(evtName="afterCreate")
→ 用户审批 → afterHandleTask(evtName="afterComplete")
→ notify（离开节点） → hasTrueCondition（条件分支判断） → 流转到下一节点
```

**会审场景**:
```
流程到达会审节点 → calcUserIds → 多人并行审批
→ 每人审批后 → getJointAuditResult（计算会审结果）
→ 会审完成 → notify → 流转
```

### IWorkflowPlugin 事件方法

| 方法 | 触发时机 | 典型用途 |
|------|----------|----------|
| `calcUserIds(AgentExecution, DynamicObject pme, DynamicObject businessModel)` | 参与人计算时 | 自定义参与人计算逻辑 |
| `filterParticipant(AgentExecution, List<Long>)` | 系统计算参与人之后 | 过滤/修改参与人列表 |
| `notify(AgentExecution)` | 流程节点到达时 | 节点回调、第三方通知、状态更新 |
| `notifyByWithdraw(AgentExecution)` | 流程撤回时 | 撤回通知、反向操作 |
| `afterHandleTask(AgentTask, String evtName, Map<String, Object>)` | 任务处理后 | 任务创建/完成后的回调 |
| `hasTrueCondition(AgentExecution)` | 条件分支判断时 | 自定义分支条件 |
| `getJointAuditResult(AgentExecution, JointResultInfo)` | 会审结果计算时 | 自定义会审通过规则 |

### IEventServicePlugin 事件方法

| 方法 | 触发时机 | 典型用途 |
|------|----------|----------|
| `handleEvent(KDBizEvent evt)` | 业务事件触发时 | 处理流程事件（待办推送、传阅通知） |

## 基础结构

### 流程节点插件

```java
package kd.{isv}.{module}.workflowplugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kd.bos.workflow.api.AgentExecution;
import kd.bos.workflow.api.AgentTask;
import kd.bos.workflow.engine.extitf.IWorkflowPlugin;
import kd.bos.dataentity.entity.DynamicObject;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

public class XxxWorkFlowPlugin implements IWorkflowPlugin {
    private static final Log log = LogFactory.getLog(XxxWorkFlowPlugin.class);

    @Override
    public List<Long> calcUserIds(AgentExecution execution, DynamicObject pme, DynamicObject businessModel) {
        List<Long> userIds = new ArrayList<>();
        // 参与人计算逻辑
        return userIds;
    }

    @Override
    public void notify(AgentExecution execution) {
        // 节点通知逻辑
    }
}
```

### 流程事件插件

```java
package kd.{isv}.{module}.workflowplugin;

import kd.bos.bec.api.IEventServicePlugin;
import kd.bos.bec.model.KDBizEvent;
import kd.bos.logging.Log;
import kd.bos.logging.LogFactory;

public class XxxEventPlugin implements IEventServicePlugin {
    private static final Log log = LogFactory.getLog(XxxEventPlugin.class);

    @Override
    public Object handleEvent(KDBizEvent evt) {
        String source = evt.getSource();
        // 事件处理逻辑
        return IEventServicePlugin.super.handleEvent(evt);
    }
}
```

## 核心 API 对象

### AgentExecution（流程执行上下文）

| 方法 | 返回类型 | 说明 |
|------|----------|------|
| `getBusinessKey()` | `String` | 获取业务主键（单据 ID） |
| `getEntityNumber()` | `String` | 获取单据编码 |
| `getProcessInstanceId()` | `Long` | 获取流程实例 ID |
| `getCurrentFlowElement()` | `WorkflowElement` | 获取当前流程元素（可转型为 AuditTask 等） |
| `getCurrentTaskResult(WFTaskResultEnum)` | `Object` | 获取当前任务审批结果 |
| `getCurrentApprover()` | `List<Long>` | 获取当前审批人列表 |

### AgentTask（任务对象）

| 方法 | 返回类型 | 说明 |
|------|----------|------|
| `getBusinessKey()` | `String` | 获取业务主键 |
| `getParticipants()` | `Set<Long>` | 获取参与人集合 |
| `getAssigneeId()` | `Long` | 获取任务负责人 ID |

## 常见场景

### 自定义参与人计算

```java
@Override
public List<Long> calcUserIds(AgentExecution execution, DynamicObject pme, DynamicObject businessModel) {
    List<Long> userIds = new ArrayList<>();
    String value = pme.getString("value");
    JSONObject valueObj = JSONObject.parseObject(value);
    String roleId = valueObj.getString("roleid");

    String entityNumber = execution.getEntityNumber();
    String businessKey = execution.getBusinessKey();

    DynamicObjectCollection userColl = QueryServiceHelper.query("bos_user", "id",
            new QFilter[]{new QFilter("number", QCP.in, userNumbers)});
    userIds.addAll(userColl.stream().map(x -> x.getLong("id")).collect(Collectors.toList()));
    return userIds;
}
```

### 节点审批回调

```java
@Override
public void notify(AgentExecution execution) {
    String businessKey = execution.getBusinessKey();
    WorkflowElement element = execution.getCurrentFlowElement();
    if (!(element instanceof AuditTask)) {
        return;
    }
    AuditTask auditTask = (AuditTask) element;
    Object auditNumber = execution.getCurrentTaskResult(WFTaskResultEnum.auditNumber);
    Object auditMessage = execution.getCurrentTaskResult(WFTaskResultEnum.auditMessage);
    DynamicObject bill = BusinessDataServiceHelper.loadSingle(businessKey, entityNumber);
    // 回调第三方系统或更新业务状态
}
```

### 自定义会审结果

```java
@Override
public CustomizedAuditResult getJointAuditResult(AgentExecution execution, JointResultInfo jointResultInfo) {
    List<JointAuditInfo> auditInfos = jointResultInfo.getAduitInfo();
    int allVoteNumbers = jointResultInfo.getAllVoteNumbers();
    CustomizedAuditResult result = new CustomizedAuditResult();
    result.setOver(false);
    result.setPass(false);
    if (auditInfos.size() == allVoteNumbers) {
        result.setOver(true);
        // 自定义通过逻辑
        result.setPass(approveCount > allVoteNumbers / 2);
    }
    return result;
}
```

## 注意事项

1. **IWorkflowPlugin 无需调用 super**：实现接口的插件直接编写业务逻辑
2. **AbstractWorkflowPlugin 必须调用 super**：继承自 AbstractFormPlugin，重写方法必须先 `super.xxx()`
3. **空值检查**：`pme.getString("value")` 获取配置后必须判空；`getCurrentFlowElement()` 需做 `instanceof` 判断
4. **参与人计算失败应抛异常**：返回空列表会导致流程卡住，应抛出 `KDException`
5. **节点类型判断**：使用 `instanceof` 判断后再转型（`AuditTask`、`WFUserTask` 等）
6. **字符串比较**：使用 `StringUtils.equals()` 而非 `.equals()`
7. **日志记录**：参与人计算结果、审批回调、外部调用必须记录日志
