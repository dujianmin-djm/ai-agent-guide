---
framework_version: "8.0.1"
api_class: "BaseDataCommonService"
api_package: "kd.bos.bd.service"
when_to_use: "当你需要使用处理其它相对小的业务功能时"
---

# BaseDataCommonService API 说明

## 概述
处理其它相对小的业务功能，如管理权转让，新增删除等。继承自 AbstractBaseDataService。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.bd.service.BaseDataCommonService;
```

---

## 方法列表

### getBaseDataFilterNoAudit

{待补充}

**方法签名：**
```java
public QFilter getBaseDataFilterNoAudit(String entityId, Long orgId)
```

**参数说明：**
- `entityId`: `String`
- `orgId`: `Long`

**返回值：**
- `QFilter`

---

### isNewModel

受控基础资料是否使用新模型
  此方法应该使用缓存存储升级状态，但是升级服务是否有升级之后回退的情况，如果有那可能会出现业务不一致性

**方法签名：**
```java
public static boolean isNewModel(String entity)
```

**参数说明：**
- `entity`: `String` — 受控实体

**返回值：**
- `boolean`: true/false

---

### setReloadOrg

setReloadOrg

**方法签名：**
```java
public void setReloadOrg(boolean reloadOrg)
```

**参数说明：**
- `reloadOrg`: `boolean` — true or false

---
