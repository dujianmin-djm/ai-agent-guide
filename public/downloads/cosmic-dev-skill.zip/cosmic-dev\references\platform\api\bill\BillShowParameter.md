---
framework_version: "8.0.1"
api_class: "BillShowParameter"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用单据界面显示参数时"
---

# BillShowParameter API 说明

## 概述
单据界面显示参数。继承自 FormShowParameter，实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.bill.BillShowParameter;
```

---

## 方法列表

### getArchiveKey

返回历史单据归档分路由

**方法签名：**
```java
public String getArchiveKey()
```

**返回值：**
- `String`: 归档分路由

---

### getBillStatus

返回单据界面状态

**方法签名：**
```java
public BillOperationStatus getBillStatus()
```

**返回值：**
- `BillOperationStatus`: 单据界面状态

---

### getBillTypeId

返回打开的单据类型，可据此确定单据布局

**方法签名：**
```java
public String getBillTypeId()
```

**返回值：**
- `String`: 单据类型内码

---

### getCachePageId

返回下推时存有目标单数据包的页面pageId，可以据此取到数据包

**方法签名：**
```java
public String getCachePageId()
```

**返回值：**
- `String`: 页面pageId

---

### getLayoutMainOrgId

返回主组织

**方法签名：**
```java
public Long getLayoutMainOrgId()
```

**返回值：**
- `Long`: 主组织内码

---

### getLayoutSchemeId

返回界面布局方案

**方法签名：**
```java
public Long getLayoutSchemeId()
```

**返回值：**
- `Long`: 界面布局方案

---

### getPermissionEntityId

返回功能验权所用的业务对象实体编码

**方法签名：**
```java
public String getPermissionEntityId()
```

**返回值：**
- `String`: 实体编码

---

### getPermissionItemId

返回打开单据界面时，验权使用的权限项
 
 返回值是自动生成的，规则如下：
 1. 单据，未传入pkid，验证新增权；
 2. 单据，传入了pkid，如果有定制参数IsCopy，则验证新增权；
 3. 单据，传入了pkid，如果编辑状态，验证修改权；
 4. 单据，传入了pkid，如果是查看状态，验证查看权；

**方法签名：**
```java
public String getPermissionItemId()
```

**返回值：**
- `String`

---

### getPkId

返回打开的单据内码

**方法签名：**
```java
public Object getPkId()
```

**返回值：**
- `Object`: 单据内码

---

### getRouteKey

返回历史单据归档主路由

**方法签名：**
```java
public String getRouteKey()
```

**返回值：**
- `String`: 归档主路由

---

### isDisableLayoutScheme

返回是否关闭界面布局方案选项值

**方法签名：**
```java
public boolean isDisableLayoutScheme()
```

**返回值：**
- `boolean`: 选项，是否关闭界面布局方案

---

### isEnableUserReentrant

返回单据是否允许同账号重入

**方法签名：**
```java
public boolean isEnableUserReentrant()
```

**返回值：**
- `boolean`: 返回true，允许同账号重入；默认返回false不允许同账号重入

---

### setArchiveKey

设置历史单据归档分路由

**方法签名：**
```java
public void setArchiveKey(String archiveKey)
```

**参数说明：**
- `archiveKey`: `String` — 归档分路由

---

### setBillStatus

设置单据界面状态

**方法签名：**
```java
public void setBillStatus(BillOperationStatus billStatus)
```

**参数说明：**
- `billStatus`: `BillOperationStatus` — 单据界面状态

---

### setBillStatusValue

设置单据界面状态枚举值
 
 供反序列化调用，功能代码不要调用

**方法签名：**
```java
public void setBillStatusValue(Integer value)
```

**参数说明：**
- `value`: `Integer` — 单据界面状态枚举值

---

### setBillTypeId

设置打开的单据类型，可据此确定单据布局

**方法签名：**
```java
public void setBillTypeId(String billTypeId)
```

**参数说明：**
- `billTypeId`: `String` — 单据类型内码

---

### setCachePageId

下推，传入目标单数据包缓存PageId，可以据此取到数据包

**方法签名：**
```java
public void setCachePageId(String cachePageId)
```

**参数说明：**
- `cachePageId`: `String` — 页面pageId

---

### setDisableLayoutScheme

设置选项，关闭界面布局方案

**方法签名：**
```java
public void setDisableLayoutScheme(boolean disableLayoutScheme)
```

**参数说明：**
- `disableLayoutScheme`: `boolean` — 选项，设置为true关闭界面布局方案

---

### setEnableUserReentrant

设置单据是否允许同账号重入
 
 用户打开单据进行编辑后，会申请互斥锁，其他人打开单据会提示冲突，同账号重入也会提示冲突。
 设置此选项为true，同账号允许重入，打开单据不会提示冲突

**方法签名：**
```java
public void setEnableUserReentrant(boolean enableUserReentrant)
```

**参数说明：**
- `enableUserReentrant`: `boolean` — 设置为true，允许同账号重入

---

### setLayoutMainOrgId

设置主组织

**方法签名：**
```java
public void setLayoutMainOrgId(Long layoutMainOrgId)
```

**参数说明：**
- `layoutMainOrgId`: `Long` — 主组织

---

### setLayoutSchemeId

设置界面布局方案

**方法签名：**
```java
public void setLayoutSchemeId(Long layoutSchemeId)
```

**参数说明：**
- `layoutSchemeId`: `Long` — 界面布局方案

---

### setPermissionEntityId

设置功能验权所用的业务对象实体编码
 
 功能权限默认按单据授权、验权。特殊场景多种单据需共用授权，打开这些单据时，指定验权采用的业务对象实体编码实现共用授权

**方法签名：**
```java
public void setPermissionEntityId(String permissionEntityId)
```

**参数说明：**
- `permissionEntityId`: `String` — 实体编码

---

### setPkId

设置打开的单据内码

**方法签名：**
```java
public void setPkId(Object pkId)
```

**参数说明：**
- `pkId`: `Object` — 单据内码

---

### setRouteKey

设置历史单据归档主路由

**方法签名：**
```java
public void setRouteKey(String routeKey)
```

**参数说明：**
- `routeKey`: `String` — 数据归档主路由

---

### setStatus

设置表单界面状态

**方法签名：**
```java
public void setStatus(OperationStatus value)
```

**参数说明：**
- `value`: `OperationStatus` — 表单界面状态

---
