---
framework_version: "8.0.1"
api_class: "FormatFieldData"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用列表格式化后的字段值,提供一个时机给插件获取列表格式化之后的结构化数据时"
---

# FormatFieldData API 说明

## 概述
列表格式化后的字段值,提供一个时机给插件获取列表格式化之后的结构化数据。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.FormatFieldData;
```

---

## 方法列表

### getFieldKey

获取对应映射的列表字段key

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### getFieldValue

获取对应映射的列表字段的格式化后的值

**方法签名：**
```java
public Object getFieldValue()
```

**返回值：**
- `Object`

---

### getFieldValueDesc

获取对应映射的列表字段的格式化后的字段描述（供引出、套打使用）

**方法签名：**
```java
public Object getFieldValueDesc()
```

**返回值：**
- `Object`

---
