---
framework_version: "8.0.1"
api_class: "ValidateResultCollection"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用校验结果集合 输出所以的校验器校验的结果时"
---

# ValidateResultCollection API 说明

## 概述
校验结果集合 输出所以的校验器校验的结果。实现 Serializable。
主要功能：读取属性、设置属性、添加元素、状态判断。

## Import 路径
```java
import kd.bos.entity.validate.ValidateResultCollection;
```

---

## 方法列表

### addValidateError

为指定校验器添加校验结果

**方法签名：**
```java
public void addValidateError(String validatorKey, ValidateResult result)
```

**参数说明：**
- `validatorKey`: `String`
- `result`: `ValidateResult`

---

### errorSize

**重载 1**

校验失败的单据张数

**方法签名：**
```java
public int errorSize()
```

**返回值：**
- `int`

---

**重载 2**

校验失败的单据张数

**方法签名：**
```java
public int errorSize(boolean reset)
```

**参数说明：**
- `reset`: `boolean` — 重新分析校验结果，提取失败的单据内码、序号

**返回值：**
- `int`

---

### getErrorDataIndexs

获取操作校验失败的数据包索引：需要基于数据包索引，确认失败的数据包

**方法签名：**
```java
public HashSet<Integer> getErrorDataIndexs()
```

**返回值：**
- `HashSet<Integer>`

---

### getErrorPkIds

获取操作校验失败的主键值集合

**方法签名：**
```java
public HashSet<Object> getErrorPkIds()
```

**返回值：**
- `HashSet<Object>`

---

### getMessage

获取校验信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getValidateErrors

**重载 1**

获取校验错误的结果集

**方法签名：**
```java
public List<kd.ValidateResult> getValidateErrors()
```

**返回值：**
- `List<kd.ValidateResult>`

---

**重载 2**

获取单个校验器校验失败的结果集

**方法签名：**
```java
public List<kd.ValidateResult> getValidateErrors(String validatorKey)
```

**参数说明：**
- `validatorKey`: `String`

**返回值：**
- `List<kd.ValidateResult>`

---

### isSuccess

输出校验器有没有发现警告级别以上的错误： 只有没有任何警告及以上级别的错误，才返回true

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`: the success

---

### setErrorDataIndexs

设置操作校验失败的数据包索引：需要基于数据包索引，确认失败的数据包

**方法签名：**
```java
public void setErrorDataIndexs(HashSet<Integer> errorDataIndex)
```

**参数说明：**
- `errorDataIndex`: `HashSet<Integer>`

---

### setErrorPkIds

设置操作校验失败的主键值集合

**方法签名：**
```java
public void setErrorPkIds(HashSet<Object> errorPkIds)
```

**参数说明：**
- `errorPkIds`: `HashSet<Object>`

---

### setMessage

设置校验信息

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String`

---
