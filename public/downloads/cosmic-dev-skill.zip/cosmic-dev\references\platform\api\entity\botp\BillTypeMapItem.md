---
framework_version: "8.0.1"
api_class: "BillTypeMapItem"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用单据类型映射条目时"
---

# BillTypeMapItem API 说明

## 概述
单据类型映射条目。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.BillTypeMapItem;
```

---

## 方法列表

### getId

自动产生的唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getPushType

下推类型：指定类型、任意类型、不允许下推、不允许下推指定类型

**方法签名：**
```java
public String getPushType()
```

**返回值：**
- `String`

---

### getSeq

执行顺序。按顺序确定目标单单据类型，找到即止

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### getSourceBillTypeId

源单单据类型

**方法签名：**
```java
public long getSourceBillTypeId()
```

**返回值：**
- `long`

---

### getSourceBillTypeName

源单类型名称：不序列化，仅用于翻译本条规则

**方法签名：**
```java
public String getSourceBillTypeName()
```

**返回值：**
- `String`

---

### getSourceType

源单类型：全部、其他、指定类型

**方法签名：**
```java
public String getSourceType()
```

**返回值：**
- `String`

---

### getTargetBillTypeId

目标单单据类型，可能是具体单据类型id，或者是特殊选项，如默认、随机、无

**方法签名：**
```java
public long getTargetBillTypeId()
```

**返回值：**
- `long`

---

### getTargetBillTypeName

目标单单据类型名称，不序列化

**方法签名：**
```java
public String getTargetBillTypeName()
```

**返回值：**
- `String`

---

### isValid

当前映射条目是否配置完整有效？ 无效的映射条目不被采用

**方法签名：**
```java
public boolean isValid()
```

**返回值：**
- `boolean`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### toString

解析出本条规则各项配置组合后的含义，提示给用户

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
