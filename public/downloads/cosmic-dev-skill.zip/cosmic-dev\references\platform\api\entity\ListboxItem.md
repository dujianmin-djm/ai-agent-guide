---
framework_version: "8.0.1"
api_class: "ListboxItem"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用listboxitem listbox类似菜单栏控件时"
---

# ListboxItem API 说明

## 概述
listboxitem listbox类似菜单栏控件。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.ListboxItem;
```

---

## 方法列表

### getContent

获取内容

**方法签名：**
```java
public String getContent()
```

**返回值：**
- `String`

---

### getId

获取id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getItems

获取子项数组

**方法签名：**
```java
public List<kd.ListboxItem> getItems()
```

**返回值：**
- `List<kd.ListboxItem>`

---

### setContent

设置内容

**方法签名：**
```java
public void setContent(String content)
```

**参数说明：**
- `content`: `String`

---

### setId

设置id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setItems

设置子项数组

**方法签名：**
```java
public void setItems(List<kd.ListboxItem> items)
```

**参数说明：**
- `items`: `List<kd.ListboxItem>`

---
