---
framework_version: "8.0.1"
api_class: "GroupFieldsUniqueValidateResult"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用组合性唯一校验结果时"
---

# GroupFieldsUniqueValidateResult API 说明

## 概述
组合性唯一校验结果。继承自 ValidateResult，实现 Serializable, IOperationResult。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.validate.GroupFieldsUniqueValidateResult;
```

---

## 方法列表

### getFieldCaptions

属性标题

**方法签名：**
```java
public List<String> getFieldCaptions()
```

**返回值：**
- `List<String>`

---

### getFieldKeys

原始属性名

**方法签名：**
```java
public List<String> getFieldKeys()
```

**返回值：**
- `List<String>`

---

### isShowUniqueResult

是否展示唯一校验结果

**方法签名：**
```java
public boolean isShowUniqueResult()
```

**返回值：**
- `boolean`

---

### setFieldCaptions

设置属性标题

**方法签名：**
```java
public void setFieldCaptions(List<String> fieldCaptions)
```

**参数说明：**
- `fieldCaptions`: `List<String>` — 属性标题

---

### setFieldKeys

设置原始属性名

**方法签名：**
```java
public void setFieldKeys(List<String> fieldKeys)
```

**参数说明：**
- `fieldKeys`: `List<String>`

---

### setShowUniqueResult

设置是否展示唯一校验结果

**方法签名：**
```java
public void setShowUniqueResult(boolean showUniqueResult)
```

**参数说明：**
- `showUniqueResult`: `boolean`

---
