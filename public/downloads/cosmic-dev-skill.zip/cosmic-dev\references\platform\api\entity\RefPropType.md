---
framework_version: "8.0.1"
api_class: "RefPropType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用引用属性时"
---

# RefPropType API 说明

## 概述
引用属性。实现 Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.RefPropType;
```

---

## 方法列表

### getId

获取id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getPropSet

引用属性解析成set集合

**方法签名：**
```java
public Set<String> getPropSet()
```

**返回值：**
- `Set<String>`

---

### getProps

获取引用属性

**方法签名：**
```java
public String getProps()
```

**返回值：**
- `String`

---

### isMaster

是否关联到主资料，对于主资料属性，需要支持第三层嵌套

**方法签名：**
```java
public boolean isMaster()
```

**返回值：**
- `boolean`

---

### setId

设置id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setMaster

设置是否关联到主资料，对于主资料属性，需要支持第三层嵌套

**方法签名：**
```java
public void setMaster(boolean master)
```

**参数说明：**
- `master`: `boolean`

---

### setProps

设置引用属性

**方法签名：**
```java
public void setProps(String props)
```

**参数说明：**
- `props`: `String`

---
