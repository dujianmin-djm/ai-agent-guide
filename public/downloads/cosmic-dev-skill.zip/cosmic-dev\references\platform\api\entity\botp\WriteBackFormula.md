---
framework_version: "8.0.1"
api_class: "WriteBackFormula"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用反写公式时"
---

# WriteBackFormula API 说明

## 概述
反写公式。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.WriteBackFormula;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public boolean check(MainEntityType srcMainType, MainEntityType tgtMainType, CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

**返回值：**
- `boolean`

---

### getCondition

反写执行条件，基于目标单字段：决定是否需要执行此反写条目

**方法签名：**
```java
public CRCondition getCondition()
```

**返回值：**
- `CRCondition`

---

### getFormula

反写执行条件，基于目标单字段：决定是否需要执行此反写条目

**方法签名：**
```java
public CRFormula getFormula()
```

**返回值：**
- `CRFormula`

---

### getId

反写条目标识，随机产生的长整数，绝不重复

**方法签名：**
```java
public long getId()
```

**返回值：**
- `long`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getSeq

反写条目执行顺序

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### getSourceCommitFieldKey

反写源单字段：把反写值，追加到此字段上

**方法签名：**
```java
public String getSourceCommitFieldKey()
```

**返回值：**
- `String`

---

### getWriteBackType

反写方式：Add = 0, Lessen = 1, Cover = 2

**方法签名：**
```java
public WriteBackType getWriteBackType()
```

**返回值：**
- `WriteBackType`

---

### getWriteType

反写方式类型

**方法签名：**
```java
public String getWriteType()
```

**返回值：**
- `String`

---

### isDisabled

是否禁用：可以临时禁用某条反写条目

**方法签名：**
```java
public boolean isDisabled()
```

**返回值：**
- `boolean`

---

### setCondition

反写执行条件，基于目标单字段：决定是否需要执行此反写条目

**方法签名：**
```java
public void setCondition(CRCondition condition)
```

**参数说明：**
- `condition`: `CRCondition`

---

### setDisabled

是否禁用：可以临时禁用某条反写条目

**方法签名：**
```java
public void setDisabled(boolean disabled)
```

**参数说明：**
- `disabled`: `boolean`

---

### setFormula

反写执行条件，基于目标单字段：决定是否需要执行此反写条目

**方法签名：**
```java
public void setFormula(CRFormula formula)
```

**参数说明：**
- `formula`: `CRFormula`

---

### setId

反写条目标识

**方法签名：**
```java
public void setId(long id)
```

**参数说明：**
- `id`: `long`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setSeq

反写条目执行顺序

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---

### setSourceCommitFieldKey

反写源单字段：把反写值，追加到此字段上

**方法签名：**
```java
public void setSourceCommitFieldKey(String sourceCommitFieldKey)
```

**参数说明：**
- `sourceCommitFieldKey`: `String`

---

### setWriteBackType

反写方式：Add = 0, Lessen = 1, Cover = 2

**方法签名：**
```java
public void setWriteBackType(WriteBackType writeBackType)
```

**参数说明：**
- `writeBackType`: `WriteBackType`

---

### setWriteType

反写方式 (字符串转换)

**方法签名：**
```java
public void setWriteType(String writeType)
```

**参数说明：**
- `writeType`: `String`

---
