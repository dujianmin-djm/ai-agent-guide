---
framework_version: "8.0.1"
api_class: "OperateErrorInfo"
api_package: "kd.bos.entity.operate.result"
when_to_use: "当你需要使用错误操作信息时"
---

# OperateErrorInfo API 说明

## 概述
错误操作信息。继承自 OperateInfo，实现 Serializable, IOperateInfo。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.result.OperateErrorInfo;
```

---

## 方法列表

### getErrorCode

获取错误码

**方法签名：**
```java
public String getErrorCode()
```

**返回值：**
- `String`

---

### getErrorCustInfos

获取错误定制信息，例如错误来源等；默认返回null，由错误源头灌入需向外传递的信息

**方法签名：**
```java
public Map<String,String> getErrorCustInfos()
```

**返回值：**
- `Map<String,String>`

---

### getErrorLevel

获取此条目的错误级别 toString()，用于序列化

**方法签名：**
```java
public String getErrorLevel()
```

**返回值：**
- `String`

---

### getLevel

获取此条目的错误级别，不序列化

**方法签名：**
```java
public ErrorLevel getLevel()
```

**返回值：**
- `ErrorLevel`

---

### getMsgReplaceHolders

{待补充}

**方法签名：**
```java
public List<kd.MsgReplaceHolder> getMsgReplaceHolders()
```

**返回值：**
- `List<kd.MsgReplaceHolder>`

---

### setErrorCode

设置错误码

**方法签名：**
```java
public void setErrorCode(String errorCode)
```

**参数说明：**
- `errorCode`: `String`

---

### setErrorCustInfos

设置错误定制信息，由错误源头调用，灌入需向外传递的信息

**方法签名：**
```java
public void setErrorCustInfos(Map<String,String> errorCustInfos)
```

**参数说明：**
- `errorCustInfos`: `Map<String,String>`

---

### setErrorLevel

设置此条目的错误级别 toString()，用于序列化

**方法签名：**
```java
public void setErrorLevel(String errorLevel)
```

**参数说明：**
- `errorLevel`: `String`

---

### setLevel

设置此条目的错误级别，不序列化

**方法签名：**
```java
public void setLevel(ErrorLevel level)
```

**参数说明：**
- `level`: `ErrorLevel`

---

### setMsgReplaceHolders

{待补充}

**方法签名：**
```java
public void setMsgReplaceHolders(List<kd.MsgReplaceHolder> msgReplaceHolders)
```

**参数说明：**
- `msgReplaceHolders`: `List<kd.MsgReplaceHolder>`

---
