---
framework_version: "8.0.1"
api_class: "VerifySignResult"
api_package: "kd.bos.ca.bean"
when_to_use: "当你需要使用验签结果类时"
---

# VerifySignResult API 说明

## 概述
验签结果类。。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.ca.bean.VerifySignResult;
```

---

## 方法列表

### getMessage

获取验签结果信息。

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`: 验签结果信息

---

### isSuccess

是否验签成功。

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`: 是否验签成功

---

### setMessage

设置验签结果信息。

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String` — 验签结果信息

---

### setSuccess

设置验签结果。

**方法签名：**
```java
public void setSuccess(boolean success)
```

**参数说明：**
- `success`: `boolean` — 验签结果

---
