---
framework_version: "8.0.1"
api_class: "SimpleProperty"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用简单属性基础实现时"
---

# SimpleProperty API 说明

## 概述
简单属性基础实现。继承自 DataEntityProperty，实现 ISimpleProperty, IDataEntityProperty, IMetadata, Cloneable, DefinedDbIgnoreAttribute。
主要功能：状态判断、读取属性、设置属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.SimpleProperty;
```

---

## 方法列表

### getAlias

{待补充}

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getDbType

{待补充}

**方法签名：**
```java
public int getDbType()
```

**返回值：**
- `int`

---

### getTableGroup

{待补充}

**方法签名：**
```java
public String getTableGroup()
```

**返回值：**
- `String`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isEnableNull

{待补充}

**方法签名：**
```java
public boolean isEnableNull()
```

**返回值：**
- `boolean`

---

### isEncrypt

{待补充}

**方法签名：**
```java
public boolean isEncrypt()
```

**返回值：**
- `boolean`

---

### isLocalizable

{待补充}

**方法签名：**
```java
public boolean isLocalizable()
```

**返回值：**
- `boolean`

---

### isPrimaryKey

{待补充}

**方法签名：**
```java
public boolean isPrimaryKey()
```

**返回值：**
- `boolean`

---

### resetValue

{待补充}

**方法签名：**
```java
public void resetValue(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

---

### setDirty

{待补充}

**方法签名：**
```java
public void setDirty(Object dataEntity, boolean newValue)
```

**参数说明：**
- `dataEntity`: `Object`
- `newValue`: `boolean`

---

### setEnableNull

设置是否允许为空

**方法签名：**
```java
public void setEnableNull(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setTableGroup

设置拆分表

**方法签名：**
```java
public void setTableGroup(String value)
```

**参数说明：**
- `value`: `String`

---

### shouldSerializeValue

{待补充}

**方法签名：**
```java
public boolean shouldSerializeValue(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
