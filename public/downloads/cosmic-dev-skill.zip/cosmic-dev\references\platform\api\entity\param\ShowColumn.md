---
framework_version: "8.0.1"
api_class: "ShowColumn"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用基础资料模糊查询列头对象时"
---

# ShowColumn API 说明

## 概述
基础资料模糊查询列头对象，用于描述查询结果中列的信息。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.param.ShowColumn;
```

---

## 方法列表

### getCaption

获取列的标题

**方法签名：**
```java
public String getCaption()
```

**返回值：**
- `String`: 列的标题

---

### getId

获取列的ID

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 列的ID

---

### getWidth

获取列的宽度

**方法签名：**
```java
public float getWidth()
```

**返回值：**
- `float`: 列的宽度

---

### isVisible

获取列是否可见的标志

**方法签名：**
```java
public boolean isVisible()
```

**返回值：**
- `boolean`: 列是否可见

---

### setCaption

设置列的标题

**方法签名：**
```java
public void setCaption(String caption)
```

**参数说明：**
- `caption`: `String` — 列的标题

---

### setId

设置列的ID

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 列的ID

---

### setVisible

设置列是否可见的标志

**方法签名：**
```java
public void setVisible(boolean visible)
```

**参数说明：**
- `visible`: `boolean` — 列是否可见

---

### setWidth

设置列的宽度

**方法签名：**
```java
public void setWidth(float width)
```

**参数说明：**
- `width`: `float` — 列的宽度

---
