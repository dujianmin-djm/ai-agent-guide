---
framework_version: "8.0.1"
api_class: "BeforeReadSourceBillEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用读取源单数据之前时"
---

# BeforeReadSourceBillEventArgs API 说明

## 概述
读取源单数据之前，触发此事件：用于添加需要加载的源单字段。继承自 WriteBackEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeReadSourceBillEventArgs;
```

---

## 方法列表

### getFieldKeys

插件需要用到的源单字段

**方法签名：**
```java
public List<String> getFieldKeys()
```

**返回值：**
- `List<String>`

---

### getRules

反写上游源单的全部反写规则

**方法签名：**
```java
public List<kd.WriteBackRuleElement> getRules()
```

**返回值：**
- `List<kd.WriteBackRuleElement>`

---

### getSrcBillIds

需要读取的源单内码：插件可以反写前，根据源单内码，读取第三方单据数据

**方法签名：**
```java
public Set<Long> getSrcBillIds()
```

**返回值：**
- `Set<Long>`

---

### getSrcMainType

上游源单主实体，包含了完整字段

**方法签名：**
```java
public BillEntityType getSrcMainType()
```

**返回值：**
- `BillEntityType`

---

### setSrcBillIds

传入源单内码

**方法签名：**
```java
public void setSrcBillIds(Set<Long> srcBillIds)
```

**参数说明：**
- `srcBillIds`: `Set<Long>`

---
