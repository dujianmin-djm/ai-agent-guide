---
framework_version: "8.0.1"
api_class: "DataEntityCacheType"
api_package: "kd.bos.dataentity.metadata"
when_to_use: "当你需要使用实体缓存的类型时"
---

# DataEntityCacheType API 说明

## 概述
实体缓存的类型，可选值包括： 共享型（缺省），隔离型。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.DataEntityCacheType;
```

---

## 方法列表

### forValue

通过整数值获取缓存类型

**方法签名：**
```java
public static DataEntityCacheType forValue(int value)
```

**参数说明：**
- `value`: `int`

**返回值：**
- `DataEntityCacheType`

---

### getValue

获取缓存类型整数值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
