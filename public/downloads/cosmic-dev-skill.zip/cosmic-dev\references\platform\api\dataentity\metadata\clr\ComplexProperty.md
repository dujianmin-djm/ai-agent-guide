---
framework_version: "8.0.1"
api_class: "ComplexProperty"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用实体复杂型属性时"
---

# ComplexProperty API 说明

## 概述
实体复杂型属性，比如基础资料。继承自 DataEntityProperty，实现 IComplexProperty, IDataEntityProperty, IMetadata, Cloneable, DefinedDbIgnoreAttribute。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.ComplexProperty;
```

---

## 方法列表

### getComplexType

{待补充}

**方法签名：**
```java
public IDataEntityType getComplexType()
```

**返回值：**
- `IDataEntityType`

---

### getRefIdPropName

{待补充}

**方法签名：**
```java
public String getRefIdPropName()
```

**返回值：**
- `String`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---
