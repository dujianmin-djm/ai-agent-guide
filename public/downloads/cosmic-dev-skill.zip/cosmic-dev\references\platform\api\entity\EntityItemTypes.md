---
framework_version: "8.0.1"
api_class: "EntityItemTypes"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用实体属性注册,用于反序列化来创建实体属性时"
---

# EntityItemTypes API 说明

## 概述
实体属性注册,用于反序列化来创建实体属性。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.EntityItemTypes;
```

---

## 方法列表

### clone

克隆一个实体属性

**方法签名：**
```java
public static IDataEntityProperty clone(IDataEntityProperty property)
```

**参数说明：**
- `property`: `IDataEntityProperty` — 被克隆的实体属性

**返回值：**
- `IDataEntityProperty`: 返回克隆的实体属性

---

### fromJsonString

从json反序列化为一个实体属性

**方法签名：**
```java
public static IDataEntityType fromJsonString(String str)
```

**参数说明：**
- `str`: `String` — 要反序列化的字符串

**返回值：**
- `IDataEntityType`: 反序列化的实体属性

---

### fromMap

从json反序列化为一个实体属性

**方法签名：**
```java
public static IDataEntityType fromMap(Map<String,Object> jsonMap)
```

**参数说明：**
- `jsonMap`: `Map<String,Object>` — 要反序列化的字符串

**返回值：**
- `IDataEntityType`: 反序列化的实体属性

---

### fromXmlString

**重载 1**

从XML反序列化为一个实体属性

**方法签名：**
```java
public static IDataEntityType fromXmlString(String str)
```

**参数说明：**
- `str`: `String` — 要反序列化的字符串

**返回值：**
- `IDataEntityType`: 反序列化的实体属性

---

**重载 2**

从XML反序列化为一个实体属性

**方法签名：**
```java
public static IDataEntityType fromXmlString(URL url)
```

**参数说明：**
- `url`: `URL` — 要反序列化的字符串资源地址

**返回值：**
- `IDataEntityType`: 反序列化的实体属性

---

### getDataEntityType

获取一个实体属性

**方法签名：**
```java
public static IDataEntityType getDataEntityType(String name)
```

**参数说明：**
- `name`: `String` — 实体属性名称

**返回值：**
- `IDataEntityType`: 返回实体属性实例

---

### register

注册一个实体属性

**方法签名：**
```java
public static void register(Class<?> clasz)
```

**参数说明：**
- `clasz`: `Class<?>`

---

### toJsonString

**重载 1**

将实体属性序列化为Json

**方法签名：**
```java
public static String toJsonString(IDataEntityType type)
```

**参数说明：**
- `type`: `IDataEntityType` — 实体属性

**返回值：**
- `String`: 返回序列化后的json字符串

---

**重载 2**

将实体属性序列化为Json

**方法签名：**
```java
public static String toJsonString(IMetadata type)
```

**参数说明：**
- `type`: `IMetadata` — 实体属性

**返回值：**
- `String`: 返回序列化后的json字符串

---

### toXmlString

将实体属性序列化为XML

**方法签名：**
```java
public static String toXmlString(IDataEntityType type)
```

**参数说明：**
- `type`: `IDataEntityType` — 实体属性

**返回值：**
- `String`: 返回序列化后的XML字符串

---
