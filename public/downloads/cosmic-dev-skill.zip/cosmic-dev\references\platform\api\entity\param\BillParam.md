---
framework_version: "8.0.1"
api_class: "BillParam"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用单据参数对象时"
---

# BillParam API 说明

## 概述
单据参数对象。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.param.BillParam;
```

---

## 方法列表

### getFuzzySearch

获取模糊查询参数

**方法签名：**
```java
public FuzzySearch getFuzzySearch()
```

**返回值：**
- `FuzzySearch`: 模糊查询参数

---

### getMobileListF7Config

获取移动端单据列表F7配置

**方法签名：**
```java
public MobileListF7Config getMobileListF7Config()
```

**返回值：**
- `MobileListF7Config`: 移动端单据列表F7配置

---

### getOverallParam

获取整体参数

**方法签名：**
```java
public OverallParam getOverallParam()
```

**返回值：**
- `OverallParam`: 整体参数

---

### setFuzzySearch

设置模糊查询参数

**方法签名：**
```java
public void setFuzzySearch(FuzzySearch fuzzySearch)
```

**参数说明：**
- `fuzzySearch`: `FuzzySearch` — 模糊查询参数

---

### setMobileListF7Config

设置移动端单据列表F7配置

**方法签名：**
```java
public void setMobileListF7Config(MobileListF7Config mobileListF7Config)
```

**参数说明：**
- `mobileListF7Config`: `MobileListF7Config` — 移动端单据列表F7配置

---

### setOverallParam

设置整体参数

**方法签名：**
```java
public void setOverallParam(OverallParam overallParam)
```

**参数说明：**
- `overallParam`: `OverallParam` — 整体参数

---
