---
framework_version: "8.0.1"
api_class: "AttachmentProp"
api_package: "kd.bos.entity.property"
when_to_use: "当你需要使用附件字段属性时"
---

# AttachmentProp API 说明

## 概述
附件字段属性。继承自 MulBasedataProp。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.AttachmentProp;
```

---

## 方法列表

### getCheckDuplicateFileName

是否检查文件名是否重复

**方法签名：**
```java
public boolean getCheckDuplicateFileName()
```

**返回值：**
- `boolean`

---

### getDragAtm

是否允许拖拽

**方法签名：**
```java
public boolean getDragAtm()
```

**返回值：**
- `boolean`

---

### getExtendName

附件后缀

**方法签名：**
```java
public String getExtendName()
```

**返回值：**
- `String`

---

### getMaxAtmCount

附件最大数量

**方法签名：**
```java
public int getMaxAtmCount()
```

**返回值：**
- `int`

---

### getMaxAtmSize

附件最大大小

**方法签名：**
```java
public int getMaxAtmSize()
```

**返回值：**
- `int`

---

### getSortField

排序字段

**方法签名：**
```java
public String getSortField()
```

**返回值：**
- `String`

---

### getSortType

排序方式

**方法签名：**
```java
public String getSortType()
```

**返回值：**
- `String`

---

### setCheckDuplicateFileName

设置是否检查文件名是否重复

**方法签名：**
```java
public void setCheckDuplicateFileName(boolean checkDuplicateFileName)
```

**参数说明：**
- `checkDuplicateFileName`: `boolean`

---

### setExtendName

设置附件后缀

**方法签名：**
```java
public void setExtendName(String extendName)
```

**参数说明：**
- `extendName`: `String`

---

### setMaxAtmCount

设置附件数量

**方法签名：**
```java
public void setMaxAtmCount(int maxAtmCount)
```

**参数说明：**
- `maxAtmCount`: `int`

---

### setSortField

设置排序字段

**方法签名：**
```java
public void setSortField(String sortField)
```

**参数说明：**
- `sortField`: `String`

---

### setSortType

获取排序方式

**方法签名：**
```java
public void setSortType(String sortType)
```

**参数说明：**
- `sortType`: `String`

---
