---
framework_version: "8.0.1"
api_class: "CacheHint"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用与缓存DataSet相关的参数时"
---

# CacheHint API 说明

## 概述
与缓存DataSet相关的参数，可以设置超时时间，每页缓存的大小，缓存的类型等信息。。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.algo.CacheHint;
```

---

## 方法列表

### getAllowMaxRows

获取dataset允许的最大数据行数

**方法签名：**
```java
public int getAllowMaxRows()
```

**返回值：**
- `int`: dataset允许的最大行数

---

### getCacheId

获取缓存id

**方法签名：**
```java
public String getCacheId()
```

**返回值：**
- `String`: 缓存id

---

### getDefault

获取一个默认的CacheHint

**方法签名：**
```java
public static CacheHint getDefault()
```

**返回值：**
- `CacheHint`: CacheHint

---

### getPageSize

获取每页大小

**方法签名：**
```java
public int getPageSize()
```

**返回值：**
- `int`: 每页大小

---

### getStorageType

获取缓存类型

**方法签名：**
```java
public String getStorageType()
```

**返回值：**
- `String`: 缓存类型

---

### getTimeout

获取超时时间

**方法签名：**
```java
public long getTimeout()
```

**返回值：**
- `long`: 超时时间

---

### isThrowExceptionWhenExceedAllowMaxRows

触发dataset允许的最大数据行数时是否抛出异常

**方法签名：**
```java
public boolean isThrowExceptionWhenExceedAllowMaxRows()
```

**返回值：**
- `boolean`: true为抛出异常，false不会抛出异常，会忽略超出最大行数的数据

---

### setAllowMaxRows

设置dataset允许的最大数据行数

**方法签名：**
```java
public void setAllowMaxRows(int allowMaxRows)
```

**参数说明：**
- `allowMaxRows`: `int` — 新的dataset允许的最大行数

---

### setCacheId

设置缓存id

**方法签名：**
```java
public void setCacheId(String cacheId)
```

**参数说明：**
- `cacheId`: `String` — 缓存id

---

### setPageSize

设置每页大小

**方法签名：**
```java
public void setPageSize(int pageSize)
```

**参数说明：**
- `pageSize`: `int` — 页大小

---

### setStorageType

设置缓存类型。

**方法签名：**
```java
public void setStorageType(String storageType)
```

**参数说明：**
- `storageType`: `String` — 缓存类型目前主要包括:redis,local(本地磁盘，不建议无法跨节点)，tempfile(文件服务器的临时文件)

---

### setThrowExceptionWhenExceedAllowMaxRows

设置触发dataset允许的最大数据行数时是否抛出异常

**方法签名：**
```java
public void setThrowExceptionWhenExceedAllowMaxRows(boolean throwExceptionWhenExceedAllowMaxRows)
```

**参数说明：**
- `throwExceptionWhenExceedAllowMaxRows`: `boolean` — true为抛出异常，false不会抛出异常，会忽略超出最大行数的数据

---

### setTimeout

**重载 1**

设置超时时间

**方法签名：**
```java
public void setTimeout(long timeout)
```

**参数说明：**
- `timeout`: `long` — 时间

---

**重载 2**

设置超时时间

**方法签名：**
```java
public void setTimeout(long timeout, TimeUnit unit)
```

**参数说明：**
- `timeout`: `long` — 时间
- `unit`: `TimeUnit` — 时间单位

---
