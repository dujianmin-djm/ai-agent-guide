---
framework_version: "8.0.1"
api_class: "CRValByConditionType"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用取值方式枚举时"
---

# CRValByConditionType API 说明

## 概述
取值方式枚举。实现 Comparable, Serializable。
主要功能：把整数枚举值转为枚举项。

## Import 路径
```java
import kd.bos.entity.botp.CRValByConditionType;
```

---

## 方法列表

### valueOf

把整数枚举值转为枚举项

**方法签名：**
```java
public static CRValByConditionType valueOf(int val)
```

**参数说明：**
- `val`: `int` — 枚举值

**返回值：**
- `CRValByConditionType`: 枚举项 ByCondition，Others

---
