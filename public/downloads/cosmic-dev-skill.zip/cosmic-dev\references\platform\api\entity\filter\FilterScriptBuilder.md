---
framework_version: "8.0.1"
api_class: "FilterScriptBuilder"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用把条件时"
---

# FilterScriptBuilder API 说明

## 概述
把条件，翻译为JavaScript脚本。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterScriptBuilder;
```

---

## 方法列表

### buildFilterScript

构建过滤对象的SQL

**方法签名：**
```java
public String[] buildFilterScript(FilterObject filterObj)
```

**参数说明：**
- `filterObj`: `FilterObject`

**返回值：**
- `String[]`: 数组, return[0] = 执行脚本；return[1] = 脚本描述

---

### isNumberField

是否为数值型字段

**方法签名：**
```java
public static boolean isNumberField(int fieldType)
```

**参数说明：**
- `fieldType`: `int`

**返回值：**
- `boolean`

---

### isStringField

是否为字符型字段

**方法签名：**
```java
public static boolean isStringField(int fieldType)
```

**参数说明：**
- `fieldType`: `int`

**返回值：**
- `boolean`

---

### setTimeService

依赖的数据服务

**方法签名：**
```java
public void setTimeService(ITimeService timeService)
```

**参数说明：**
- `timeService`: `ITimeService`

---

### setUserService

依赖的数据服务

**方法签名：**
```java
public void setUserService(IUserService userService)
```

**参数说明：**
- `userService`: `IUserService`

---
