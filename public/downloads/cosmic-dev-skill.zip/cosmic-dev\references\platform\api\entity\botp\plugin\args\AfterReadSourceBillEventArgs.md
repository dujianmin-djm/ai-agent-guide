---
framework_version: "8.0.1"
api_class: "AfterReadSourceBillEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用读取源单数据之后时"
---

# AfterReadSourceBillEventArgs API 说明

## 概述
读取源单数据之后，触发此事件：供插件读取相关的第三方单据。继承自 WriteBackEventArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterReadSourceBillEventArgs;
```

---

## 方法列表

### getSrcDataEntities

源单数据包，只包含了部分用到的字段

**方法签名：**
```java
public DynamicObject[] getSrcDataEntities()
```

**返回值：**
- `DynamicObject[]`

---

### getSrcSubMainType

源单主实体，只包含了部分用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---
