---
framework_version: "8.0.1"
api_class: "BillTypeControlInfo"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用单据类型时"
---

# BillTypeControlInfo API 说明

## 概述
单据类型，字段控制。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.BillTypeControlInfo;
```

---

## 方法列表

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### getDefValue

获取字段defValue的值

**方法签名：**
```java
public String getDefValue()
```

**返回值：**
- `String`: defValue的值

---

### getDefValueType

缺省值类型：0:不支持缺省值 1：简单类型 2：复杂类型

**方法签名：**
```java
public int getDefValueType()
```

**返回值：**
- `int`

---

### getEntityFieldKey

实体标识key

**方法签名：**
```java
public String getEntityFieldKey()
```

**返回值：**
- `String`: 实体标识key

---

### getFieldId

实体Id,关联实体用

**方法签名：**
```java
public String getFieldId()
```

**返回值：**
- `String`: 实体Id,关联实体用

---

### getFieldKey

获取字段fieldKey的值

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`: fieldKey的值

---

### getFieldName

获取字段fieldName的值

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: fieldName的值

---

### getFieldType

获取字段fieldType的值

**方法签名：**
```java
public String getFieldType()
```

**返回值：**
- `String`: fieldType的值

---

### getLock

获取字段lock的值

**方法签名：**
```java
public int getLock()
```

**返回值：**
- `int`: lock的值

---

### getMustInputType

必录类型：0：不支持必录 1：支持

**方法签名：**
```java
public int getMustInputType()
```

**返回值：**
- `int`: 必录类型：0：不支持必录 1：支持

---

### getVisible

获取字段visible的值

**方法签名：**
```java
public int getVisible()
```

**返回值：**
- `int`: visible的值

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---

### isLock

获取字段是否锁定

**方法签名：**
```java
public boolean isLock(String status)
```

**参数说明：**
- `status`: `String`

**返回值：**
- `boolean`

---

### isMustInput

获取字段mustInput的值

**方法签名：**
```java
public boolean isMustInput()
```

**返回值：**
- `boolean`: mustInput的值

---

### isVisible

获取字段是否可见

**方法签名：**
```java
public boolean isVisible(String status)
```

**参数说明：**
- `status`: `String`

**返回值：**
- `boolean`

---

### setDefValue

将参数defValue的值赋给字段defValue

**方法签名：**
```java
public void setDefValue(String defValue)
```

**参数说明：**
- `defValue`: `String`

---

### setDefValueType

缺省值类型：0:不支持缺省值 1：简单类型 2：复杂类型

**方法签名：**
```java
public void setDefValueType(int defValueType)
```

**参数说明：**
- `defValueType`: `int`

---

### setEntityFieldKey

实体标识key

**方法签名：**
```java
public void setEntityFieldKey(String entityFieldKey)
```

**参数说明：**
- `entityFieldKey`: `String` — 实体标识key

---

### setFieldId

实体Id,关联实体用

**方法签名：**
```java
public void setFieldId(String fieldId)
```

**参数说明：**
- `fieldId`: `String` — 实体Id,关联实体用

---

### setFieldKey

将参数fieldKey的值赋给字段fieldKey

**方法签名：**
```java
public void setFieldKey(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String`

---

### setFieldName

将参数fieldName的值赋给字段fieldName

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setFieldType

将参数fieldType的值赋给字段fieldType

**方法签名：**
```java
public void setFieldType(String fieldType)
```

**参数说明：**
- `fieldType`: `String`

---

### setLock

将参数lock的值赋给字段lock

**方法签名：**
```java
public void setLock(int lock)
```

**参数说明：**
- `lock`: `int`

---

### setLockInStr

根据参数 lock 的锁定性设置字段的锁定性，参数eg:new,edit

**方法签名：**
```java
public void setLockInStr(String lock)
```

**参数说明：**
- `lock`: `String`

---

### setMustInput

将参数mustInput的值赋给字段mustInput

**方法签名：**
```java
public void setMustInput(boolean mustInput)
```

**参数说明：**
- `mustInput`: `boolean`

---

### setMustInputType

必录类型：0：不支持必录 1：支持

**方法签名：**
```java
public void setMustInputType(int mustInputType)
```

**参数说明：**
- `mustInputType`: `int` — 必录类型：0：不支持必录 1：支持

---

### setVisible

将参数visible的值赋给字段visible

**方法签名：**
```java
public void setVisible(int visible)
```

**参数说明：**
- `visible`: `int`

---
