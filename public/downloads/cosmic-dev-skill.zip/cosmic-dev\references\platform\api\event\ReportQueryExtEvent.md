---
framework_version: "8.0.1"
api_class: "ReportQueryExtEvent"
api_package: "kd.bos.event"
when_to_use: "当你需要使用报表查询扩展事件类时"
---

# ReportQueryExtEvent API 说明

## 概述
报表查询扩展事件类。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.event.ReportQueryExtEvent;
```

---

## 方法列表

### getColumns

获取报表列集合

**方法签名：**
```java
public List<AbstractReportColumn> getColumns()
```

**返回值：**
- `List<AbstractReportColumn>`: 报表列集合，包含所有列信息

---

### getDataSet

获取数据集

**方法签名：**
```java
public DataSet getDataSet()
```

**返回值：**
- `DataSet`: 数据集，包含报表查询结果的数据集合

---

### getEntityType

获取报表主实体

**方法签名：**
```java
public MainEntityType getEntityType()
```

**返回值：**
- `MainEntityType`

---

### getReportQueryParam

获取报表查询参数

**方法签名：**
```java
public ReportQueryParam getReportQueryParam()
```

**返回值：**
- `ReportQueryParam`: 报表查询参数，包含查询条件和参数信息

---

### setDataSet

设置数据集

**方法签名：**
```java
public void setDataSet(DataSet dataSet)
```

**参数说明：**
- `dataSet`: `DataSet` — 数据集

---
