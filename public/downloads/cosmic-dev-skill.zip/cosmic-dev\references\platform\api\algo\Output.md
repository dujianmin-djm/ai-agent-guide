---
framework_version: "8.0.1"
api_class: "Output"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用algox使用:在algox处理完输入的Input之后时"
---

# Output API 说明

## 概述
algox使用:在algox处理完输入的Input之后，会形成一个输出，此接口是顶层接口。建议自定义输出时使用kd.bos.algo.CustomizedOutput。实现 Serializable。
主要功能：状态判断。

## Import 路径
```java
import kd.bos.algo.Output;
```

---

## 方法列表

### isSingleParallel

此输出是否是串行的

**方法签名：**
```java
public boolean isSingleParallel()
```

**返回值：**
- `boolean`: true if output is single parallel

---
