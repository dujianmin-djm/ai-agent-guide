---
framework_version: "8.0.1"
api_class: "SensitiveArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用敏感事件参数时"
---

# SensitiveArgs API 说明

## 概述
敏感事件参数。继承自 EventObject，实现 Serializable。
主要功能：添加元素、读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.SensitiveArgs;
```

---

## 方法列表

### addField

**重载 1**

添加需要处理的敏感字段

**方法签名：**
```java
public void addField(String field)
```

**参数说明：**
- `field`: `String`

---

**重载 2**

添加需要处理的敏感字段

**方法签名：**
```java
public void addField(String field, String regex, String replacement)
```

**参数说明：**
- `field`: `String`
- `regex`: `String`
- `replacement`: `String`

---

**重载 3**

添加需要处理的敏感字段

**方法签名：**
```java
public void addField(String field, SensitiveArgs.SensitiveRule rule)
```

**参数说明：**
- `field`: `String`
- `rule`: `SensitiveArgs.SensitiveRule`

---

**重载 4**

添加需要处理的敏感字段

**方法签名：**
```java
public void addField(List<String> fields)
```

**参数说明：**
- `fields`: `List<String>`

---

**重载 5**

添加需要处理的敏感字段

**方法签名：**
```java
public void addField(Map<String,SensitiveArgs.SensitiveRule> fieldMap)
```

**参数说明：**
- `fieldMap`: `Map<String,SensitiveArgs.SensitiveRule>`

---

### clearField

清空所有敏感字段

**方法签名：**
```java
public void clearField()
```

---

### contain

是否包含给定的字段

**方法签名：**
```java
public boolean contain(String field)
```

**参数说明：**
- `field`: `String`

**返回值：**
- `boolean`

---

### getDesensitiveFun

获取替换函数

**方法签名：**
```java
public SensitiveArgs.DesensitiveFun getDesensitiveFun()
```

**返回值：**
- `SensitiveArgs.DesensitiveFun`

---

### getRule

获取给定字段的敏感词规则

**方法签名：**
```java
public SensitiveArgs.SensitiveRule getRule(String field)
```

**参数说明：**
- `field`: `String`

**返回值：**
- `SensitiveArgs.SensitiveRule`

---

### setDesensitiveFun

设置替换函数

**方法签名：**
```java
public void setDesensitiveFun(SensitiveArgs.DesensitiveFun desensitiveFun)
```

**参数说明：**
- `desensitiveFun`: `SensitiveArgs.DesensitiveFun`

---
