---
framework_version: "8.0.1"
api_class: "FilterScheme"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用方案过滤存储类时"
---

# FilterScheme API 说明

## 概述
方案过滤存储类。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.FilterScheme;
```

---

## 方法列表

### getCreateTime

创建时间

**方法签名：**
```java
public Date getCreateTime()
```

**返回值：**
- `Date`

---

### getDataEntityState

获取数据包状态

**方法签名：**
```java
public DataEntityState getDataEntityState()
```

**返回值：**
- `DataEntityState`

---

### getDescription

方案描述

**方法签名：**
```java
public String getDescription()
```

**返回值：**
- `String`

---

### getEntryEntity

分录标识

**方法签名：**
```java
public String getEntryEntity()
```

**返回值：**
- `String`

---

### getFormId

表单id

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`

---

### getId

方案id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getLocaleFilterScheme

多语言过滤方案

**方法签名：**
```java
public LocaleFilterScheme getLocaleFilterScheme()
```

**返回值：**
- `LocaleFilterScheme`

---

### getLocaleName

多语言名称

**方法签名：**
```java
public LocaleString getLocaleName()
```

**返回值：**
- `LocaleString`

---

### getModifyTime

修改时间

**方法签名：**
```java
public Date getModifyTime()
```

**返回值：**
- `Date`

---

### getScheme

方案内容

**方法签名：**
```java
public String getScheme()
```

**返回值：**
- `String`

---

### getSchemeName

方案名称

**方法签名：**
```java
public String getSchemeName()
```

**返回值：**
- `String`

---

### getSeq

序号

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### getUserId

用户id

**方法签名：**
```java
public long getUserId()
```

**返回值：**
- `long`

---

### isDefault

默认方案

**方法签名：**
```java
public boolean isDefault()
```

**返回值：**
- `boolean`

---

### isF7

isF7

**方法签名：**
```java
public boolean isF7()
```

**返回值：**
- `boolean`

---

### isFixed

全局方案

**方法签名：**
```java
public boolean isFixed()
```

**返回值：**
- `boolean`

---

### isNextEntryScheme

是否是下一个分录方案

**方法签名：**
```java
public boolean isNextEntryScheme()
```

**返回值：**
- `boolean`

---

### isShare

是否共享

**方法签名：**
```java
public boolean isShare()
```

**返回值：**
- `boolean`

---

### setCreateTime

创建时间

**方法签名：**
```java
public void setCreateTime(Date createTime)
```

**参数说明：**
- `createTime`: `Date`

---

### setDataEntityState

设置数据包状态

**方法签名：**
```java
public void setDataEntityState(DataEntityState dataEntityState)
```

**参数说明：**
- `dataEntityState`: `DataEntityState`

---

### setDefault

默认方案

**方法签名：**
```java
public void setDefault(boolean isDefault)
```

**参数说明：**
- `isDefault`: `boolean`

---

### setDescription

方案描述

**方法签名：**
```java
public void setDescription(String description)
```

**参数说明：**
- `description`: `String`

---

### setEntryEntity

分录标识

**方法签名：**
```java
public void setEntryEntity(String entryEntity)
```

**参数说明：**
- `entryEntity`: `String`

---

### setF7

isF7

**方法签名：**
```java
public void setF7(boolean isF7)
```

**参数说明：**
- `isF7`: `boolean`

---

### setFixed

全局方案

**方法签名：**
```java
public void setFixed(boolean isFixed)
```

**参数说明：**
- `isFixed`: `boolean`

---

### setFormId

表单id

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String`

---

### setId

方案id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String`

---

### setLocaleFilterScheme

设置多语言过滤方案

**方法签名：**
```java
public void setLocaleFilterScheme(LocaleFilterScheme localeFilterScheme)
```

**参数说明：**
- `localeFilterScheme`: `LocaleFilterScheme`

---

### setModifyTime

修改时间

**方法签名：**
```java
public void setModifyTime(Date modifyTime)
```

**参数说明：**
- `modifyTime`: `Date`

---

### setNextEntryScheme

是否是下一个分录方案

**方法签名：**
```java
public void setNextEntryScheme(boolean isNextEntryScheme)
```

**参数说明：**
- `isNextEntryScheme`: `boolean`

---

### setScheme

方案内容

**方法签名：**
```java
public void setScheme(String scheme)
```

**参数说明：**
- `scheme`: `String`

---

### setSchemeName

方案名称

**方法签名：**
```java
public void setSchemeName(String schemeName)
```

**参数说明：**
- `schemeName`: `String`

---

### setSeq

序号

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int`

---

### setShare

是否共享

**方法签名：**
```java
public void setShare(boolean isShare)
```

**参数说明：**
- `isShare`: `boolean`

---

### setUserId

用户id

**方法签名：**
```java
public void setUserId(long userId)
```

**参数说明：**
- `userId`: `long`

---
