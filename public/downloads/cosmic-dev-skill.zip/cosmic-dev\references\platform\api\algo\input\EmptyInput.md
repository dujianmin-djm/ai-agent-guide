---
framework_version: "8.0.1"
api_class: "EmptyInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用构建一个空的Dataset时时"
---

# EmptyInput API 说明

## 概述
构建一个空的Dataset时，使用此Input作为输入。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.EmptyInput;
```

---

## 方法列表

### getRowMeta

获取元数据信息

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`

---
