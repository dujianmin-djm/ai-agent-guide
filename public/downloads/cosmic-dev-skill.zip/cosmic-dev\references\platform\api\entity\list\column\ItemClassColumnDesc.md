---
framework_version: "8.0.1"
api_class: "ItemClassColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用多列表基础资料格式化处理类时"
---

# ItemClassColumnDesc API 说明

## 概述
多列表基础资料格式化处理类。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.ItemClassColumnDesc;
```

---

## 方法列表

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject o)
```

**参数说明：**
- `o`: `DynamicObject`

**返回值：**
- `Object`

---
