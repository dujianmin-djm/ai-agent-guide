---
framework_version: "8.0.1"
api_class: "DcJsonSerializer"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用对象序列化工具（JSON）时"
---

# DcJsonSerializer API 说明

## 概述
对象序列化工具（JSON）。继承自 DcSerializer。
主要功能：对指定数据执行反序列化操作、对指定的文本执行反序列化操作、序列化实体数据、序列化实体数据，产生差量信息。

## Import 路径
```java
import kd.bos.dataentity.serialization.DcJsonSerializer;
```

---

## 方法列表

### deserializeFromMap

对指定数据执行反序列化操作

**方法签名：**
```java
public final Object deserializeFromMap(Map<String,Object> jsonMap, Object entity)
```

**参数说明：**
- `jsonMap`: `Map<String,Object>` — 数据
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

### deserializeFromString

对指定的文本执行反序列化操作

**方法签名：**
```java
public final Object deserializeFromString(String jsonString, Object entity)
```

**参数说明：**
- `jsonString`: `String` — 数据来源
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

### serializeToMap

序列化实体数据

**方法签名：**
```java
public final Map<String,Object> serializeToMap(Object currentEntity, Object baseEntity)
```

**参数说明：**
- `currentEntity`: `Object` — 当前实体
- `baseEntity`: `Object` — 基础实体

**返回值：**
- `Map<String,Object>`

---

### serializeToString

序列化实体数据，产生差量信息

**方法签名：**
```java
public final String serializeToString(Object currentEntity, Object baseEntity)
```

**参数说明：**
- `currentEntity`: `Object` — 当前实体
- `baseEntity`: `Object` — 基础实体

**返回值：**
- `String`

---
