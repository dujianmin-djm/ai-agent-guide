---
framework_version: "8.0.1"
api_class: "DataEntityType"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用实体基类时"
---

# DataEntityType API 说明

## 概述
实体基类。实现 IDataEntityType, IMetadata, Cloneable。
主要功能：读取属性、设置属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.DataEntityType;
```

---

## 方法列表

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createInstance

**重载 1**

{待补充}

**方法签名：**
```java
public Object createInstance()
```

**返回值：**
- `Object`

---

**重载 2**

{待补充}

**方法签名：**
```java
public Object createInstance(boolean isQueryObj)
```

**参数说明：**
- `isQueryObj`: `boolean`

**返回值：**
- `Object`

---

### getAlias

{待补充}

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getCacheType

{待补充}

**方法签名：**
```java
public DataEntityCacheType getCacheType()
```

**返回值：**
- `DataEntityCacheType`

---

### getDBRouteKey

{待补充}

**方法签名：**
```java
public final String getDBRouteKey()
```

**返回值：**
- `String`

---

### getDataEntityClass

获取实体对象的强类型

**方法签名：**
```java
public Class<?> getDataEntityClass()
```

**返回值：**
- `Class<?>`

---

### getDataEntityReferenceSchema

{待补充}

**方法签名：**
```java
public Object getDataEntityReferenceSchema()
```

**返回值：**
- `Object`

---

### getDataEntityType

根据Type类型获取实体类型DataEntityType，用于将强类型的实体类转为DataEntityType

**方法签名：**
```java
public static IDataEntityType getDataEntityType(Class<?> type)
```

**参数说明：**
- `type`: `Class<?>` — 传入的实体类型

**返回值：**
- `IDataEntityType`

---

### getDirtyProperties

**重载 1**

{待补充}

**方法签名：**
```java
public final List<kd.IDataEntityProperty> getDirtyProperties(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `List<kd.IDataEntityProperty>`

---

**重载 2**

{待补充}

**方法签名：**
```java
public final List<kd.IDataEntityProperty> getDirtyProperties(Object dataEntity, boolean includehasDefualt)
```

**参数说明：**
- `dataEntity`: `Object`
- `includehasDefualt`: `boolean`

**返回值：**
- `List<kd.IDataEntityProperty>`

---

### getDisplayName

获取显示名称

**方法签名：**
```java
public LocaleString getDisplayName()
```

**返回值：**
- `LocaleString`: 返回显示名称

---

### getFlag

{待补充}

**方法签名：**
```java
public DataEntityTypeFlag getFlag()
```

**返回值：**
- `DataEntityTypeFlag`

---

### getFullIndexFields

{待补充}

**方法签名：**
```java
public Set<String> getFullIndexFields()
```

**返回值：**
- `Set<String>`

---

### getJsonSerializerProperties

{待补充}

**方法签名：**
```java
public List<kd.IDataEntityProperty> getJsonSerializerProperties()
```

**返回值：**
- `List<kd.IDataEntityProperty>`

---

### getName

{待补充}

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getParent

**重载 1**

{待补充}

**方法签名：**
```java
public IDataEntityType getParent()
```

**返回值：**
- `IDataEntityType`

---

**重载 2**

{待补充}

**方法签名：**
```java
public Object getParent(Object currentObject)
```

**参数说明：**
- `currentObject`: `Object`

**返回值：**
- `Object`

---

### getPkSnapshot

{待补充}

**方法签名：**
```java
public final PkSnapshotSet getPkSnapshot(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `PkSnapshotSet`

---

### getPrimaryKey

{待补充}

**方法签名：**
```java
public ISimpleProperty getPrimaryKey()
```

**返回值：**
- `ISimpleProperty`

---

### getProperties

{待补充}

**方法签名：**
```java
public DataEntityPropertyCollection getProperties()
```

**返回值：**
- `DataEntityPropertyCollection`

---

### getSortProperties

{待补充}

**方法签名：**
```java
public List<kd.ISimpleProperty> getSortProperties()
```

**返回值：**
- `List<kd.ISimpleProperty>`

---

### isDbIgnore

{待补充}

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---

### isDirty

{待补充}

**方法签名：**
```java
public boolean isDirty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isFullIndexDataSynced

{待补充}

**方法签名：**
```java
public boolean isFullIndexDataSynced()
```

**返回值：**
- `boolean`

---

### setAlias

{待补充}

**方法签名：**
```java
public void setAlias(String tableName)
```

**参数说明：**
- `tableName`: `String`

---

### setDataEntityReferenceSchema

{待补充}

**方法签名：**
```java
public void setDataEntityReferenceSchema(Object dataEntityReferenceSchema)
```

**参数说明：**
- `dataEntityReferenceSchema`: `Object`

---

### setDirty

设置实体全部为脏或不脏

**方法签名：**
```java
public final void setDirty(Object dataEntity, boolean newValue)
```

**参数说明：**
- `dataEntity`: `Object`
- `newValue`: `boolean`

---

### setDisplayName

设置显示名称

**方法签名：**
```java
public void setDisplayName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setFromDatabase

**重载 1**

{待补充}

**方法签名：**
```java
public void setFromDatabase(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

---

**重载 2**

{待补充}

**方法签名：**
```java
public void setFromDatabase(Object dataEntity, boolean clearDirty)
```

**参数说明：**
- `dataEntity`: `Object`
- `clearDirty`: `boolean`

---

### setPkSnapshot

{待补充}

**方法签名：**
```java
public final void setPkSnapshot(Object dataEntity, PkSnapshotSet pkSnapshotSet)
```

**参数说明：**
- `dataEntity`: `Object`
- `pkSnapshotSet`: `PkSnapshotSet`

---

### toString

返回类型的名称。

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 在CLR实现中，返回的是类的名称。

---
