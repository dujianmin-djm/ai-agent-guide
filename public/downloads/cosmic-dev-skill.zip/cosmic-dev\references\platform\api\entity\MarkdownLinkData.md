---
framework_version: "8.0.1"
api_class: "MarkdownLinkData"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用Markdown链接数据对象时"
---

# MarkdownLinkData API 说明

## 概述
Markdown链接数据对象。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.MarkdownLinkData;
```

---

## 方法列表

### getCode

获取指令
 可以是外部指令，如：https://www.baidu.com，外部指令会跳转到新页签打开页面
 可以是内部指令，如：click，会发送customEvent事件到插件。

**方法签名：**
```java
public String getCode()
```

**返回值：**
- `String`

---

### getIndex

获取占位符索引，和占位符 #{index}对应

**方法签名：**
```java
public Integer getIndex()
```

**返回值：**
- `Integer`

---

### setCode

设置指令
 可以是外部指令，如：https://www.baidu.com，外部指令会跳转到新页签打开页面
 可以是内部指令，如：click，会发送customEvent事件到插件。

**方法签名：**
```java
public void setCode(String code)
```

**参数说明：**
- `code`: `String`

---

### setIndex

设置占位符索引，和占位符 #{index}对应

**方法签名：**
```java
public void setIndex(Integer index)
```

**参数说明：**
- `index`: `Integer`

---
