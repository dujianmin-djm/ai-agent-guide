---
framework_version: "8.0.1"
api_class: "BeforeSaveAuditLogArg"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作完成时"
---

# BeforeSaveAuditLogArg API 说明

## 概述
操作完成，保存审计日志前事件参数。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.BeforeSaveAuditLogArg;
```

---

## 方法列表

### getModifyInfo

返回单据审计日志内容

**方法签名：**
```java
public EntityModifyInfo getModifyInfo()
```

**返回值：**
- `EntityModifyInfo`

---
