---
framework_version: "8.0.1"
api_class: "CollectionProperty"
api_package: "kd.bos.dataentity.metadata.clr"
when_to_use: "当你需要使用实体集合型属性时"
---

# CollectionProperty API 说明

## 概述
实体集合型属性，比如分录，多选基础资料，多语言属性等。继承自 DataEntityProperty，实现 ICollectionProperty, IDataEntityProperty, IMetadata, Cloneable, DefinedDbIgnoreAttribute。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.metadata.clr.CollectionProperty;
```

---

## 方法列表

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### getItemType

{待补充}

**方法签名：**
```java
public IDataEntityType getItemType()
```

**返回值：**
- `IDataEntityType`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---
