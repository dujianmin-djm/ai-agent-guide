---
framework_version: "8.0.1"
api_class: "Collector"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用可通过该接口进行数据处理时"
---

# Collector API 说明

## 概述
可通过该接口进行数据处理，譬如构建构建DataSet。。
主要功能：数据处理。

## Import 路径
```java
import kd.bos.algo.Collector;
```

---

## 方法列表

### collect

数据处理

**方法签名：**
```java
public void collect(Object[] values)
```

**参数说明：**
- `values`: `Object[]` — 构成结果集的行信息

---
