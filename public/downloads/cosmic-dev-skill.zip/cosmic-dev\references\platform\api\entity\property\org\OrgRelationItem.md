---
framework_version: "8.0.1"
api_class: "OrgRelationItem"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用组织字段上的委托关系属性时"
---

# OrgRelationItem API 说明

## 概述
组织字段上的委托关系属性。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgRelationItem;
```

---

## 方法列表

### getDirect

获取协作方向，本组织是委托方还是受托方

**方法签名：**
```java
public OrgRelationItemDirect getDirect()
```

**返回值：**
- `OrgRelationItemDirect`: 协作方向

---

### getId

获取内码，随机生成的唯一标识

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 内码

---

### getOrg

获取关联组织字段

**方法签名：**
```java
public OrgRelationItemOrg getOrg()
```

**返回值：**
- `OrgRelationItemOrg`: 关联组织字段

---

### getType

获取业务协作类型

**方法签名：**
```java
public OrgRelationItemType getType()
```

**返回值：**
- `OrgRelationItemType`: 业务协作类型

---

### setDirect

设置协作方向

**方法签名：**
```java
public void setDirect(OrgRelationItemDirect direct)
```

**参数说明：**
- `direct`: `OrgRelationItemDirect` — 协作方向

---

### setId

设置内码

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 内码

---

### setOrg

设置关联组织字段

**方法签名：**
```java
public void setOrg(OrgRelationItemOrg org)
```

**参数说明：**
- `org`: `OrgRelationItemOrg` — 关联组织字段

---

### setType

设置业务协作类型

**方法签名：**
```java
public void setType(OrgRelationItemType type)
```

**参数说明：**
- `type`: `OrgRelationItemType` — 业务协作类型

---
