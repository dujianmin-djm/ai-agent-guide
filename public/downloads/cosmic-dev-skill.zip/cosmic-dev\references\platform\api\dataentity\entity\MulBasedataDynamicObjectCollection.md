---
framework_version: "8.0.1"
api_class: "MulBasedataDynamicObjectCollection"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用多选基础资料的数据行集合时"
---

# MulBasedataDynamicObjectCollection API 说明

## 概述
多选基础资料的数据行集合。继承自 DynamicObjectCollection，实现 Serializable, ISupportInitialize, List, RandomAccess, Cloneable。
主要功能：添加元素。

## Import 路径
```java
import kd.bos.dataentity.entity.MulBasedataDynamicObjectCollection;
```

---

## 方法列表

### add

新增实体对象

**方法签名：**
```java
public boolean add(DynamicObject item)
```

**参数说明：**
- `item`: `DynamicObject` — 动态实体对象

**返回值：**
- `boolean`

---
