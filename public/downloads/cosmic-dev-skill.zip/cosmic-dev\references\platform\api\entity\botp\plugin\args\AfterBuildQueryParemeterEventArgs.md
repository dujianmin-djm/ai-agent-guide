---
framework_version: "8.0.1"
api_class: "AfterBuildQueryParemeterEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用构建取数参数后事件：可在正式读取源单数据之前时"
---

# AfterBuildQueryParemeterEventArgs API 说明

## 概述
构建取数参数后事件：可在正式读取源单数据之前，添加额外的字段、过滤条件。继承自 ConvertPluginEventArgs。
主要功能：读取属性、添加元素。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterBuildQueryParemeterEventArgs;
```

---

## 方法列表

### addSrcField

添加需加载的源单字段

**方法签名：**
```java
public void addSrcField(String fullPropName)
```

**参数说明：**
- `fullPropName`: `String` — 字段及引用属性名，如 basedata.name；不需要在前面带单据体标识

---

### getQFilters

系统自动生成的源单内码条件；插件可以修改与追加新条件

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getSrcFldAlias

系统自动生成，源单字段与字段别名字典；插件可以向此字典追加新字段，并指定别名；不支持删除字段

**方法签名：**
```java
public Map<String,String> getSrcFldAlias()
```

**返回值：**
- `Map<String,String>`

---
