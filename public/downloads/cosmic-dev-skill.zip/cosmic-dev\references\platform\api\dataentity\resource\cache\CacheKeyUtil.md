---
framework_version: "8.0.1"
api_class: "CacheKeyUtil"
api_package: "kd.bos.dataentity.resource.cache"
when_to_use: "当你需要使用缓存标识构造工具时"
---

# CacheKeyUtil API 说明

## 概述
缓存标识构造工具。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.resource.cache.CacheKeyUtil;
```

---

## 方法列表

### getAcctId

获取账套隔离的缓存Key

**方法签名：**
```java
public static String getAcctId()
```

**返回值：**
- `String`

---

### getPageCacheKeyTimeout

获取表单页面数据缓存 过期时间

**方法签名：**
```java
public static int getPageCacheKeyTimeout()
```

**返回值：**
- `int`

---
