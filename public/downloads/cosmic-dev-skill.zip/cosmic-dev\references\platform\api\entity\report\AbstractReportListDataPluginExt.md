---
framework_version: "8.0.1"
api_class: "AbstractReportListDataPluginExt"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用 AbstractReportListDataPluginExt 相关功能时"
---

# AbstractReportListDataPluginExt API 说明

## 概述
AbstractReportListDataPluginExt 类。实现 IReportListDataServiceExt, Serializable。
主要功能：事件处理、读取属性。

## Import 路径
```java
import kd.bos.entity.report.AbstractReportListDataPluginExt;
```

---

## 方法列表

### afterQuery

{待补充}

**方法签名：**
```java
public void afterQuery(AfterQueryEvent event)
```

**参数说明：**
- `event`: `AfterQueryEvent`

---

### getDynamicColumns

{待补充}

**方法签名：**
```java
public void getDynamicColumns(DynamicReportColumnEvent event)
```

**参数说明：**
- `event`: `DynamicReportColumnEvent`

---
