---
framework_version: "8.0.1"
api_class: "DataEntityDeserializerOption"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用数据包反序列化参数时"
---

# DataEntityDeserializerOption API 说明

## 概述
数据包反序列化参数。
主要功能：状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.serialization.DataEntityDeserializerOption;
```

---

## 方法列表

### isIncludeDataEntityState

获取数据包中是否包含state标志

**方法签名：**
```java
public boolean isIncludeDataEntityState()
```

**返回值：**
- `boolean`: true：包含，false：不包含

---

### setIncludeDataEntityState

设置数据包中是否包含state标志

**方法签名：**
```java
public void setIncludeDataEntityState(boolean includeDataEntityState)
```

**参数说明：**
- `includeDataEntityState`: `boolean` — 数据包中是否包含state标志

---
