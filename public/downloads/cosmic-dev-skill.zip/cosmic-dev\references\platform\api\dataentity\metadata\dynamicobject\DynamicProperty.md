---
framework_version: "8.0.1"
api_class: "DynamicProperty"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用动态属性的基类,对实体字段值的操作是通过它来完成的.时"
---

# DynamicProperty API 说明

## 概述
动态属性的基类,对实体字段值的操作是通过它来完成的.。继承自 DynamicMetadata，实现 IDataEntityProperty, ILongDataProperty, Serializable, Cloneable, IMetadata。
主要功能：读取属性、设置属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicProperty;
```

---

## 方法列表

### buildPlainStrMap

输出关键信息，用于日志记录

**方法签名：**
```java
public Map<String,Object> buildPlainStrMap()
```

**返回值：**
- `Map<String,Object>`

---

### clone

返回动态属性的克隆

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createHashCode

根据元数据创建HashCode

**方法签名：**
```java
public int createHashCode()
```

**返回值：**
- `int`

---

### findTrueProperty

返回此属性被引用的类型

**方法签名：**
```java
public final DynamicProperty findTrueProperty(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject`

**返回值：**
- `DynamicProperty`

---

### getAlias

{待补充}

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getBitPos

{待补充}

**方法签名：**
```java
public int getBitPos()
```

**返回值：**
- `int`

---

### getCustomProperty

获取自定义属性

**方法签名：**
```java
public Object getCustomProperty(String key)
```

**参数说明：**
- `key`: `String`

**返回值：**
- `Object`

---

### getCustomPropertyKeys

自定义属性Key，用于遍历

**方法签名：**
```java
public Set<String> getCustomPropertyKeys()
```

**返回值：**
- `Set<String>`

---

### getDTValue

从实体中检索当前属性的值并直接返回指定类型
 
 返回值的类型

**方法签名：**
```java
public final Object getDTValue(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject`

**返回值：**
- `Object`: 此实体中此属性的值

---

### getDTValueFast

从实体中快速检索当前属性的值,在确定dataEntity实体类型和此属性对应实体类型一致时采用此方法

**方法签名：**
```java
public Object getDTValueFast(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject`

**返回值：**
- `Object`: 此实体中此属性的值

---

### getDefaultValue

返回此属性的缺省值

**方法签名：**
```java
public final Object getDefaultValue()
```

**返回值：**
- `Object`

---

### getDisplayName

{待补充}

**方法签名：**
```java
public LocaleString getDisplayName()
```

**返回值：**
- `LocaleString`

---

### getIsReadOnly

返回是否只读

**方法签名：**
```java
public final boolean getIsReadOnly()
```

**返回值：**
- `boolean`

---

### getName

返回此元数据对象的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getNullBit

{待补充}

**方法签名：**
```java
public int getNullBit()
```

**返回值：**
- `int`

---

### getOrdinal

返回此属性在所在DynamicObjectType上的位置（内部使用，请慎重处理）

**方法签名：**
```java
public final int getOrdinal()
```

**返回值：**
- `int`

---

### getParent

{待补充}

**方法签名：**
```java
public IDataEntityType getParent()
```

**返回值：**
- `IDataEntityType`

---

### getPropertyType

返回属性的返回类型

**方法签名：**
```java
public Class<?> getPropertyType()
```

**返回值：**
- `Class<?>`

---

### getReadOnly

{待补充}

**方法签名：**
```java
public boolean getReadOnly()
```

**返回值：**
- `boolean`

---

### getValue

给定一个实体，读取此属性描述符在此实体的值

**方法签名：**
```java
public Object getValue(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Object`: 最后取得的值

---

### getValueFast

给定一个实体，读取此属性描述符在此实体的值

**方法签名：**
```java
public Object getValueFast(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `Object`: 最后取得的值

---

### hasDefaultValue

{待补充}

**方法签名：**
```java
public final boolean hasDefaultValue()
```

**返回值：**
- `boolean`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### resetDTValue

重置动态实体的值

**方法签名：**
```java
public final void resetDTValue(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject`

---

### setAlias

设置数据库字段名

**方法签名：**
```java
public void setAlias(String alias)
```

**参数说明：**
- `alias`: `String`

---

### setBitPos

{待补充}

**方法签名：**
```java
public void setBitPos(int bitPos)
```

**参数说明：**
- `bitPos`: `int`

---

### setCustomProperty

设置自定义属性，初始化结束后，不允许修改

**方法签名：**
```java
public void setCustomProperty(String key, Object value)
```

**参数说明：**
- `key`: `String`
- `value`: `Object`

---

### setDTValue

设置动态实体的值

**方法签名：**
```java
public final void setDTValue(DynamicObject dataEntity, Object newValue)
```

**参数说明：**
- `dataEntity`: `DynamicObject`
- `newValue`: `Object`

---

### setDTValueFast

设置动态实体的值,在确定dataEntity实体类型和此属性对应实体类型一致时采用此方法

**方法签名：**
```java
public void setDTValueFast(DynamicObject dataEntity, Object newValue)
```

**参数说明：**
- `dataEntity`: `DynamicObject`
- `newValue`: `Object`

---

### setDefaultValue

设置属性的初始值

**方法签名：**
```java
public void setDefaultValue(Object value)
```

**参数说明：**
- `value`: `Object`

---

### setDisplayName

设置字段显示名称

**方法签名：**
```java
public void setDisplayName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString`

---

### setName

设置属性名

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String`

---

### setNullBit

{待补充}

**方法签名：**
```java
public void setNullBit(int nullBit)
```

**参数说明：**
- `nullBit`: `int`

---

### setOrdinal

设置字段在实体上的序号

**方法签名：**
```java
public final void setOrdinal(int value)
```

**参数说明：**
- `value`: `int`

---

### setValue

{待补充}

**方法签名：**
```java
public void setValue(Object dataEntity, Object value)
```

**参数说明：**
- `dataEntity`: `Object`
- `value`: `Object`

---

### setValueFast

{待补充}

**方法签名：**
```java
public void setValueFast(Object dataEntity, Object value)
```

**参数说明：**
- `dataEntity`: `Object`
- `value`: `Object`

---

### toPlainString

{待补充}

**方法签名：**
```java
public String toPlainString()
```

**返回值：**
- `String`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
