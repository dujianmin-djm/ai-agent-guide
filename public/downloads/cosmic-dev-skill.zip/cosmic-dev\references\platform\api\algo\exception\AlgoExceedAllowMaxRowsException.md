---
framework_version: "8.0.1"
api_class: "AlgoExceedAllowMaxRowsException"
api_package: "kd.bos.algo.exception"
when_to_use: "当你需要使用超过最大行数异常信息时"
---

# AlgoExceedAllowMaxRowsException API 说明

## 概述
超过最大行数异常信息。继承自 AlgoException，实现 Serializable。
主要功能：输出异常信息。

## Import 路径
```java
import kd.bos.algo.exception.AlgoExceedAllowMaxRowsException;
```

---

## 方法列表

### toString

输出异常信息

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`: 异常信息

---
