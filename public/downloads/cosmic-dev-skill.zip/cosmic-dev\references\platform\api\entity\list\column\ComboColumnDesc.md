---
framework_version: "8.0.1"
api_class: "ComboColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用下拉列表格式化字段处理类时"
---

# ComboColumnDesc API 说明

## 概述
下拉列表格式化字段处理类。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.ComboColumnDesc;
```

---

## 方法列表

### getComboProp

获取对应原单上的下拉列表属性

**方法签名：**
```java
public ComboProp getComboProp()
```

**返回值：**
- `ComboProp`

---

### getDesensitizeValue

{待补充}

**方法签名：**
```java
public Object getDesensitizeValue(String localeid, DynamicObject dynamicObject, Object value)
```

**参数说明：**
- `localeid`: `String`
- `dynamicObject`: `DynamicObject`
- `value`: `Object`

**返回值：**
- `Object`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---

### setShowStyle

{待补充}

**方法签名：**
```java
public void setShowStyle(int showStyle)
```

**参数说明：**
- `showStyle`: `int`

---
