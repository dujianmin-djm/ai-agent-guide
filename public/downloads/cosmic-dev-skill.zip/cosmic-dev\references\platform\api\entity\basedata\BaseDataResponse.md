---
framework_version: "8.0.1"
api_class: "BaseDataResponse"
api_package: "kd.bos.entity.basedata"
when_to_use: "当你需要使用返回信息pojo时"
---

# BaseDataResponse API 说明

## 概述
返回信息pojo。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.basedata.BaseDataResponse;
```

---

## 方法列表

### getErrorMsg

获取错误信息

**方法签名：**
```java
public String getErrorMsg()
```

**返回值：**
- `String`

---

### getResult

获取返回详细信息

**方法签名：**
```java
public Map<Long,Map<Long,String>> getResult()
```

**返回值：**
- `Map<Long,Map<Long,String>>`

---

### isSuccess

获取是否成功

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`

---

### setErrorMsg

设置错误信息

**方法签名：**
```java
public void setErrorMsg(String errorMsg)
```

**参数说明：**
- `errorMsg`: `String`

---

### setResult

设置返回详细信息

**方法签名：**
```java
public void setResult(Map<Long,Map<Long,String>> result)
```

**参数说明：**
- `result`: `Map<Long,Map<Long,String>>`

---

### setSuccess

设置是否成功

**方法签名：**
```java
public void setSuccess(boolean success)
```

**参数说明：**
- `success`: `boolean`

---
