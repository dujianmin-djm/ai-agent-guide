---
framework_version: "8.0.1"
api_class: "ControlFilter"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用列表过滤条件原始值实例类时"
---

# ControlFilter API 说明

## 概述
列表过滤条件原始值实例类。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.ControlFilter;
```

---

## 方法列表

### getCompareType

获取过滤比较符

**方法签名：**
```java
public String getCompareType()
```

**返回值：**
- `String`: 过滤比较符

---

### getFieldName

获取过滤字段名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: 过滤字段名

---

### getValue

获取过滤值

**方法签名：**
```java
public List<Object> getValue()
```

**返回值：**
- `List<Object>`: 过滤值

---

### setCompareType

设置过滤比较符

**方法签名：**
```java
public void setCompareType(String compareType)
```

**参数说明：**
- `compareType`: `String` — 过滤比较符

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
