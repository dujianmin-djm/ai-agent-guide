---
framework_version: "8.0.1"
api_class: "BillOperationStatus"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用单据界面操作状态时"
---

# BillOperationStatus API 说明

## 概述
单据界面操作状态。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.bill.BillOperationStatus;
```

---

## 方法列表

### forValue

把整数值转换为枚举类型，如果传入的整数无枚举类型匹配，会报 RuntimeException 异常

**方法签名：**
```java
public static BillOperationStatus forValue(int value)
```

**参数说明：**
- `value`: `int` — 整数值

**返回值：**
- `BillOperationStatus`: 枚举类型

---

### getValue

获取枚举类型整数值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`: 枚举类型整数值

---
