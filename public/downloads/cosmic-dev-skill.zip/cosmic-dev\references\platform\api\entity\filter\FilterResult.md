---
framework_version: "8.0.1"
api_class: "FilterResult"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤条件解析结果类时"
---

# FilterResult API 说明

## 概述
过滤条件解析结果类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterResult;
```

---

## 方法列表

### getFilterGroup

获取过滤条件描述数据，主要是两个，第一个是SQL描述，第二个是中文描述

**方法签名：**
```java
public String[] getFilterGroup()
```

**返回值：**
- `String[]`: 过滤条件描述数据

---

### getLogicOperate

获取过滤比较符

**方法签名：**
```java
public LogicOperate getLogicOperate()
```

**返回值：**
- `LogicOperate`: 过滤比较符 kd.bos.entity.filter.LogicOperate

---

### getQFilter

获取过滤条件

**方法签名：**
```java
public QFilter getQFilter()
```

**返回值：**
- `QFilter`: 过滤条件

---

### getQFilters

获取过滤条件，每个数组元素对应每行FilterRow kd.bos.entity.filter.FilterRow的解析结果

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---
