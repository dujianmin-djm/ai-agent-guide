---
framework_version: "8.0.1"
api_class: "AppParam"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用应用参数实体对象时"
---

# AppParam API 说明

## 概述
应用参数实体对象。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.param.AppParam;
```

---

## 方法列表

### getAcctingBookId

获取会计账簿

**方法签名：**
```java
public Long getAcctingBookId()
```

**返回值：**
- `Long`: 会计账簿

---

### getActBookId

获取账簿

**方法签名：**
```java
public Long getActBookId()
```

**返回值：**
- `Long`: 账簿

---

### getAppId

获取应用ID

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用ID

---

### getCloudId

获取云ID

**方法签名：**
```java
public String getCloudId()
```

**返回值：**
- `String`: 云ID

---

### getFormId

获取参数表单Id

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`: 参数表单Id

---

### getGcFields

获取集团管控字段

**方法签名：**
```java
public List<String> getGcFields()
```

**返回值：**
- `List<String>`: 集团管控字段

---

### getOrgId

获取组织

**方法签名：**
```java
public Long getOrgId()
```

**返回值：**
- `Long`: 组织

---

### getOrgIds

获取组织列表

**方法签名：**
```java
public List<Long> getOrgIds()
```

**返回值：**
- `List<Long>`: 组织列表

---

### getParamId

获取参数发布平台Id

**方法签名：**
```java
public String getParamId()
```

**返回值：**
- `String`: 参数发布平台Id

---

### getSubSystem

获取子系统

**方法签名：**
```java
public String getSubSystem()
```

**返回值：**
- `String`: 子系统

---

### getViewType

获取职能类型

**方法签名：**
```java
public String getViewType()
```

**返回值：**
- `String`: 职能类型

---

### setAcctingBookId

设置会计账簿

**方法签名：**
```java
public void setAcctingBookId(Long acctingBookId)
```

**参数说明：**
- `acctingBookId`: `Long` — 会计账簿

---

### setActBookId

设置账簿

**方法签名：**
```java
public void setActBookId(Long actBookId)
```

**参数说明：**
- `actBookId`: `Long` — 账簿

---

### setAppId

设置应用ID

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 应用ID

---

### setCloudId

设置云ID

**方法签名：**
```java
public void setCloudId(String cloudId)
```

**参数说明：**
- `cloudId`: `String` — 云ID

---

### setFormId

获取参数表单Id

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 参数表单Id

---

### setGcFields

设置集团管控字段

**方法签名：**
```java
public void setGcFields(List<String> gcFields)
```

**参数说明：**
- `gcFields`: `List<String>` — 集团管控字段

---

### setOrgId

设置组织

**方法签名：**
```java
public void setOrgId(Long orgId)
```

**参数说明：**
- `orgId`: `Long` — 组织

---

### setOrgIds

设置组织列表

**方法签名：**
```java
public void setOrgIds(List<Long> orgIds)
```

**参数说明：**
- `orgIds`: `List<Long>` — 组织列表

---

### setParamId

设置参数发布平台Id

**方法签名：**
```java
public void setParamId(String paramId)
```

**参数说明：**
- `paramId`: `String` — 参数发布平台Id

---

### setSubSystem

设置子系统

**方法签名：**
```java
public void setSubSystem(String subSystem)
```

**参数说明：**
- `subSystem`: `String` — 子系统

---

### setViewType

设置职能类型

**方法签名：**
```java
public void setViewType(String viewType)
```

**参数说明：**
- `viewType`: `String` — 职能类型

---
