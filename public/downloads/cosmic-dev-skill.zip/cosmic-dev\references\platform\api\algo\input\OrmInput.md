---
framework_version: "8.0.1"
api_class: "OrmInput"
api_package: "kd.bos.algo.input"
when_to_use: "当你需要使用使用orm作为创建一个DataSet的输入源时"
---

# OrmInput API 说明

## 概述
使用orm作为创建一个DataSet的输入源，使用参数的形式。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.input.OrmInput;
```

---

## 方法列表

### getAlgoKey

获取algoKey

**方法签名：**
```java
public String getAlgoKey()
```

**返回值：**
- `String`: algoKey 用来表示DataSet的key

---

### getCacheSize

取数大小

**方法签名：**
```java
public Integer getCacheSize()
```

**返回值：**
- `Integer`: 取数大小

---

### getEntityName

获取实体名称

**方法签名：**
```java
public String getEntityName()
```

**返回值：**
- `String`: 实体名称

---

### getFilters

获取查询条件

**方法签名：**
```java
public QFilter[] getFilters()
```

**返回值：**
- `QFilter[]`: 查询条件

---

### getRequestContext

获取请求上下文信息

**方法签名：**
```java
public RequestContext getRequestContext()
```

**返回值：**
- `RequestContext`: 上下文信息

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`

---

### getSelectFields

获取查询列信息

**方法签名：**
```java
public String getSelectFields()
```

**返回值：**
- `String`: 查询列信息

---
