---
framework_version: "8.0.1"
api_class: "ApproverColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用当前审批人列表字段格式化处理类时"
---

# ApproverColumnDesc API 说明

## 概述
当前审批人列表字段格式化处理类。继承自 AbstractColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.ApproverColumnDesc;
```

---

## 方法列表

### getApproverNums

获取审批人Map，key:单据主键key,value:显示信息

**方法签名：**
```java
public Map<String,String> getApproverNums()
```

**返回值：**
- `Map<String,String>`

---

### getShowApproverType

获取审批节点显示类型：1.显示审批人/审批节点，2.仅显示节点，3.仅显示处理人，默认仅显示处理人

**方法签名：**
```java
public String getShowApproverType()
```

**返回值：**
- `String`

---

### getValue

根据单据key获取审批人显示信息

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject` — 数据来源

**返回值：**
- `Object`

---

### setApproverNums

设置审批人Map，key:单据主键key,value:显示信息

**方法签名：**
```java
public void setApproverNums(Map<String,String> approverNums)
```

**参数说明：**
- `approverNums`: `Map<String,String>`

---

### setShowApproverType

设置审批节点显示类型：1.显示审批人/审批节点，2.仅显示节点，3.仅显示处理人，默认仅显示处理人

**方法签名：**
```java
public void setShowApproverType(String showApproverType)
```

**参数说明：**
- `showApproverType`: `String`

---
