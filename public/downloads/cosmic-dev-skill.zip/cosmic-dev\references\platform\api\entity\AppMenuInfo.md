---
framework_version: "8.0.1"
api_class: "AppMenuInfo"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用业务应用-首页菜单项时"
---

# AppMenuInfo API 说明

## 概述
业务应用-首页菜单项。实现 NodeInfo, Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.AppMenuInfo;
```

---

## 方法列表

### getAppId

获取应用编码

**方法签名：**
```java
public String getAppId()
```

**返回值：**
- `String`: 应用编码

---

### getData

获取菜单的 xml 数据：侧导航图标和快捷图标路径名称

**方法签名：**
```java
public String getData()
```

**返回值：**
- `String`: 获取菜单的 xml 数据：侧导航图标和快捷图标路径名称

---

### getDescription

获取菜单描述

**方法签名：**
```java
public LocaleString getDescription()
```

**返回值：**
- `LocaleString`: 获取菜单描述

---

### getEntityNumber

获取菜单绑定的实体编码

**方法签名：**
```java
public String getEntityNumber()
```

**返回值：**
- `String`: 获取菜单绑定的实体编码

---

### getFormId

获取菜单绑定的表单编码

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`: 获取菜单绑定的表单编码

---

### getFormName

获取页面名称

**方法签名：**
```java
public LocaleString getFormName()
```

**返回值：**
- `LocaleString`: 获取页面名称

---

### getId

获取菜单 id

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 菜单 id

---

### getLinkUrl

获取菜单连接地址

**方法签名：**
```java
public String getLinkUrl()
```

**返回值：**
- `String`: 获取菜单连接地址

---

### getMenuType

获取菜单类型

**方法签名：**
```java
public String getMenuType()
```

**返回值：**
- `String`: 获取菜单类型

---

### getName

获取菜单名称

**方法签名：**
```java
public LocaleString getName()
```

**返回值：**
- `LocaleString`: 获取菜单名称

---

### getNaviVector

获取菜单的侧导航图标

**方法签名：**
```java
public String getNaviVector()
```

**返回值：**
- `String`: 获取菜单的侧导航图标

---

### getNodeType

{待补充}

**方法签名：**
```java
public String getNodeType()
```

**返回值：**
- `String`

---

### getOpenType

获取菜单打开方式

**方法签名：**
```java
public String getOpenType()
```

**返回值：**
- `String`: 获取菜单打开方式

---

### getOrder

获取菜单序号

**方法签名：**
```java
public int getOrder()
```

**返回值：**
- `int`: 菜单序号

---

### getParamType

获取菜单的打开的页面类型

**方法签名：**
```java
public String getParamType()
```

**返回值：**
- `String`: 获取菜单的打开的页面类型

---

### getParams

获取菜单入口参数

**方法签名：**
```java
public String getParams()
```

**返回值：**
- `String`: 获取菜单入口参数

---

### getParentId

获取菜单的上级菜单 id

**方法签名：**
```java
public String getParentId()
```

**返回值：**
- `String`: 获取菜单的上级菜单 id

---

### getPermission

获取菜单的权限项

**方法签名：**
```java
public String getPermission()
```

**返回值：**
- `String`: 获取菜单的权限项

---

### getSeq

获取菜单序号

**方法签名：**
```java
public Short getSeq()
```

**返回值：**
- `Short`: 菜单序号

---

### getShortcutIcon

获取菜单的快捷图标

**方法签名：**
```java
public String getShortcutIcon()
```

**返回值：**
- `String`: 获取菜单的快捷图标

---

### setAppId

设置应用编码

**方法签名：**
```java
public void setAppId(String appId)
```

**参数说明：**
- `appId`: `String` — 应用编码

---

### setData

设置菜单的 xml 数据：侧导航图标和快捷图标路径名称

**方法签名：**
```java
public void setData(String data)
```

**参数说明：**
- `data`: `String` — 设置菜单的 xml 数据：侧导航图标和快捷图标路径名称

---

### setDescription

设置菜单描述

**方法签名：**
```java
public void setDescription(LocaleString description)
```

**参数说明：**
- `description`: `LocaleString` — 设置菜单描述

---

### setEntityNumber

设置菜单绑定的实体编码

**方法签名：**
```java
public void setEntityNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String` — 设置菜单绑定的实体编码

---

### setFormId

设置菜单绑定的表单编码

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 菜单绑定的表单编码

---

### setFormName

设置页面名称

**方法签名：**
```java
public void setFormName(LocaleString formName)
```

**参数说明：**
- `formName`: `LocaleString` — 设置页面名称

---

### setId

设置菜单 id

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 菜单 id

---

### setLinkUrl

设置菜单连接地址

**方法签名：**
```java
public void setLinkUrl(String linkUrl)
```

**参数说明：**
- `linkUrl`: `String` — 设置菜单连接地址

---

### setMenuType

设置菜单类型

**方法签名：**
```java
public void setMenuType(String menuType)
```

**参数说明：**
- `menuType`: `String` — 设置菜单类型

---

### setName

设置菜单名称

**方法签名：**
```java
public void setName(LocaleString name)
```

**参数说明：**
- `name`: `LocaleString` — 设置菜单名称

---

### setNaviVector

设置菜单的侧导航图标

**方法签名：**
```java
public void setNaviVector(String naviVector)
```

**参数说明：**
- `naviVector`: `String` — 设置菜单的侧导航图标

---

### setOpenType

设置菜单打开方式

**方法签名：**
```java
public void setOpenType(String openType)
```

**参数说明：**
- `openType`: `String` — 设置菜单打开方式

---

### setParamType

设置菜单的打开的页面类型

**方法签名：**
```java
public void setParamType(String paramType)
```

**参数说明：**
- `paramType`: `String` — 设置菜单的打开的页面类型

---

### setParams

设置菜单入口参数

**方法签名：**
```java
public void setParams(String params)
```

**参数说明：**
- `params`: `String` — 设置菜单入口参数

---

### setParentId

设置菜单的上级菜单 id

**方法签名：**
```java
public void setParentId(String parentId)
```

**参数说明：**
- `parentId`: `String` — 设置菜单的上级菜单 id

---

### setPermission

设置菜单的权限项

**方法签名：**
```java
public void setPermission(String permission)
```

**参数说明：**
- `permission`: `String` — 设置菜单的权限项

---

### setSeq

设置菜单序号

**方法签名：**
```java
public void setSeq(Short seq)
```

**参数说明：**
- `seq`: `Short` — 菜单序号

---

### setShortcutIcon

设置菜单的快捷图标

**方法签名：**
```java
public void setShortcutIcon(String shortcutIcon)
```

**参数说明：**
- `shortcutIcon`: `String` — 设置菜单的快捷图标

---
