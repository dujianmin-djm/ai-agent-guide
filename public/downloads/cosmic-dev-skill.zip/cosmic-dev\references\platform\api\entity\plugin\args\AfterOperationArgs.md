---
framework_version: "8.0.1"
api_class: "AfterOperationArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作事务提交后事件参数时"
---

# AfterOperationArgs API 说明

## 概述
操作事务提交后事件参数。继承自 OperationArgs。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.AfterOperationArgs;
```

---

## 方法列表

### getDataEntities

返回单据数据包，仅含已成功完成了操作的单据

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`: 单据数据包

---

### getSelectedRows

返回单据数据包，仅含已成功完成了操作的单据：ExtendedDataEntity 对数据包进行了再包装，增加数据索引等信息

**方法签名：**
```java
public List<kd.ExtendedDataEntity> getSelectedRows()
```

**返回值：**
- `List<kd.ExtendedDataEntity>`

---
