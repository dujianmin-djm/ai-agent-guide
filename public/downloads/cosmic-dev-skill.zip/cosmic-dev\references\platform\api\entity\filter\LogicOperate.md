---
framework_version: "8.0.1"
api_class: "LogicOperate"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤条件时"
---

# LogicOperate API 说明

## 概述
过滤条件，条件之间逻辑拼接符。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.filter.LogicOperate;
```

---

## 方法列表

### getName

获取逻辑拼接符的名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getValue

获取逻辑拼接符的值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
