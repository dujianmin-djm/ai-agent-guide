---
framework_version: "8.0.1"
api_class: "TreeEntryType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用树形单据体实体类型时"
---

# TreeEntryType API 说明

## 概述
树形单据体实体类型。继承自 EntryType，实现 ITreeEntryType。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.TreeEntryType;
```

---

## 方法列表

### endInit

初始化结束之后，确保树形单据体实体包含isgroupnode属性

**方法签名：**
```java
public synchronized void endInit()
```

---

### getPidProperty

{待补充}

**方法签名：**
```java
public IDataEntityProperty getPidProperty()
```

**返回值：**
- `IDataEntityProperty`

---
