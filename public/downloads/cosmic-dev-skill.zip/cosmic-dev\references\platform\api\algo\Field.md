---
framework_version: "8.0.1"
api_class: "Field"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用内存数据库中的列信息,包含名称时"
---

# Field API 说明

## 概述
内存数据库中的列信息,包含名称，别名以及类型。。实现 Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.algo.Field;
```

---

## 方法列表

### copy

拷贝该field，返回新的实例

**方法签名：**
```java
public Field copy()
```

**返回值：**
- `Field`

---

### derive

拷贝该field，返回新的实例，但是使用自定义名称和别名

**方法签名：**
```java
public Field derive(String name, String alias)
```

**参数说明：**
- `name`: `String` — 属性名称
- `alias`: `String` — 属性别名

**返回值：**
- `Field`: Field

---

### deriveAlias

拷贝该field，返回新的实例，但是别名是自定义的

**方法签名：**
```java
public Field deriveAlias(String alias)
```

**参数说明：**
- `alias`: `String` — 别名

**返回值：**
- `Field`

---

### deriveName

拷贝该field，返回新的实例，但是使用自定义名称和别名

**方法签名：**
```java
public Field deriveName(String name)
```

**参数说明：**
- `name`: `String` — 属性名称

**返回值：**
- `Field`

---

### equals

判断两个field是否相等

**方法签名：**
```java
public boolean equals(Object x)
```

**参数说明：**
- `x`: `Object` — 另外一个字段

**返回值：**
- `boolean`

---

### getAlias

获取属性别名

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`: 别名

---

### getDataType

获取属性类型

**方法签名：**
```java
public DataType getDataType()
```

**返回值：**
- `DataType`: 属性类型

---

### getName

获取属性名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 属性名称

---

### isNullable

是否允许为空

**方法签名：**
```java
public boolean isNullable()
```

**返回值：**
- `boolean`

---

### setAlias

设置属性别名

**方法签名：**
```java
public void setAlias(String alias)
```

**参数说明：**
- `alias`: `String` — 别名

---

### setDataType

设置属性类型

**方法签名：**
```java
public void setDataType(DataType dataType)
```

**参数说明：**
- `dataType`: `DataType` — 属性类型

---

### setName

设置属性名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String` — 属性名称

---

### toString

输出属性和别名(name as alias),如果别名一致则只输出name

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
