---
framework_version: "8.0.1"
api_class: "ResManager"
api_package: "kd.bos.dataentity.resource"
when_to_use: "当你需要使用获取多语言资源工具时"
---

# ResManager API 说明

## 概述
获取多语言资源工具。
主要功能：读取属性、查询数据。

## Import 路径
```java
import kd.bos.dataentity.resource.ResManager;
```

---

## 方法列表

### getKDString

加载多语言字符

**方法签名：**
```java
public static String getKDString(String resourceID, String systemType, Object[] args)
```

**参数说明：**
- `resourceID`: `String` — 资源ID
- `systemType`: `String` — 资源文件
- `args`: `Object[]` — 参数列表

**返回值：**
- `String`

---

### getLocaleString

根据资源ID获取LocaleString信息对象。

**方法签名：**
```java
public static LocaleString getLocaleString(String description, String resourceID, String systemType)
```

**参数说明：**
- `description`: `String` — 描述字符串
- `resourceID`: `String` — 资源ID
- `systemType`: `String` — 资源文件

**返回值：**
- `LocaleString`: LocaleStringLocaleString

---

### loadKDString

**重载 1**

加载多语言字符

**方法签名：**
```java
public static String loadKDString(String description, String resourceID, String systemType, Object[] args)
```

**参数说明：**
- `description`: `String` — 描述字符串
- `resourceID`: `String` — 资源ID
- `systemType`: `String` — 资源文件
- `args`: `Object[]` — 参数列表

**返回值：**
- `String`

---

**重载 2**

加载多语言字符

**方法签名：**
```java
public static String loadKDString(Lang lang, String description, String resourceID, String systemType, Object[] args)
```

**参数说明：**
- `lang`: `Lang` — 语种
- `description`: `String` — 描述字符串
- `resourceID`: `String` — 资源ID
- `systemType`: `String` — 资源文件
- `args`: `Object[]` — 参数列表

**返回值：**
- `String`

---
