---
framework_version: "8.0.1"
api_class: "CRValByCondition"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用取值项：单项条件+值的组合时"
---

# CRValByCondition API 说明

## 概述
取值项：单项条件+值的组合，如果条件满足，即返回此项。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.CRValByCondition;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType mainType, CheckPoint parentPoint, CheckResult checkResult)
```

**参数说明：**
- `mainType`: `MainEntityType`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`

---

### equals

{待补充}

**方法签名：**
```java
public boolean equals(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `boolean`

---

### getCondition

取值条件：如果为空，表示不设条件

**方法签名：**
```java
public CRCondition getCondition()
```

**返回值：**
- `CRCondition`

---

### getFormula

取值公式：条件满足则取此计算公式结果

**方法签名：**
```java
public CRFormula getFormula()
```

**返回值：**
- `CRFormula`

---

### getId

自动产生的唯一标识，据此与扩展对象，进行差量化对比定位

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`

---

### getIfconstant

是否是按条件取值中的常量取值
 0否  1是

**方法签名：**
```java
public int getIfconstant()
```

**返回值：**
- `int`

---

### getSelect

取值方式toString，用于序列化

**方法签名：**
```java
public String getSelect()
```

**返回值：**
- `String`

---

### getSelectType

本项取值方式：
 1. 严格按条件取值：只有条件满足，才会选用本项；条件为空，认为满足条件
 2. 其他情况：不判断条件，直接选用本项；适用于放在最后，进行兜底

**方法签名：**
```java
public CRValByConditionType getSelectType()
```

**返回值：**
- `CRValByConditionType`

---

### getSeq

选择顺序：
 取值时，从前往后，逐项比较条件，条件满足时，即选中返回；后面的选择项，不再分析；
 因此，选择顺序，对取值结果起到非常关键的作用

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`

---

### hashCode

{待补充}

**方法签名：**
```java
public int hashCode()
```

**返回值：**
- `int`

---
