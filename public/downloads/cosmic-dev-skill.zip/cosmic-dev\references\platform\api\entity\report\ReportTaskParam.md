---
framework_version: "8.0.1"
api_class: "ReportTaskParam"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表任务参数类时"
---

# ReportTaskParam API 说明

## 概述
报表任务参数类。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.report.ReportTaskParam;
```

---

## 方法列表

### existQueryPlugin

{待补充}

**方法签名：**
```java
public boolean existQueryPlugin()
```

**返回值：**
- `boolean`

---

### getColumns

获取报表设计列

**方法签名：**
```java
public List<AbstractReportColumn> getColumns()
```

**返回值：**
- `List<AbstractReportColumn>`

---

### getDataSource

**重载 1**

获取数据源配置json

**方法签名：**
```java
public String getDataSource()
```

**返回值：**
- `String`

---

**重载 2**

获取数据源配置json

**方法签名：**
```java
public DataSource getDataSource(ReportQueryParam queryParam, Object selectedObj)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数
- `selectedObj`: `Object` — 数据包

**返回值：**
- `DataSource`

---

### getFilterEntityId

获取过滤条件实体

**方法签名：**
```java
public String getFilterEntityId()
```

**返回值：**
- `String`

---

### getOtherParam

获取其他参数，例如左树（表）选择对象

**方法签名：**
```java
public Object getOtherParam()
```

**返回值：**
- `Object`

---

### getPluginClassName

获取报表查询插件

**方法签名：**
```java
public String getPluginClassName()
```

**返回值：**
- `String`

---

### getPluginExtplugins

获取报表查询扩展插件

**方法签名：**
```java
public List<Plugin> getPluginExtplugins()
```

**返回值：**
- `List<Plugin>`

---

### getQueryDataSource

获取查询数据源

**方法签名：**
```java
public String getQueryDataSource()
```

**返回值：**
- `String`

---

### getQueryParam

获取过滤条件

**方法签名：**
```java
public ReportQueryParam getQueryParam()
```

**返回值：**
- `ReportQueryParam`

---

### getReportName

获取报表名称

**方法签名：**
```java
public String getReportName()
```

**返回值：**
- `String`

---

### getReportQueryPlugins

获取查询插件

**方法签名：**
```java
public List<Plugin> getReportQueryPlugins()
```

**返回值：**
- `List<Plugin>`: 查询插件

---

### getTaskId

获取后台任务ID

**方法签名：**
```java
public String getTaskId()
```

**返回值：**
- `String`

---

### getTaskType

获取后台任务类型

**方法签名：**
```java
public String getTaskType()
```

**返回值：**
- `String`

---

### initQueryPlugin

{待补充}

**方法签名：**
```java
public IReportListDataPlugin initQueryPlugin()
```

**返回值：**
- `IReportListDataPlugin`

---

### isAsyncTotal

获取是否开启异步合计

**方法签名：**
```java
public boolean isAsyncTotal()
```

**返回值：**
- `boolean`

---

### isRelease

界面是否已经关闭

**方法签名：**
```java
public boolean isRelease()
```

**返回值：**
- `boolean`

---

### isReportTree

获取是否树形报表

**方法签名：**
```java
public boolean isReportTree()
```

**返回值：**
- `boolean`

---

### setAsyncTotal

设置是否开启异步合计

**方法签名：**
```java
public void setAsyncTotal(boolean asyncTotal)
```

**参数说明：**
- `asyncTotal`: `boolean`

---

### setColumns

设置报表设计列

**方法签名：**
```java
public void setColumns(List<AbstractReportColumn> columns)
```

**参数说明：**
- `columns`: `List<AbstractReportColumn>` — 报表列

---

### setDataSource

设置数据源配置json

**方法签名：**
```java
public void setDataSource(String dataSource)
```

**参数说明：**
- `dataSource`: `String`

---

### setFilterEntityId

设置过滤条件实体

**方法签名：**
```java
public void setFilterEntityId(String filterEntityId)
```

**参数说明：**
- `filterEntityId`: `String` — 过滤条件实体

---

### setOtherParam

设置其他参数，例如左树（表）选择对象

**方法签名：**
```java
public void setOtherParam(Object otherParam)
```

**参数说明：**
- `otherParam`: `Object` — 其他参数

---

### setPluginClassName

设置报表查询插件

**方法签名：**
```java
public void setPluginClassName(String pluginClassName)
```

**参数说明：**
- `pluginClassName`: `String` — 报表查询插件

---

### setPluginExtplugins

设置报表查询扩展插件

**方法签名：**
```java
public void setPluginExtplugins(List<Plugin> pluginExtplugins)
```

**参数说明：**
- `pluginExtplugins`: `List<Plugin>` — 查询扩展插件

---

### setQueryDataSource

设置查询数据源

**方法签名：**
```java
public void setQueryDataSource(String queryDataSource)
```

**参数说明：**
- `queryDataSource`: `String`

---

### setQueryParam

设置过滤条件

**方法签名：**
```java
public void setQueryParam(ReportQueryParam queryParam)
```

**参数说明：**
- `queryParam`: `ReportQueryParam`

---

### setRelease

设置界面是否已关闭

**方法签名：**
```java
public void setRelease(boolean release)
```

**参数说明：**
- `release`: `boolean`

---

### setReportName

设置报表名称

**方法签名：**
```java
public void setReportName(String reportName)
```

**参数说明：**
- `reportName`: `String` — 报表名称

---

### setReportQueryPlugins

设置查询插件

**方法签名：**
```java
public void setReportQueryPlugins(List<Plugin> reportQueryPlugins)
```

**参数说明：**
- `reportQueryPlugins`: `List<Plugin>` — 查询插件

---

### setReportTree

设置是否树形报表

**方法签名：**
```java
public void setReportTree(boolean isReportTree)
```

**参数说明：**
- `isReportTree`: `boolean`

---

### setTaskId

设置后台任务id

**方法签名：**
```java
public void setTaskId(String taskId)
```

**参数说明：**
- `taskId`: `String`

---

### setTaskType

设置后台任务类型

**方法签名：**
```java
public void setTaskType(String taskType)
```

**参数说明：**
- `taskType`: `String`

---
