---
framework_version: "8.0.1"
api_class: "JoinEntity"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用查询实体关联实体时"
---

# JoinEntity API 说明

## 概述
查询实体关联实体。实现 Serializable。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.list.JoinEntity;
```

---

## 方法列表

### getAlias

获取实体数据库映射名称

**方法签名：**
```java
public String getAlias()
```

**返回值：**
- `String`

---

### getDisplayName

实体名称

**方法签名：**
```java
public String getDisplayName()
```

**返回值：**
- `String`

---

### getEntityName

获取实体标识

**方法签名：**
```java
public String getEntityName()
```

**返回值：**
- `String`

---

### getFKProperty

获取关联外键字段名

**方法签名：**
```java
public String getFKProperty()
```

**返回值：**
- `String`

---

### getIncludeFieldNames

实体包含的字段列表

**方法签名：**
```java
public String getIncludeFieldNames()
```

**返回值：**
- `String`

---

### getLocaleDisplayName

获取实体多语言名称

**方法签名：**
```java
public LocaleString getLocaleDisplayName()
```

**返回值：**
- `LocaleString`

---

### getProperty

获取关联字段名

**方法签名：**
```java
public String getProperty()
```

**返回值：**
- `String`

---

### isIncludeEntry

是否包含分录

**方法签名：**
```java
public boolean isIncludeEntry()
```

**返回值：**
- `boolean`

---

### setDisplayName

设置实体名称

**方法签名：**
```java
public void setDisplayName(String displayName)
```

**参数说明：**
- `displayName`: `String`

---

### setEntityName

设置实体标识

**方法签名：**
```java
public void setEntityName(String entityName)
```

**参数说明：**
- `entityName`: `String`

---
