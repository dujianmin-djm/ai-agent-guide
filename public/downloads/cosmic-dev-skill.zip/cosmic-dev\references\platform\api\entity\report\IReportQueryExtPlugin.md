---
framework_version: "8.0.1"
api_class: "IReportQueryExtPlugin"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表查询通用扩展插件接口时"
---

# IReportQueryExtPlugin API 说明

## 概述
报表查询通用扩展插件接口。
主要功能：事件处理。

## Import 路径
```java
import kd.bos.entity.report.IReportQueryExtPlugin;
```

---

## 方法列表

### afterQuery

在报表查询之后执行的方法，可在该方法中二次过滤数据

**方法签名：**
```java
public void afterQuery(ReportQueryExtEvent event)
```

**参数说明：**
- `event`: `ReportQueryExtEvent` — 报表查询扩展事件，包含查询事件的相关信息和结果

---
