---
framework_version: "8.0.1"
api_class: "ReturnOperationArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作微服务执行结束时"
---

# ReturnOperationArgs API 说明

## 概述
操作微服务执行结束，返回结果之前事件参数。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.ReturnOperationArgs;
```

---

## 方法列表

### getOperationResult

返回操作执行结果

**方法签名：**
```java
public IOperationResult getOperationResult()
```

**返回值：**
- `IOperationResult`: 操作执行结果

---
