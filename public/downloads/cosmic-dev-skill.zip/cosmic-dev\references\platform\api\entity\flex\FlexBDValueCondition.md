---
framework_version: "8.0.1"
api_class: "FlexBDValueCondition"
api_package: "kd.bos.entity.flex"
when_to_use: "当你需要使用弹性域维度定义时配置基础资料过滤条件的时"
---

# FlexBDValueCondition API 说明

## 概述
弹性域维度定义时配置基础资料过滤条件的。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.flex.FlexBDValueCondition;
```

---

## 方法列表

### buildFullFormula

构造完整公式

**方法签名：**
```java
public String buildFullFormula(MainEntityType mainType)
```

**参数说明：**
- `mainType`: `MainEntityType`

**返回值：**
- `String`

---

### getDescription

获取描述

**方法签名：**
```java
public LocaleString getDescription()
```

**返回值：**
- `LocaleString`

---

### getExpression

获取表达式

**方法签名：**
```java
public String getExpression()
```

**返回值：**
- `String`

---

### getFilterCondition

获取过滤条件

**方法签名：**
```java
public FilterCondition getFilterCondition()
```

**返回值：**
- `FilterCondition`

---

### setDescription

设置描述

**方法签名：**
```java
public void setDescription(LocaleString description)
```

**参数说明：**
- `description`: `LocaleString`

---

### setExpression

设置表达式

**方法签名：**
```java
public void setExpression(String expression)
```

**参数说明：**
- `expression`: `String`

---

### setFilterCondition

设置过滤条件

**方法签名：**
```java
public void setFilterCondition(FilterCondition filterCondition)
```

**参数说明：**
- `filterCondition`: `FilterCondition`

---
