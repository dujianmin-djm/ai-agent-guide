---
framework_version: "8.0.1"
api_class: "BeforeGetSourceDataEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用取源单数据前事件：可在正式读取源单数据之前时"
---

# BeforeGetSourceDataEventArgs API 说明

## 概述
取源单数据前事件：可在正式读取源单数据之前，修改取数语句、取数条件。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeGetSourceDataEventArgs;
```

---

## 方法列表

### getQFilters

条件

**方法签名：**
```java
public List<QFilter> getQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getSelectSQL

取数SELECT子句，包含了全部字段及别名

**方法签名：**
```java
public String getSelectSQL()
```

**返回值：**
- `String`

---

### setSelectSQL

设置取数SELECT子句，包含了全部字段及别名

**方法签名：**
```java
public void setSelectSQL(String selectSQL)
```

**参数说明：**
- `selectSQL`: `String`

---
