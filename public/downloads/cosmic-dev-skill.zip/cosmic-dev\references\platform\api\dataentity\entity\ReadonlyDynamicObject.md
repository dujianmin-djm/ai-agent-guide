---
framework_version: "8.0.1"
api_class: "ReadonlyDynamicObject"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用只读的数据包时"
---

# ReadonlyDynamicObject API 说明

## 概述
只读的数据包。实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.entity.ReadonlyDynamicObject;
```

---

## 方法列表

### get

返回此实体中指定属性名称的值

**方法签名：**
```java
public Object get(String propertyName)
```

**参数说明：**
- `propertyName`: `String` — 属性名称

**返回值：**
- `Object`: 返回此属性名称的值

---

### getDataEntityType

获取实体模型

**方法签名：**
```java
public IDataEntityType getDataEntityType()
```

**返回值：**
- `IDataEntityType`: 返回实际数据包的实体模型

---

### getParent

获取父级数据包

**方法签名：**
```java
public Object getParent()
```

**返回值：**
- `Object`: 返回父级数据包，也包装为只读数据包

---

### toString

重写toString方法，返回动态对象类型的名称+存储器的toString

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
