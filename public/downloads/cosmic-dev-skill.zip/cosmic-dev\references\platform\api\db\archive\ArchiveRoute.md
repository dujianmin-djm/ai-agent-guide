---
framework_version: "8.0.1"
api_class: "ArchiveRoute"
api_package: "kd.bos.db.archive"
when_to_use: "当你需要使用归档路由映射，线程上下文生效。时"
---

# ArchiveRoute API 说明

## 概述
归档路由映射，线程上下文生效。。实现 AutoCloseable。
主要功能：其他操作。

## Import 路径
```java
import kd.bos.db.archive.ArchiveRoute;
```

---

## 方法列表

### close

{待补充}

**方法签名：**
```java
public void close()
```

---

### mapRoute

API：设置归档路由映射上下文进行访问。

**方法签名：**
```java
public static ArchiveRoute mapRoute(String routeKey, String archiveRouteKey)
```

**参数说明：**
- `routeKey`: `String` — 原路由
- `archiveRouteKey`: `String` — 归档库路由

**返回值：**
- `ArchiveRoute`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
