---
framework_version: "8.0.1"
api_class: "GroupByPolicy"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用分单合并策略时"
---

# GroupByPolicy API 说明

## 概述
分单合并策略。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.GroupByPolicy;
```

---

## 方法列表

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<Integer,ExtControlElement> elementMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `elementMap`: `Map<Integer,ExtControlElement>`

---

### getGroupByField

分单依赖的字段：只有按字段分单模式下，这个属性才会赋值

**方法签名：**
```java
public String getGroupByField()
```

**返回值：**
- `String`

---

### getGroupByField2

单据体行合并依赖字段：只有按字段合并模式下，这个属性才会赋值

**方法签名：**
```java
public String getGroupByField2()
```

**返回值：**
- `String`

---

### getGroupByField3

单据体行合并依赖字段：只有按字段合并模式下，这个属性才会赋值

**方法签名：**
```java
public String getGroupByField3()
```

**返回值：**
- `String`

---

### getGroupByMode

单据分单方式：一对一、全部合并、按字段分单

**方法签名：**
```java
public GroupByMode getGroupByMode()
```

**返回值：**
- `GroupByMode`

---

### getGroupByMode2

单据体行合并方式：一对一、全部合并、按字段合并

**方法签名：**
```java
public GroupByMode getGroupByMode2()
```

**返回值：**
- `GroupByMode`

---

### getGroupByMode3

子单据体行合并方式：一对一、全部合并、按字段合并

**方法签名：**
```java
public GroupByMode getGroupByMode3()
```

**返回值：**
- `GroupByMode`

---

### getGroupMode

分单模式，用于序列化

**方法签名：**
```java
public String getGroupMode()
```

**返回值：**
- `String`

---

### getGroupMode2

单据体行合并模式，用于序列化

**方法签名：**
```java
public String getGroupMode2()
```

**返回值：**
- `String`

---

### getGroupMode3

子单据体行合并方式，用于序列化

**方法签名：**
```java
public String getGroupMode3()
```

**返回值：**
- `String`

---

### setGroupByField

分单依赖的字段

**方法签名：**
```java
public void setGroupByField(String groupByField)
```

**参数说明：**
- `groupByField`: `String`

---

### setGroupByField2

单据体行合并依赖字段

**方法签名：**
```java
public void setGroupByField2(String groupByField2)
```

**参数说明：**
- `groupByField2`: `String`

---

### setGroupByField3

单据体行合并依赖字段

**方法签名：**
```java
public void setGroupByField3(String groupByField3)
```

**参数说明：**
- `groupByField3`: `String`

---

### setGroupByMode

单据分单方式：一对一、全部合并、按字段分单

**方法签名：**
```java
public void setGroupByMode(GroupByMode groupByMode)
```

**参数说明：**
- `groupByMode`: `GroupByMode`

---

### setGroupByMode2

单据体行合并方式

**方法签名：**
```java
public void setGroupByMode2(GroupByMode groupByMode2)
```

**参数说明：**
- `groupByMode2`: `GroupByMode`

---

### setGroupByMode3

子单据体行合并方式

**方法签名：**
```java
public void setGroupByMode3(GroupByMode groupByMode3)
```

**参数说明：**
- `groupByMode3`: `GroupByMode`

---

### setGroupMode

分单模式，用于序列化

**方法签名：**
```java
public void setGroupMode(String groupMode)
```

**参数说明：**
- `groupMode`: `String`

---

### setGroupMode2

单据体行合并模式，用于序列化

**方法签名：**
```java
public void setGroupMode2(String groupMode)
```

**参数说明：**
- `groupMode`: `String`

---

### setGroupMode3

子单据体行合并方式

**方法签名：**
```java
public void setGroupMode3(String groupMode)
```

**参数说明：**
- `groupMode`: `String`

---
