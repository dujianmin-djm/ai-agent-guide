---
framework_version: "8.0.1"
api_class: "GroupCombineFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用combine操作回调函数时"
---

# GroupCombineFunction API 说明

## 概述
combine操作回调函数。继承自 Function，实现 ResultAwarable, Serializable。
主要功能：combine。

## Import 路径
```java
import kd.bos.algox.GroupCombineFunction;
```

---

## 方法列表

### combine

combine
 
 需要保证输入和输出的结构一致

**方法签名：**
```java
public abstract void combine(Iterable<kd.RowX> iter, Collector collector)
```

**参数说明：**
- `iter`: `Iterable<kd.RowX>` — 分组后的数据集
- `collector`: `Collector` — collector

---
