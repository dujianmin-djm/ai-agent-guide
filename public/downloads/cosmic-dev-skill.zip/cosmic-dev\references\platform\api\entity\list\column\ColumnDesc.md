---
framework_version: "8.0.1"
api_class: "ColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用列表字段格式化基类时"
---

# ColumnDesc API 说明

## 概述
列表字段格式化基类。继承自 AbstractColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.ColumnDesc;
```

---

## 方法列表

### getDesensitizeValue

获取脱敏值
 ListModel#getDesensitizeValue代替

**方法签名：**
```java
public Object getDesensitizeValue(String localeid, DynamicObject dynamicObject, Object value)
```

**参数说明：**
- `localeid`: `String`
- `dynamicObject`: `DynamicObject`
- `value`: `Object`

**返回值：**
- `Object`

---

### getDisplayFormatString

获取格式化字符串

**方法签名：**
```java
public String getDisplayFormatString()
```

**返回值：**
- `String`

---

### getFieldProp

获取末级字段

**方法签名：**
```java
public IDataEntityProperty getFieldProp()
```

**返回值：**
- `IDataEntityProperty`

---

### getMask

获取掩码

**方法签名：**
```java
public String getMask()
```

**返回值：**
- `String`

---

### getSrcFieldProp

获取根字段

**方法签名：**
```java
public IDataEntityProperty getSrcFieldProp()
```

**返回值：**
- `IDataEntityProperty`

---

### getValue

从数据包获取字段对应的格式化值

**方法签名：**
```java
public Object getValue(DynamicObject o)
```

**参数说明：**
- `o`: `DynamicObject` — 数据来源

**返回值：**
- `Object`

---

### setDisplayFormatString

{待补充}

**方法签名：**
```java
public void setDisplayFormatString(String displayFormatString)
```

**参数说明：**
- `displayFormatString`: `String`

---

### setMask

{待补充}

**方法签名：**
```java
public void setMask(String mask)
```

**参数说明：**
- `mask`: `String` — 设置掩码

---
