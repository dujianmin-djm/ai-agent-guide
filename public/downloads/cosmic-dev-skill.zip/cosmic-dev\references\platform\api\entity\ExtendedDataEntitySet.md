---
framework_version: "8.0.1"
api_class: "ExtendedDataEntitySet"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用将垂直的实体数据打平时"
---

# ExtendedDataEntitySet API 说明

## 概述
将垂直的实体数据打平，便于获取，工具类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.ExtendedDataEntitySet;
```

---

## 方法列表

### AddExtendedDataEntities

添加一批新的扩展行到指定的实体中

**方法签名：**
```java
public void AddExtendedDataEntities(String entityKey, List<kd.ExtendedDataEntity> rows)
```

**参数说明：**
- `entityKey`: `String` — 实体标识
- `rows`: `List<kd.ExtendedDataEntity>` — 新的扩展行

---

### FindByEntityKey

根据表的键，获取对应的数据行集合

**方法签名：**
```java
public ExtendedDataEntity[] FindByEntityKey(String entityKey)
```

**参数说明：**
- `entityKey`: `String` — 实体的键

**返回值：**
- `ExtendedDataEntity[]`: 如果包含数据，返回扩展实体集合，否则返回null

---

### Parse

**重载 1**

此方法已废弃

**方法签名：**
```java
public void Parse(DynamicObject[] dataEntities)
```

**参数说明：**
- `dataEntities`: `DynamicObject[]`

---

**重载 2**

将数据拉平，并放入字典

**方法签名：**
```java
public void Parse(DynamicObject[] dataEntities, MainEntityType dType)
```

**参数说明：**
- `dataEntities`: `DynamicObject[]` — 数据集合
- `dType`: `MainEntityType` — 实体类型

---

### getBillNo

获取单据编号

**方法签名：**
```java
public String getBillNo(DynamicObject dataEntity)
```

**参数说明：**
- `dataEntity`: `DynamicObject`

**返回值：**
- `String`

---

### getExtDataEntityMap

星辰扩展支持：便于星辰外部操作该对象

**方法签名：**
```java
public Map<String,List<kd.ExtendedDataEntity>> getExtDataEntityMap()
```

**返回值：**
- `Map<String,List<kd.ExtendedDataEntity>>`

---
