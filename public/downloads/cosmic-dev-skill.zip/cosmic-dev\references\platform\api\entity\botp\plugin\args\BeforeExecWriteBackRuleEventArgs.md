---
framework_version: "8.0.1"
api_class: "BeforeExecWriteBackRuleEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用开始分析反写规则时"
---

# BeforeExecWriteBackRuleEventArgs API 说明

## 概述
开始分析反写规则，计算反写量前触发此事件：用于取消当前反写规则的执行。继承自 WriteBackEventArgs。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeExecWriteBackRuleEventArgs;
```

---

## 方法列表

### getRule

当前准备执行的反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getRuleItem

当前准备执行的反写公式

**方法签名：**
```java
public WriteBackFormula getRuleItem()
```

**返回值：**
- `WriteBackFormula`

---

### isCancel

是否取消本反写公式的执行

**方法签名：**
```java
public boolean isCancel()
```

**返回值：**
- `boolean`

---

### setCancel

设置是否取消本反写公式的执行

**方法签名：**
```java
public void setCancel(boolean cancel)
```

**参数说明：**
- `cancel`: `boolean`

---

### setContext

调整当前反写规则、反写条目

**方法签名：**
```java
public void setContext(WriteBackRuleElement rule, WriteBackFormula ruleItem)
```

**参数说明：**
- `rule`: `WriteBackRuleElement`
- `ruleItem`: `WriteBackFormula`

---
