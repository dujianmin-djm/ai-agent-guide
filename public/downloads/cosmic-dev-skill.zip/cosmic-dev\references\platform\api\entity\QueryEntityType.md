---
framework_version: "8.0.1"
api_class: "QueryEntityType"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用查询实体类型时"
---

# QueryEntityType API 说明

## 概述
查询实体类型。继承自 BasedataEntityType。
主要功能：读取属性、添加元素、设置属性。

## Import 路径
```java
import kd.bos.entity.QueryEntityType;
```

---

## 方法列表

### addQueryPlugInFields

添加查询配置插件字段

**方法签名：**
```java
public void addQueryPlugInFields(QueryPlugInField queryPlugInField)
```

**参数说明：**
- `queryPlugInField`: `QueryPlugInField`

---

### addQuerySourceJoinRelation

添加关联关系

**方法签名：**
```java
public void addQuerySourceJoinRelation(QuerySourceJoinRelation rel)
```

**参数说明：**
- `rel`: `QuerySourceJoinRelation`

---

### addSelectField

**重载 1**

添加查询字段

**方法签名：**
```java
public void addSelectField(QuerySelectField selectField)
```

**参数说明：**
- `selectField`: `QuerySelectField`

---

**重载 2**

添加排序字段

**方法签名：**
```java
public void addSelectField(QuerySortField selectField)
```

**参数说明：**
- `selectField`: `QuerySortField`

---

### addWhereCondition

添加where条件

**方法签名：**
```java
public void addWhereCondition(QSConditionRow qsConditionRow)
```

**参数说明：**
- `qsConditionRow`: `QSConditionRow`

---

### endInit

{待补充}

**方法签名：**
```java
public synchronized void endInit()
```

---

### getAllJoinEntityType

获取所有的关联实体

**方法签名：**
```java
public List<kd.MainEntityType> getAllJoinEntityType()
```

**返回值：**
- `List<kd.MainEntityType>`

---

### getEditEntityAliasName

多实体编辑实体的别名

**方法签名：**
```java
public String getEditEntityAliasName()
```

**返回值：**
- `String`

---

### getEditEntityName

根据编辑实体别名获取编辑实体名，也就是实体编码
 用于操作，和验权限

**方法签名：**
```java
public String getEditEntityName()
```

**返回值：**
- `String`

---

### getEntityAlias

获取实体别名

**方法签名：**
```java
public String getEntityAlias()
```

**返回值：**
- `String`

---

### getEntityName

获取实体名称

**方法签名：**
```java
public String getEntityName()
```

**返回值：**
- `String`

---

### getEntityNameByAlias

根据实体别名获取实体名

**方法签名：**
```java
public String getEntityNameByAlias(String entityAlias)
```

**参数说明：**
- `entityAlias`: `String`

**返回值：**
- `String`

---

### getJoinEntitys

获取关联实体

**方法签名：**
```java
public List<kd.JoinEntity> getJoinEntitys()
```

**返回值：**
- `List<kd.JoinEntity>`

---

### getJoinOnFilterValue

根据字段属性类型，拼装过滤属性字段值

**方法签名：**
```java
public Object[] getJoinOnFilterValue(QSConditionRow row)
```

**参数说明：**
- `row`: `QSConditionRow`

**返回值：**
- `Object[]`

---

### getJoinRelations

获取关联关系

**方法签名：**
```java
public List<kd.QuerySourceJoinRelation> getJoinRelations()
```

**返回值：**
- `List<kd.QuerySourceJoinRelation>`

---

### getMainEntityType

获取主实体

**方法签名：**
```java
public MainEntityType getMainEntityType()
```

**返回值：**
- `MainEntityType`

---

### getMainOrgProperty

根据查询配置上配置的主业务组织字段，返回主业务组织属性

**方法签名：**
```java
public MainOrgProp getMainOrgProperty()
```

**返回值：**
- `MainOrgProp`: 获取主业务组织

---

### getQFilter

获取过滤条件

**方法签名：**
```java
public List<QFilter> getQFilter()
```

**返回值：**
- `List<QFilter>`

---

### getQueryDataCount

**重载 1**

查询列表调用，取总行数

**方法签名：**
```java
public int getQueryDataCount(QueryBuilder queryBuilder, String queryFileds)
```

**参数说明：**
- `queryBuilder`: `QueryBuilder`
- `queryFileds`: `String`

**返回值：**
- `int`

---

**重载 2**

取总行数

**方法签名：**
```java
public int getQueryDataCount(String queryFileds, QFilter[] qFilters)
```

**参数说明：**
- `queryFileds`: `String`
- `qFilters`: `QFilter[]`

**返回值：**
- `int`

---

### getQueryDataSet

**重载 1**

查询列表调用，按查询条件取数

**方法签名：**
```java
public DataSet getQueryDataSet(QueryBuilder queryBuilder, String queryFileds, boolean isLimitCount)
```

**参数说明：**
- `queryBuilder`: `QueryBuilder`
- `queryFileds`: `String`
- `isLimitCount`: `boolean`

**返回值：**
- `DataSet`

---

**重载 2**

按查询字段，过滤条件，排序，获取查询数据的数据集

**方法签名：**
```java
public DataSet getQueryDataSet(String queryFileds, QFilter[] qFilters, String orderBys)
```

**参数说明：**
- `queryFileds`: `String` — 查询字段
- `qFilters`: `QFilter[]` — 过滤信息
- `orderBys`: `String` — 排序字段，多个用,分隔

**返回值：**
- `DataSet`

---

**重载 3**

按查询字段，过滤条件，排序，获取查询数据的数据集

**方法签名：**
```java
public DataSet getQueryDataSet(String queryFileds, QFilter[] qFilters, String orderBys, int start, int limit)
```

**参数说明：**
- `queryFileds`: `String` — 查询字段
- `qFilters`: `QFilter[]` — 过滤信息
- `orderBys`: `String` — 排序字段，多个用,分隔
- `start`: `int` — 开始行数
- `limit`: `int` — 数量

**返回值：**
- `DataSet`

---

**重载 4**

按查询字段，过滤条件，排序，获取查询数据的数据集

**方法签名：**
```java
public DataSet getQueryDataSet(String queryFileds, QFilter[] qFilters, String orderBys, boolean isLimitCount, int start, int limit)
```

**参数说明：**
- `queryFileds`: `String` — 查询字段
- `qFilters`: `QFilter[]` — 过滤信息
- `orderBys`: `String` — 排序字段，多个用,分隔
- `isLimitCount`: `boolean` — 获取指定范围的数据 ，为 false 时 不限制范围
- `start`: `int` — 开始行数
- `limit`: `int` — 数量

**返回值：**
- `DataSet`

---

### getQueryDataSetByPK

查询列表调用，按查询条件取数，用于主键取数调用

**方法签名：**
```java
public DataSet getQueryDataSetByPK(QueryBuilder queryBuilder, List<QFilter> idFilters, String queryFileds, boolean isLimitCount)
```

**参数说明：**
- `queryBuilder`: `QueryBuilder`
- `idFilters`: `List<QFilter>`
- `queryFileds`: `String`
- `isLimitCount`: `boolean`

**返回值：**
- `DataSet`

---

### getQueryPlugInFields

获取查询配置插件字段

**方法签名：**
```java
public List<kd.QueryPlugInField> getQueryPlugInFields()
```

**返回值：**
- `List<kd.QueryPlugInField>`

---

### getQuerySortFields

获取排序字段

**方法签名：**
```java
public List<kd.QuerySortField> getQuerySortFields()
```

**返回值：**
- `List<kd.QuerySortField>`

---

### getSelectFields

获取查询字段

**方法签名：**
```java
public List<kd.QuerySelectField> getSelectFields()
```

**返回值：**
- `List<kd.QuerySelectField>`

---

### getWhereConditions

获取where条件

**方法签名：**
```java
public List<kd.QSConditionRow> getWhereConditions()
```

**返回值：**
- `List<kd.QSConditionRow>`

---

### setEditEntityAliasName

设置多实体编辑实体的别名

**方法签名：**
```java
public void setEditEntityAliasName(String editEntityAliasName)
```

**参数说明：**
- `editEntityAliasName`: `String`

---

### setEntityAlias

设置实体别名

**方法签名：**
```java
public void setEntityAlias(String entityAlias)
```

**参数说明：**
- `entityAlias`: `String`

---

### setEntityName

设置实体名称

**方法签名：**
```java
public void setEntityName(String entityName)
```

**参数说明：**
- `entityName`: `String`

---

### setJoinEntitys

设置关联实体

**方法签名：**
```java
public void setJoinEntitys(List<kd.JoinEntity> joinEntitys)
```

**参数说明：**
- `joinEntitys`: `List<kd.JoinEntity>`

---
