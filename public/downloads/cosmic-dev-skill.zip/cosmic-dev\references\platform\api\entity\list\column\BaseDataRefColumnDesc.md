---
framework_version: "8.0.1"
api_class: "BaseDataRefColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用基础资料属性格式化处理类时"
---

# BaseDataRefColumnDesc API 说明

## 概述
基础资料属性格式化处理类。继承自 BaseDataColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.BaseDataRefColumnDesc;
```

---

## 方法列表

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---
