---
framework_version: "8.0.1"
api_class: "DataEntityTypeAttribute"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用标记一个类是实体类时"
---

# DataEntityTypeAttribute API 说明

## 概述
标记一个类是实体类。实现 Annotation。
主要功能：界面显示、状态判断。

## Import 路径
```java
import kd.bos.dataentity.entity.DataEntityTypeAttribute;
```

---

## 方法列表

### dbRouteKey

数据库路由标识

**方法签名：**
```java
public String dbRouteKey()
```

**返回值：**
- `String`

---

### displayName

显示名称（属性描述）

**方法签名：**
```java
public String displayName()
```

**返回值：**
- `String`

---

### isDbIgnore

是否关联数据库物理表，与数据库字段对应。false:关联，true：不关联

**方法签名：**
```java
public boolean isDbIgnore()
```

**返回值：**
- `boolean`

---

### name

属性名称

**方法签名：**
```java
public String name()
```

**返回值：**
- `String`

---

### tableName

数据库表名称

**方法签名：**
```java
public String tableName()
```

**返回值：**
- `String`

---
