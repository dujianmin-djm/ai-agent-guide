---
framework_version: "8.0.1"
api_class: "RowUtil"
api_package: "kd.bos.algo"
when_to_use: "当你需要使用DataSet行(Row)处理的工具类时"
---

# RowUtil API 说明

## 概述
DataSet行(Row)处理的工具类。
主要功能：对Algox的行进行类型转换、持久化Row、将行变成数组、将row转成map。

## Import 路径
```java
import kd.bos.algo.RowUtil;
```

---

## 方法列表

### convert

对Algox的行进行类型转换

**方法签名：**
```java
public static RowX convert(RowMeta rowMeta, RowX rowX)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据信息
- `rowX`: `RowX` — Algox中的行数据

**返回值：**
- `RowX`

---

### persist

持久化Row

**方法签名：**
```java
public static Row persist(Row row)
```

**参数说明：**
- `row`: `Row` — 行数据

**返回值：**
- `Row`: 持久化的Row

---

### toArray

将行变成数组

**方法签名：**
```java
public static Object[] toArray(Row row)
```

**参数说明：**
- `row`: `Row` — 构造DataSet结果集的行数据

**返回值：**
- `Object[]`: 行数据转换后的Object数组值

---

### toMap

将row转成map

**方法签名：**
```java
public static Map<String,Object> toMap(Row row)
```

**参数说明：**
- `row`: `Row` — 行数据

**返回值：**
- `Map<String,Object>`

---
