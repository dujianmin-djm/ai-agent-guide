---
framework_version: "8.0.1"
api_class: "OrgViewSchemeProp"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用组织视图方案时"
---

# OrgViewSchemeProp API 说明

## 概述
组织视图方案。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgViewSchemeProp;
```

---

## 方法列表

### getId

获取视图方案ID

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 视图方案ID

---

### getName

获取视图方案名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`: 视图方案名称

---

### getNumber

获取视图方案标识

**方法签名：**
```java
public String getNumber()
```

**返回值：**
- `String`: 视图方案标识

---

### setId

设置视图方案ID

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 视图方案ID

---

### setName

设置视图方案名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String` — 视图方案名称

---

### setNumber

设置视图方案标识

**方法签名：**
```java
public void setNumber(String number)
```

**参数说明：**
- `number`: `String` — 视图方案标识

---
