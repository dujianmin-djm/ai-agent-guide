---
framework_version: "8.0.1"
api_class: "DynamicCollectionProperty"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用动态实体的集合属性 集合属性指向另外一个实体类型的引用时"
---

# DynamicCollectionProperty API 说明

## 概述
动态实体的集合属性 集合属性指向另外一个实体类型的引用，所不同的是集合属性表达主表与明细表的关系时候使用。。继承自 DynamicProperty，实现 ICollectionProperty, Serializable, IDataEntityProperty, IMetadata, Cloneable。
主要功能：读取属性、创建对象、状态判断、设置属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicCollectionProperty;
```

---

## 方法列表

### buildPlainStrMap

{待补充}

**方法签名：**
```java
public Map<String,Object> buildPlainStrMap()
```

**返回值：**
- `Map<String,Object>`

---

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createHashCode

根据元数据创建HashCode

**方法签名：**
```java
public int createHashCode()
```

**返回值：**
- `int`

---

### getDTValueFast

{待补充}

**方法签名：**
```java
public Object getDTValueFast(DynamicObject obj)
```

**参数说明：**
- `obj`: `DynamicObject`

**返回值：**
- `Object`

---

### getDynamicCollectionItemPropertyType

返回集合属性的元素数据类型

**方法签名：**
```java
public DynamicObjectType getDynamicCollectionItemPropertyType()
```

**返回值：**
- `DynamicObjectType`

---

### getEntryInfo

{待补充}

**方法签名：**
```java
public EntryInfo getEntryInfo(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `EntryInfo`

---

### getFkFieldName

获取单据体的标识

**方法签名：**
```java
public String getFkFieldName()
```

**返回值：**
- `String`: 单据体标识

---

### getItemType

{待补充}

**方法签名：**
```java
public IDataEntityType getItemType()
```

**返回值：**
- `IDataEntityType`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### setFkFieldName

设置单据体标识

**方法签名：**
```java
public void setFkFieldName(String fkFieldName)
```

**参数说明：**
- `fkFieldName`: `String`

---
