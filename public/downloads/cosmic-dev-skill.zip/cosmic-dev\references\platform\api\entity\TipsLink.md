---
framework_version: "8.0.1"
api_class: "TipsLink"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用tips链接对象时"
---

# TipsLink API 说明

## 概述
tips链接对象。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.TipsLink;
```

---

## 方法列表

### getCode

获取指令

**方法签名：**
```java
public String getCode()
```

**返回值：**
- `String`

---

### getCodeName

获取指令名称

**方法签名：**
```java
public LocaleString getCodeName()
```

**返回值：**
- `LocaleString`

---

### getIndex

获取索引

**方法签名：**
```java
public int getIndex()
```

**返回值：**
- `int`

---

### setCode

设置指令

**方法签名：**
```java
public void setCode(String code)
```

**参数说明：**
- `code`: `String`

---

### setCodeName

设置指令名称

**方法签名：**
```java
public void setCodeName(LocaleString codeName)
```

**参数说明：**
- `codeName`: `LocaleString`

---

### setIndex

设置索引

**方法签名：**
```java
public void setIndex(int index)
```

**参数说明：**
- `index`: `int`

---
