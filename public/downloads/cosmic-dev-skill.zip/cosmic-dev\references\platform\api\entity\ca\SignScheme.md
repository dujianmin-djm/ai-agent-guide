---
framework_version: "8.0.1"
api_class: "SignScheme"
api_package: "kd.bos.entity.ca"
when_to_use: "当你需要使用签名配置方案时"
---

# SignScheme API 说明

## 概述
签名配置方案。。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.ca.SignScheme;
```

---

## 方法列表

### getBizAppId

获取业务对象所在应用id。

**方法签名：**
```java
public String getBizAppId()
```

**返回值：**
- `String`: 应用id

---

### getFormName

获取业务对象名称。

**方法签名：**
```java
public String getFormName()
```

**返回值：**
- `String`: 业务对象名称

---

### getFormNumber

获取业务对象编码。

**方法签名：**
```java
public String getFormNumber()
```

**返回值：**
- `String`: 业务对象编码

---

### getId

获取签名配置方案id。

**方法签名：**
```java
public long getId()
```

**返回值：**
- `long`: id

---

### getSignField

获取签名字段配置。

**方法签名：**
```java
public String getSignField()
```

**返回值：**
- `String`: 签名字段配置

---

### getSignOperate

获取签名操作配置。

**方法签名：**
```java
public String getSignOperate()
```

**返回值：**
- `String`: 签名操作配置

---

### getVerifyOperate

获取验签操作配置。

**方法签名：**
```java
public String getVerifyOperate()
```

**返回值：**
- `String`: 验签操作配置

---

### setBizAppId

设置业务对象所在应用id。

**方法签名：**
```java
public void setBizAppId(String bizAppId)
```

**参数说明：**
- `bizAppId`: `String` — 应用id

---

### setFormName

设置业务对象名称。

**方法签名：**
```java
public void setFormName(String formName)
```

**参数说明：**
- `formName`: `String` — 业务对象名称

---

### setFormNumber

设置业务对象编码。

**方法签名：**
```java
public void setFormNumber(String formNumber)
```

**参数说明：**
- `formNumber`: `String` — 业务对象编码

---

### setId

设置签名配置方案id。

**方法签名：**
```java
public void setId(long id)
```

**参数说明：**
- `id`: `long` — id

---

### setSignField

设置签名字段配置。

**方法签名：**
```java
public void setSignField(String signField)
```

**参数说明：**
- `signField`: `String` — 签名字段配置

---

### setSignOperate

设置签名操作配置。

**方法签名：**
```java
public void setSignOperate(String signOperate)
```

**参数说明：**
- `signOperate`: `String` — 签名操作配置

---

### setVerifyOperate

设置验签操作配置。

**方法签名：**
```java
public void setVerifyOperate(String verifyOperate)
```

**参数说明：**
- `verifyOperate`: `String` — 验签操作配置

---
