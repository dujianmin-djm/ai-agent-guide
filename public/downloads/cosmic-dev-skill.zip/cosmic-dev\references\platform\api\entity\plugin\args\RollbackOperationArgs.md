---
framework_version: "8.0.1"
api_class: "RollbackOperationArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作处理失败时"
---

# RollbackOperationArgs API 说明

## 概述
操作处理失败，回滚事务时事件参数。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.RollbackOperationArgs;
```

---

## 方法列表

### getDataEntitys

返回单据数据包

**方法签名：**
```java
public DynamicObject[] getDataEntitys()
```

**返回值：**
- `DynamicObject[]`: 单据数据包

---
