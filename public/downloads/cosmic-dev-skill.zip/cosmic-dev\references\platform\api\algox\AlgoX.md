---
framework_version: "8.0.1"
api_class: "AlgoX"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用分布式计算接口时"
---

# AlgoX API 说明

## 概述
分布式计算接口。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.algox.AlgoX;
```

---

## 方法列表

### createSession

**重载 1**

创建任务会话

**方法签名：**
```java
public static JobSession createSession(String name)
```

**参数说明：**
- `name`: `String` — 任务名称

**返回值：**
- `JobSession`: 任务会话

---

**重载 2**

创建任务会话，可以通过会话提交任务给计算集群执行

**方法签名：**
```java
public static JobSession createSession(String name, String title)
```

**参数说明：**
- `name`: `String` — 任务名称
- `title`: `String` — 任务标题

**返回值：**
- `JobSession`: 任务会话

---
