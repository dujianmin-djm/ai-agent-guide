---
framework_version: "8.0.1"
api_class: "CacheFactory"
api_package: "kd.bos.cache"
when_to_use: "当你需要使用缓存工厂抽象类时"
---

# CacheFactory API 说明

## 概述
缓存工厂抽象类，提供统一的缓存实例创建与管理入口。。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.cache.CacheFactory;
```

---

## 方法列表

### $createOrReplaceLocalMemoryCache

{待补充}

**方法签名：**
```java
public abstract LocalMemoryCache $createOrReplaceLocalMemoryCache(String region, String type, CacheConfigInfo cacheConfig)
```

**参数说明：**
- `region`: `String` — 缓存区域标识符
- `type`: `String` — 缓存类型
- `cacheConfig`: `CacheConfigInfo`

**返回值：**
- `LocalMemoryCache`: 新创建的缓存实例（强制替换已存在的）

---

### $getLocalMemoryCache

获取已存在的本地缓存实例

**方法签名：**
```java
public abstract LocalMemoryCache $getLocalMemoryCache(String region, String type)
```

**参数说明：**
- `region`: `String` — 缓存区域标识符
- `type`: `String` — 缓存类型

**返回值：**
- `LocalMemoryCache`: 存在的实例，若未创建则返回 ` null`

---

### $getOrCreateLocalMemoryCache

**重载 1**

获取或创建本地内存缓存实例（自动加载配置文件）
 
 当首次请求 region+type 组合时，根据配置文件初始化缓存；
 后续调用返回已创建的实例。

**方法签名：**
```java
public abstract LocalMemoryCache $getOrCreateLocalMemoryCache(String region, String type)
```

**参数说明：**
- `region`: `String` — 缓存区域，用于隔离不同业务模块
- `type`: `String` — 缓存类型，同一区域下的子分类

**返回值：**
- `LocalMemoryCache`: 存在的或新建的本地缓存实例

---

**重载 2**

获取或创建带自定义配置的本地缓存（首次创建生效）
 
 cacheConfig 仅在首次创建时生效，后续调用忽略配置参数

**方法签名：**
```java
public abstract LocalMemoryCache $getOrCreateLocalMemoryCache(String region, String type, CacheConfigInfo cacheConfig)
```

**参数说明：**
- `region`: `String` — 缓存区域标识符
- `type`: `String` — 缓存类型
- `cacheConfig`: `CacheConfigInfo` — 初始化配置（仅首次生效）

**返回值：**
- `LocalMemoryCache`: 本地缓存实例

---

**重载 3**

获取或创建指定存储类型的本地缓存
 
 支持堆内/堆外存储配置，适用于特殊内存管理场景

**方法签名：**
```java
public abstract LocalMemoryCache $getOrCreateLocalMemoryCache(String region, String type, CacheConfigInfo cacheConfig, EhcacheStoreType storeType)
```

**参数说明：**
- `region`: `String`
- `type`: `String`
- `cacheConfig`: `CacheConfigInfo`
- `storeType`: `EhcacheStoreType` — 存储类型 EhcacheStoreType

**返回值：**
- `LocalMemoryCache`: 配置指定存储策略的缓存实例

---

### getCommonCacheFactory

获取 JVM 范围内共享的通用缓存工厂（线程安全单例）

**方法签名：**
```java
public static CacheFactory getCommonCacheFactory()
```

**返回值：**
- `CacheFactory`: 全局唯一的缓存工厂实例

---

### getTempFileCache

获取临时文件缓存实例（全局单例）
 
 用于存储临时生成的文件对象，支持自动清理机制

**方法签名：**
```java
public abstract TempFileCache getTempFileCache()
```

**返回值：**
- `TempFileCache`: 临时文件缓存实例

---
