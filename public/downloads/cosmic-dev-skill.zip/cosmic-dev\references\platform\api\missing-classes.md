---
last_updated: "2026-03-07"
total_referenced: 124
missing_count: 46
---

# 缺失的 API 类

> 以下类在场景文档中被引用，但尚未在 output/platform/api/ 下生成 API 文档。
> 需要用 extract-api-html 或 extract-api 补充提取。

| 类名 | 引用来源（场景文档） | 状态 |
|------|-------------------|------|
| AbstractFormPlugin | common/batch-load-save.md, common/db-batch.md, common/form-show-param.md 等31个 | 缺失 |
| BasedataEdit | common/page-cache.md, event/after-f7-select-process.md, event/before-f7-select-qfilter.md 等4个 | 缺失 |
| BeforeClickEvent | workflow/message-carousel.md | 缺失 |
| BeforeItemClickEvent | event/before-item-click-validate.md | 缺失 |
| Button | event/click-return-data.md | 缺失 |
| ComboEdit | control/combo-edit/combo-edit-set-items.md, event/before-field-post-back-validate.md, pending-scenes.md | 缺失 |
| ComboItem | control/combo-edit/combo-edit-set-items.md, pending-scenes.md | 缺失 |
| Control | event/click-parent-view-set-value.md | 缺失 |
| DB | common/db-batch.md, pending-scenes.md | 缺失 |
| DBRoute | common/db-batch.md, pending-scenes.md | 缺失 |
| EntryGrid | control/entry-grid/entry-grid-bind-data.md, event/after-do-operation-show-form.md, event/before-do-operation-validate.md 等5个 | 缺失 |
| EntryGridBindDataEvent | control/entry-grid/entry-grid-bind-data.md | 缺失 |
| FilterGrid | control/filter-grid/filter-grid-set-value.md, pending-scenes.md | 缺失 |
| HyperLinkClickListener | pending-scenes.md | 缺失 |
| IDataEntityProperty | pending-scenes.md | 缺失 |
| IDataEntityType | common/batch-load-save.md, pending-scenes.md | 缺失 |
| IDataModel | business/attachment-name-process.md, business/dynamic-update-field.md, business/password-conflict-validate.md 等22个 | 缺失 |
| IFormPlugin | pending-scenes.md | 缺失 |
| IFormView | business/attachment-name-process.md, business/dynamic-update-field.md, business/password-encryption.md 等26个 | 缺失 |
| IListColumn | control/list/list-column-hide.md | 缺失 |
| IListDataProvider | pending-scenes.md | 缺失 |
| ILocaleString | workflow/workflow-reminder.md | 缺失 |
| ImportLogger | common/batch-import-validate.md | 缺失 |
| ItemClickEvent | business/dynamic-update-field.md, common/mq-publish.md, control/list/list-show-form.md 等7个 | 缺失 |
| LicenseCheckResult | pending-scenes.md | 缺失 |
| ListDataProvider | control/list/list-data-provider.md | 缺失 |
| ListFilterParameter | control/list/list-show-form.md | 缺失 |
| Log | common/batch-import-validate.md, common/dispatch-service-call.md | 缺失 |
| MCNavigationItemCustomEvent | workflow/message-center-navigation.md | 缺失 |
| MessageCarouselContainer | workflow/message-carousel.md | 缺失 |
| MessagePublisher | common/mq-publish.md | 缺失 |
| NavigationTreeNode | workflow/message-center-navigation.md | 缺失 |
| ORM | pending-scenes.md | 缺失 |
| PasswordEncryptUtil | business/password-encryption.md | 缺失 |
| QCP | business/dynamic-update-field.md, business/password-encryption.md, control/list/list-data-provider.md 等10个 | 缺失 |
| RowClickEvent | pending-scenes.md | 缺失 |
| RowClickEventListener | pending-scenes.md | 缺失 |
| TabSelectEvent | control/tab/tab-selected.md, pending-scenes.md | 缺失 |
| Toolbar | pending-scenes.md | 缺失 |
| TreeNodeClickEvent | pending-scenes.md | 缺失 |
| TreeNodeClickListener | pending-scenes.md | 缺失 |
| TreeView | pending-scenes.md | 缺失 |
| UploadEvent | pending-scenes.md | 缺失 |
| UploadListener | pending-scenes.md | 缺失 |
| UrlService | business/dynamic-update-field.md | 缺失 |
| WorkflowViewFlowchartPlugin | workflow/workflow-reminder.md | 缺失 |