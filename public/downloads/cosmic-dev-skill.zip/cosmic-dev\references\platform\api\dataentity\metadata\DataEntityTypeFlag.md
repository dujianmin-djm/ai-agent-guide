---
framework_version: "8.0.1"
api_class: "DataEntityTypeFlag"
api_package: "kd.bos.dataentity.metadata"
when_to_use: "当你需要使用定义了实体类型的特征时"
---

# DataEntityTypeFlag API 说明

## 概述
定义了实体类型的特征，可选值包括：Class(缺省)、Abstract、Sealed、Interface。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.DataEntityTypeFlag;
```

---

## 方法列表

### forValue

根据整数值获取实体类型的特征

**方法签名：**
```java
public static DataEntityTypeFlag forValue(int value)
```

**参数说明：**
- `value`: `int`

**返回值：**
- `DataEntityTypeFlag`

---

### getValue

实体类型的特征整数值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
