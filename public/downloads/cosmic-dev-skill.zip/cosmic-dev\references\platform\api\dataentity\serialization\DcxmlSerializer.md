---
framework_version: "8.0.1"
api_class: "DcxmlSerializer"
api_package: "kd.bos.dataentity.serialization"
when_to_use: "当你需要使用对象序列化工具（XML）时"
---

# DcxmlSerializer API 说明

## 概述
对象序列化工具（XML）。继承自 DcSerializer。
主要功能：设置属性、读取属性、添加元素、状态判断。

## Import 路径
```java
import kd.bos.dataentity.serialization.DcxmlSerializer;
```

---

## 方法列表

### addTemplate

**重载 1**

根据url地址添加模板

**方法签名：**
```java
public void addTemplate(String loacleId, URL xmlTemplate)
```

**参数说明：**
- `loacleId`: `String` — 当前语言
- `xmlTemplate`: `URL` — url地址

---

**重载 2**

根据文件添加模板

**方法签名：**
```java
public void addTemplate(String loacleId, File xmlTemplate)
```

**参数说明：**
- `loacleId`: `String` — 当前语言
- `xmlTemplate`: `File` — 当前文件

---

### addTemplateFromString

根据内容添加模板

**方法签名：**
```java
public void addTemplateFromString(String loacleId, String xmlTemplate)
```

**参数说明：**
- `loacleId`: `String` — 当前语言
- `xmlTemplate`: `String` — 当前内容

---

### deserialize

**重载 1**

对指定的位置执行反序列化操作

**方法签名：**
```java
public final Object deserialize(URL url, Object entity)
```

**参数说明：**
- `url`: `URL` — 数据来源
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

**重载 2**

对指定的位置执行反序列化操作

**方法签名：**
```java
public final Object deserialize(File file, Object entity)
```

**参数说明：**
- `file`: `File` — 文件
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

**重载 3**

对指定的位置执行反序列化操作

**方法签名：**
```java
public final Object deserialize(Document doc, Object entity)
```

**参数说明：**
- `doc`: `Document` — xml文档
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

### deserializeFromString

对指定的文本执行反序列化操作

**方法签名：**
```java
public final Object deserializeFromString(String xml, Object entity)
```

**参数说明：**
- `xml`: `String` — 数据来源
- `entity`: `Object` — 如果已经存在一个实体，可以提供给他

**返回值：**
- `Object`: 反序列化后的实体

---

### getColloctionIgnorePKValue

获取反序列化是否忽略主键冲突

**方法签名：**
```java
public final boolean getColloctionIgnorePKValue()
```

**返回值：**
- `boolean`

---

### getDiffDesc

对指定的文本执行反序列化操作

**方法签名：**
```java
public final String getDiffDesc(String diffxml, Object baseentity, IDcDescReadPlugin plugin)
```

**参数说明：**
- `diffxml`: `String` — 数据来源
- `baseentity`: `Object` — 如果已经存在一个实体，可以提供给他
- `plugin`: `IDcDescReadPlugin` — 插件

**返回值：**
- `String`: 反序列化后的实体

---

### getNeedDBIgnore

获取是否需要忽略不支持数据库操作的元素序列化

**方法签名：**
```java
public final boolean getNeedDBIgnore()
```

**返回值：**
- `boolean`

---

### getOnlyLocaleVale

获取是否只包含LocaleValue

**方法签名：**
```java
public final boolean getOnlyLocaleVale()
```

**返回值：**
- `boolean`

---

### getResetLoacaleValueBy2052

获取2052多语言发生变化，是否重置其他语言

**方法签名：**
```java
public final boolean getResetLoacaleValueBy2052()
```

**返回值：**
- `boolean`

---

### isIgnoreTrimText

xml输出内容时，是否忽略 去重空格处理
 去重空格效果(OutputFormat.trimtext)

**方法签名：**
```java
public boolean isIgnoreTrimText()
```

**返回值：**
- `boolean`

---

### isIndent

获取是否缩进

**方法签名：**
```java
public boolean isIndent()
```

**返回值：**
- `boolean`

---

### isNewlines

获取是否换行

**方法签名：**
```java
public boolean isNewlines()
```

**返回值：**
- `boolean`

---

### serializeToString

比对当前实体和基础实体的信息，并返回差量化的XML数据。

**方法签名：**
```java
public final String serializeToString(Object currentEntity, Object baseEntity)
```

**参数说明：**
- `currentEntity`: `Object` — 当前实体
- `baseEntity`: `Object` — 基础比对实体。

**返回值：**
- `String`: 差量化的XML数据。

---

### setColloctionIgnorePKValue

设置反序列化是否忽略主键冲突

**方法签名：**
```java
public final void setColloctionIgnorePKValue(boolean value)
```

**参数说明：**
- `value`: `boolean` — 反序列化是否忽略主键冲突

---

### setIgnoreTrimText

设置xml输出时，是否忽略去重空格
 true: 强制忽略
 false: 按原有效果输出（ json忽略，xml进行去重）

**方法签名：**
```java
public void setIgnoreTrimText(boolean ignoreTrimText)
```

**参数说明：**
- `ignoreTrimText`: `boolean`

---

### setIndent

设置是否缩进

**方法签名：**
```java
public void setIndent(boolean indent)
```

**参数说明：**
- `indent`: `boolean` — 缩进

---

### setNeedDBIgnore

设置是否需要忽略不支持数据库操作的元素序列化

**方法签名：**
```java
public final void setNeedDBIgnore(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否忽略不支持数据库操作的元素序列化

---

### setNewlines

设置是否换行

**方法签名：**
```java
public void setNewlines(boolean newlines)
```

**参数说明：**
- `newlines`: `boolean` — 换行

---

### setOnlyLocaleVale

设置是否只包含LocaleValue

**方法签名：**
```java
public final void setOnlyLocaleVale(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否只包含LocaleValue

---

### setResetLoacaleValueBy2052

设置2052多语言发生变化，是否重置其他语言

**方法签名：**
```java
public final void setResetLoacaleValueBy2052(boolean value)
```

**参数说明：**
- `value`: `boolean` — 是否重置其他语言

---
