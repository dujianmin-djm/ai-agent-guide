---
framework_version: "8.0.1"
api_class: "ObjectUtils"
api_package: "kd.bos.dataentity.utils"
when_to_use: "当你需要使用Miscellaneous object utility methods.时"
---

# ObjectUtils API 说明

## 概述
Miscellaneous object utility methods.。
主要功能：状态判断、读取属性、添加元素。

## Import 路径
```java
import kd.bos.dataentity.utils.ObjectUtils;
```

---

## 方法列表

### addObjectToArray

Append the given object to the given array, returning a new array
 consisting of the input array contents plus the given object.

**方法签名：**
```java
public static Object addObjectToArray(A[] array, O obj)
```

**参数说明：**
- `array`: `A[]` — the array to append to (can be ` null`)
- `obj`: `O` — the object to append

**返回值：**
- `Object`: the new array (of the same component type; never ` null`)

---

### caseInsensitiveValueOf

Case insensitive alternative to String).

**方法签名：**
```java
public static Enum caseInsensitiveValueOf(E[] enumValues, String constant)
```

**参数说明：**
- `enumValues`: `E[]` — the array of all Enum constants in question, usually per Enum.values()
- `constant`: `String` — the constant to get the enum value of

**返回值：**
- `Enum`

---

### containsConstant

**重载 1**

Check whether the given array of enum constants contains a constant with the given name,
 ignoring case when determining a match.

**方法签名：**
```java
public static boolean containsConstant(Enum<?>[] enumValues, String constant)
```

**参数说明：**
- `enumValues`: `Enum<?>[]` — the enum values to check, typically the product of a call to MyEnum.values()
- `constant`: `String` — the constant name to find (must not be null or empty string)

**返回值：**
- `boolean`: whether the constant has been found in the given array

---

**重载 2**

Check whether the given array of enum constants contains a constant with the given name.

**方法签名：**
```java
public static boolean containsConstant(Enum<?>[] enumValues, String constant, boolean caseSensitive)
```

**参数说明：**
- `enumValues`: `Enum<?>[]` — the enum values to check, typically the product of a call to MyEnum.values()
- `constant`: `String` — the constant name to find (must not be null or empty string)
- `caseSensitive`: `boolean` — whether case is significant in determining a match

**返回值：**
- `boolean`: whether the constant has been found in the given array

---

### containsElement

Check whether the given array contains the given element.

**方法签名：**
```java
public static boolean containsElement(Object[] array, Object element)
```

**参数说明：**
- `array`: `Object[]` — the array to check (may be ` null`,
 in which case the return value will always be ` false`)
- `element`: `Object` — the element to check for

**返回值：**
- `boolean`: whether the element has been found in the given array

---

### getDisplayString

Return a content-based String representation if ` obj` is
 not ` null`; otherwise returns an empty String.
 Differs from #nullSafeToString(Object) in that it returns
 an empty String rather than "null" for a ` null` value.

**方法签名：**
```java
public static String getDisplayString(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object to build a display String for

**返回值：**
- `String`: a display String representation of ` obj`

---

### getIdentityHexString

Return a hex String form of an object's identity hash code.

**方法签名：**
```java
public static String getIdentityHexString(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object

**返回值：**
- `String`: the object's identity code in hex notation

---

### hashCode

**重载 1**

Return the same value as Boolean#hashCode()}.

**方法签名：**
```java
public static int hashCode(boolean bool)
```

**参数说明：**
- `bool`: `boolean`

**返回值：**
- `int`

---

**重载 2**

Return the same value as Double#hashCode()}.

**方法签名：**
```java
public static int hashCode(double dbl)
```

**参数说明：**
- `dbl`: `double`

**返回值：**
- `int`

---

**重载 3**

Return the same value as Float#hashCode()}.

**方法签名：**
```java
public static int hashCode(float flt)
```

**参数说明：**
- `flt`: `float`

**返回值：**
- `int`

---

**重载 4**

Return the same value as Long#hashCode()}.

**方法签名：**
```java
public static int hashCode(long lng)
```

**参数说明：**
- `lng`: `long`

**返回值：**
- `int`

---

### identityToString

Return a String representation of an object's overall identity.

**方法签名：**
```java
public static String identityToString(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object (may be ` null`)

**返回值：**
- `String`: the object's identity as String representation,
 or an empty String if the object was ` null`

---

### isArray

Determine whether the given object is an array:
 either an Object array or a primitive array.

**方法签名：**
```java
public static boolean isArray(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object to check

**返回值：**
- `boolean`

---

### isCheckedException

Return whether the given throwable is a checked exception:
 that is, neither a RuntimeException nor an Error.

**方法签名：**
```java
public static boolean isCheckedException(Throwable ex)
```

**参数说明：**
- `ex`: `Throwable` — the throwable to check

**返回值：**
- `boolean`: whether the throwable is a checked exception

---

### isCompatibleWithThrowsClause

Check whether the given exception is compatible with the specified
 exception types, as declared in a throws clause.

**方法签名：**
```java
public static boolean isCompatibleWithThrowsClause(Throwable ex, Class<?>[] declaredExceptions)
```

**参数说明：**
- `ex`: `Throwable` — the exception to check
- `declaredExceptions`: `Class<?>[]` — the exception types declared in the throws clause

**返回值：**
- `boolean`: whether the given exception is compatible

---

### isEmpty

**重载 1**

Determine whether the given array is empty:
 i.e. ` null` or of zero length.

**方法签名：**
```java
public static boolean isEmpty(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — the array to check

**返回值：**
- `boolean`

---

**重载 2**

Determine whether the given object is empty.
 This method supports the following object types.
 
 ` Optional`: considered empty if Optional#empty()
 ` Array`: considered empty if its length is zero
 CharSequence: considered empty if its length is zero
 Collection: delegates to Collection#isEmpty()
 Map: delegates to Map#isEmpty()
 
 If the given object is non-null and not one of the aforementioned
 supported types, this method returns ` false`.

**方法签名：**
```java
public static boolean isEmpty(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object to check

**返回值：**
- `boolean`: ` true` if the object is ` null` or empty

---

### nullSafeClassName

Determine the class name for the given object.
 Returns ` "null"` if ` obj` is ` null`.

**方法签名：**
```java
public static String nullSafeClassName(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object to introspect (may be ` null`)

**返回值：**
- `String`: the corresponding class name

---

### nullSafeEquals

Determine if the given objects are equal, returning ` true` if
 both are ` null` or ` false` if only one is ` null`.
 Compares arrays with ` Arrays.equals`, performing an equality
 check based on the array elements rather than the array reference.

**方法签名：**
```java
public static boolean nullSafeEquals(Object o1, Object o2)
```

**参数说明：**
- `o1`: `Object` — first Object to compare
- `o2`: `Object` — second Object to compare

**返回值：**
- `boolean`: whether the given objects are equal

---

### nullSafeHashCode

**重载 1**

Return as hash code for the given object; typically the value of
 ` Object#hashCode()`}. If the object is an array,
 this method will delegate to any of the ` nullSafeHashCode`
 methods for arrays in this class. If the object is ` null`,
 this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(Object obj)
```

**参数说明：**
- `obj`: `Object`

**返回值：**
- `int`

---

**重载 2**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(Object[] array)
```

**参数说明：**
- `array`: `Object[]`

**返回值：**
- `int`

---

**重载 3**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]`

**返回值：**
- `int`

---

**重载 4**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(byte[] array)
```

**参数说明：**
- `array`: `byte[]`

**返回值：**
- `int`

---

**重载 5**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(char[] array)
```

**参数说明：**
- `array`: `char[]`

**返回值：**
- `int`

---

**重载 6**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(double[] array)
```

**参数说明：**
- `array`: `double[]`

**返回值：**
- `int`

---

**重载 7**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(float[] array)
```

**参数说明：**
- `array`: `float[]`

**返回值：**
- `int`

---

**重载 8**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(int[] array)
```

**参数说明：**
- `array`: `int[]`

**返回值：**
- `int`

---

**重载 9**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(long[] array)
```

**参数说明：**
- `array`: `long[]`

**返回值：**
- `int`

---

**重载 10**

Return a hash code based on the contents of the specified array.
 If ` array` is ` null`, this method returns 0.

**方法签名：**
```java
public static int nullSafeHashCode(short[] array)
```

**参数说明：**
- `array`: `short[]`

**返回值：**
- `int`

---

### nullSafeToString

**重载 1**

Return a String representation of the specified Object.
 Builds a String representation of the contents in case of an array.
 Returns ` "null"` if ` obj` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(Object obj)
```

**参数说明：**
- `obj`: `Object` — the object to build a String representation for

**返回值：**
- `String`: a String representation of ` obj`

---

**重载 2**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(Object[] array)
```

**参数说明：**
- `array`: `Object[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 3**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(boolean[] array)
```

**参数说明：**
- `array`: `boolean[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 4**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(byte[] array)
```

**参数说明：**
- `array`: `byte[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 5**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(char[] array)
```

**参数说明：**
- `array`: `char[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 6**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(double[] array)
```

**参数说明：**
- `array`: `double[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 7**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(float[] array)
```

**参数说明：**
- `array`: `float[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 8**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(int[] array)
```

**参数说明：**
- `array`: `int[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 9**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(long[] array)
```

**参数说明：**
- `array`: `long[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

**重载 10**

Return a String representation of the contents of the specified array.
 The String representation consists of a list of the array's elements,
 enclosed in curly braces (` "{}"`). Adjacent elements are separated
 by the characters ` ", "` (a comma followed by a space). Returns
 ` "null"` if ` array` is ` null`.

**方法签名：**
```java
public static String nullSafeToString(short[] array)
```

**参数说明：**
- `array`: `short[]` — the array to build a String representation for

**返回值：**
- `String`: a String representation of ` array`

---

### toObjectArray

Convert the given array (which may be a primitive array) to an
 object array (if necessary of primitive wrapper objects).
 A ` null` source value will be converted to an
 empty Object array.

**方法签名：**
```java
public static Object[] toObjectArray(Object source)
```

**参数说明：**
- `source`: `Object` — the (potentially primitive) array

**返回值：**
- `Object[]`: the corresponding object array (never ` null`)

---
