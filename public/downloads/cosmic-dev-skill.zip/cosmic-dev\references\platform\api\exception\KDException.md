---
framework_version: "8.0.1"
api_class: "KDException"
api_package: "kd.bos.exception"
when_to_use: "当你需要使用系统异常时"
---

# KDException API 说明

## 概述
系统异常，所有异常定义均须继承本异常。。继承自 RuntimeException，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.exception.KDException;
```

---

## 方法列表

### getArgs

{待补充}

**方法签名：**
```java
public Object[] getArgs()
```

**返回值：**
- `Object[]`: 错误码对应的表达式参数

---

### getErrorCode

{待补充}

**方法签名：**
```java
public ErrorCode getErrorCode()
```

**返回值：**
- `ErrorCode`: 异常码

---

### getMessage

{待补充}

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`: 获取异常信息

---

### getStackTraceMessage

{待补充}

**方法签名：**
```java
public String getStackTraceMessage()
```

**返回值：**
- `String`: 堆栈异常信息

---
