---
framework_version: "8.0.1"
api_class: "RequestContextCreator"
api_package: "kd.bos.context"
when_to_use: "当你需要使用Web端创建RequestContext的统一入口时"
---

# RequestContextCreator API 说明

## 概述
Web端创建RequestContext的统一入口，不允许有其他入口或者拷贝代码修改。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.context.RequestContextCreator;
```

---

## 方法列表

### create

**重载 1**

根据用户会话信息创建请求上下文

**方法签名：**
```java
public static void create(HttpServletRequest request, String globalSessionId, SessionInfo sessionInfo)
```

**参数说明：**
- `request`: `HttpServletRequest` — servlet容器的request对象
- `globalSessionId`: `String` — 全局会话id
- `sessionInfo`: `SessionInfo` — 用户会话信息

---

**重载 2**

创建上下文

**方法签名：**
```java
public static void create(HttpServletRequest request, String globalSessionId, SessionInfo sessionInfo, boolean isRefreshSession)
```

**参数说明：**
- `request`: `HttpServletRequest` — servlet容器的请求对象
- `globalSessionId`: `String` — 全局会话id
- `sessionInfo`: `SessionInfo` — 用户会话信息
- `isRefreshSession`: `boolean` — 是否刷新session

---

### createBatch

**重载 1**

创建userAgent=Schedule，client=batch的请求上下文

**方法签名：**
```java
public static void createBatch(String tenantId, String userId)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `userId`: `String` — 用户id

---

**重载 2**

创建userAgent=Schedule，client=batch的请求上下文

**方法签名：**
```java
public static void createBatch(String tenantId, String accountId, String userId)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id
- `userId`: `String` — 用户id

---

**重载 3**

创建userAgent=Schedule，client=batch的请求上下文

**方法签名：**
```java
public static void createBatch(String tenantId, String accountId, String userId, long orgId, Lang lang)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id
- `userId`: `String` — 用户id
- `orgId`: `long` — 组织id
- `lang`: `Lang` — 语种

---

**重载 4**

创建userAgent=Schedule，client=batch的请求上下文

**方法签名：**
```java
public static void createBatch(String tenantId, String accountId, String userId, long orgId, Lang lang, boolean cacheGlSessionId)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id
- `userId`: `String` — 用户id
- `orgId`: `long` — 组织id
- `lang`: `Lang` — 语种
- `cacheGlSessionId`: `boolean` — 是否缓存会话信息

---

### createFor3RDMQ

第三方的MQ集成，需要在后台创建上下文对象 注意的地方：使用时，只有traceId，globalSessionId，和传入的3个参数是可靠可用的

**方法签名：**
```java
public static void createFor3RDMQ(String tenantId, String accountId, String userId, Lang lang)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id
- `userId`: `String` — 用户id
- `lang`: `Lang` — 语种

---

### createForOnlySesssion

创建符合当前session的上下文，目前仅给Mutex删除使用

**方法签名：**
```java
public static void createForOnlySesssion(String globalSessionId, SessionInfo sessionInfo, String client)
```

**参数说明：**
- `globalSessionId`: `String` — 全局会话id
- `sessionInfo`: `SessionInfo` — 会话信息
- `client`: `String` — 客户端

---

### createForPreheat

创建userAgent=Schedule，client=batch的请求上下文

**方法签名：**
```java
public static void createForPreheat(String tenantId, String accountId)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id

---

### createForThreadPool

创建线程池专用的请求上下文

**方法签名：**
```java
public static RequestContext createForThreadPool()
```

**返回值：**
- `RequestContext`: 请求上下文

---

### createForTripSI

商旅集成

**方法签名：**
```java
public static void createForTripSI(String tenantId, String accountId, String userId)
```

**参数说明：**
- `tenantId`: `String` — 租户id
- `accountId`: `String` — 账套id
- `userId`: `String` — 用户id

---

### createOnlySession

创建请求上下文并设置到当前线程，设置全局会话id

**方法签名：**
```java
public static RequestContext createOnlySession(String sessionId)
```

**参数说明：**
- `sessionId`: `String` — 全局会话id

**返回值：**
- `RequestContext`: 请求上下文

---

### restoreForMQ

MQ使用，请求上下文对象设置到当前线程

**方法签名：**
```java
public static void restoreForMQ(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext` — 请求上下文

---

### restoreForThreadPool

线程池使用，请求上下文对象设置到当前线程

**方法签名：**
```java
public static void restoreForThreadPool(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext` — 请求上下文

---
