---
framework_version: "8.0.1"
api_class: "AfterCommitAmountEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用执行反写规则时"
---

# AfterCommitAmountEventArgs API 说明

## 概述
执行反写规则，把当前反写量，写到源单行之后，触发此事件：用于对源单行，进行连锁更新。继承自 WriteBackEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterCommitAmountEventArgs;
```

---

## 方法列表

### getCurrCVal

覆盖反写值

**方法签名：**
```java
public Object getCurrCVal()
```

**返回值：**
- `Object`

---

### getCurrVal

本次操作，对源单行执行的反写差量：公式计算出的反写量  - 上一次保存已执行的反写量；如果是删除行，反冲历史量

**方法签名：**
```java
public BigDecimal getCurrVal()
```

**返回值：**
- `BigDecimal`

---

### getRealVal

本次操作执行完毕完后，对源单行的反写总量；如果是删除行，反写总量 = 0；

**方法签名：**
```java
public BigDecimal getRealVal()
```

**返回值：**
- `BigDecimal`

---

### getRule

反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getRuleItem

反写公式

**方法签名：**
```java
public WriteBackFormula getRuleItem()
```

**返回值：**
- `WriteBackFormula`

---

### getSrcActiveRow

上游源单，关联主实体数据行

**方法签名：**
```java
public DynamicObject getSrcActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getSrcEntity

上游源单，关联主实体

**方法签名：**
```java
public EntityType getSrcEntity()
```

**返回值：**
- `EntityType`

---

### getSrcFieldKey

上游源单反写字段

**方法签名：**
```java
public String getSrcFieldKey()
```

**返回值：**
- `String`

---

### getSrcSubMainType

上游源单主实体，仅包含需要用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---

### getTargetActiveRow

下游目标单关联主实体，当前数据行；删除行时，这个属性可能没值

**方法签名：**
```java
public DynamicObject getTargetActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getTargetEntity

下游目标单关联主实体

**方法签名：**
```java
public EntityType getTargetEntity()
```

**返回值：**
- `EntityType`

---

### getTargetRowId

下游目标单关联行信息：删除操作，可以据此从数据库取到删除前的行数据

**方法签名：**
```java
public BFRowId getTargetRowId()
```

**返回值：**
- `BFRowId`

---

### setTargetRowId

设置下游目标单关联行

**方法签名：**
```java
public void setTargetRowId(BFRowId targetRowId)
```

**参数说明：**
- `targetRowId`: `BFRowId` — 目标单关联行

---
