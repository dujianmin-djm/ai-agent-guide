---
framework_version: "8.0.1"
api_class: "AfterExcessCheckEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用对源单行反写执行完毕时"
---

# AfterExcessCheckEventArgs API 说明

## 概述
对源单行反写执行完毕，超额检查完毕后，触发此事件：用于控制是否中止反写、提示超额，修正提示内容。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterExcessCheckEventArgs;
```

---

## 方法列表

### getMessage

超额提示

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getRule

反写规则

**方法签名：**
```java
public WriteBackRuleElement getRule()
```

**返回值：**
- `WriteBackRuleElement`

---

### getSrcActiveRow

上游源单，关联主实体数据行

**方法签名：**
```java
public DynamicObject getSrcActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getSrcEntity

上游源单，关联主实体

**方法签名：**
```java
public EntityType getSrcEntity()
```

**返回值：**
- `EntityType`

---

### getSrcSubMainType

上游源单主实体，仅包含需要用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---

### getTargetActiveRow

下游目标单关联主实体，当前数据行；删除行时，这个属性可能没值

**方法签名：**
```java
public DynamicObject getTargetActiveRow()
```

**返回值：**
- `DynamicObject`

---

### getTargetEntity

下游目标单关联主实体

**方法签名：**
```java
public EntityType getTargetEntity()
```

**返回值：**
- `EntityType`

---

### isExcess

是否超额；插件可以调整此属性值，决定是否显示超额提示

**方法签名：**
```java
public boolean isExcess()
```

**返回值：**
- `boolean`

---

### setExcess

设置是否超额

**方法签名：**
```java
public void setExcess(boolean excess)
```

**参数说明：**
- `excess`: `boolean` — 是否超额

---

### setMessage

设置超额提示

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String` — 超额提示

---
