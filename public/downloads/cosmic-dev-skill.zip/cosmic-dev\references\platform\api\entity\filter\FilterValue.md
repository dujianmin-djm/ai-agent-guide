---
framework_version: "8.0.1"
api_class: "FilterValue"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤值对象时"
---

# FilterValue API 说明

## 概述
过滤值对象。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.FilterValue;
```

---

## 方法列表

### getId

获取主键，元数据差量化使用

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 主键

---

### getValue

获取过滤值，一般是一个数组

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`: 过滤值

---

### setId

设置主键

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 主键

---

### setValue

设置过滤值

**方法签名：**
```java
public void setValue(Object value)
```

**参数说明：**
- `value`: `Object` — 过滤值

---
