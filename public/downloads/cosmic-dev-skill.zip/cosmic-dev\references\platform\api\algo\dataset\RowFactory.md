---
framework_version: "8.0.1"
api_class: "RowFactory"
api_package: "kd.bos.algo.dataset"
when_to_use: "当你需要使用 RowFactory 相关功能时"
---

# RowFactory API 说明

## 概述
RowFactory 类。
主要功能：创建对象。

## Import 路径
```java
import kd.bos.algo.dataset.RowFactory;
```

---

## 方法列表

### convert

将数组值根据元数据信息进行类型转换

**方法签名：**
```java
public static void convert(RowMeta rowMeta, Object[] values)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据
- `values`: `Object[]` — 数组值

---

### createNewMetaRow

将innerRow根据元数据信息进行类型转换后生成新的行数据

**方法签名：**
```java
public static Row createNewMetaRow(RowMeta rowMeta, Row innerRow)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 新的元数据
- `innerRow`: `Row` — 旧的行数据

**返回值：**
- `Row`: 新的行数据

---

### createPersistedRow

创建行数据

**方法签名：**
```java
public static PersistedRow createPersistedRow(RowMeta rowMeta, Object[] values, boolean needConvert)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据信息
- `values`: `Object[]` — 转为行的数组值
- `needConvert`: `boolean` — 是否需要进行类型转换

**返回值：**
- `PersistedRow`

---

### createRow

**重载 1**

创建行数据

**方法签名：**
```java
public static Row createRow(RowMeta rowMeta, Object[] values)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据
- `values`: `Object[]` — 转为行的数组值

**返回值：**
- `Row`: 行数据

---

**重载 2**

创建行数据

**方法签名：**
```java
public static Row createRow(RowMeta rowMeta, Object[] values, boolean needConvert)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据信息
- `values`: `Object[]` — 转为行的数组值
- `needConvert`: `boolean` — 是否需要进行类型转换

**返回值：**
- `Row`

---

**重载 3**

根据数据库结果集创建行数据

**方法签名：**
```java
public static Row createRow(RowMeta rowMeta, ResultSet rs)
```

**参数说明：**
- `rowMeta`: `RowMeta` — 元数据信息
- `rs`: `ResultSet` — 数据库结果集

**返回值：**
- `Row`: 行数据

---
