---
framework_version: "8.0.1"
api_class: "AbstractBillWebApiPlugin"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用单据-自定义WebApi服务插件基类时"
---

# AbstractBillWebApiPlugin API 说明

## 概述
单据-自定义WebApi服务插件基类。实现 IBillWebApiPlugin。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.bill.AbstractBillWebApiPlugin;
```

---

## 方法列表

### getFormId

获取单据标识

**方法签名：**
```java
public String getFormId()
```

**返回值：**
- `String`: 返回单据标识，如"bd_currency"

---

### setFormId

设置单据标识

**方法签名：**
```java
public void setFormId(String formId)
```

**参数说明：**
- `formId`: `String` — 单据标识，如"bd_currency"

---
