---
framework_version: "8.0.1"
api_class: "AppMetadataCache"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用应用元数据服务类,用于获取应用元数据的信息时"
---

# AppMetadataCache API 说明

## 概述
应用元数据服务类,用于获取应用元数据的信息。
主要功能：读取属性、移除元素、设置属性。

## Import 路径
```java
import kd.bos.entity.AppMetadataCache;
```

---

## 方法列表

### getAllAppInfo

取所有应用运行时元数据

**方法签名：**
```java
public static Map<String,AppInfo> getAllAppInfo()
```

**返回值：**
- `Map<String,AppInfo>`: 应用元数据map(应用编码,应用对象)

---

### getAllAppMenus

获取所有应用的菜单信息

**方法签名：**
```java
public static Map<String,List<kd.AppMenuInfo>> getAllAppMenus()
```

**返回值：**
- `Map<String,List<kd.AppMenuInfo>>`: 获取所有应用的菜单信息

---

### getAppInfo

同步查询应用信息，异步查询应用菜单信息

**方法签名：**
```java
public static AppInfo getAppInfo(String appId)
```

**参数说明：**
- `appId`: `String` — 应用id， 类似2deb950100005dac， 不是编码

**返回值：**
- `AppInfo`: AppInfo 应用信息

---

### getAppInfoByNumber

根据应用编码获取应用信息

**方法签名：**
```java
public static AppInfo getAppInfoByNumber(String number)
```

**参数说明：**
- `number`: `String` — 应用编码

**返回值：**
- `AppInfo`: AppInfo

---

### getAppMenuInfo

根据应用 id 与 菜单 id 获取菜单信息

**方法签名：**
```java
public static AppMenuInfo getAppMenuInfo(String appId, String menuId)
```

**参数说明：**
- `appId`: `String` — 应用 id
- `menuId`: `String` — 菜单 id

**返回值：**
- `AppMenuInfo`: 菜单信息

---

### getAppMenuInfoByAppNumAndMenuId

根据应用编码和菜单id，获取指定菜单信息

**方法签名：**
```java
public static AppMenuInfo getAppMenuInfoByAppNumAndMenuId(String appNum, String menuId)
```

**参数说明：**
- `appNum`: `String` — 应用编码
- `menuId`: `String` — 菜单id

**返回值：**
- `AppMenuInfo`: 应用菜单对象

---

### getAppMenusInfoByAppId

根据应用编码，获取应用的全部菜单信息

**方法签名：**
```java
public static List<kd.AppMenuInfo> getAppMenusInfoByAppId(String appId)
```

**参数说明：**
- `appId`: `String`

**返回值：**
- `List<kd.AppMenuInfo>`

---

### getAppMenusInfoByAppNum

根据应用编码，获取应用菜单信息

**方法签名：**
```java
public static List<kd.AppMenuInfo> getAppMenusInfoByAppNum(String appNum)
```

**参数说明：**
- `appNum`: `String` — 应用编码

**返回值：**
- `List<kd.AppMenuInfo>`: 应用菜单对象列表

---

### getAppNumberById

根据应用 id 获取应用编码

**方法签名：**
```java
public static String getAppNumberById(String id)
```

**参数说明：**
- `id`: `String` — 应用 id

**返回值：**
- `String`: 应用编码

---

### getAppNumbers

取应用Map

**方法签名：**
```java
public static Map<String,String> getAppNumbers()
```

**返回值：**
- `Map<String,String>`

---

### getProvider

{待补充}

**方法签名：**
```java
public static IEntityMetaDataProvider getProvider()
```

**返回值：**
- `IEntityMetaDataProvider`: DataProvider

---

### getVisibleAndEnableAppInfos

取所有应用运行时元数据

**方法签名：**
```java
public static Map<String,AppInfo> getVisibleAndEnableAppInfos()
```

**返回值：**
- `Map<String,AppInfo>`

---

### removeAppmetaLocalCache

**重载 1**

删除应用的本地缓存

**方法签名：**
```java
public static void removeAppmetaLocalCache(String appId)
```

**参数说明：**
- `appId`: `String`

---

**重载 2**

批量删除指定的应用本地缓存

**方法签名：**
```java
public static void removeAppmetaLocalCache(String[] appIds)
```

**参数说明：**
- `appIds`: `String[]`

---

### removeCache

清理应用缓存

**方法签名：**
```java
public static void removeCache()
```

---

### setProvider

设置实体元数据 provider

**方法签名：**
```java
public static void setProvider(IEntityMetaDataProvider pro)
```

**参数说明：**
- `pro`: `IEntityMetaDataProvider`

---
