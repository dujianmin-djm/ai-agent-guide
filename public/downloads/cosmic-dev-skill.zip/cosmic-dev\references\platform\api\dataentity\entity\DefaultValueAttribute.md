---
framework_version: "8.0.1"
api_class: "DefaultValueAttribute"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用标注属性的默认值时"
---

# DefaultValueAttribute API 说明

## 概述
标注属性的默认值。实现 Annotation。
主要功能：返回/设置属性的默认值。

## Import 路径
```java
import kd.bos.dataentity.entity.DefaultValueAttribute;
```

---

## 方法列表

### value

返回/设置属性的默认值

**方法签名：**
```java
public String value()
```

**返回值：**
- `String`

---
