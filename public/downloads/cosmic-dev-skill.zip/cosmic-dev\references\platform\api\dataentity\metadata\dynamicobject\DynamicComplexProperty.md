---
framework_version: "8.0.1"
api_class: "DynamicComplexProperty"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用动态实体复杂属性 复杂属性指向另外一个实体类型的引用时"
---

# DynamicComplexProperty API 说明

## 概述
动态实体复杂属性 复杂属性指向另外一个实体类型的引用，以一个字段保存一个整体段信息。。继承自 DynamicProperty，实现 IComplexProperty, Serializable, IDataEntityProperty, IMetadata, Cloneable。
主要功能：读取属性、设置属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicComplexProperty;
```

---

## 方法列表

### buildPlainStrMap

{待补充}

**方法签名：**
```java
public Map<String,Object> buildPlainStrMap()
```

**返回值：**
- `Map<String,Object>`

---

### clone

{待补充}

**方法签名：**
```java
public Object clone()
```

**返回值：**
- `Object`

---

### createHashCode

根据元数据创建HashCode

**方法签名：**
```java
public int createHashCode()
```

**返回值：**
- `int`

---

### getComplexType

{待补充}

**方法签名：**
```java
public IDataEntityType getComplexType()
```

**返回值：**
- `IDataEntityType`

---

### getDynamicComplexPropertyType

返回复杂属性的属性返回类型

**方法签名：**
```java
public DynamicObjectType getDynamicComplexPropertyType()
```

**返回值：**
- `DynamicObjectType`

---

### getRefIdPropName

{待补充}

**方法签名：**
```java
public String getRefIdPropName()
```

**返回值：**
- `String`

---

### getTableGroup

{待补充}

**方法签名：**
```java
public String getTableGroup()
```

**返回值：**
- `String`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### loadValue

{待补充}

**方法签名：**
```java
public void loadValue(Object dataEntity, Object value)
```

**参数说明：**
- `dataEntity`: `Object`
- `value`: `Object`

---

### setComplexType

设置复杂属性的元数据类型

**方法签名：**
```java
public void setComplexType(IDataEntityType dynamicObjectType)
```

**参数说明：**
- `dynamicObjectType`: `IDataEntityType`

---

### setRefIdPropName

设置复杂属性隐藏Id属性名

**方法签名：**
```java
public void setRefIdPropName(String name)
```

**参数说明：**
- `name`: `String`

---

### setTableGroup

设置拆分表名

**方法签名：**
```java
public void setTableGroup(String tableGroup)
```

**参数说明：**
- `tableGroup`: `String`

---
