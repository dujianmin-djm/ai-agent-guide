---
framework_version: "8.0.1"
api_class: "SummaryResult"
api_package: "kd.bos.entity.list"
when_to_use: "当你需要使用汇总集合对象时"
---

# SummaryResult API 说明

## 概述
汇总集合对象。实现 Serializable。
主要功能：读取属性、设置属性、添加元素。

## Import 路径
```java
import kd.bos.entity.list.SummaryResult;
```

---

## 方法列表

### addResult

获取累加值

**方法签名：**
```java
public void addResult(BigDecimal result)
```

**参数说明：**
- `result`: `BigDecimal` — 需要累加的值

---

### getFieldName

获取合计字段名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`: 字段名

---

### getNumberPrecision

获取精度类型

**方法签名：**
```java
public NumberPrecision getNumberPrecision()
```

**返回值：**
- `NumberPrecision`: 精度类型

---

### getSummary

获取汇总类型: 0：无，1:合计 2：平均值 3:最大值,4:最小值,5：计数

**方法签名：**
```java
public int getSummary()
```

**返回值：**
- `int`: 汇总类型: 0：无，1:合计 2：平均值 3:最大值,4:最小值,5：计数

---

### setFieldName

设置合计字段名

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String` — 字段名

---

### setNumberPrecision

设置精度类型

**方法签名：**
```java
public void setNumberPrecision(NumberPrecision numberPrecision)
```

**参数说明：**
- `numberPrecision`: `NumberPrecision` — 精度类型

---

### setSummary

设置合计类型

**方法签名：**
```java
public void setSummary(int summary)
```

**参数说明：**
- `summary`: `int` — 合计类型

---

### toFmtString

获取格式化字符串

**方法签名：**
```java
public String toFmtString()
```

**返回值：**
- `String`: 格式化字符串

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
