---
framework_version: "8.0.1"
api_class: "CtsyBillShowParameter"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用多租户协同单据打开参数时"
---

# CtsyBillShowParameter API 说明

## 概述
多租户协同单据打开参数。继承自 BillShowParameter，实现 ICtsyShowParameter, Serializable。
主要功能：读取属性、设置属性、创建对象、状态判断。

## Import 路径
```java
import kd.bos.bill.CtsyBillShowParameter;
```

---

## 方法列表

### createClientConfig

{待补充}

**方法签名：**
```java
public Map<String,Object> createClientConfig(Map<String,Object> setting)
```

**参数说明：**
- `setting`: `Map<String,Object>`

**返回值：**
- `Map<String,Object>`

---

### getAccountId

获取远程租户数据中心id

**方法签名：**
```java
public String getAccountId()
```

**返回值：**
- `String`

---

### getCloseCallBackActionIdSuffix

获取关闭回调actionId的固定后缀缀，后面业务可在前面加自定义的actionId，已用"$"分隔

**方法签名：**
```java
public String getCloseCallBackActionIdSuffix()
```

**返回值：**
- `String`

---

### getTenantCode

获取远程租户编码

**方法签名：**
```java
public String getTenantCode()
```

**返回值：**
- `String`

---

### isRuntimeMetaChanged

{待补充}

**方法签名：**
```java
public boolean isRuntimeMetaChanged()
```

**返回值：**
- `boolean`

---

### setAccountId

设置远程租户数据中心id

**方法签名：**
```java
public void setAccountId(String accountId)
```

**参数说明：**
- `accountId`: `String`

---

### setTenantCode

设置远程租户编码

**方法签名：**
```java
public void setTenantCode(String tenantCode)
```

**参数说明：**
- `tenantCode`: `String`

---
