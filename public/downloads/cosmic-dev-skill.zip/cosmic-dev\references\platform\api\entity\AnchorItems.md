---
framework_version: "8.0.1"
api_class: "AnchorItems"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用锚点数据集合时"
---

# AnchorItems API 说明

## 概述
锚点数据集合。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.AnchorItems;
```

---

## 方法列表

### getBadge

获取徽标

**方法签名：**
```java
public BadgeInfo getBadge()
```

**返回值：**
- `BadgeInfo`: 徽标

---

### getCaption

获取锚点名称

**方法签名：**
```java
public String getCaption()
```

**返回值：**
- `String`

---

### getItems

获取下级锚点（总共只有2级, 下级锚点没有items属性）

**方法签名：**
```java
public List<kd.AnchorItems> getItems()
```

**返回值：**
- `List<kd.AnchorItems>`

---

### getTarget

获取目标id

**方法签名：**
```java
public String getTarget()
```

**返回值：**
- `String`

---

### setBadge

设置徽标

**方法签名：**
```java
public void setBadge(BadgeInfo badge)
```

**参数说明：**
- `badge`: `BadgeInfo` — 徽标

---

### setCaption

设置锚点名称

**方法签名：**
```java
public void setCaption(String caption)
```

**参数说明：**
- `caption`: `String`

---

### setItems

设置下级锚点（总共只有2级, 下级锚点没有items属性）

**方法签名：**
```java
public void setItems(List<kd.AnchorItems> items)
```

**参数说明：**
- `items`: `List<kd.AnchorItems>`

---

### setTarget

设置目标id

**方法签名：**
```java
public void setTarget(String target)
```

**参数说明：**
- `target`: `String`

---
