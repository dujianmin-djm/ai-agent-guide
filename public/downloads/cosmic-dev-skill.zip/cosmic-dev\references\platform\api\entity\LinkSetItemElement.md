---
framework_version: "8.0.1"
api_class: "LinkSetItemElement"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用BOTP关联子实体定义(即LK实体)时"
---

# LinkSetItemElement API 说明

## 概述
BOTP关联子实体定义(即LK实体)。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.LinkSetItemElement;
```

---

## 方法列表

### getCtrlFldKeys

控制字段，如果有多个控制字段，使用逗号隔开；

**方法签名：**
```java
public String getCtrlFldKeys()
```

**返回值：**
- `String`

---

### getLinkEntityKey

关联子实体Key，即LK实体标识

**方法签名：**
```java
public String getLinkEntityKey()
```

**返回值：**
- `String`

---

### getParentEntityKey

父实体Key，如单据体，关联子实体数据用于记录父实体每条数据的BOTP来源

**方法签名：**
```java
public String getParentEntityKey()
```

**返回值：**
- `String`

---

### getTableName

关联子实体的物理表格

**方法签名：**
```java
public String getTableName()
```

**返回值：**
- `String`

---

### setCtrlFldKeys

设置控制字段，如果有多个控制字段，使用逗号隔开；

**方法签名：**
```java
public void setCtrlFldKeys(String ctrlFldKeys)
```

**参数说明：**
- `ctrlFldKeys`: `String`

---

### setLinkEntityKey

设置关联子实体Key，即LK实体标识

**方法签名：**
```java
public void setLinkEntityKey(String linkEntityKey)
```

**参数说明：**
- `linkEntityKey`: `String`

---

### setParentEntityKey

设置父实体Key，如单据体，关联子实体数据用于记录父实体每条数据的BOTP来源

**方法签名：**
```java
public void setParentEntityKey(String parentEntityKey)
```

**参数说明：**
- `parentEntityKey`: `String`

---

### setTableName

设置关联子实体的物理表格

**方法签名：**
```java
public void setTableName(String tableName)
```

**参数说明：**
- `tableName`: `String`

---

### splitCtrlFldKeys

对控制字段字符串进行拆分，分成多个独立的字段标识

**方法签名：**
```java
public HashSet<String> splitCtrlFldKeys()
```

**返回值：**
- `HashSet<String>`

---
