---
framework_version: "8.0.1"
api_class: "AbstractAsyncOpBizRuleAction"
api_package: "kd.bos.entity.operate.bizrule.asyncbizrule"
when_to_use: "当你需要使用 AbstractAsyncOpBizRuleAction 相关功能时"
---

# AbstractAsyncOpBizRuleAction API 说明

## 概述
AbstractAsyncOpBizRuleAction 类。继承自 AbstractOpBizRuleAction，实现 IOperationServicePlugIn, IOperationService。
主要功能：事件处理、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.bizrule.asyncbizrule.AbstractAsyncOpBizRuleAction;
```

---

## 方法列表

### afterExecuteOperationTransaction

{待补充}

**方法签名：**
```java
public void afterExecuteOperationTransaction(AfterOperationArgs e)
```

**参数说明：**
- `e`: `AfterOperationArgs`

---

### beforeExecuteOperationTransaction

{待补充}

**方法签名：**
```java
public void beforeExecuteOperationTransaction(BeforeOperationArgs e)
```

**参数说明：**
- `e`: `BeforeOperationArgs`

---

### beginOperationTransaction

{待补充}

**方法签名：**
```java
public void beginOperationTransaction(BeginOperationTransactionArgs e)
```

**参数说明：**
- `e`: `BeginOperationTransactionArgs`

---

### onPreparePropertys

{待补充}

**方法签名：**
```java
public void onPreparePropertys(PreparePropertysEventArgs e)
```

**参数说明：**
- `e`: `PreparePropertysEventArgs`

---

### setMServiceParam

{待补充}

**方法签名：**
```java
public abstract void setMServiceParam(AsyncOpBizRuleServiceMsgInfo serviceMessageInfo, DynamicObject[] datas)
```

**参数说明：**
- `serviceMessageInfo`: `AsyncOpBizRuleServiceMsgInfo` — 消息对象
- `datas`: `DynamicObject[]` — 单据信息

---
