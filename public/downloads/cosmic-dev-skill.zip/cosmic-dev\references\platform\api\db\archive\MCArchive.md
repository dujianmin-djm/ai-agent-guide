---
framework_version: "8.0.1"
api_class: "MCArchive"
api_package: "kd.bos.db.archive"
when_to_use: "当你需要使用单据归档路由获取时"
---

# MCArchive API 说明

## 概述
单据归档路由获取。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.db.archive.MCArchive;
```

---

## 方法列表

### get

API：根据单据所属路由与单据编码获取单据归档路由

**方法签名：**
```java
public static RouteInfo get(String routeKey, String entityNumber)
```

**参数说明：**
- `routeKey`: `String`
- `entityNumber`: `String`

**返回值：**
- `RouteInfo`

---
