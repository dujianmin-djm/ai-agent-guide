---
framework_version: "8.0.1"
api_class: "FieldMapItem"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用字段映射配置时"
---

# FieldMapItem API 说明

## 概述
字段映射配置。
主要功能：读取属性、状态判断、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.FieldMapItem;
```

---

## 方法列表

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### check

检查配置是否合理

**方法签名：**
```java
public void check(MainEntityType srcMainType, MainEntityType tgtMainType, ConvertRuleElement rule, CheckPoint parentPoint, CheckResult checkResult, Map<String,Boolean> fieldMap)
```

**参数说明：**
- `srcMainType`: `MainEntityType`
- `tgtMainType`: `MainEntityType`
- `rule`: `ConvertRuleElement`
- `parentPoint`: `CheckPoint`
- `checkResult`: `CheckResult`
- `fieldMap`: `Map<String,Boolean>`

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### getConstant

按常量取值
 去常量Id，支持基础资料与下拉列表

**方法签名：**
```java
public CRFormula getConstant()
```

**返回值：**
- `CRFormula`

---

### getConvertType

输出字段取值模式的名称，用于序列化

**方法签名：**
```java
public String getConvertType()
```

**返回值：**
- `String`

---

### getConvertType2

输出(字段取值模式+取值公式hashCode)合并成的字符串，由序列化自动调用

**方法签名：**
```java
public String getConvertType2()
```

**返回值：**
- `String`

---

### getFieldConvertType

字段取值模式：取源单字段、取计算公式、按条件取值

**方法签名：**
```java
public FieldConvertType getFieldConvertType()
```

**返回值：**
- `FieldConvertType`

---

### getFieldSumType

多行合并时，字段值合并模式：取第一行，合计、平均、计数、最大、最小、拼接

**方法签名：**
```java
public FieldSumType getFieldSumType()
```

**返回值：**
- `FieldSumType`

---

### getFormula

计算公式

**方法签名：**
```java
public CRFormula getFormula()
```

**返回值：**
- `CRFormula`

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getSourceFieldKey

源单字段标识

**方法签名：**
```java
public String getSourceFieldKey()
```

**返回值：**
- `String`: :

---

### getSumType

字段值合并模式，用于序列化

**方法签名：**
```java
public String getSumType()
```

**返回值：**
- `String`

---

### getTargetFieldKey

目标字段

**方法签名：**
```java
public String getTargetFieldKey()
```

**返回值：**
- `String`

---

### getValByCondiionsString

输出按条件取数设置的整体json字符串

**方法签名：**
```java
public String getValByCondiionsString()
```

**返回值：**
- `String`

---

### getValByConditions

按条件取值

**方法签名：**
```java
public CRValByConditions getValByConditions()
```

**返回值：**
- `CRValByConditions`

---

### isBreakForNoDistribute

如果目标组织没有分配此基础资料，是否中断下推过程？

**方法签名：**
```java
public boolean isBreakForNoDistribute()
```

**返回值：**
- `boolean`

---

### isDrawAgainFilter

追加选单时，是否按此字段过滤数据，即不允许追加选择上一次所选之外的数据

**方法签名：**
```java
public boolean isDrawAgainFilter()
```

**返回值：**
- `boolean`

---

### isDrawFilter

选单时，是否按此字段过滤数据

**方法签名：**
```java
public boolean isDrawFilter()
```

**返回值：**
- `boolean`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### isOnlyTakeApprovedData

是否仅携带已审核的数据

**方法签名：**
```java
public boolean isOnlyTakeApprovedData()
```

**返回值：**
- `boolean`

---

### isOnlyTakeUsedData

是否仅携带未禁用的数据

**方法签名：**
```java
public boolean isOnlyTakeUsedData()
```

**返回值：**
- `boolean`

---

### isValid

判断字段映射配置是否完整有效：无效的规则，不能在运行时被使用
 判断标准：取值模式和取值公式一致

**方法签名：**
```java
public boolean isValid()
```

**返回值：**
- `boolean`

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
