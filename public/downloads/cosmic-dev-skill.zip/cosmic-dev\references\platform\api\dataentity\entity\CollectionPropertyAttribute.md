---
framework_version: "8.0.1"
api_class: "CollectionPropertyAttribute"
api_package: "kd.bos.dataentity.entity"
when_to_use: "当你需要使用标注实体类的集合属性时"
---

# CollectionPropertyAttribute API 说明

## 概述
标注实体类的集合属性。实现 Annotation。
主要功能：界面显示。

## Import 路径
```java
import kd.bos.dataentity.entity.CollectionPropertyAttribute;
```

---

## 方法列表

### collectionItemPropertyType

返回/设置明细的数据类型，如果集合是泛型，可以不指定

**方法签名：**
```java
public Class collectionItemPropertyType()
```

**返回值：**
- `Class`

---

### displayName

返回/设置元数据的显示名称，例如列的中文名称

**方法签名：**
```java
public String displayName()
```

**返回值：**
- `String`

---

### name

返回/设置属性名称

**方法签名：**
```java
public String name()
```

**返回值：**
- `String`: 属性名称

---
