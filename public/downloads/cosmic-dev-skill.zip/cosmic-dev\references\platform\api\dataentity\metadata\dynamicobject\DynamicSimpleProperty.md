---
framework_version: "8.0.1"
api_class: "DynamicSimpleProperty"
api_package: "kd.bos.dataentity.metadata.dynamicobject"
when_to_use: "当你需要使用简单属性时"
---

# DynamicSimpleProperty API 说明

## 概述
简单属性，此属性参与ORM的处理 简单属性对应数据库中最基本的类型,包括(整型、字符、浮点型、日期等)。继承自 DynamicProperty，实现 ISimpleProperty, Serializable, IDataEntityProperty, IMetadata, Cloneable。
主要功能：设置属性、状态判断、读取属性。

## Import 路径
```java
import kd.bos.dataentity.metadata.dynamicobject.DynamicSimpleProperty;
```

---

## 方法列表

### getDbType

{待补充}

**方法签名：**
```java
public int getDbType()
```

**返回值：**
- `int`

---

### getPrivacyType

获取隐私类型

**方法签名：**
```java
public long getPrivacyType()
```

**返回值：**
- `long`

---

### getTableGroup

{待补充}

**方法签名：**
```java
public String getTableGroup()
```

**返回值：**
- `String`

---

### isEmpty

{待补充}

**方法签名：**
```java
public boolean isEmpty(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### isEnableNull

是否允许存储null

**方法签名：**
```java
public boolean isEnableNull()
```

**返回值：**
- `boolean`

---

### isEncrypt

{待补充}

**方法签名：**
```java
public boolean isEncrypt()
```

**返回值：**
- `boolean`

---

### isLocalizable

{待补充}

**方法签名：**
```java
public boolean isLocalizable()
```

**返回值：**
- `boolean`

---

### isPrimaryKey

{待补充}

**方法签名：**
```java
public boolean isPrimaryKey()
```

**返回值：**
- `boolean`

---

### setDbType

设置数据类型

**方法签名：**
```java
public void setDbType(int dbType)
```

**参数说明：**
- `dbType`: `int`

---

### setDirty

{待补充}

**方法签名：**
```java
public void setDirty(Object dataEntity, boolean newValue)
```

**参数说明：**
- `dataEntity`: `Object`
- `newValue`: `boolean`

---

### setEnableNull

设置是否允许存储null

**方法签名：**
```java
public void setEnableNull(boolean enableNull)
```

**参数说明：**
- `enableNull`: `boolean`

---

### setEncrypt

设置是否加密

**方法签名：**
```java
public void setEncrypt(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setPrimaryKey

设置是否为主键

**方法签名：**
```java
public void setPrimaryKey(boolean value)
```

**参数说明：**
- `value`: `boolean`

---

### setTableGroup

设置拆分表名

**方法签名：**
```java
public void setTableGroup(String tableGroup)
```

**参数说明：**
- `tableGroup`: `String`

---

### shouldSerializeValue

{待补充}

**方法签名：**
```java
public boolean shouldSerializeValue(Object dataEntity)
```

**参数说明：**
- `dataEntity`: `Object`

**返回值：**
- `boolean`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
