---
framework_version: "8.0.1"
api_class: "OperationArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用单据操作插件事件参数基类时"
---

# OperationArgs API 说明

## 概述
单据操作插件事件参数基类。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.OperationArgs;
```

---

## 方法列表

### getOperationKey

返回当前操作的标识

**方法签名：**
```java
public String getOperationKey()
```

**返回值：**
- `String`: 操作标识

---
