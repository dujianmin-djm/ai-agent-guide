---
framework_version: "8.0.1"
api_class: "GroupReduceFunction"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用reduce操作回调函数时"
---

# GroupReduceFunction API 说明

## 概述
reduce操作回调函数。继承自 Function，实现 ResultAwarable, ResultConvertable, Serializable。
主要功能：reduce。

## Import 路径
```java
import kd.bos.algox.GroupReduceFunction;
```

---

## 方法列表

### reduce

reduce

**方法签名：**
```java
public abstract void reduce(Iterable<kd.RowX> iter, Collector collector)
```

**参数说明：**
- `iter`: `Iterable<kd.RowX>` — 分组后的数据集
- `collector`: `Collector` — collector

---
