---
framework_version: "8.0.1"
api_class: "UserConfig"
api_package: "kd.bos.entity.userconfig"
when_to_use: "当你需要使用用户自定义数据配置表映射类时"
---

# UserConfig API 说明

## 概述
用户自定义数据配置表映射类。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.userconfig.UserConfig;
```

---

## 方法列表

### getDataEntityState

获取ORM状态管理

**方法签名：**
```java
public DataEntityState getDataEntityState()
```

**返回值：**
- `DataEntityState`: 状态管理

---

### getId

获取主键

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 主键

---

### getKey

获取用户配置检索字段

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`: 用户配置检索字段

---

### getSetting

获取用户配置

**方法签名：**
```java
public String getSetting()
```

**返回值：**
- `String`: 用户配置

---

### getUserId

获取用户标识

**方法签名：**
```java
public long getUserId()
```

**返回值：**
- `long`: 用户标识

---

### setDataEntityState

设置ORM状态管理

**方法签名：**
```java
public void setDataEntityState(DataEntityState dataEntityState)
```

**参数说明：**
- `dataEntityState`: `DataEntityState` — 状态管理

---

### setId

设置主键

**方法签名：**
```java
public void setId(String id)
```

**参数说明：**
- `id`: `String` — 主键

---

### setKey

设置用户配置检索字段

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String` — 用户配置检索字段

---

### setSetting

设置用户配置

**方法签名：**
```java
public void setSetting(String setting)
```

**参数说明：**
- `setting`: `String` — 用户配置

---

### setUserId

设置用户标识

**方法签名：**
```java
public void setUserId(long userId)
```

**参数说明：**
- `userId`: `long` — 用户标识

---
