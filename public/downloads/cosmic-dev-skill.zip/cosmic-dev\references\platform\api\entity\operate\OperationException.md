---
framework_version: "8.0.1"
api_class: "OperationException"
api_package: "kd.bos.entity.operate"
when_to_use: "当你需要使用操作异常    根据异常可以定位错误的数据时"
---

# OperationException API 说明

## 概述
操作异常    根据异常可以定位错误的数据。继承自 RuntimeException，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.OperationException;
```

---

## 方法列表

### getMessage

获取操作信息内容

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getPkValue

获取单据内码

**方法签名：**
```java
public Object getPkValue()
```

**返回值：**
- `Object`

---

### getTitle

获取操作信息标题（返回信息关键字列内容）

**方法签名：**
```java
public String getTitle()
```

**返回值：**
- `String`

---

### setMessage

设置操作信息内容

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String`

---

### setTitle

设置操作信息标题（返回信息关键字列内容）

**方法签名：**
```java
public void setTitle(String title)
```

**参数说明：**
- `title`: `String`

---
