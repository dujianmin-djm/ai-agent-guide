---
framework_version: "8.0.1"
api_class: "BillStatus"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用单据状态值时"
---

# BillStatus API 说明

## 概述
单据状态值。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.validate.BillStatus;
```

---

## 方法列表

### getValue

获取单据状态当前语种下的显示值

**方法签名：**
```java
public String getValue()
```

**返回值：**
- `String`: 当前语种显示值

---
