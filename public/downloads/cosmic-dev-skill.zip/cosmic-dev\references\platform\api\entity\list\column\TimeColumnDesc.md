---
framework_version: "8.0.1"
api_class: "TimeColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用时间格式化处理时"
---

# TimeColumnDesc API 说明

## 概述
时间格式化处理。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.list.column.TimeColumnDesc;
```

---

## 方法列表

### getDisplayFormatString

{待补充}

**方法签名：**
```java
public String getDisplayFormatString()
```

**返回值：**
- `String`

---

### getMask

{待补充}

**方法签名：**
```java
public String getMask()
```

**返回值：**
- `String`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---

### setDisplayFormatString

{待补充}

**方法签名：**
```java
public void setDisplayFormatString(String displayFormatString)
```

**参数说明：**
- `displayFormatString`: `String` — 设置格式化字符串

---

### setMask

{待补充}

**方法签名：**
```java
public void setMask(String mask)
```

**参数说明：**
- `mask`: `String` — 设置掩码

---
