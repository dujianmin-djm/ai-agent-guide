---
framework_version: "8.0.1"
api_class: "AbstractReportTreeDataPlugin"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表树构造插件时"
---

# AbstractReportTreeDataPlugin API 说明

## 概述
报表树构造插件。
主要功能：查询数据、设置属性。

## Import 路径
```java
import kd.bos.entity.report.AbstractReportTreeDataPlugin;
```

---

## 方法列表

### query

查询树节点数据

**方法签名：**
```java
public abstract List<TreeNode> query(ReportQueryParam queryParam, String nodeId)
```

**参数说明：**
- `queryParam`: `ReportQueryParam` — 查询参数
- `nodeId`: `String`

**返回值：**
- `List<TreeNode>`: 返回树控件一级节点集合，内含下级节点（树形结构）

---

### setProgress

设置进度

**方法签名：**
```java
public void setProgress(int percent)
```

**参数说明：**
- `percent`: `int`

---
