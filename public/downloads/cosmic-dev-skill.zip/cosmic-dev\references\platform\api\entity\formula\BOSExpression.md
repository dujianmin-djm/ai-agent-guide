---
framework_version: "8.0.1"
api_class: "BOSExpression"
api_package: "kd.bos.entity.formula"
when_to_use: "当你需要使用解析后的表达式时"
---

# BOSExpression API 说明

## 概述
解析后的表达式。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.formula.BOSExpression;
```

---

## 方法列表

### getErrMessage

解析出错原因

**方法签名：**
```java
public String getErrMessage()
```

**返回值：**
- `String`

---

### getExpr

解析后的表达式对象

**方法签名：**
```java
public Expr getExpr()
```

**返回值：**
- `Expr`

---

### getExpression

原始表达式

**方法签名：**
```java
public String getExpression()
```

**返回值：**
- `String`

---

### getFuncs

表达式中包含的函数

**方法签名：**
```java
public Set<String> getFuncs()
```

**返回值：**
- `Set<String>`

---

### getVars

表达式中包含的变量

**方法签名：**
```java
public Set<String> getVars()
```

**返回值：**
- `Set<String>`

---

### isError

解析过程有没有出错

**方法签名：**
```java
public boolean isError()
```

**返回值：**
- `boolean`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
