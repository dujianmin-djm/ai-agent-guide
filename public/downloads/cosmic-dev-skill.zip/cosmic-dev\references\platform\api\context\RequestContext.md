---
framework_version: "8.0.1"
api_class: "RequestContext"
api_package: "kd.bos.context"
when_to_use: "当你需要使用Request Context时"
---

# RequestContext API 说明

## 概述
Request Context，非SessionContext 包括： 请求相关:RequestInfo 会话相关:SessionInfo,。实现 Serializable。
主要功能：读取属性、设置属性、创建对象。

## Import 路径
```java
import kd.bos.context.RequestContext;
```

---

## 方法列表

### convertTenantURL

根据租户的code构建新的URL

**方法签名：**
```java
public String convertTenantURL(String url)
```

**参数说明：**
- `url`: `String`

**返回值：**
- `String`

---

### copy

增加全局属性时，请在此同步增加复制。
 
 注意使用场合 ：务必在新线程中调用本方法，用于自行启动线程设置上下文。

**方法签名：**
```java
public static RequestContext copy(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext`

**返回值：**
- `RequestContext`

---

### copyAndSet

拷贝并设置为当前线程上下文

**方法签名：**
```java
public static RequestContext copyAndSet(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext` — 上下文信息

**返回值：**
- `RequestContext`: 新的上下文信息

---

### create

**重载 1**

创建新的上下文信息

**方法签名：**
```java
public static RequestContext create()
```

**返回值：**
- `RequestContext`: 上下文信息

---

**重载 2**

创建上下文信息

**方法签名：**
```java
public static RequestContext create(boolean setCurrent)
```

**参数说明：**
- `setCurrent`: `boolean` — true-创建新的山下文
                   false-返回当前上下文

**返回值：**
- `RequestContext`: 上下文信息

---

### get

获取上下文信息

**方法签名：**
```java
public static RequestContext get()
```

**返回值：**
- `RequestContext`: 上下文信息

---

### getAccCompanyId

获取账套所属公司ID

**方法签名：**
```java
public String getAccCompanyId()
```

**返回值：**
- `String`

---

### getAccountId

获取账套ID

**方法签名：**
```java
public String getAccountId()
```

**返回值：**
- `String`

---

### getApi3rdAppId

获取第三方应用系统api访问应用id

**方法签名：**
```java
public String getApi3rdAppId()
```

**返回值：**
- `String`

---

### getBizPartnerId

获取第三方商务合作伙伴ID

**方法签名：**
```java
public Long getBizPartnerId()
```

**返回值：**
- `Long`

---

### getClient

获取请求的客户端类型

**方法签名：**
```java
public String getClient()
```

**返回值：**
- `String`

---

### getClientFullContextPath

获取客户端完整路径

**方法签名：**
```java
public String getClientFullContextPath()
```

**返回值：**
- `String`

---

### getClientUrl

设置客户端URL

**方法签名：**
```java
public String getClientUrl()
```

**返回值：**
- `String`

---

### getCurrUserId

获取当前用户ID

**方法签名：**
```java
public long getCurrUserId()
```

**返回值：**
- `long`

---

### getGlobalSessionId

获取当前sessionId

**方法签名：**
```java
public String getGlobalSessionId()
```

**返回值：**
- `String`

---

### getLang

获取当前语言

**方法签名：**
```java
public Lang getLang()
```

**返回值：**
- `Lang`

---

### getLoginIP

获取登陆IP

**方法签名：**
```java
public String getLoginIP()
```

**返回值：**
- `String`

---

### getLoginOrg

获取登陆组织

**方法签名：**
```java
public String getLoginOrg()
```

**返回值：**
- `String`

---

### getLoginTime

获取登陆时间

**方法签名：**
```java
public String getLoginTime()
```

**返回值：**
- `String`

---

### getOperationType

获取操作类型

**方法签名：**
```java
public String getOperationType()
```

**返回值：**
- `String`

---

### getOrCreate

获取或创建一个新的上下文

**方法签名：**
```java
public static RequestContext getOrCreate()
```

**返回值：**
- `RequestContext`: 上下文信息

---

### getOrgId

获取当前用户登录的组织内码

**方法签名：**
```java
public long getOrgId()
```

**返回值：**
- `long`

---

### getQueryString

获取查询参数

**方法签名：**
```java
public String getQueryString()
```

**返回值：**
- `String`

---

### getRequestId

获取上下文请求ID

**方法签名：**
```java
public String getRequestId()
```

**返回值：**
- `String`

---

### getSetStack

获取异常堆栈信息

**方法签名：**
```java
public static String getSetStack()
```

**返回值：**
- `String`

---

### getTenantCode

获取当前会话的租户别名

**方法签名：**
```java
public String getTenantCode()
```

**返回值：**
- `String`

---

### getTenantId

获取租户ID

**方法签名：**
```java
public String getTenantId()
```

**返回值：**
- `String`

---

### getTenantInfo

获取租户信息

**方法签名：**
```java
public TenantInfo getTenantInfo()
```

**返回值：**
- `TenantInfo`

---

### getTraceId

获取当前调用链跟踪信息ID

**方法签名：**
```java
public String getTraceId()
```

**返回值：**
- `String`

---

### getUserAgent

获取请求的客户端代理名称

**方法签名：**
```java
public String getUserAgent()
```

**返回值：**
- `String`

---

### getUserName

获取用户名

**方法签名：**
```java
public String getUserName()
```

**返回值：**
- `String`

---

### getUserOpenId

获取用户的openId

**方法签名：**
```java
public String getUserOpenId()
```

**返回值：**
- `String`

---

### getUserType

获取用户类型

**方法签名：**
```java
public String getUserType()
```

**返回值：**
- `String`

---

### getYzjAppId

获取云之家应用登录的AppId

**方法签名：**
```java
public String getYzjAppId()
```

**返回值：**
- `String`

---

### getYzjAppTicket

获取云之家应用登录的Ticket

**方法签名：**
```java
public String getYzjAppTicket()
```

**返回值：**
- `String`

---

### set

设置上下文信息

**方法签名：**
```java
public static void set(RequestContext rc)
```

**参数说明：**
- `rc`: `RequestContext`

---

### setAccCompanyId

设置账套所属公司ID

**方法签名：**
```java
public void setAccCompanyId(String accCompanyId)
```

**参数说明：**
- `accCompanyId`: `String`

---

### setAccountId

设置账套ID

**方法签名：**
```java
public void setAccountId(String accountId)
```

**参数说明：**
- `accountId`: `String`

---

### setApi3rdAppId

设置第三方应用系统api访问应用id

**方法签名：**
```java
public void setApi3rdAppId(String api3rdAppId)
```

**参数说明：**
- `api3rdAppId`: `String`

---

### setBizPartnerId

{待补充}

**方法签名：**
```java
public void setBizPartnerId(Long bizPartnerId)
```

**参数说明：**
- `bizPartnerId`: `Long`

---

### setClient

设置请求的客户端类型

**方法签名：**
```java
public void setClient(String client)
```

**参数说明：**
- `client`: `String`

---

### setClientFullContextPath

设置客户端路径

**方法签名：**
```java
public void setClientFullContextPath(String clientFullContextPath)
```

**参数说明：**
- `clientFullContextPath`: `String`

---

### setClientUrl

设置客户端URL

**方法签名：**
```java
public void setClientUrl(String clientUrl)
```

**参数说明：**
- `clientUrl`: `String`

---

### setGlobalSessionId

设置当前sessionId

**方法签名：**
```java
public void setGlobalSessionId(String globalSessionId)
```

**参数说明：**
- `globalSessionId`: `String`

---

### setLang

设置当前语言

**方法签名：**
```java
public void setLang(Lang lang)
```

**参数说明：**
- `lang`: `Lang`

---

### setLoginIP

设置登陆ID

**方法签名：**
```java
public void setLoginIP(String loginIP)
```

**参数说明：**
- `loginIP`: `String`

---

### setLoginOrg

设置登陆组织

**方法签名：**
```java
public void setLoginOrg(String loginOrg)
```

**参数说明：**
- `loginOrg`: `String`

---

### setLoginTime

设置登陆时间

**方法签名：**
```java
public void setLoginTime(String loginTime)
```

**参数说明：**
- `loginTime`: `String`

---

### setOperationType

设置操作类型

**方法签名：**
```java
public void setOperationType(String operationType)
```

**参数说明：**
- `operationType`: `String`

---

### setOrgId

设置当前用户登录的组织内码

**方法签名：**
```java
public void setOrgId(long orgid)
```

**参数说明：**
- `orgid`: `long`

---

### setQueryString

设置查询参数

**方法签名：**
```java
public void setQueryString(String queryString)
```

**参数说明：**
- `queryString`: `String`

---

### setRequestId

设置上下文请求ID

**方法签名：**
```java
public void setRequestId(String requestId)
```

**参数说明：**
- `requestId`: `String`

---

### setTenantCode

设置当前会话的租户别名

**方法签名：**
```java
public void setTenantCode(String tenantCode)
```

**参数说明：**
- `tenantCode`: `String`

---

### setTenantId

设置租户ID

**方法签名：**
```java
public void setTenantId(String tenantId)
```

**参数说明：**
- `tenantId`: `String`

---

### setTenantInfo

设置租户信息

**方法签名：**
```java
public void setTenantInfo(TenantInfo tenantInfo)
```

**参数说明：**
- `tenantInfo`: `TenantInfo`

---

### setTraceId

设置当前调用链跟踪信息ID

**方法签名：**
```java
public void setTraceId(String traceId)
```

**参数说明：**
- `traceId`: `String`

---

### setUserAgent

设置请求的客户端代理名称

**方法签名：**
```java
public void setUserAgent(String userAgent)
```

**参数说明：**
- `userAgent`: `String`

---

### setUserName

设置用户名

**方法签名：**
```java
public void setUserName(String userName)
```

**参数说明：**
- `userName`: `String`

---

### setUserOpenId

设置用户的openId

**方法签名：**
```java
public void setUserOpenId(String userOpenId)
```

**参数说明：**
- `userOpenId`: `String`

---

### setUserType

设置用户类型

**方法签名：**
```java
public void setUserType(String userType)
```

**参数说明：**
- `userType`: `String`

---

### setYzjAppId

设置云之家应用登录的AppId

**方法签名：**
```java
public void setYzjAppId(String yzjAppId)
```

**参数说明：**
- `yzjAppId`: `String`

---

### setYzjAppTicket

设置云之家应用登录的Ticket

**方法签名：**
```java
public void setYzjAppTicket(String yzjAppTicket)
```

**参数说明：**
- `yzjAppTicket`: `String`

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
