---
framework_version: "8.0.1"
api_class: "AbstractBillPlugIn"
api_package: "kd.bos.bill"
when_to_use: "当你需要使用单据视图层插件抽象基类时"
---

# AbstractBillPlugIn API 说明

## 概述
单据视图层插件抽象基类。继承自 AbstractFormPlugin，实现 IBillPlugin。
主要功能：其他操作。

## Import 路径
```java
import kd.bos.bill.AbstractBillPlugIn;
```

---

## 方法列表

### registerListener

监听控件事件
 
 在基类中默认监听工具栏的菜单项点击事件，插件重写此方法时注意别全部覆盖了

**方法签名：**
```java
public void registerListener(EventObject e)
```

**参数说明：**
- `e`: `EventObject`

---
