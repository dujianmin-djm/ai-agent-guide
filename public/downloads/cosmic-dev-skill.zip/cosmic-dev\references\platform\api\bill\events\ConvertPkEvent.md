---
framework_version: "8.0.1"
api_class: "ConvertPkEvent"
api_package: "kd.bos.bill.events"
when_to_use: "当你需要使用转换PK事件参数时"
---

# ConvertPkEvent API 说明

## 概述
转换PK事件参数。继承自 EventObject，实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.bill.events.ConvertPkEvent;
```

---

## 方法列表

### getDataObject

获取数据

**方法签名：**
```java
public Map<String,Object> getDataObject()
```

**返回值：**
- `Map<String,Object>`

---

### getOpNumber

获取操作编码

**方法签名：**
```java
public String getOpNumber()
```

**返回值：**
- `String`

---

### getPK

获取 pk 值

**方法签名：**
```java
public Object getPK()
```

**返回值：**
- `Object`

---

### setPK

设置 pk 值

**方法签名：**
```java
public void setPK(Object pk)
```

**参数说明：**
- `pk`: `Object`

---
