---
framework_version: "8.0.1"
api_class: "DataSetOutput"
api_package: "kd.bos.algo.output"
when_to_use: "当你需要使用将计算结果生成为Algo DataSet时"
---

# DataSetOutput API 说明

## 概述
将计算结果生成为Algo DataSet，任务运行结束后，可以通过JobSession#readDataSet获取到。。继承自 AbstractOutput。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.algo.output.DataSetOutput;
```

---

## 方法列表

### getId

获取id，用于从JobSession#readDataSet获取结果

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: id

---

### getRowMeta

获取元数据

**方法签名：**
```java
public RowMeta getRowMeta()
```

**返回值：**
- `RowMeta`: 元数据

---
