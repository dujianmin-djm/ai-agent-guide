---
framework_version: "8.0.1"
api_class: "FilterObject"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用过滤解析中间类时"
---

# FilterObject API 说明

## 概述
过滤解析中间类，过滤数据缓存，调用下级进行处理。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.FilterObject;
```

---

## 方法列表

### buildFilter

**重载 1**

解析过滤条件

**方法签名：**
```java
public void buildFilter()
```

---

**重载 2**

解析过滤条件

**方法签名：**
```java
public void buildFilter(boolean returnSql)
```

**参数说明：**
- `returnSql`: `boolean`

---

### buildFilterScript

解析条件，输出脚本表达式与表达式说明

**方法签名：**
```java
public String[] buildFilterScript()
```

**返回值：**
- `String[]`: return[0] =脚本表达式，return[1] = 表达式说明

---

### getAllFilterFields

{待补充}

**方法签名：**
```java
public Map<String,FilterField> getAllFilterFields()
```

**返回值：**
- `Map<String,FilterField>`: 过滤字段集合

---

### getCompareFilterFields

获取字段名与过滤工具类映射

**方法签名：**
```java
public Map<String,FilterField> getCompareFilterFields()
```

**返回值：**
- `Map<String,FilterField>`: 字段名与过滤工具类映射

---

### getDataType

{待补充}

**方法签名：**
```java
public MainEntityType getDataType()
```

**返回值：**
- `MainEntityType`: 实体

---

### getFilter

{待补充}

**方法签名：**
```java
public String getFilter()
```

**返回值：**
- `String`: 解析后的过滤表达式

---

### getFilterFields

获取字段名与过滤工具类映射

**方法签名：**
```java
public Map<String,FilterField> getFilterFields()
```

**返回值：**
- `Map<String,FilterField>`: 字段名与过滤工具类映射

---

### getFilterResult

获取过滤结果

**方法签名：**
```java
public FilterResult getFilterResult()
```

**返回值：**
- `FilterResult`: 过滤结果

---

### getFilterRows

{待补充}

**方法签名：**
```java
public List<kd.FilterRow> getFilterRows()
```

**返回值：**
- `List<kd.FilterRow>`: 过滤行集合

---

### getQFilter

{待补充}

**方法签名：**
```java
public QFilter getQFilter()
```

**返回值：**
- `QFilter`: 解析后的过滤条件

---

### getSelectFields

获取选择的字段

**方法签名：**
```java
public List<String> getSelectFields()
```

**返回值：**
- `List<String>`

---

### getSelectFieldsWithNotCompare

获取选择的字段

**方法签名：**
```java
public List<String> getSelectFieldsWithNotCompare()
```

**返回值：**
- `List<String>`

---

### isCheckInput

获取是否检查输入开关

**方法签名：**
```java
public boolean isCheckInput()
```

**返回值：**
- `boolean`: 是否检查输入开关

---

### isConvertValueWithTimeZone

获取是否需要将当前的值转换为用户时区去过滤

**方法签名：**
```java
public boolean isConvertValueWithTimeZone()
```

**返回值：**
- `boolean`

---

### setConvertValueWithTimeZone

设置是否需要将当前的值转换为用户时区去过滤
 需要过滤字段配置为用户时区则将当时过滤值转换为用户时区，否则不转换

**方法签名：**
```java
public void setConvertValueWithTimeZone(boolean convertValueWithTimeZone)
```

**参数说明：**
- `convertValueWithTimeZone`: `boolean`

---

### setDataType

{待补充}

**方法签名：**
```java
public void setDataType(MainEntityType dataType)
```

**参数说明：**
- `dataType`: `MainEntityType`

---

### setFilter

{待补充}

**方法签名：**
```java
public void setFilter(String filter)
```

**参数说明：**
- `filter`: `String`

---

### setFilterRows

{待补充}

**方法签名：**
```java
public void setFilterRows(List<kd.FilterRow> filterRows)
```

**参数说明：**
- `filterRows`: `List<kd.FilterRow>`

---

### setQFilter

{待补充}

**方法签名：**
```java
public void setQFilter(QFilter qFilter)
```

**参数说明：**
- `qFilter`: `QFilter`

---
