---
framework_version: "8.0.1"
api_class: "AfterBuildDrawFilterEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用选单前时"
---

# AfterBuildDrawFilterEventArgs API 说明

## 概述
选单前，生成选单条件之后，触发事件的参数。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.AfterBuildDrawFilterEventArgs;
```

---

## 方法列表

### getPlugFilter

插件追加的选单条件

**方法签名：**
```java
public QFilter getPlugFilter()
```

**返回值：**
- `QFilter`

---

### getSourceLayout

获取插件设置的选单时打开的源单列表布局

**方法签名：**
```java
public String getSourceLayout()
```

**返回值：**
- `String`

---

### getTargetDataEntity

目标单当前数据包

**方法签名：**
```java
public DynamicObject getTargetDataEntity()
```

**返回值：**
- `DynamicObject`

---

### setPlugFilter

插件追加选单条件

**方法签名：**
```java
public void setPlugFilter(QFilter plugFilter)
```

**参数说明：**
- `plugFilter`: `QFilter`

---

### setSourceLayout

插件设置选单时打开的源单列表布局

**方法签名：**
```java
public void setSourceLayout(String sourceLayout)
```

**参数说明：**
- `sourceLayout`: `String`

---
