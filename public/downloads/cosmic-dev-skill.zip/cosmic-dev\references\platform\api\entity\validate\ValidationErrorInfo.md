---
framework_version: "8.0.1"
api_class: "ValidationErrorInfo"
api_package: "kd.bos.entity.validate"
when_to_use: "当你需要使用校验错误信息时"
---

# ValidationErrorInfo API 说明

## 概述
校验错误信息。继承自 OperateErrorInfo，实现 Serializable, IOperateInfo。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.validate.ValidationErrorInfo;
```

---

## 方法列表

### getDisplayFieldsCaption

获取显示字段标题

**方法签名：**
```java
public String getDisplayFieldsCaption(DynamicObjectType entityType, String sFieldDelimChar)
```

**参数说明：**
- `entityType`: `DynamicObjectType`
- `sFieldDelimChar`: `String` — =','

**返回值：**
- `String`

---

### getDisplayToFieldKey

返回此错误信息将显示到哪个字段上。
 多数情况下，错误的字段并不显示到界面上，这样造成设置了错误，但是不能很好的定位到控件上的问题。为解决这一问题，我们提供了此属性。

**方法签名：**
```java
public String getDisplayToFieldKey()
```

**返回值：**
- `String`

---
