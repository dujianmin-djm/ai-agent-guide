---
framework_version: "8.0.1"
api_class: "IColumn"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用列定义时"
---

# IColumn API 说明

## 概述
列定义，应用于报表列等。实现 IBaseColumn。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.IColumn;
```

---

## 方法列表

### getFieldKey

获取列标识

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### getFmtInfo

获取列格式化信息

**方法签名：**
```java
public int getFmtInfo(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject`
- `numberFormatProvider`: `NumberFormatProvider`

**返回值：**
- `int`

---

### getValue

获取当前数据行中这个列的值

**方法签名：**
```java
public Object getValue(DynamicObject rowData, NumberFormatProvider numberFormatProvider)
```

**参数说明：**
- `rowData`: `DynamicObject`
- `numberFormatProvider`: `NumberFormatProvider`

**返回值：**
- `Object`

---

### getWidth

获取列宽

**方法签名：**
```java
public LocaleString getWidth()
```

**返回值：**
- `LocaleString`

---

### isHide

获取列是否隐藏

**方法签名：**
```java
public boolean isHide()
```

**返回值：**
- `boolean`

---

### isPicture

获取列类型是否是图片

**方法签名：**
```java
public boolean isPicture()
```

**返回值：**
- `boolean`

---
