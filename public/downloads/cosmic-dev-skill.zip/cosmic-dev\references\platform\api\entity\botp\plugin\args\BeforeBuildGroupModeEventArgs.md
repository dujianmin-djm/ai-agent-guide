---
framework_version: "8.0.1"
api_class: "BeforeBuildGroupModeEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用构建分单、行合并模式之前事件：调整分单、合并策略及依赖的字段时"
---

# BeforeBuildGroupModeEventArgs API 说明

## 概述
构建分单、行合并模式之前事件：调整分单、合并策略及依赖的字段。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeBuildGroupModeEventArgs;
```

---

## 方法列表

### getEntryGroupKey

单据体分组字段

**方法签名：**
```java
public String getEntryGroupKey()
```

**返回值：**
- `String`

---

### getHeadGroupKey

单据头分组(分单)字段

**方法签名：**
```java
public String getHeadGroupKey()
```

**返回值：**
- `String`

---

### getSubEntryGroupKey

子单据体分组字段

**方法签名：**
```java
public String getSubEntryGroupKey()
```

**返回值：**
- `String`

---

### setEntryGroupKey

设置单据体分组字段

**方法签名：**
```java
public void setEntryGroupKey(String entryGroupKey)
```

**参数说明：**
- `entryGroupKey`: `String` — 单据体分组字段

---

### setHeadGroupKey

设置单据头分组(分单)字段

**方法签名：**
```java
public void setHeadGroupKey(String headGroupKey)
```

**参数说明：**
- `headGroupKey`: `String` — 单据头分组(分单)字段

---

### setSubEntryGroupKey

设置子单据体分组字段

**方法签名：**
```java
public void setSubEntryGroupKey(String subEntryGroupKey)
```

**参数说明：**
- `subEntryGroupKey`: `String` — 子单据体分组字段

---
