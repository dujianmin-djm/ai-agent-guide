---
framework_version: "8.0.1"
api_class: "AmountColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用金额格式化类时"
---

# AmountColumnDesc API 说明

## 概述
金额格式化类。继承自 NumberColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.AmountColumnDesc;
```

---

## 方法列表

### formatCell

**重载 1**

{待补充}

**方法签名：**
```java
public Object formatCell(DynamicObject dr, Object value, boolean forExport)
```

**参数说明：**
- `dr`: `DynamicObject`
- `value`: `Object`
- `forExport`: `boolean`

**返回值：**
- `Object`

---

**重载 2**

获取格式化字段值（获取币别，计量单位符号存在性能问题，需要调整

**方法签名：**
```java
public Object formatCell(DynamicObject dr, Object value)
```

**参数说明：**
- `dr`: `DynamicObject`
- `value`: `Object`

**返回值：**
- `Object`

---

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject o)
```

**参数说明：**
- `o`: `DynamicObject`

**返回值：**
- `Object`

---
