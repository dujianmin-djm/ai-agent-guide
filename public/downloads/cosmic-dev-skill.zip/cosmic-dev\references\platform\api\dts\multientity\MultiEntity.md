---
framework_version: "8.0.1"
api_class: "MultiEntity"
api_package: "kd.bos.dts.multientity"
when_to_use: "当你需要使用被mapping引用时"
---

# MultiEntity API 说明

## 概述
被mapping引用。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.dts.multientity.MultiEntity;
```

---

## 方法列表

### getMainEntityNumber

获取当前多实体查询的main实体

**方法签名：**
```java
public String getMainEntityNumber(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String`

**返回值：**
- `String`

---

### isMainEntity

指定编码是否为当前多实体查询的main实体

**方法签名：**
```java
public boolean isMainEntity(String entityNumber)
```

**参数说明：**
- `entityNumber`: `String`

**返回值：**
- `boolean`

---
