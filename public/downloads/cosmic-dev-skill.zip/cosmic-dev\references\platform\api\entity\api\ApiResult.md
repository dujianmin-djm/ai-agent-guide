---
framework_version: "8.0.1"
api_class: "ApiResult"
api_package: "kd.bos.entity.api"
when_to_use: "当你需要使用WebAPI 请求返回结果时"
---

# ApiResult API 说明

## 概述
WebAPI 请求返回结果。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.api.ApiResult;
```

---

## 方法列表

### ex

**重载 1**

构建异常返回结果

**方法签名：**
```java
public static ApiResult ex(Throwable ex)
```

**参数说明：**
- `ex`: `Throwable`

**返回值：**
- `ApiResult`

---

**重载 2**

构建异常返回结果

**方法签名：**
```java
public static ApiResult ex(Throwable ex, boolean showStackTrace)
```

**参数说明：**
- `ex`: `Throwable`
- `showStackTrace`: `boolean`

**返回值：**
- `ApiResult`

---

### fail

**重载 1**

构建失败返回结果

**方法签名：**
```java
public static ApiResult fail(String msg)
```

**参数说明：**
- `msg`: `String` — 返回结果描述信息

**返回值：**
- `ApiResult`

---

**重载 2**

构建失败返回结果

**方法签名：**
```java
public static ApiResult fail(String msg, String errorCode)
```

**参数说明：**
- `msg`: `String` — 返回结果描述信息
- `errorCode`: `String` — 错误嘛

**返回值：**
- `ApiResult`

---

### fromMap

将map转换返回结果

**方法签名：**
```java
public static ApiResult fromMap(Map<String,Object> ret)
```

**参数说明：**
- `ret`: `Map<String,Object>`

**返回值：**
- `ApiResult`

---

### getData

获取返回结果数据

**方法签名：**
```java
public Object getData()
```

**返回值：**
- `Object`

---

### getErrorCode

获取返回结果错误码

**方法签名：**
```java
public String getErrorCode()
```

**返回值：**
- `String`

---

### getHttpStatus

获取HTTP请求状态

**方法签名：**
```java
public Integer getHttpStatus()
```

**返回值：**
- `Integer`

---

### getMessage

获取返回结果描述信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getSuccess

是否成功标记

**方法签名：**
```java
public boolean getSuccess()
```

**返回值：**
- `boolean`

---

### setData

设置返回结果数据

**方法签名：**
```java
public void setData(Object data)
```

**参数说明：**
- `data`: `Object`

---

### setErrorCode

设置返回结果错误码

**方法签名：**
```java
public void setErrorCode(String errorCode)
```

**参数说明：**
- `errorCode`: `String`

---

### setHttpStatus

设置HTTP请求状态

**方法签名：**
```java
public void setHttpStatus(Integer httpStatus)
```

**参数说明：**
- `httpStatus`: `Integer`

---

### setMessage

设置返回结果描述信息

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String`

---

### setSuccess

设置是否成功标记

**方法签名：**
```java
public void setSuccess(boolean success)
```

**参数说明：**
- `success`: `boolean`

---

### success

构建成功返回结果

**方法签名：**
```java
public static ApiResult success(Object data)
```

**参数说明：**
- `data`: `Object`

**返回值：**
- `ApiResult`

---

### toMap

将返回结果转换map

**方法签名：**
```java
public static Map<String,Object> toMap(ApiResult result)
```

**参数说明：**
- `result`: `ApiResult`

**返回值：**
- `Map<String,Object>`

---
