---
framework_version: "8.0.1"
api_class: "OrgEntryInfo"
api_package: "kd.bos.coderule.api"
when_to_use: "当你需要使用编码规则受控组织信息时"
---

# OrgEntryInfo API 说明

## 概述
编码规则受控组织信息。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.coderule.api.OrgEntryInfo;
```

---

## 方法列表

### getIsIncludeSubOrg

获取组织是否包含下级

**方法签名：**
```java
public Boolean getIsIncludeSubOrg()
```

**返回值：**
- `Boolean`: true：包含下级；false：不包含下级

---

### getOrgId

获取组织id

**方法签名：**
```java
public Long getOrgId()
```

**返回值：**
- `Long`: 组织id

---

### setIsIncludeSubOrg

设置组织是否包含下级

**方法签名：**
```java
public void setIsIncludeSubOrg(Boolean isIncludeSubOrg)
```

**参数说明：**
- `isIncludeSubOrg`: `Boolean` — true：包含下级；false：不包含下级

---

### setOrgId

设置组织id

**方法签名：**
```java
public void setOrgId(Long orgId)
```

**参数说明：**
- `orgId`: `Long`

---
