---
framework_version: "8.0.1"
api_class: "JoinDataSetX"
api_package: "kd.bos.algox"
when_to_use: "当你需要使用 JoinDataSetX 相关功能时"
---

# JoinDataSetX API 说明

## 概述
JoinDataSetX 类。继承自 AbstractDataSetX，实现 DataSetX。
主要功能：事件处理。

## Import 路径
```java
import kd.bos.algox.JoinDataSetX;
```

---

## 方法列表

### on

Join on

**方法签名：**
```java
public JoinDataSetX on(String leftField, String rightField)
```

**参数说明：**
- `leftField`: `String` — 左数据集字段
- `rightField`: `String` — 右数据集字段

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### select

**重载 1**

返回join后的列

**方法签名：**
```java
public JoinDataSetX select(String[] leftFields, String[] rightFields)
```

**参数说明：**
- `leftFields`: `String[]` — 左数据集字段数组
- `rightFields`: `String[]` — 右数据集字段数组

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

**重载 2**

返回join后的列

**方法签名：**
```java
public JoinDataSetX select(String[] fields)
```

**参数说明：**
- `fields`: `String[]` — 列数组，可用left.xxx代表左数据集中的列，right.xxx代表右数据集中的列

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---

### withFunc

可以自行决定返回的列
 
 如果使用了withFunc，那么select会被忽略。

**方法签名：**
```java
public JoinDataSetX withFunc(JoinFunction func)
```

**参数说明：**
- `func`: `JoinFunction` — JoinFunction

**返回值：**
- `JoinDataSetX`: JoinDataSetX

---
