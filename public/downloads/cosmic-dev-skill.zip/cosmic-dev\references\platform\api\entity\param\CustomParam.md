---
framework_version: "8.0.1"
api_class: "CustomParam"
api_package: "kd.bos.entity.param"
when_to_use: "当你需要使用系统参数自定义参数接口参数时"
---

# CustomParam API 说明

## 概述
系统参数自定义参数接口参数。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.param.CustomParam;
```

---

## 方法列表

### getGroupNumber

获取参数分组,即指定分组key.

**方法签名：**
```java
public String getGroupNumber()
```

**返回值：**
- `String`: 参数分组,即指定分组key.

---

### getSearchKeySet

获取查询key集合

**方法签名：**
```java
public Set<String> getSearchKeySet()
```

**返回值：**
- `Set<String>`: 查询key集合

---

### setGroupNumber

设置参数分组,即指定分组key.

**方法签名：**
```java
public void setGroupNumber(String groupNumber)
```

**参数说明：**
- `groupNumber`: `String` — 参数分组,即指定分组key.

---

### setSearchKeySet

设置查询key集合

**方法签名：**
```java
public void setSearchKeySet(Set<String> searchKeySet)
```

**参数说明：**
- `searchKeySet`: `Set<String>` — 查询key集合

---
