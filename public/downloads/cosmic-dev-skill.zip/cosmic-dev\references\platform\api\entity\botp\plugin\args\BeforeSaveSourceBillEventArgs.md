---
framework_version: "8.0.1"
api_class: "BeforeSaveSourceBillEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用反写规则执行完毕后时"
---

# BeforeSaveSourceBillEventArgs API 说明

## 概述
反写规则执行完毕后，源单数据保存到数据库之前调用。继承自 WriteBackEventArgs。
主要功能：读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeSaveSourceBillEventArgs;
```

---

## 方法列表

### getSrcDataEntities

源单数据包，只包含了部分用到的字段

**方法签名：**
```java
public DynamicObject[] getSrcDataEntities()
```

**返回值：**
- `DynamicObject[]`

---

### getSrcSubMainType

源单主实体，只包含了部分用到的字段

**方法签名：**
```java
public BillEntityType getSrcSubMainType()
```

**返回值：**
- `BillEntityType`

---

### isNewThread

当前事件是否由异步线程触发，不在事务内：跨库反写时，会启动一个异步线程，在事务外单独的保存源单反写结果，没有事务保护，不能回滚数据。
 此时插件抛出异常并不能取消反写，回滚数据。因此，此场景下插件要确保不抛出异常

**方法签名：**
```java
public boolean isNewThread()
```

**返回值：**
- `boolean`

---
