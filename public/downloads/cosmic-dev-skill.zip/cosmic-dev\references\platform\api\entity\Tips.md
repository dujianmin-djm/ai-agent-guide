---
framework_version: "8.0.1"
api_class: "Tips"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用设计器tips属性配置时"
---

# Tips API 说明

## 概述
设计器tips属性配置。实现 Serializable。
主要功能：设置属性、读取属性、状态判断、创建对象。

## Import 路径
```java
import kd.bos.entity.Tips;
```

---

## 方法列表

### beginInit

{待补充}

**方法签名：**
```java
public void beginInit()
```

---

### createLinkData

**重载 1**

创建一个链接数据对象

**方法签名：**
```java
public static List<Map<String,Object>> createLinkData(List<kd.TipsLink> tipsLink)
```

**参数说明：**
- `tipsLink`: `List<kd.TipsLink>`

**返回值：**
- `List<Map<String,Object>>`

---

**重载 2**

创建一个链接数据对象

**方法签名：**
```java
public static List<Map<String,Object>> createLinkData(TipsLink tipsLink)
```

**参数说明：**
- `tipsLink`: `TipsLink`

**返回值：**
- `List<Map<String,Object>>`

---

### endInit

{待补充}

**方法签名：**
```java
public void endInit()
```

---

### getBillno

获取表单id

**方法签名：**
```java
public String getBillno()
```

**返回值：**
- `String`

---

### getContent

获取纯文本内容

**方法签名：**
```java
public LocaleString getContent()
```

**返回值：**
- `LocaleString`

---

### getIconClassName

获取小图标样式

**方法签名：**
```java
public String getIconClassName()
```

**返回值：**
- `String`

---

### getLinkData

获取链接数据项 (运行时)

**方法签名：**
```java
public List<Map<String,Object>> getLinkData()
```

**返回值：**
- `List<Map<String,Object>>`

---

### getLinkTitles

获取连接标题

**方法签名：**
```java
public List<kd.TipLinkTitle> getLinkTitles()
```

**返回值：**
- `List<kd.TipLinkTitle>`

---

### getOriLinkData

获取链接数据项

**方法签名：**
```java
public List<Map<String,Object>> getOriLinkData()
```

**返回值：**
- `List<Map<String,Object>>`

---

### getPlace

获取显示位置

**方法签名：**
```java
public String getPlace()
```

**返回值：**
- `String`

---

### getTitle

获取纯文本title

**方法签名：**
```java
public LocaleString getTitle()
```

**返回值：**
- `LocaleString`

---

### getTriggerType

获取触发类型

**方法签名：**
```java
public String getTriggerType()
```

**返回值：**
- `String`

---

### getType

获取显示类型 text/bill

**方法签名：**
```java
public String getType()
```

**返回值：**
- `String`

---

### insertLinkPlaceholder

插入链接占位符

**方法签名：**
```java
public static String insertLinkPlaceholder(int index)
```

**参数说明：**
- `index`: `int`

**返回值：**
- `String`

---

### isInitialized

{待补充}

**方法签名：**
```java
public boolean isInitialized()
```

**返回值：**
- `boolean`

---

### isIsConfirm

是否设置确认操作开关

**方法签名：**
```java
public boolean isIsConfirm()
```

**返回值：**
- `boolean`

---

### isLink

是否包含链接

**方法签名：**
```java
public boolean isLink()
```

**返回值：**
- `boolean`

---

### isShowIcon

是否显示小图标

**方法签名：**
```java
public boolean isShowIcon()
```

**返回值：**
- `boolean`

---

### setBillno

设置表单id

**方法签名：**
```java
public void setBillno(String billno)
```

**参数说明：**
- `billno`: `String`

---

### setContent

设置纯文本内容

**方法签名：**
```java
public void setContent(LocaleString content)
```

**参数说明：**
- `content`: `LocaleString`

---

### setIconClassName

设置小图标样式

**方法签名：**
```java
public void setIconClassName(String iconClassName)
```

**参数说明：**
- `iconClassName`: `String`

---

### setIsConfirm

设置确认操作开关

**方法签名：**
```java
public void setIsConfirm(boolean isConfirm)
```

**参数说明：**
- `isConfirm`: `boolean`

---

### setLink

设置是否包含链接

**方法签名：**
```java
public void setLink(boolean link)
```

**参数说明：**
- `link`: `boolean`

---

### setLinkData

设置链接数据项

**方法签名：**
```java
public void setLinkData(List<Map<String,Object>> linkData)
```

**参数说明：**
- `linkData`: `List<Map<String,Object>>`

---

### setLinkTitles

设置连接标题

**方法签名：**
```java
public void setLinkTitles(List<kd.TipLinkTitle> linkTitles)
```

**参数说明：**
- `linkTitles`: `List<kd.TipLinkTitle>`

---

### setOriLinkData

设置链接数据项

**方法签名：**
```java
public void setOriLinkData(List<Map<String,Object>> linkData)
```

**参数说明：**
- `linkData`: `List<Map<String,Object>>`

---

### setPlace

设置显示位置

**方法签名：**
```java
public void setPlace(String place)
```

**参数说明：**
- `place`: `String`

---

### setShowIcon

设置是否显示小图标

**方法签名：**
```java
public void setShowIcon(boolean showIcon)
```

**参数说明：**
- `showIcon`: `boolean`

---

### setTitle

设置纯文本title

**方法签名：**
```java
public void setTitle(LocaleString title)
```

**参数说明：**
- `title`: `LocaleString`

---

### setTriggerType

设置触发类型

**方法签名：**
```java
public void setTriggerType(String triggerType)
```

**参数说明：**
- `triggerType`: `String`

---

### setType

设置显示类型 text/bill

**方法签名：**
```java
public void setType(String type)
```

**参数说明：**
- `type`: `String`

---
