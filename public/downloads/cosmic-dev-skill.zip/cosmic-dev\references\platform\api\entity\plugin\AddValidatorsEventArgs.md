---
framework_version: "8.0.1"
api_class: "AddValidatorsEventArgs"
api_package: "kd.bos.entity.plugin"
when_to_use: "当你需要使用单据操作插件IOperationServicePlugIn - onAddValidators 事件参数时"
---

# AddValidatorsEventArgs API 说明

## 概述
单据操作插件IOperationServicePlugIn - onAddValidators 事件参数。
主要功能：读取属性、添加元素。

## Import 路径
```java
import kd.bos.entity.plugin.AddValidatorsEventArgs;
```

---

## 方法列表

### addValidator

注册自定义操作校验器

**方法签名：**
```java
public void addValidator(AbstractValidator validator)
```

**参数说明：**
- `validator`: `AbstractValidator` — 自定义的操作校验器实例

---

### getDataEntities

获取单据数据包

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`: 单据数据包

---

### getValidators

获取已注册的操作校验器集合

**方法签名：**
```java
public List<kd.AbstractValidator> getValidators()
```

**返回值：**
- `List<kd.AbstractValidator>`: 已注册的操作校验器集合

---
