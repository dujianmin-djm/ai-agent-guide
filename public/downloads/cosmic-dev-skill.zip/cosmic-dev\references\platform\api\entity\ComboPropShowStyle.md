---
framework_version: "8.0.1"
api_class: "ComboPropShowStyle"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用下拉列表类型时"
---

# ComboPropShowStyle API 说明

## 概述
下拉列表类型。实现 Comparable, Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.ComboPropShowStyle;
```

---

## 方法列表

### getValue

获取下拉列表类型的 value 值

**方法签名：**
```java
public int getValue()
```

**返回值：**
- `int`

---
