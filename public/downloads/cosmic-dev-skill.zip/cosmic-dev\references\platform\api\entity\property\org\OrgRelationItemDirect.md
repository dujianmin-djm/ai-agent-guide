---
framework_version: "8.0.1"
api_class: "OrgRelationItemDirect"
api_package: "kd.bos.entity.property.org"
when_to_use: "当你需要使用业务单元间协作方向时"
---

# OrgRelationItemDirect API 说明

## 概述
业务单元间协作方向。实现 Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.property.org.OrgRelationItemDirect;
```

---

## 方法列表

### getDisplay

获取协作方向说明

**方法签名：**
```java
public String getDisplay()
```

**返回值：**
- `String`: 协作方向说明，如"本组织是受托组织"

---

### getIndex

获取协作方向编码

**方法签名：**
```java
public String getIndex()
```

**返回值：**
- `String`: 协作方向编码，如"toorg"

---

### setDisplay

设置协作方向说明

**方法签名：**
```java
public void setDisplay(String display)
```

**参数说明：**
- `display`: `String` — 协作方向说明，如"本组织是受托组织"

---

### setIndex

设置协作方向编码

**方法签名：**
```java
public void setIndex(String index)
```

**参数说明：**
- `index`: `String` — 协作方向编码，如"toorg"

---
