---
framework_version: "8.0.1"
api_class: "SerializationException"
api_package: "kd.bos.dataentity.exception"
when_to_use: "当你需要使用在序列化时发生的异常时"
---

# SerializationException API 说明

## 概述
在序列化时发生的异常。继承自 OrmException，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.exception.SerializationException;
```

---

## 方法列表

### getExceptionData

返回异常的相关信息

**方法签名：**
```java
public final SerializationException.SerializationExceptionData getExceptionData()
```

**返回值：**
- `SerializationException.SerializationExceptionData`: SerializationExceptionData

---

### getMessage

返回自定义的序列化异常消息。

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---
