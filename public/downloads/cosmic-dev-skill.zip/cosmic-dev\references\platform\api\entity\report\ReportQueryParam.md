---
framework_version: "8.0.1"
api_class: "ReportQueryParam"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表查询参数类时"
---

# ReportQueryParam API 说明

## 概述
报表查询参数类。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.report.ReportQueryParam;
```

---

## 方法列表

### byBatchInfo

分批加载数据-批次等信息

**方法签名：**
```java
public IReportBatchQueryInfo byBatchInfo()
```

**返回值：**
- `IReportBatchQueryInfo`

---

### getCustomFilter

获取报表自定义过滤条件

**方法签名：**
```java
public List<QFilter> getCustomFilter()
```

**返回值：**
- `List<QFilter>`

---

### getCustomParam

获取自定义参数

**方法签名：**
```java
public Map<String,Object> getCustomParam()
```

**返回值：**
- `Map<String,Object>`

---

### getFilter

获取通用过滤条件

**方法签名：**
```java
public FilterInfo getFilter()
```

**返回值：**
- `FilterInfo`

---

### getMessage

获取提示信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getMulLang

获取多语言

**方法签名：**
```java
public Lang getMulLang()
```

**返回值：**
- `Lang`

---

### getReportFilterFieldConfig

获取报表过滤条件配置

**方法签名：**
```java
public ReportFilterFieldConfig getReportFilterFieldConfig()
```

**返回值：**
- `ReportFilterFieldConfig`

---

### getSortInfo

获取排序信息

**方法签名：**
```java
public String getSortInfo()
```

**返回值：**
- `String`

---

### getSortSource

获取排序类型

**方法签名：**
```java
public String getSortSource()
```

**返回值：**
- `String`

---

### isTreeReportList

获取是否树形报表

**方法签名：**
```java
public boolean isTreeReportList()
```

**返回值：**
- `boolean`

---

### setCustomFilter

设置报表自定义过滤条件

**方法签名：**
```java
public void setCustomFilter(List<QFilter> customFilter)
```

**参数说明：**
- `customFilter`: `List<QFilter>`

---

### setCustomParam

设置自定义参数到取数插件

**方法签名：**
```java
public void setCustomParam(Map<String,Object> customParam)
```

**参数说明：**
- `customParam`: `Map<String,Object>` — 自定义参数

---

### setFilter

设置通用过滤条件

**方法签名：**
```java
public void setFilter(FilterInfo filter)
```

**参数说明：**
- `filter`: `FilterInfo` — 通用过滤条件

---

### setMessage

设置提示信息

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String`

---

### setMulLang

设置多语言

**方法签名：**
```java
public void setMulLang(Lang mulLang)
```

**参数说明：**
- `mulLang`: `Lang`

---

### setReportFilterFieldConfig

设置报表过滤条件配置

**方法签名：**
```java
public void setReportFilterFieldConfig(ReportFilterFieldConfig reportFilterFieldConfig)
```

**参数说明：**
- `reportFilterFieldConfig`: `ReportFilterFieldConfig` — 过滤配置

---

### setSortInfo

设置排序信息

**方法签名：**
```java
public void setSortInfo(String sortInfo)
```

**参数说明：**
- `sortInfo`: `String`

---

### setSortSource

设置排序类型

**方法签名：**
```java
public void setSortSource(String sortSource)
```

**参数说明：**
- `sortSource`: `String` — 排序类型：singleSort、multiSort

---

### setTreeReportList

设置是否树形报表

**方法签名：**
```java
public void setTreeReportList(boolean isTreeReportList)
```

**参数说明：**
- `isTreeReportList`: `boolean` — 树形报表

---
