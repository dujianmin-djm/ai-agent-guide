---
framework_version: "8.0.1"
api_class: "OperateInfo"
api_package: "kd.bos.entity.operate.result"
when_to_use: "当你需要使用操作信息时"
---

# OperateInfo API 说明

## 概述
操作信息。实现 IOperateInfo, Serializable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.result.OperateInfo;
```

---

## 方法列表

### getDataEntityIndex

获取单据顺序号：批量处理多张单据时，提示单据的位置

**方法签名：**
```java
public int getDataEntityIndex()
```

**返回值：**
- `int`

---

### getEntityKey

获取提示信息所在的实体

**方法签名：**
```java
public String getEntityKey()
```

**返回值：**
- `String`

---

### getFieldKey

获取提示信息所在的字段

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### getMessage

获取提示信息

**方法签名：**
```java
public String getMessage()
```

**返回值：**
- `String`

---

### getPattern

获取提示信息格式

**方法签名：**
```java
public String getPattern()
```

**返回值：**
- `String`

---

### getPkValue

获取数据的对象的主键值（单据/基础资料主键值）

**方法签名：**
```java
public Object getPkValue()
```

**返回值：**
- `Object`

---

### getRowIndex

获取单据体行号，用于给客户提示 （返回错误信息对应到哪个行上。如果是分录，对应到所在行号，如果是主表，总是0）

**方法签名：**
```java
public int getRowIndex()
```

**返回值：**
- `int`

---

### getSubRowIndex

获取子单据体行号

**方法签名：**
```java
public int getSubRowIndex()
```

**返回值：**
- `int`

---

### getTitle

获取操作信息标题（返回信息关键字列内容）

**方法签名：**
```java
public String getTitle()
```

**返回值：**
- `String`

---

### setDataEntityIndex

设置单据顺序号：批量处理多张单据时，提示单据的位置

**方法签名：**
```java
public void setDataEntityIndex(int dataEntityIndex)
```

**参数说明：**
- `dataEntityIndex`: `int`

---

### setEntityKey

设置提示信息所在的实体

**方法签名：**
```java
public void setEntityKey(String entityKey)
```

**参数说明：**
- `entityKey`: `String`

---

### setFieldKey

设置提示信息所在的字段

**方法签名：**
```java
public void setFieldKey(String fieldKey)
```

**参数说明：**
- `fieldKey`: `String`

---

### setMessage

设置提示信息

**方法签名：**
```java
public void setMessage(String message)
```

**参数说明：**
- `message`: `String`

---

### setPattern

设置提示信息格式

**方法签名：**
```java
public void setPattern(String pattern)
```

**参数说明：**
- `pattern`: `String`

---

### setPkValue

设置数据的对象的主键值（单据/基础资料主键值）

**方法签名：**
```java
public void setPkValue(Object pkValue)
```

**参数说明：**
- `pkValue`: `Object`

---

### setRowIndex

设置单据体行号，用于给客户提示 （返回错误信息对应到哪个行上。如果是分录，对应到所在行号，如果是主表，总是0）

**方法签名：**
```java
public void setRowIndex(int rowIndex)
```

**参数说明：**
- `rowIndex`: `int`

---

### setSubRowIndex

设置子单据体行号

**方法签名：**
```java
public void setSubRowIndex(int subRowIndex)
```

**参数说明：**
- `subRowIndex`: `int`

---

### setTitle

设置操作信息标题（返回信息关键字列内容）

**方法签名：**
```java
public void setTitle(String title)
```

**参数说明：**
- `title`: `String`

---

### toString

toString

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
