---
framework_version: "8.0.1"
api_class: "AbstractOpBizRuleAction"
api_package: "kd.bos.entity.operate.bizrule"
when_to_use: "当你需要使用操作的服务端服务时"
---

# AbstractOpBizRuleAction API 说明

## 概述
操作的服务端服务，本质是操作的插件，对操作的功能进行扩展，添加一些通用的业务逻辑。因此，把操作的服务端服务执行类，当成标准的操作插件进行开发。。继承自 AbstractOperationServicePlugIn，实现 IOperationServicePlugIn, IOperationService。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.operate.bizrule.AbstractOpBizRuleAction;
```

---

## 方法列表

### getBizRule

获取本服务运行时元数据对象，包含了服务参数配置；由操作执行类，在初始化服务执行类后传入；

**方法签名：**
```java
public OpBizRule getBizRule()
```

**返回值：**
- `OpBizRule`

---

### setBizRule

设置本服务运行时元数据对象，包含了服务参数配置；由操作执行类，在初始化服务执行类后传入；

**方法签名：**
```java
public void setBizRule(OpBizRule bizRule)
```

**参数说明：**
- `bizRule`: `OpBizRule`

---
