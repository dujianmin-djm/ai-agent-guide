# cosmic-dev Skill 路由重设计规格文档

**日期**：2026-03-24  
**状态**：已通过设计审查  
**范围**：`.cursor/rules/cosmic-skill-routing.md`（重写）+ `.cursor/skills/cosmic-dev/SKILL.md`（重构）+ `.cursor/skills/cosmic-dev/rules/cosmic-skill-routing.md`（删除）

> **术语说明**：`SKILL_DIR` = `.cursor/skills/cosmic-dev/` 的绝对路径，由 AI 在激活 SKILL.md 时从文件读取路径推算，后续所有路径均基于此目录拼接。

---

## 一、背景与问题

### 现状

| 文件 | 行数 | 问题 |
|------|------|------|
| `.cursor/rules/cosmic-skill-routing.md` | 80行 | 内容为旧版，仍指向 `cosmic-custom-control`；自包含完整决策树，与 SKILL.md 职责重叠 |
| `.cursor/skills/cosmic-dev/rules/cosmic-skill-routing.md` | 75行 | 路径错误，Cursor 读不到；应删除 |
| `.cursor/skills/cosmic-dev/SKILL.md` | 269行 | description 仅覆盖插件生成场景；无流水线阶段结构 |

### 核心问题

1. **路由分裂**：路由逻辑分散在 rules 文件与 SKILL.md 两处，内容不一致
2. **覆盖不全**：SKILL.md description 未覆盖元数据建模、修改、PDM、测试等阶段
3. **无扩展结构**：当前设计无法平滑支持未来新增的流水线阶段（需求分析、架构设计等）
4. **错误文件残留**：`skills/cosmic-dev/rules/` 中有误写文件需清理
5. **术语问题**：沿用"二开"术语，应改为"标品开发/各业务线开发"

---

## 二、设计决策

### 2.1 整合模式

采用**「薄规则 + 厚 SKILL.md」**模式：

- **`.cursor/rules/`**：保留 `alwaysApply: true`，内容精简为触发层（关键词快速映射 + 硬性防错规则）
- **`cosmic-dev/SKILL.md`**：扩展为流水线编排中心，包含所有业务路由决策树和阶段跳转表

### 2.2 阶段入口判断

采用**关键词优先匹配**：
- 关键词命中 → 直接路由到对应阶段
- 无法判断 → 展示流水线阶段表，询问用户

### 2.3 阶段间状态传递

`runtime/context.md` 为**可选加速机制**，不作为强制依赖：
- 有 context.md：跨阶段自动传递 entityKey / formId，免重复输入
- 无 context.md：各阶段子技能自行询问或探查（各子技能已覆盖此场景）

---

## 三、流水线阶段定义

```
Cosmic Vibecoding Pipeline（金蝶云苍穹标品开发）

Stage 1  需求分析    [预留] keywords: 需求分析/PRD/功能描述/用户故事
Stage 2  架构设计    [预留] keywords: 架构/模块划分/服务设计
─────────────────────────────────────────────── ↑ 未来阶段
Stage 3  元数据建模  [现有] → cosmic-meta-modeling/SKILL.md
Stage 4  元数据修改  [现有] → cosmic-meta-modifier/SKILL.md
Stage 5  PDM 生成    [现有] → pdm_auto.py
Stage 6  插件开发    [现有] → cosmic-gen/SKILL.md (+kwc-react-development)
Stage 7  单元测试    [现有] → cosmic-meta-test/SKILL.md
─────────────────────────────────────────────── ↑ 当前已有
```

**约束**：任意阶段均可直接跳入，无需从 Stage 1 开始。Stage 5/6/7 均不强制依赖 context.md——各子技能自身已覆盖无 context.md 的场景（Stage 5 无 context.md 时提示用户手动提供 entityKey）。

---

## 四、文件设计规格

### 4.1 `.cursor/rules/cosmic-skill-routing.md`（重写，目标 ≤ 30 行）

```markdown
---
description: 苍穹标品/各业务线开发技能路由（触发层）
alwaysApply: true
---

# 苍穹技能路由

收到苍穹开发相关指令时，**第一动作必须是：读取 cosmic-dev/SKILL.md**，再按其阶段跳转表执行。

## 快速阶段映射（关键词参考）

| 关键词 | 阶段 |
|--------|------|
| 建单据 / 需求建模 / 建基础资料 / 主数据 / 元数据建模 | Stage 3 元数据建模 |
| 改单据 / 加字段 / 删字段 / 改必填 / 改类型 / 修改元数据 | Stage 4 元数据修改 |
| 生成PDM / 同步数据模型 / 建表脚本 / PDM同步 | Stage 5 PDM 生成 |
| 写插件 / 生成插件 / 业务逻辑 / 联动 / 校验 / 生成代码 | Stage 6 插件开发 |
| 跑测试 / 验证元数据 / 测试建模 / 设计测试用例 | Stage 7 单元测试 |
| 重置环境 / RST ENV / rst env（大小写不敏感） | → 直接读 cosmic-meta-api/modules/reset/SKILL.md |

## 硬性防错（强制，无需读 SKILL.md 即生效）

- **已有表单字段变更**：必须用 `modifyMeta`，**禁止** `buildMeta` 代替（会产生新 formId）
- **含 formId 或"已有表单"语义**：强制路由到 Stage 4 元数据修改
- **SKILL.md 未加载时**：禁止自创流程，必须先读技能再执行
```

### 4.2 `.cursor/skills/cosmic-dev/SKILL.md`（重构）

**YAML front matter**（扩展 description）：

```yaml
---
name: cosmic-dev
description: >
  金蝶云苍穹（Kingdee Cloud Cosmic）标品开发 / 各业务线开发全流程助手。
  ALWAYS TRIGGER when 用户提到以下任一场景：
  元数据建模（建单据、建基础资料、主数据建模、创建元数据）；
  元数据修改（加字段、删字段、改必填、改类型、修改元数据）；
  PDM生成（数据模型同步、建表脚本、PDM同步）；
  插件开发（表单插件、操作插件、列表插件、工作流、调度任务、Java代码生成）；
  KWC 前端开发（React组件、前后端分离）；
  单元测试（验证元数据、测试建模、设计测试用例）；
  苍穹 OpenAPI / 框架问题。
---
```

**主体结构变更**：

```
## 轻量启动门（保持不变）

## Vibecoding 流水线（新增核心节，放在启动门之后）
  阶段表 + 阶段入口判断逻辑

## 全局配置（保持不变）

## 项目目录（保持不变）

## 技能执行原则（从旧规则迁入，放在 Stage 6 详情之前）
  先读再做 / 不替技能造轮子 / 例外允许

## Stage 6 详情：插件开发（原"入口判断"+"需求分析与路由"节重命名）
  （现有内容原地保留，仅加标注）

## 错误恢复（保持不变）
```

**新增节：Vibecoding 流水线** 内容规格：

```markdown
## Vibecoding 流水线

金蝶云苍穹标品开发标准流水线（各阶段可独立进入，无需按顺序）：

| 阶段 | 名称 | 关键词 | 执行路径 | 状态 |
|------|------|--------|----------|------|
| Stage 1 | 需求分析 | 需求分析/PRD/功能描述 | `skills/requirements/SKILL.md` | 预留 |
| Stage 2 | 架构设计 | 架构/模块划分/服务设计 | `skills/architecture/SKILL.md` | 预留 |
| Stage 3 | 元数据建模 | 建单据/建基础资料/主数据/一键建模 | 读取 `skills/cosmic-meta-modeling/SKILL.md` | ✅ |
| Stage 4 | 元数据修改 | 加字段/删字段/改必填/改类型 | 读取 `skills/cosmic-meta-modifier/SKILL.md` | ✅ |
| Stage 5 | PDM 生成 | 生成PDM/同步数据模型/建表脚本 | 从 context.md 获取 entityKey（可选）或手动提供 → `SKILL_DIR/skills/cosmic-meta-api/scripts/pdm-automation/pdm_auto.py` | ✅ |
| Stage 6 | 插件开发 | 写插件/生成插件/业务逻辑/联动 | 见下方「Stage 6 详情」节 | ✅ |
| Stage 7 | 单元测试 | 跑测试/验证元数据/测试建模 | 读取 `skills/cosmic-meta-test/SKILL.md` | ✅ |

### 入口判断规则

1. **关键词命中** → 直接跳入对应阶段，读取执行路径中的 SKILL.md
2. **无法判断** → 展示上方阶段表，询问用户处于哪个阶段
3. **阶段上下文传递**：如果 `SKILL_DIR/skills/cosmic-meta-api/runtime/context.md` 存在，可从中读取 entityKey / formId 加速后续阶段；Stage 5/6/7 不强制依赖此文件

> 预留阶段（Stage 1/2）被触发时，告知用户该阶段尚未实现，并按以下规则引导：若用户意图是建模类（建单据/建基础资料/主数据）→ 引导至 Stage 3；若用户意图是插件/代码开发类 → 引导至 Stage 6；无法判断则直接展示阶段表询问。
```

---

## 五、变更清单

| 文件 | 操作 | 变更内容 |
|------|------|----------|
| `.cursor/rules/cosmic-skill-routing.md` | **重写** | 80行→≤30行；删除完整决策树；保留薄映射表+硬性防错 |
| `.cursor/skills/cosmic-dev/SKILL.md` | **重构** | 扩展 description；新增 Vibecoding 流水线节；新增技能执行原则节（从旧规则迁入）；"入口判断"节重命名为"Stage 6 详情" |
| `.cursor/skills/cosmic-dev/rules/cosmic-skill-routing.md` | **删除** | 路径错误的残留文件 |
| 各子技能 SKILL.md | **不变** | 各子技能保持现有设计 |

---

## 六、扩展操作手册（未来新增阶段）

当需要加入新阶段（如需求分析 Stage 1）时，标准操作（两步必须 + 一步可选）：

```
Step 1：创建子技能目录
  SKILL_DIR/skills/requirements/
  SKILL_DIR/skills/requirements/SKILL.md  ← 定义该阶段完整流程

Step 2：在 cosmic-dev/SKILL.md 流水线阶段表更新对应行
  将 Stage 1 的"预留"状态改为 ✅，更新执行路径

Step 3（可选）：在薄规则的快速阶段映射表追加关键词
```

**扩展影响范围**：仅修改 1 个子技能目录 + 2 处文本行，不影响其他阶段和配置。

---

## 七、不在本次范围内

- 子技能内部逻辑不变（cosmic-meta-modeling、cosmic-meta-modifier、cosmic-gen 等）
- config.json 结构不变
- Python 脚本不变
- Stage 1/2（需求分析、架构设计）不在本次实现范围，仅预留位置
