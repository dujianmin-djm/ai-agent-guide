---
framework_version: "8.0.1"
api_class: "ControlColumnDesc"
api_package: "kd.bos.entity.list.column"
when_to_use: "当你需要使用精度控制字段时"
---

# ControlColumnDesc API 说明

## 概述
精度控制字段。继承自 ColumnDesc，实现 Serializable。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.entity.list.column.ControlColumnDesc;
```

---

## 方法列表

### getValue

{待补充}

**方法签名：**
```java
public Object getValue(DynamicObject dr)
```

**参数说明：**
- `dr`: `DynamicObject`

**返回值：**
- `Object`

---
