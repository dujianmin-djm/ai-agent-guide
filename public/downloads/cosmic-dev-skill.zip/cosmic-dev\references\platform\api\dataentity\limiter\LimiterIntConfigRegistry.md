---
framework_version: "8.0.1"
api_class: "LimiterIntConfigRegistry"
api_package: "kd.bos.dataentity.limiter"
when_to_use: "当你需要使用限流配置注册中心时"
---

# LimiterIntConfigRegistry API 说明

## 概述
限流配置注册中心。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.dataentity.limiter.LimiterIntConfigRegistry;
```

---

## 方法列表

### getLimiterIntConfigValue

获取限流值

**方法签名：**
```java
public static int getLimiterIntConfigValue(String key)
```

**参数说明：**
- `key`: `String` — 配置键

**返回值：**
- `int`: 限流值

---
