---
framework_version: "8.0.1"
api_class: "ReportFilterDefaultField"
api_package: "kd.bos.entity.report"
when_to_use: "当你需要使用报表过滤初始字段定义时"
---

# ReportFilterDefaultField API 说明

## 概述
报表过滤初始字段定义。实现 Serializable。
主要功能：设置属性、状态判断、读取属性。

## Import 路径
```java
import kd.bos.entity.report.ReportFilterDefaultField;
```

---

## 方法列表

### getFieldKey

获取字段标识

**方法签名：**
```java
public String getFieldKey()
```

**返回值：**
- `String`

---

### isInitialHide

是否是初始隐藏字段

**方法签名：**
```java
public boolean isInitialHide()
```

**返回值：**
- `boolean`

---

### isUserHide

是否是用户隐藏字段

**方法签名：**
```java
public boolean isUserHide()
```

**返回值：**
- `boolean`

---

### setFieldKey

设置字段标识

**方法签名：**
```java
public void setFieldKey(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setInitialHide

设置是否是初始隐藏字段

**方法签名：**
```java
public void setInitialHide(boolean initialHide)
```

**参数说明：**
- `initialHide`: `boolean`

---

### setUserHide

设置是否是用户隐藏字段

**方法签名：**
```java
public void setUserHide(boolean userHide)
```

**参数说明：**
- `userHide`: `boolean`

---
