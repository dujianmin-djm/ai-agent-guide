---
framework_version: "8.0.1"
api_class: "GetMonitorAppIdArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用 GetMonitorAppIdArgs 相关功能时"
---

# GetMonitorAppIdArgs API 说明

## 概述
GetMonitorAppIdArgs 类。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.plugin.args.GetMonitorAppIdArgs;
```

---

## 方法列表

### getNeedMonitorAppId

{待补充}

**方法签名：**
```java
public Set<String> getNeedMonitorAppId()
```

**返回值：**
- `Set<String>`

---

### setNeedMonitorAppId

{待补充}

**方法签名：**
```java
public void setNeedMonitorAppId(Set<String> needMonitorAppId)
```

**参数说明：**
- `needMonitorAppId`: `Set<String>`

---
