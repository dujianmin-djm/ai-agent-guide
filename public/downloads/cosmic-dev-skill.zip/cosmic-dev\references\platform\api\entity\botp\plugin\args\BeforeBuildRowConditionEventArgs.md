---
framework_version: "8.0.1"
api_class: "BeforeBuildRowConditionEventArgs"
api_package: "kd.bos.entity.botp.plugin.args"
when_to_use: "当你需要使用编译数据筛选条件前事件：可追加定制条件时"
---

# BeforeBuildRowConditionEventArgs API 说明

## 概述
编译数据筛选条件前事件：可追加定制条件，是否忽略规则原生的条件。继承自 ConvertPluginEventArgs。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.botp.plugin.args.BeforeBuildRowConditionEventArgs;
```

---

## 方法列表

### getAdvancedCustomFilters

获取高级定制条件

**方法签名：**
```java
public List<kd.AdvancedCustomFilter> getAdvancedCustomFilters()
```

**返回值：**
- `List<kd.AdvancedCustomFilter>`

---

### getCustFilterDesc

插件定制条件的说明：当数据不符合条件时，会显示条件说明，提示用户原因

**方法签名：**
```java
public String getCustFilterDesc()
```

**返回值：**
- `String`

---

### getCustFilterExpression

插件定制条件：用于脚本执行 
 
 特别说明：必须同时设置用于数据库查询的CustQFilters，且效果要保持一致

**方法签名：**
```java
public String getCustFilterExpression()
```

**返回值：**
- `String`

---

### getCustQFilters

插件定制条件：用于数据库查询

**方法签名：**
```java
public List<QFilter> getCustQFilters()
```

**返回值：**
- `List<QFilter>`

---

### getSelectedRows

当前规则需要处理的源单行 ： 已经通过了规则启动条件校验

**方法签名：**
```java
public List<ListSelectedRow> getSelectedRows()
```

**返回值：**
- `List<ListSelectedRow>`

---

### isAdvancedCustomCondition

是否打开高级定制条件

**方法签名：**
```java
public boolean isAdvancedCustomCondition()
```

**返回值：**
- `boolean`

---

### isIgnoreRuleFilterPolicy

是否忽略规则上配置的数据筛选条件，仅使用插件设置的定制条件；
 如果不设置这个属性，插件传入的定制条件，会与规则条件，同时起作用

**方法签名：**
```java
public boolean isIgnoreRuleFilterPolicy()
```

**返回值：**
- `boolean`

---

### setCustFilterDesc

设置插件定制条件的说明

**方法签名：**
```java
public void setCustFilterDesc(String custFilterDesc)
```

**参数说明：**
- `custFilterDesc`: `String`

---

### setCustFilterExpression

设置插件定制条件

**方法签名：**
```java
public void setCustFilterExpression(String custFilterExpression)
```

**参数说明：**
- `custFilterExpression`: `String`

---

### setIgnoreRuleFilterPolicy

设置是否忽略规则上配置的数据筛选条件，仅使用插件设置的定制条件

**方法签名：**
```java
public void setIgnoreRuleFilterPolicy(boolean ignoreRuleFilterPolicy)
```

**参数说明：**
- `ignoreRuleFilterPolicy`: `boolean`

---

### setSelectedRows

设置当前规则需要处理的源单行

**方法签名：**
```java
public void setSelectedRows(List<ListSelectedRow> selectedRows)
```

**参数说明：**
- `selectedRows`: `List<ListSelectedRow>` — 当前规则需要处理的源单行

---
