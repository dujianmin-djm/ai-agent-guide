---
framework_version: "8.0.1"
api_class: "AttachmentPanelMapItem"
api_package: "kd.bos.entity.botp"
when_to_use: "当你需要使用附件面板对象时"
---

# AttachmentPanelMapItem API 说明

## 概述
附件面板对象。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.botp.AttachmentPanelMapItem;
```

---

## 方法列表

### getAttachmentPanelMergeType

获取附件面板合并类型标识

**方法签名：**
```java
public String getAttachmentPanelMergeType()
```

**返回值：**
- `String`: 合并类型标识字符串（默认返回"0"）

---

### getId

获取自动生成的唯一标识（主键）
 当id为空时会自动生成16位UUID

**方法签名：**
```java
public String getId()
```

**返回值：**
- `String`: 当前对象的唯一标识符字符串

---

### getIsv

{待补充}

**方法签名：**
```java
public String getIsv()
```

**返回值：**
- `String`

---

### getSeq

获取当前对象的顺序值

**方法签名：**
```java
public int getSeq()
```

**返回值：**
- `int`: 表示顺序的整型数值（通常用于列表排序）

---

### getSourceAttachmentPanel

获取源单附件面板标识

**方法签名：**
```java
public String getSourceAttachmentPanel()
```

**返回值：**
- `String`: 源单据附件面板的关联标识字符串

---

### getTargetAttachmentPanel

获取目标单附件面板标识

**方法签名：**
```java
public String getTargetAttachmentPanel()
```

**返回值：**
- `String`: 目标单据附件面板的关联标识字符串

---

### setAttachmentPanelMergeType

设置附件面板合并类型

**方法签名：**
```java
public void setAttachmentPanelMergeType(String attachmentPanelMergeType)
```

**参数说明：**
- `attachmentPanelMergeType`: `String` — 要设置的合并类型标识字符串

---

### setId

设置唯一标识

**方法签名：**
```java
public void setId(String value)
```

**参数说明：**
- `value`: `String` — 要设置的标识符字符串

---

### setIsv

{待补充}

**方法签名：**
```java
public void setIsv(String isvStr)
```

**参数说明：**
- `isvStr`: `String`

---

### setSeq

设置顺序值

**方法签名：**
```java
public void setSeq(int seq)
```

**参数说明：**
- `seq`: `int` — 要设置的顺序整型数值

---

### setSourceAttachmentPanel

设置源单附件面板标识

**方法签名：**
```java
public void setSourceAttachmentPanel(String sourceAttachmentPanel)
```

**参数说明：**
- `sourceAttachmentPanel`: `String` — 要设置的源单据附件面板标识

---

### setTargetAttachmentPanel

设置目标单附件面板标识

**方法签名：**
```java
public void setTargetAttachmentPanel(String targetAttachmentPanel)
```

**参数说明：**
- `targetAttachmentPanel`: `String` — 要设置的目标单据附件面板标识

---
