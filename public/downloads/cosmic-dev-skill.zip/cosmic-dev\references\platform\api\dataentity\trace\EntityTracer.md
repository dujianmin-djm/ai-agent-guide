---
framework_version: "8.0.1"
api_class: "EntityTracer"
api_package: "kd.bos.dataentity.trace"
when_to_use: "当你需要使用实体运行监控-调用链时"
---

# EntityTracer API 说明

## 概述
实体运行监控-调用链。
主要功能：添加元素、创建对象、读取属性、状态判断。

## Import 路径
```java
import kd.bos.dataentity.trace.EntityTracer;
```

---

## 方法列表

### addLocaleTag

**重载 1**

添加标签，只存在本地，不和云架构调用链对接

**方法签名：**
```java
public static void addLocaleTag(String key, String value)
```

**参数说明：**
- `key`: `String` — 标签名
- `value`: `String` — 标签值

---

**重载 2**

添加标签，只存在本地，不和云架构调用链对接

**方法签名：**
```java
public static void addLocaleTag(String key, Object value)
```

**参数说明：**
- `key`: `String` — 标签名
- `value`: `Object` — 标签值

---

### addTag

添加标签，和云架构调用链对接

**方法签名：**
```java
public static void addTag(String key, String value)
```

**参数说明：**
- `key`: `String` — 标签名
- `value`: `String` — 标签值

---

### close

关闭当前的调用链节点，切换到父节点

**方法签名：**
```java
public static void close()
```

---

### create

**重载 1**

创建调用链节点实例

**方法签名：**
```java
public static EntityTraceSpan create(String type, String name)
```

**参数说明：**
- `type`: `String` — 调用类
- `name`: `String` — 调用方法

**返回值：**
- `EntityTraceSpan`: 调用链节点实例

---

**重载 2**

创建调用链节点实例

**方法签名：**
```java
public static EntityTraceSpan create(String type, String name, EntityTraceHint hint)
```

**参数说明：**
- `type`: `String` — 调用类
- `name`: `String` — 调用方法
- `hint`: `EntityTraceHint` — 配置是否和apm对接的参数

**返回值：**
- `EntityTraceSpan`: 调用链节点实例

---

### error

**重载 1**

捕获到异常，通知监听器进行处理
 
 监听器在收到异常后，实时把当前调用堆栈各个方法执行参数打印出来，以便更好的在线分析问题

**方法签名：**
```java
public static void error(String msg)
```

**参数说明：**
- `msg`: `String` — 异常提示

---

**重载 2**

捕获到异常，通知监听器进行处理
 
 监听器在收到异常后，实时把当前调用堆栈各个方法执行参数打印出来，以便更好的在线分析问题

**方法签名：**
```java
public static void error(Throwable e)
```

**参数说明：**
- `e`: `Throwable` — 异常对象

---

**重载 3**

捕获到异常，通知监听器进行处理
 
 监听器在收到异常后，实时把当前调用堆栈各个方法执行参数打印出来，以便更好的在线分析问题

**方法签名：**
```java
public void error(String msg, Throwable e)
```

**参数说明：**
- `msg`: `String` — 异常提示
- `e`: `Throwable` — 异常对象

---

### getCurrent

获取当前正执行的调用链节点

**方法签名：**
```java
public static EntityTraceSpan getCurrent()
```

**返回值：**
- `EntityTraceSpan`: 调用链节点实例

---

### ignoreException

忽略已捕捉的异常，不向外输出信息
 
 适用于业务代码在try catch捕获异常后，吃掉异常不外抛，也不需要后台输出异常信息

**方法签名：**
```java
public static void ignoreException()
```

---

### isRealtime

是否为实时监听模式：
 
 部分场景，只有在实时监听模式才需要创建调用链节点，上传数据。
 不是实时监听模式则直接跳过，减少性能开销

**方法签名：**
```java
public static boolean isRealtime()
```

**返回值：**
- `boolean`

---

### logEvent

触发事件，通知监听器分析输出的数据

**方法签名：**
```java
public static void logEvent(String event)
```

**参数说明：**
- `event`: `String` — 事件名：由调用代码随意设置，供监听器定位当前事件

---

### throwException

**重载 1**

抛出异常，通知监听器开始收集调用链上下文数据，保护异常现场

**方法签名：**
```java
public static void throwException(String msg)
```

**参数说明：**
- `msg`: `String` — 异常提示

---

**重载 2**

抛出异常，通知监听器开始收集调用链上下文数据，保护异常现场

**方法签名：**
```java
public static void throwException(Throwable e)
```

**参数说明：**
- `e`: `Throwable` — 异常对象

---

**重载 3**

抛出异常，通知监听器开始收集调用链上下文数据，保护异常现场

**方法签名：**
```java
public static void throwException(String msg, Throwable e)
```

**参数说明：**
- `msg`: `String` — 异常提示
- `e`: `Throwable` — 异常对象

---

**重载 4**

抛出异常，通知监听器开始收集调用链上下文数据，保护异常现场

**方法签名：**
```java
public static void throwException(String type, String name, String msg, Throwable e, Map<String,Object> tags)
```

**参数说明：**
- `type`: `String` — 触发异常的类名
- `name`: `String` — 触发异常的方法名
- `msg`: `String` — 异常提示
- `e`: `Throwable` — 异常对象
- `tags`: `Map<String,Object>` — 附加信息数组，每个元素为一条附加信息，包括标识+信息对象

---
