---
framework_version: "8.0.1"
api_class: "MobLocation"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用移动端定位时"
---

# MobLocation API 说明

## 概述
移动端定位。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.MobLocation;
```

---

## 方法列表

### getAddress

地址

**方法签名：**
```java
public String getAddress()
```

**返回值：**
- `String`

---

### getAddressdetail

详细地址

**方法签名：**
```java
public String getAddressdetail()
```

**返回值：**
- `String`

---

### getCity

城市

**方法签名：**
```java
public String getCity()
```

**返回值：**
- `String`

---

### getCityId

获取城市id

**方法签名：**
```java
public String getCityId()
```

**返回值：**
- `String`

---

### getDistrict

区域

**方法签名：**
```java
public String getDistrict()
```

**返回值：**
- `String`

---

### getLatitude

精度

**方法签名：**
```java
public float getLatitude()
```

**返回值：**
- `float`

---

### getLongitude

维度

**方法签名：**
```java
public float getLongitude()
```

**返回值：**
- `float`

---

### getName

名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getProvince

省份

**方法签名：**
```java
public String getProvince()
```

**返回值：**
- `String`

---

### setCityId

设置城市id

**方法签名：**
```java
public void setCityId(String cityId)
```

**参数说明：**
- `cityId`: `String`

---
