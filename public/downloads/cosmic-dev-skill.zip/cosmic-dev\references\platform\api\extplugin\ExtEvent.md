---
framework_version: "8.0.1"
api_class: "ExtEvent"
api_package: "kd.bos.extplugin"
when_to_use: "当你需要使用预置的插件二次扩展事件参数时"
---

# ExtEvent API 说明

## 概述
预置的插件二次扩展事件参数。
主要功能：读取属性。

## Import 路径
```java
import kd.bos.extplugin.ExtEvent;
```

---

## 方法列表

### getEventArg

获取事件参数值

**方法签名：**
```java
public Object getEventArg(String key)
```

**参数说明：**
- `key`: `String` — 指定参数名。事件可能有多个参数值，通过参数名(key)区分

**返回值：**
- `Object`: 返回参数值

---

### getEventName

获取二次扩展事件名，根据事件名区分当前事件

**方法签名：**
```java
public String getEventName()
```

**返回值：**
- `String`

---

### putEventArg

存入事件参数值
 本方法通常由业务插件调用，向二次扩展插件事件传递参数值

**方法签名：**
```java
public void putEventArg(String key, Object eventArg)
```

**参数说明：**
- `key`: `String` — 指定参数名
- `eventArg`: `Object` — 传入参数值

---
