---
framework_version: "8.0.1"
api_class: "AbstractBasedataController"
api_package: "kd.bos.base"
when_to_use: "当你需要使用实现基础资料标准功能时"
---

# AbstractBasedataController API 说明

## 概述
实现基础资料标准功能。
主要功能：添加元素、设置属性。

## Import 路径
```java
import kd.bos.base.AbstractBasedataController;
```

---

## 方法列表

### addFuzzySearchField

{待补充}

**方法签名：**
```java
public void addFuzzySearchField(AddFuzzySearchEvent addFuzzySearchEvent)
```

**参数说明：**
- `addFuzzySearchEvent`: `AddFuzzySearchEvent`

---

### buildBaseDataCoreFilter

{待补充}

**方法签名：**
```java
public void buildBaseDataCoreFilter(BaseDataCustomControllerEvent event)
```

**参数说明：**
- `event`: `BaseDataCustomControllerEvent`

---

### modifyFilterValues

{待补充}

**方法签名：**
```java
public void modifyFilterValues(ModifyFilterValuesControllerEvent event)
```

**参数说明：**
- `event`: `ModifyFilterValuesControllerEvent`

---

### setShowFormCustomParam

{待补充}

**方法签名：**
```java
public void setShowFormCustomParam(SetShowFormCustomParamControllerEvent event)
```

**参数说明：**
- `event`: `SetShowFormCustomParamControllerEvent`

---
