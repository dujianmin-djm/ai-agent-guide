---
framework_version: "8.0.1"
api_class: "CompareTypeValue"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用将字段比较符存下来时"
---

# CompareTypeValue API 说明

## 概述
将字段比较符存下来，传给插件。实现 Serializable, Cloneable。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.entity.filter.CompareTypeValue;
```

---

## 方法列表

### getCompareTypeId

字段比较符

**方法签名：**
```java
public CompareTypeEnum getCompareTypeId()
```

**返回值：**
- `CompareTypeEnum`

---

### getFieldName

字段比较名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`

---

### getValue

字段比较值

**方法签名：**
```java
public Object getValue()
```

**返回值：**
- `Object`

---

### setCompareTypeId

字段比较符

**方法签名：**
```java
public void setCompareTypeId(CompareTypeEnum compareTypeId)
```

**参数说明：**
- `compareTypeId`: `CompareTypeEnum`

---

### setFieldName

设置字段比较名

**方法签名：**
```java
public void setFieldName(String fieldName)
```

**参数说明：**
- `fieldName`: `String`

---

### setValue

字段比较值

**方法签名：**
```java
public void setValue(Object value)
```

**参数说明：**
- `value`: `Object`

---
