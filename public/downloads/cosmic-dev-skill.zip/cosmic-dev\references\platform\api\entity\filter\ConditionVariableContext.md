---
framework_version: "8.0.1"
api_class: "ConditionVariableContext"
api_package: "kd.bos.entity.filter"
when_to_use: "当你需要使用常量解析上下文时"
---

# ConditionVariableContext API 说明

## 概述
常量解析上下文。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.filter.ConditionVariableContext;
```

---

## 方法列表

### getColType

数据库字段值类型：整数、字符等，据此确定是否需要增加单引号

**方法签名：**
```java
public int getColType()
```

**返回值：**
- `int`

---

### getConstantValue

用户录入的比较值

**方法签名：**
```java
public int getConstantValue()
```

**返回值：**
- `int`

---

### getFieldName

ORM字段完整名

**方法签名：**
```java
public String getFieldName()
```

**返回值：**
- `String`

---

### getFilter

输出SQL过滤条件子句

**方法签名：**
```java
public String getFilter()
```

**返回值：**
- `String`

---

### getFilterDesc

输出条件中文描述

**方法签名：**
```java
public String getFilterDesc()
```

**返回值：**
- `String`

---

### getFilterObject

过滤对象：包含了全部过滤行、全部过滤字段等信息

**方法签名：**
```java
public FilterObject getFilterObject()
```

**返回值：**
- `FilterObject`

---

### getFilterRow

当前过滤行

**方法签名：**
```java
public FilterRow getFilterRow()
```

**返回值：**
- `FilterRow`

---

### getInteService

获取时区信息的服务

**方法签名：**
```java
public IInteService getInteService()
```

**返回值：**
- `IInteService`

---

### getMainType

单据主实体

**方法签名：**
```java
public MainEntityType getMainType()
```

**返回值：**
- `MainEntityType`

---

### getOperater

比较符号

**方法签名：**
```java
public String getOperater()
```

**返回值：**
- `String`

---

### getParam

输出变量参数值

**方法签名：**
```java
public List<SqlParameter> getParam()
```

**返回值：**
- `List<SqlParameter>`

---

### getQFilter

输出QFilter条件

**方法签名：**
```java
public QFilter getQFilter()
```

**返回值：**
- `QFilter`

---

### getScript

输出条件表达式脚本

**方法签名：**
```java
public String getScript()
```

**返回值：**
- `String`

---

### getUserService

读取用户信息的服务

**方法签名：**
```java
public IUserService getUserService()
```

**返回值：**
- `IUserService`

---

### isParam

确定生成的条件，是否使用参数对象

**方法签名：**
```java
public boolean isParam()
```

**返回值：**
- `boolean`

---

### setConstantValue

设置用户录入的比较值

**方法签名：**
```java
public void setConstantValue(int constantValue)
```

**参数说明：**
- `constantValue`: `int`

---

### setFilter

设置输出SQL过滤条件子句

**方法签名：**
```java
public void setFilter(String filter)
```

**参数说明：**
- `filter`: `String`

---

### setFilterDesc

设置条件中文描述

**方法签名：**
```java
public void setFilterDesc(String filterDesc)
```

**参数说明：**
- `filterDesc`: `String`

---

### setParam

**重载 1**

设置确定生成的条件，是否使用参数对象

**方法签名：**
```java
public void setParam(boolean isParam)
```

**参数说明：**
- `isParam`: `boolean`

---

**重载 2**

设置变量参数值

**方法签名：**
```java
public void setParam(List<SqlParameter> param)
```

**参数说明：**
- `param`: `List<SqlParameter>`

---

### setQFilter

设置QFilter条件

**方法签名：**
```java
public void setQFilter(QFilter qFilter)
```

**参数说明：**
- `qFilter`: `QFilter`

---

### setScript

设置条件表达式脚本

**方法签名：**
```java
public void setScript(String script)
```

**参数说明：**
- `script`: `String`

---

### setUserService

设置读取用户信息的服务

**方法签名：**
```java
public void setUserService(IUserService userService)
```

**参数说明：**
- `userService`: `IUserService`

---
