---
framework_version: "8.0.1"
api_class: "ArchiveInfo"
api_package: "kd.bos.db.archive"
when_to_use: "当你需要使用归档路由信息时"
---

# ArchiveInfo API 说明

## 概述
归档路由信息。
主要功能：读取属性、设置属性。

## Import 路径
```java
import kd.bos.db.archive.ArchiveInfo;
```

---

## 方法列表

### getDesc

归档路由描述

**方法签名：**
```java
public String getDesc()
```

**返回值：**
- `String`

---

### getKey

归档路由

**方法签名：**
```java
public String getKey()
```

**返回值：**
- `String`

---

### getName

归档路由名称

**方法签名：**
```java
public String getName()
```

**返回值：**
- `String`

---

### getRouteType

归档路由类型

**方法签名：**
```java
public ArchiveRouteType getRouteType()
```

**返回值：**
- `ArchiveRouteType`

---

### setDesc

归档路由描述

**方法签名：**
```java
public void setDesc(String desc)
```

**参数说明：**
- `desc`: `String`

---

### setKey

归档路由

**方法签名：**
```java
public void setKey(String key)
```

**参数说明：**
- `key`: `String`

---

### setName

归档路由名称

**方法签名：**
```java
public void setName(String name)
```

**参数说明：**
- `name`: `String`

---

### setRouteType

归档路由类型

**方法签名：**
```java
public void setRouteType(ArchiveRouteType routeType)
```

**参数说明：**
- `routeType`: `ArchiveRouteType`

---
