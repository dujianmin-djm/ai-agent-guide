---
framework_version: "8.0.1"
api_class: "BadgeInfo"
api_package: "kd.bos.entity"
when_to_use: "当你需要使用徽章信息时"
---

# BadgeInfo API 说明

## 概述
徽章信息。实现 Serializable。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.BadgeInfo;
```

---

## 方法列表

### getBadgeText

获取自定义小圆点的内容

**方法签名：**
```java
public String getBadgeText()
```

**返回值：**
- `String`

---

### getColor

获取自定义小圆点的颜色

**方法签名：**
```java
public String getColor()
```

**返回值：**
- `String`

---

### getCount

获取展示的数字

**方法签名：**
```java
public Integer getCount()
```

**返回值：**
- `Integer`

---

### getOffset

获取设置显示位置，[right，top]

**方法签名：**
```java
public String[] getOffset()
```

**返回值：**
- `String[]`

---

### getOverflowCount

获取数字显示的上限值，默认是99，超过时显示为 99+

**方法签名：**
```java
public Integer getOverflowCount()
```

**返回值：**
- `Integer`

---

### isDot

获取不展示数字，只有一个小红点，默认是false

**方法签名：**
```java
public boolean isDot()
```

**返回值：**
- `boolean`

---

### isShowZero

获取数值为0时，是否显示，默认是false

**方法签名：**
```java
public boolean isShowZero()
```

**返回值：**
- `boolean`

---

### setBadgeText

设置自定义小圆点的内容

**方法签名：**
```java
public void setBadgeText(String badgeText)
```

**参数说明：**
- `badgeText`: `String`

---

### setColor

设置自定义小圆点的颜色

**方法签名：**
```java
public void setColor(String color)
```

**参数说明：**
- `color`: `String`

---

### setCount

设置展示的数字

**方法签名：**
```java
public void setCount(Integer count)
```

**参数说明：**
- `count`: `Integer`

---

### setDot

设置不展示数字，只有一个小红点，默认是false

**方法签名：**
```java
public void setDot(boolean dot)
```

**参数说明：**
- `dot`: `boolean`

---

### setOffset

设置设置显示位置，[right，top]

**方法签名：**
```java
public void setOffset(String[] offset)
```

**参数说明：**
- `offset`: `String[]`

---

### setOverflowCount

设置数字显示的上限值，默认是99，超过时显示为 99+

**方法签名：**
```java
public void setOverflowCount(Integer overflowCount)
```

**参数说明：**
- `overflowCount`: `Integer`

---

### setShowZero

设置数值为0时，是否显示，默认是false

**方法签名：**
```java
public void setShowZero(boolean showZero)
```

**参数说明：**
- `showZero`: `boolean`

---
