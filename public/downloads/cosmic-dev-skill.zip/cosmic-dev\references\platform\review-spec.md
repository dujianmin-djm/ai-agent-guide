# 知识审核规范

> 本规范定义知识库文档的人工审核流程，确保所有文档内容准确、符合苍穹框架正确写法。
> 审核通过后将文档 YAML front matter 中的 `status` 从 `'draft'` 改为 `'approved'`。

## 审核范围

| 目录 | 内容类型 | 文件数量参考 |
|------|---------|-------------|
| `platform/*.md` | 插件开发指南（表单/列表/移动/操作/工作流/调度） | 6 个 |
| `platform/core/` | 核心对象文档（DynamicObject / Model / View 等） | 5 个 |
| `platform/scenes/` | 场景文档（按事件/操作/业务等分类） | 116+ 个 |
| `platform/template/` | 代码模板（Java 插件模板 + 功能规格模板） | 5 个 |


## 通用审核项

以下检查项适用于所有类型的文档：

### 1. 代码片段与语义的匹配性（重点）

> 代码片段必须与文档描述的语义完全一致，不能出现"说的是 A，代码做的是 B"的情况。

- [ ] 代码片段的实际行为与章节标题/说明文字描述的功能一致
- [ ] 方法调用的意图与上下文描述匹配（如描述"设置字段值"，代码确实在调用 `setValue` 而非 `getValue`）
- [ ] 注释内容与代码逻辑一致，无误导性注释
- [ ] 变量命名能反映其语义用途，与文档描述的业务含义对应
- [ ] 代码片段中的条件判断逻辑与文档描述的前置条件/触发条件一致

### 2. 场景的匹配性（重点）

> 文档归属的场景分类必须准确，代码示例必须真正解决该场景下的问题。

- [ ] 文档所在目录（event/operation/business 等）与其实际内容的场景分类一致
- [ ] `scene_name` 准确概括文档内容，不存在名不副实
- [ ] `trigger_event` 与代码中实际覆写的事件方法一致
- [ ] `scene_keywords` 中的关键词能准确反映该场景，不存在误导性关键词
- [ ] 代码示例确实解决了「适用情况」中描述的问题，而非另一个场景的解法
- [ ] 同一场景不存在重复文档（不同文件描述相同场景）

### 3. API 引用正确性

- [ ] 类名全限定路径正确（如 `kd.bos.dataentity.entity.DynamicObject`）
- [ ] 方法签名与框架实际 API 一致（方法名、参数类型、返回值）
- [ ] import 语句完整且无多余引入
- [ ] 无已废弃（deprecated）API 的使用，若使用需标注替代方案

### 4. 代码示例正确性

- [ ] 代码示例可通过编译（无语法错误）
- [ ] 变量类型声明正确（如 `DynamicObjectCollection` 而非 `List`）
- [ ] 强制类型转换合理（如 `getString` / `getInt` / `getBigDecimal` 使用正确）
- [ ] 无空指针风险的写法（如先判空再操作）

### 5. 反例覆盖（重点）

> 文档应包含常见错误写法的反例，帮助开发者避免踩坑。审核时检查是否缺少反例，若缺少应补充。

- [ ] 关键 API 调用是否标注了常见错误用法（如 `❌ 不要这样做` / `✅ 正确做法`）
- [ ] 易混淆的方法是否给出了对比说明（如 `loadSingle` vs `loadSingleFromCache` 的区别与误用）
- [ ] 事件方法中是否标注了不应执行的操作（如 `afterBindData` 中不要调用 `setValue` 触发死循环）
- [ ] 类型转换是否标注了错误示例（如对 `BigDecimal` 字段误用 `getString`）
- [ ] 存在性能陷阱的写法是否给出了反例（如在循环中反复调用 `loadSingle` 查询数据库）
- [ ] 反例的格式统一，使用 `> ❌` 或 `> ⚠️` 前缀与正确示例区分

#### 反例格式参考

```markdown
> ✅ 正确做法
` ` `java
DynamicObjectCollection entries = entity.getDynamicObjectCollection("entryentity");
for (DynamicObject entry : entries) {
    BigDecimal amount = entry.getBigDecimal("amount");
}
` ` `

> ❌ 不要这样做
` ` `java
// 错误：在循环中逐行查询数据库
for (int i = 0; i < rowCount; i++) {
    DynamicObject entry = BusinessDataServiceHelper.loadSingle(id, "entryentity");
}
` ` `
```

### 6. 框架规范一致性

- [ ] 插件继承关系正确（如表单插件继承 `AbstractBillPlugIn` 或 `AbstractFormPlugin`）
- [ ] 事件方法覆写正确（方法名、参数类型与父类一致）
- [ ] 调用 `super.xxx()` 的时机正确
- [ ] 包路径符合 `{isv}.{module}.{分类}` 规范




## 常见问题清单

以下是审核中高频发现的问题类型，审核时重点关注：

| 问题类型 | 示例 |
|---------|------|
| 代码与语义不匹配 | 标题写"设置字段只读"，代码却在做"隐藏字段" |
| 场景归属错误 | 文档放在 `event/` 目录下，但实际内容是操作插件的场景 |
| 关键词误导 | `scene_keywords` 包含"审核"，但文档实际是"提交"场景 |
| 方法不存在 | `AfterOperationArgs.getOperationResult()` 实际不存在 |
| 参数类型错误 | 事件方法参数写成 `EventObject` 但实际应为专用 Args 类 |
| import 路径错误 | `kd.bos.entity.plugin` 写成 `kd.bos.plugin` |
| 废弃 API | 使用已废弃方法但未标注替代方案 |
| 强转类型不匹配 | 对 `BigDecimal` 字段使用 `getString` 获取 |
| 生命周期顺序错误 | 事件调用顺序与实际框架执行顺序不一致 |
| 缺少反例 | 易错 API 只展示正确写法，未标注常见错误用法 |
| 反例不够典型 | 反例过于简单或不是开发者实际会犯的错误 |
