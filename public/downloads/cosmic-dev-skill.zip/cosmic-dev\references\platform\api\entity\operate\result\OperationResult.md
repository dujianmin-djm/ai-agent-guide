---
framework_version: "8.0.1"
api_class: "OperationResult"
api_package: "kd.bos.entity.operate.result"
when_to_use: "当你需要使用操作结果时"
---

# OperationResult API 说明

## 概述
操作结果。继承自 AbstractOperationResult，实现 IInteractionRequest, Serializable, IOperationResult。
主要功能：读取属性、设置属性、状态判断。

## Import 路径
```java
import kd.bos.entity.operate.result.OperationResult;
```

---

## 方法列表

### getAllErrorOrValidateInfo

获取所有操作错误信息

**方法签名：**
```java
public List<kd.IOperateInfo> getAllErrorOrValidateInfo()
```

**返回值：**
- `List<kd.IOperateInfo>`: 操作信息集合

---

### getCustShowFormId

获取操作结果展示表单
 当设置了操作结果提示信息和展示表单，操作完毕，打开该表单显示结果

**方法签名：**
```java
public String getCustShowFormId()
```

**返回值：**
- `String`

---

### getCustomData

自定义信息

**方法签名：**
```java
public Map<String,String> getCustomData()
```

**返回值：**
- `Map<String,String>`

---

### getFinishedTime

获取下推引擎，完成执行时间

**方法签名：**
```java
public Date getFinishedTime()
```

**返回值：**
- `Date`: 完成时间

---

### getInteractionContext

获取本次交互上下文，包含交互提示内容及交互界面参数

**方法签名：**
```java
public InteractionContext getInteractionContext()
```

**返回值：**
- `InteractionContext`

---

### getRunSecond

获取操作运行时间（单位秒）

**方法签名：**
```java
public long getRunSecond()
```

**返回值：**
- `long`: 操作耗时

---

### getSponsor

获取交互请求标识，区分发起请求的来源，各交互请求不重复

**方法签名：**
```java
public String getSponsor()
```

**返回值：**
- `String`

---

### getStartTime

获取操作开始执行时间

**方法签名：**
```java
public Date getStartTime()
```

**返回值：**
- `Date`: 日期

---

### getValidateResult

获取校验结果

**方法签名：**
```java
public ValidateResultCollection getValidateResult()
```

**返回值：**
- `ValidateResultCollection`: 校验结果集

---

### isSuccess

操作是否成功：重写此方法，加上校验结果的判断：如果有校验失败信息，有错误提示信息，均标注操作失败（即没有完全成功）

**方法签名：**
```java
public boolean isSuccess()
```

**返回值：**
- `boolean`

---

### mergeOperateResult

请谨慎使用，该方法侧重合并部分关键信息（successpkid,校验异常信息），提供给页面分批场景使用，其余场景建议自行提取/合并所需的信息

**方法签名：**
```java
public void mergeOperateResult(OperationResult opResult)
```

**参数说明：**
- `opResult`: `OperationResult` — 操作结果

---

### mergeSubOpResult

合并子操作结果至当前操作 （内部使用，支持场景有限，业务场景需自行分析）

**方法签名：**
```java
public void mergeSubOpResult(OperationResult subOpResult)
```

**参数说明：**
- `subOpResult`: `OperationResult` — 子操作结果

---

### setCustShowFormId

设置操作结果展示表单(模态打开)
 当设置了操作结果提示信息和展示表单，操作完毕，打开该表单显示结果
 注意事项：  1. 表单自定义参数通过结果 customData 传递 （FormShowParameter.getCustomParam("customData")）
           2. 该优先级高于交互信息InteractionContext
           3. 设定弹出自定义页面不会执行成功后下一操作（如提交后关闭，保存后提交等），该场景多适用于操作失败自定义反馈场景

**方法签名：**
```java
public void setCustShowFormId(String custShowFormId)
```

**参数说明：**
- `custShowFormId`: `String` — 表单编码

---

### setCustomData

设置自定义信息

**方法签名：**
```java
public void setCustomData(Map<String,String> customData)
```

**参数说明：**
- `customData`: `Map<String,String>` — 自定义信息

---

### setFinishedTime

设置下推引擎，完成执行时间

**方法签名：**
```java
public void setFinishedTime(Date finishedTime)
```

**参数说明：**
- `finishedTime`: `Date` — 完成时间

---

### setInteractionContext

设置本次交互上下文，包含交互提示内容及交互界面参数

**方法签名：**
```java
public void setInteractionContext(InteractionContext interactionContext)
```

**参数说明：**
- `interactionContext`: `InteractionContext` — 交互上下文

---

### setSponsor

设置交互请求标识，区分发起请求的来源，各交互请求不重复

**方法签名：**
```java
public void setSponsor(String sponsor)
```

**参数说明：**
- `sponsor`: `String`

---

### setStartTime

设置操作开始执行时间

**方法签名：**
```java
public void setStartTime(Date startTime)
```

**参数说明：**
- `startTime`: `Date` — 开始时间

---

### setValidateResult

设置校验结果

**方法签名：**
```java
public void setValidateResult(ValidateResultCollection validateResultCollection)
```

**参数说明：**
- `validateResultCollection`: `ValidateResultCollection` — 校验结果集

---

### toString

{待补充}

**方法签名：**
```java
public String toString()
```

**返回值：**
- `String`

---
