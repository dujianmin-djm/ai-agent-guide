---
framework_version: "8.0.1"
api_class: "LocalMemoryCache"
api_package: "kd.bos.cache"
when_to_use: "当你需要使用会话无关本地内存缓存的操作接口时"
---

# LocalMemoryCache API 说明

## 概述
会话无关本地内存缓存的操作接口，定义对缓存数据的增删改查等基础操作。。
主要功能：读取属性、移除元素。

## Import 路径
```java
import kd.bos.cache.LocalMemoryCache;
```

---

## 方法列表

### clear

清空当前缓存实例中的所有数据。
 
 此操作不会移除缓存配置（如超时时间、内存限制），仅删除所有缓存项。

**方法签名：**
```java
public void clear()
```

---

### contains

检查指定键是否存在且未过期。

**方法签名：**
```java
public boolean contains(String key)
```

**参数说明：**
- `key`: `String` — 缓存键

**返回值：**
- `boolean`: 存在且有效返回 ` true`，否则返回 ` false`

---

### get

**重载 1**

获取指定键对应的缓存值。
 
 若键不存在或已过期，返回 ` null`。

**方法签名：**
```java
public Object get(String key)
```

**参数说明：**
- `key`: `String` — 缓存键

**返回值：**
- `Object`: 缓存值，可能为 ` null`

---

**重载 2**

批量获取多个键对应的缓存值。
 
 返回的 Map 仅包含存在的键值对，未找到的键不会出现在结果中。

**方法签名：**
```java
public Map<String,Object> get(String[] keys)
```

**参数说明：**
- `keys`: `String[]` — 一个或多个缓存键

**返回值：**
- `Map<String,Object>`: 存在的键值对映射（不会为 ` null`，但可能为空）

---

### put

存储键值对到缓存中。
 
 若 ` key` 已存在，则旧值将被 ` value` 覆盖，并重置过期时间（取决于实现策略）。

**方法签名：**
```java
public void put(String key, Object value)
```

**参数说明：**
- `key`: `String` — 缓存键，不可为 ` null`，需确保全局唯一性
- `value`: `Object` — 缓存值，不可为 ` null`，支持任意可序列化对象

---

### remove

删除一个或多个缓存项。
 
 若某个键不存在，则静默跳过，不抛出异常。

**方法签名：**
```java
public void remove(String[] keys)
```

**参数说明：**
- `keys`: `String[]` — 要删除的缓存键

---

### removeMapFields

从缓存中的 Map 结构删除指定字段。
 
 此方法要求 ` key` 对应的值必须为 Map 类型，否则行为取决于实现（可能抛出 ClassCastException 或静默失败）。

**方法签名：**
```java
public void removeMapFields(String key, String[] fields)
```

**参数说明：**
- `key`: `String` — 缓存中 Map 结构的键
- `fields`: `String[]` — 要删除的 Map 字段，若为空数组则不执行任何操作

---
