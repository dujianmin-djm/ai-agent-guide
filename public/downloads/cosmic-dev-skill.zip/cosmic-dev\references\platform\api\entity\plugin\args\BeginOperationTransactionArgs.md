---
framework_version: "8.0.1"
api_class: "BeginOperationTransactionArgs"
api_package: "kd.bos.entity.plugin.args"
when_to_use: "当你需要使用操作开启事务后事件参数时"
---

# BeginOperationTransactionArgs API 说明

## 概述
操作开启事务后事件参数。继承自 OperationArgs。
主要功能：设置属性、读取属性、状态判断。

## Import 路径
```java
import kd.bos.entity.plugin.args.BeginOperationTransactionArgs;
```

---

## 方法列表

### getDataEntities

返回校验通过的单据

**方法签名：**
```java
public DynamicObject[] getDataEntities()
```

**返回值：**
- `DynamicObject[]`: 单据数据包

---

### isCancelOperation

返回插件是否要求略过更新数据库逻辑

**方法签名：**
```java
public boolean isCancelOperation()
```

**返回值：**
- `boolean`

---

### setCancelOperation

设置参数，略过更新数据库逻辑
 
 设置为true会跳过标准操作内含的更新数据库逻辑，但操作还是会继续，返回结果也为操作成功（已经更改为操作失败2023/5/23）：
 
 特别说明：这个参数非常容易引起误解，而且因为跳过了数据库更新逻辑，但操作结果成功，出现问题非常难以排查。
 如果需要操作结果返回失败，则需抛出异常强制中断操作，如` throw new KDBizException("异常提示")`

**方法签名：**
```java
public void setCancelOperation(boolean cancelOperation)
```

**参数说明：**
- `cancelOperation`: `boolean` — 传入true，将跳过更新数据库的逻辑，单据不会保存入库，事务会回滚

---

### setDataEntities

设置通过校验的单据

**方法签名：**
```java
public void setDataEntities(DynamicObject[] dataEntities)
```

**参数说明：**
- `dataEntities`: `DynamicObject[]` — 单据数据包

---
